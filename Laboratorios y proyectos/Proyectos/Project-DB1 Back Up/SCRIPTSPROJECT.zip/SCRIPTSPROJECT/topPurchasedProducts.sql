CREATE OR REPLACE PROCEDURE top_purchased_products(pCursorTopPurchased out sys_refcursor)
AS
BEGIN
    OPEN pCursorTopPurchased for
    SELECT description_product,cost_product,total_count
    from (SELECT description_product,cost_product,count(id_product_pa) as total_count from product
          inner join productxauthor
          on productxauthor.id_product_pa = product.id_product 
          group by description_product, cost_product
          order by total_count desc)
    where rownum<=10;
END;