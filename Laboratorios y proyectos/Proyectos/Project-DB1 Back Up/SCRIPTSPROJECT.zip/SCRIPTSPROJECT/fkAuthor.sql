ALTER TABLE author
ADD CONSTRAINT fk_author_idperson FOREIGN KEY (id_person) REFERENCES person (id_person)
ADD CONSTRAINT  fk_author_authorcategory FOREIGN KEY (id_author_cathegory) REFERENCES authorcategory (id_author_category)
