Update photo
SET
route = REPLACE (route,'\\','\');

UPDATE photo
set
route = 'C:\app\JeffreyLeiva\oradata\photosdb\marchafees.jpeg'
WHERE id_article = 0;

UPDATE photo
set route = 'C:\app\JeffreyLeiva\oradata\photosdb\feesUcr.png'
WHERE id_article = 11;

UPDATE photo
set route = 'C:\app\JeffreyLeiva\oradata\photosdb\feesUcr.png'
WHERE id_article = 11;

