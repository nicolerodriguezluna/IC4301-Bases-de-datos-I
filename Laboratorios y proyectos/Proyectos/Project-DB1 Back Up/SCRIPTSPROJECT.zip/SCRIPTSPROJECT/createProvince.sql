CREATE TABLE Province(
    id_province Number(15) CONSTRAINT province_idprovince_nn NOT NULL,
    name_province VARCHAR2(100) CONSTRAINT province_nameprovince_nn NOT NULL,
    id_nation NUMBER (3) CONSTRAINT province_idnation_nn NOT NULL
);