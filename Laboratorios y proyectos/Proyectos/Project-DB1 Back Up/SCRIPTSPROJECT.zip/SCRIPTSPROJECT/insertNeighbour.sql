insert into neighbour
(id_person, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(11,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into neighbour
(id_person, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(12,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



