CREATE TABLE digitalnewspaper
(
    id_digital_newspaper NUMBER(15) CONSTRAINT digitnews_iddigitnews_nn NOT NULL,
    name_digital_newspaper VARCHAR2(30) CONSTRAINT digitnews_namedigitnew_nn NOT NULL,
    id_quad NUMBER(15) CONSTRAINT digitnews_idquad_nn NOT NULL
);