ALTER TABLE favourite
ADD CONSTRAINT fk_favourite_idarticle FOREIGN KEY (id_article_fav) REFERENCES article(id_article)
ADD CONSTRAINT fk_favourite_iduser FOREIGN KEY (id_user_fav) REFERENCES userdb(id_user)
