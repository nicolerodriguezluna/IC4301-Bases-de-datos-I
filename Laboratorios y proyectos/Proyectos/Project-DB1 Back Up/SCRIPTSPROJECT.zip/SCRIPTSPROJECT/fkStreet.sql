ALTER TABLE street
ADD CONSTRAINT fk_street_iddistrict FOREIGN KEY (id_location) REFERENCES district (id_district)
