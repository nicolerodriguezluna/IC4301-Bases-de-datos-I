CREATE TABLE catalog
(
    id_catalog NUMBER(15) CONSTRAINT catalog_idcatalog_nn NOT NULL
)