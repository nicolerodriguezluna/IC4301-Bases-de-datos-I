create or replace FUNCTION get_author_current_points(idAuthor in number) return integer
is
currentPoints number;
BEGIN
    Select a.total-b.exchanged
    into currentPoints
    from (Select sum(stars) as total
          from review
          inner join article
          on review.id_article_rev = article.id_article
          inner join authorxarticle
          on authorxarticle.id_article_autart = article.id_article
          where authorxarticle.id_author_autart = idAuthor)a,
          (SELECT COALESCE(sum(cost_product),0) as exchanged
           from product
           inner join productxauthor
           on productxauthor.id_product_pa = product.id_product
           where productxauthor.id_author_pa = idAuthor)b;
   return (currentPoints);
END;
