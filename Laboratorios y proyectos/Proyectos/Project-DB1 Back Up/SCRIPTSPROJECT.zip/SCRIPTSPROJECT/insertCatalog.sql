INSERT INTO Catalog
(id_catalog,description_catalog,id_newspaper,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_catalog.nextval,'InvierTEC',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO Catalog
(id_catalog,description_catalog,id_newspaper,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_catalog.nextval,'UCR te vende',1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO Catalog
(id_catalog,description_catalog,id_newspaper,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_catalog.nextval,'UNA te vende',2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

