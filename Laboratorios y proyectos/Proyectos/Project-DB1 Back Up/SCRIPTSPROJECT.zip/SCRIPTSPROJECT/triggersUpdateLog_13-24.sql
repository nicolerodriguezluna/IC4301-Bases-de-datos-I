CREATE OR REPLACE trigger beforeUpdateCommitteeDescrp
    before insert or update of description_committe
    on committe
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New description of committee',:old.description_committe, :new.description_committe);
    END beforeUpdateCommitteeDescrp;

CREATE OR REPLACE trigger beforeUpdateDedicationDescrp
    before insert or update of description_dedication
    on dedication
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New description of dedication ',:old.description_dedication, :new.description_dedication);
    END beforeUpdateDedicationDescrp;

CREATE OR REPLACE trigger beforeUpdateNewspaperName
    before insert or update of name_digital_newspaper
    on digitalnewspaper
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New name for Digital Newspaper',:old.name_digital_newspaper, :new.name_digital_newspaper);
    END beforeUpdateNewspaperName;

CREATE OR REPLACE trigger beforeUpdateNewspaperQuad
    before insert or update of id_quad
    on digitalnewspaper
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New quad for Digital Newspaper',:old.id_quad, :new.id_quad);
    END beforeUpdateNewspaperQuad;

CREATE OR REPLACE trigger beforeUpdateDistrictName
    before insert or update of name_district
    on district
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New name of district',:old.name_district, :new.name_district);
    END beforeUpdateDistrictName;

CREATE OR REPLACE trigger beforeUpdateDistrictSector
    before insert or update of id_sector
    on district
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New sector for district',:old.id_sector, :new.id_sector);
    END beforeUpdateDistrictSector;

CREATE OR REPLACE trigger beforeUpdateEmailAdress
    before insert or update of address_email
    on email
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New address email',:old.address_email, :new.address_email);
    END bbeforeUpdateEmailAdress;


CREATE OR REPLACE trigger beforeUpdateFavouriteDate
    before insert or update of date_favourite
    on favourite
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New date of favourite',:old.date_favourite, :new.date_favourite);
    END beforeUpdateFavouriteDate;

CREATE OR REPLACE trigger beforeUpdateGenderType
    before insert or update of type_gender
    on gender
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New gender type',:old.type_gender, :new.type_gender);
    END beforeUpdateGenderType;

CREATE OR REPLACE trigger beforeUpdateLogDBChangeDescrp
    before insert or update of change_descrp
    on logDB
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New change description',:old.change_descrp, :new.change_descrp);
    END beforeUpdateLogDBChangeDescrp;


CREATE OR REPLACE trigger beforeUpdateLogDBPreviousText
    before insert or update of previous_text
    on logDB
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New previous text',:old.previous_text, :new.previous_text);
    END beforeUpdateLogDBPreviousText;

CREATE OR REPLACE trigger beforeUpdateLogDBCurrentText
    before insert or update of current_text
    on logDB
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New current text',:old.current_text, :new.current_text);
    END beforeUpdateLogDBCurrentText;

CREATE OR REPLACE trigger beforeUpdateParameterDBName
    before insert or update of name_parameter
    on parameterDB
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New name of parameter',:old.name_parameter, :new.name_parameter);
    END beforeUpdateParameterDBName;


CREATE OR REPLACE trigger beforeUpdateParameterDBDescrp
    before insert or update of description_parameter
    on parameterDB
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New description of parameter',:old.description_parameter, :new.description_parameter);
    END beforeUpdateParameterDBDescrp;


CREATE OR REPLACE trigger beforeUpdateParameterDBValue
    before insert or update of value_parameter
    on parameterDB
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New value of parameter',:old.value_parameter, :new.value_parameter);
    END beforeUpdateParameterDBValue;

CREATE OR REPLACE trigger beforeUpdateParameterDBRoute
    before insert or update of route
    on parameterDB
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New route of parameter',:old.route, :new.route);
    END beforeUpdateParameterDBRoute;


CREATE OR REPLACE trigger beforeUpdatePersonIdCard
    before insert or update of identification_card
    on person
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New identification card',:old.identification_card, :new.identification_card);
    END beforeUpdatePersonIdCard;


CREATE OR REPLACE trigger beforeUpdatePersonFirstName
    before insert or update of first_name
    on person
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New first name',:old.first_name, :new.first_name);
    END beforeUpdatePersonFirstName;


CREATE OR REPLACE trigger beforeUpdatePersonSecondName
    before insert or update of second_name
    on person
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New second name',:old.second_name, :new.second_name);
    END beforeUpdatePersonSecondName;



CREATE OR REPLACE trigger beforeUpdatePersonFirstSurname
    before insert or update of first_surname
    on person
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New first surname',:old.first_surname, :new.first_surname);
    END beforeUpdatePersonFirstSurname;


CREATE OR REPLACE trigger beforeUpdatePersonSecondSur
    before insert or update of second_surname
    on person
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New second surname',:old.second_surname, :new.second_surname);
    END beforeUpdatePersonSecondSur;

CREATE OR REPLACE trigger beforeUpdatePersonDatebirth
    before insert or update of datebirth
    on person
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New datebirth',:old.datebirth, :new.datebirth);
    END beforeUpdatePersonDatebirth;

CREATE OR REPLACE trigger beforeUpdatePersonQuad
    before insert or update of id_quad
    on person
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New quad',:old.id_quad, :new.id_quad);
    END beforeUpdatePersonQuad;



CREATE OR REPLACE trigger beforeUpdatePersonGender
    before insert or update of id_gender
    on person
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New gender',:old.id_gender, :new.id_gender);
    END beforeUpdatePersonGender;

CREATE OR REPLACE trigger beforeUpdatePersonLocation
    before insert or update of exact_location
    on person
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New exact Localitation',:old.exact_location, :new.exact_location);
    END eforeUpdatePersonLocalitation;

CREATE OR REPLACE trigger beforeUpdatePersonDistrict
    before insert or update of id_district
    on person
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New district',:old.id_district, :new.id_district);
    END beforeUpdatePersonDistrict;
