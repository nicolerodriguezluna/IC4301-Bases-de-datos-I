CREATE TABLE article
(
    id_article NUMBER(15) CONSTRAINT article_idarticle_nn NOT NULL,
    title_article VARCHAR2(100) CONSTRAINT article_titlearticle_nn NOT NULL,
    text_note VARCHAR2(4000) CONSTRAINT article_textnote_nn NOT NULL,
    publication_date DATE CONSTRAINT article_pubDate_nn NOT NULL,
    id_status_article NUMBER(1) CONSTRAINT article_statart_nn NOT NULL,
    id_dig_news NUMBER(15) CONSTRAINT article_idnews_nn NOT NULL,
    id_art_cat NUMBER(15) CONSTRAINT article_idartcat_nn NOT NULL,
    id_committe_art NUMBER(15) CONSTRAINT article_idcommit_nn NOT NULL
);