ALTER TABLE province 
ADD CONSTRAINT fk_province_idCountry FOREIGN KEY (id_nation) REFERENCES country (id_country)
