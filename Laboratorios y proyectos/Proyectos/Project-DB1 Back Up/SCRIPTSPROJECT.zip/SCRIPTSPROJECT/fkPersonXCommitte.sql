ALTER TABLE personxcommitte
add constraint fk_perxcom_idperson foreign key (id_person) references person(id_person)