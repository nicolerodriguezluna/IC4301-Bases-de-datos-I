create table review
(
    id_review NUMBER(15) CONSTRAINT review_idreview_nn NOT NULL,
    description_review VARCHAR2(200) CONSTRAINT review_descrp_nn NOT NULL,
    stars NUMBER(1) CONSTRAINT review_stars_nn NOT NULL,
    id_article_rev NUMBER(15) CONSTRAINT review_artrev_nn NOT NULL,
    id_user_rev NUMBER(15) CONSTRAINT review_iduserre_nn NOT NULL
);