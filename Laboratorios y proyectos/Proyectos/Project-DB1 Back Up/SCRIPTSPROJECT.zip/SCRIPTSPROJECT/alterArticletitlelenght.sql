alter table article
modify title_article VARCHAR2(1000);