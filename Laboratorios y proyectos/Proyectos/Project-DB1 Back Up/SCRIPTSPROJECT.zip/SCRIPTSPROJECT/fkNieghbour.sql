ALTER TABLE neighbour
ADD CONSTRAINT fk_neighbour_idperson FOREIGN KEY (id_person) REFERENCES person (id_person)
