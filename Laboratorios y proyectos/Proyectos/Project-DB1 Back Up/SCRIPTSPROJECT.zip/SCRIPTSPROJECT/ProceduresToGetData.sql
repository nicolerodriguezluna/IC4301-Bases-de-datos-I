CREATE OR REPLACE PROCEDURE get_administratives(pCursorAdministrative out sys_refcursor)
AS
BEGIN
    Open pCursorAdministrative for
    select administrative.id_person,first_name||' '||second_name||' '||first_surname||' '||second_surname as name
    from person
    inner join administrative
    On administrative.id_person = person.id_person
    where person.id_person = administrative.id_person
    ORDER BY(name)desc;
END;

CREATE OR REPLACE PROCEDURE get_administrative(pId in number,pCursorAdministrative out sys_refcursor)
AS
BEGIN
    OPEN pCursorAdministrative for
    select administrative.id_person,first_name||' '||second_name||' '||first_surname||' '||second_surname as name,dedication.description_dedication
    from person
    inner join administrative
    on person.id_person = administrative.id_person
    inner join dedication
    on administrative.id_dedication = dedication.id_dedication
    where administrative.id_person = pId;
END;
    
CREATE OR REPLACE PROCEDURE get_administrators(pCursorAdministrator out sys_refcursor)
AS
BEGIN
    OPEN pCursorAdministrator for
    SELECT administrator.id_person,first_name||' '||second_name||' '||first_surname||' '||second_surname as name
    from administrator
    inner join person
    On person.id_person = administrator.id_person
    where person.id_person = administrator.id_person
    ORDER BY(name)desc;
END;

CREATE OR REPLACE PROCEDURE get_Administrator(pId in Number,pCursorAdministrator out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAdministrator for
    select administrator.id_person,first_name||' '||second_name||' '||first_surname||' '||second_surname as name
    from administrator
    inner join person
    On person.id_person = administrator.id_person
    where person.id_person = pId;
END;

--Get article by author is the same as get authorxarticle

CREATE OR REPLACE PROCEDURE get_article_bydate(pDate in VARCHAR2,pCursorNews out sys_refcursor)
AS
BEGIN
    OPEN pCursorNews for
    select title_article,text_note,publication_date
    from article
    where article.publication_date = TO_DATE(pDate,'YYYY-MM-DD') and id_status_article=0;
END;

CREATE OR REPLACE PROCEDURE get_article_bycategory(pIdCategory in NUMBER, pCursorNews out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorNews for
    select title_article,text_note,publication_date
    from article
    where article.id_art_cat = pIdCategory and id_status_article=0;
END;

CREATE OR REPLACE PROCEDURE get_article_fullsearch(pidAuthor IN number,pArticleCategory IN number,pDate IN VARCHAR2,pCursorNews out SYS_REFCURSOR)
AS
  BEGIN
    OPEN pCursorNews for
    select title_article,text_note,publication_date
    from article
    inner join articlecategory
    on article.id_art_cat = articlecategory.id_article_category
    inner join authorxarticle
    ON authorxarticle.id_article_autart = article.id_article
    where articlecategory.id_article_category = pArticleCategory AND article.publication_date = TO_DATE(pDate,'YYYY-MM-DD') AND authorxarticle.id_author_autart = pidAuthor;
 END;

CREATE OR REPLACE PROCEDURE get_articlecategories(pCursorCategories out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorCategories for
    select id_article_category,name_category
    from articlecategory;
END;

CREATE OR REPLACE PROCEDURE get_articlecategory_descr(pIdCategory in NUMBER,pCursorDescription out sys_refcursor)
AS
BEGIN
    OPEN pCursorDescription for
    SELECT description_category
    from articlecategory
    where id_article_category = pIdCategory;
END;


CREATE OR REPLACE PROCEDURE get_authors(pCursorAuthors out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthors for
    SELECT author.id_person,first_name||' '||second_name||' '||first_surname||' '||second_surname as name
    from author
    inner join person
    on author.id_person = person.id_person
    where author.id_person = person.id_person
    ORDER BY(name)desc;
END;

CREATE OR REPLACE PROCEDURE get_author_categories(pCursorAuthorCategories out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthorCategories for
    SELECT id_author_category,type_category
    from authorcategory;
END;

CREATE OR REPLACE PROCEDURE get_author_bycategory(pIdCategory in NUMBER,pCursorAuthorCategories out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthorCategories for
    SELECT author.id_person,first_name||' '||second_name||' '||first_surname||' '||second_surname as name
    from author
    inner join person
    on person.id_person = author.id_person
    where id_author_cathegory = pIdCategory;
END;

CREATE OR REPLACE PROCEDURE get_authorxarticle(pIdAuthor in NUMBER,pCursorArticle out sys_refcursor)
AS
BEGIN
    OPEN pCursorArticle for
    SELECT title_article,text_note,publication_date
    from article
    inner join authorxarticle
    on article.id_article = authorxarticle.id_article_autart
    where authorxarticle.id_author_autart = pIdAuthor  and id_status_article=0;
END;

CREATE OR REPLACE PROCEDURE get_availability(pCursorAvailability out sys_refcursor)
AS
BEGIN
    OPEN pCursorAvailability for
    SELECT id_availability,description_availability
    from availabilitypr;
END;

CREATE OR REPLACE PROCEDURE get_campusbycollege(pIdCollege in number,pCursorCampus out sys_refcursor)
AS
BEGIN
    OPEN pCursorCampus for
    select id_campus,name_campus
    from campus
    where id_university = pIdcollege;
END;

CREATE OR REPLACE PROCEDURE get_canton(pIdArea in number, pCursorCantons out sys_refcursor)
AS
BEGIN
    OPEN pCursorCantons for
    select id_canton,name_canton
    from canton
    where id_area = pIdArea;
END;

CREATE OR REPLACE PROCEDURE get_catalogs(pidNPaper in number,pCursorCatalogs out sys_refcursor)
as
begin
    open pCursorCatalogs for
    select id_catalog,description_catalog
    from catalog
    where id_newspaper = pidNPaper;
END;

CREATE OR REPLACE PROCEDURE get_colleges(pCursorColleges out sys_refcursor)
AS
BEGIN
    OPEN pCursorColleges for
    select id_college,name_college
    from college;
END;
    


    




    










    









