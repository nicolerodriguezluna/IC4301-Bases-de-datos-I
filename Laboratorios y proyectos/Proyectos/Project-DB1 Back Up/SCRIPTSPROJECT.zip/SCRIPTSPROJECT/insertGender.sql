INSERT INTO GENDER
(id_gender,type_gender, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_gender.nextval,'Femenino',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO GENDER
(id_gender,type_gender, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_gender.nextval,'Masculino',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO GENDER
(id_gender,type_gender, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_gender.nextval,'No definido',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

