ALTER TABLE personxcommitte
add constraint pk_personxcommitte primary key (id_person,id_committe)
USING index
tablespace bdproject_ind PCTFREE 20
STORAGE (INITIAL 10K NEXT 10K PCTINCREASE 0); 
