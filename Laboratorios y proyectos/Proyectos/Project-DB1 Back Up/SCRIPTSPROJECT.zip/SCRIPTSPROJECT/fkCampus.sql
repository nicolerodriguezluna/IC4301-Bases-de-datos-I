ALTER TABLE campus
ADD CONSTRAINT fk_campus_idcollege FOREIGN KEY (id_university) REFERENCES college (id_college)
ADD CONSTRAINT fk_campus_idstreet FOREIGN KEY (id_ubication) REFERENCES street (id_street)
