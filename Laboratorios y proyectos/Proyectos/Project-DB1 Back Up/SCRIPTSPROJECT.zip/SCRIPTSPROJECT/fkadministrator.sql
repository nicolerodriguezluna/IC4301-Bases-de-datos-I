ALTER TABLE administrator
ADD CONSTRAINT fk_administrator_idperson FOREIGN KEY (id_person) REFERENCES person (id_person)
