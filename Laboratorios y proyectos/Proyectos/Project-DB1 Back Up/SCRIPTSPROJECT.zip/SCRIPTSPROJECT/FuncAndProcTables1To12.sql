CREATE OR REPLACE PROCEDURE insert_administrative(pidPerson in NUMBER, pIdDedication in number)
as
BEGIN 
    insert into administrative(id_person,id_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
    values (pidPerson,pIdDedication,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_administrative;

CREATE OR REPLACE PROCEDURE insert_administrator(pidPerson in NUMBER,pvPassword in VARCHAR2)
as
BEGIN 
    insert into administrator(id_person,password_admin,creationdate,userid,lastmodifydate,lastmodifyby)
    values (pidPerson,pvPassword,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_administrator;

CREATE OR REPLACE PROCEDURE insert_article(pvTitle Varchar2,pvText VARCHAR2,pvPublication IN VARCHAR2,pidStatus in NUMBER,
pidNewspaper in NUMBER,pidArticlecategory in NUMBER, pidcommitte in NUMBER)
AS
BEGIN
    insert into article(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art,
    creationdate,userid,lastmodifydate,lastmodifyby)
    VALUES (s_article.nextval,pvTitle,pvText,TO_DATE(pvPublication),pidStatus,pidNewspaper,pidArticlecategory,pidcommitte,
    NULL, NULL, NULL, NULL);
    COMMIT;
END insert_article;

CREATE OR REPLACE PROCEDURE insert_article_category(pvNameCategory IN VARCHAR2,pvDescription IN VARCHAR2)
AS
BEGIN
    insert into articlecategory(id_article_category,name_category,description_category,creationdate,userid,lastmodifydate,lastmodifyby)
    VALUES(s_articlecategory.nextval,pvNameCategory,pvDescription,NULL,NULL,NULL,NULL);
    COMMIT;
END insert_article_category;

CREATE OR REPLACE PROCEDURE insert_author(pidPerson in NUMBER, pidAuthorCategory in Number) AS
BEGIN
    insert into author(id_person,id_author_cathegory,creationdate,userid,lastmodifydate,lastmodifyby)
    VALUES (pidPerson,pidAuthorCategory,NULL,NULL,NULL,NULL);
    COMMIT;
END insert_author;

CREATE OR REPLACE PROCEDURE insert_author_category(pvTypeCategory in VARCHAR2) AS
BEGIN
INSERT INTO AUTHORCATEGORY(id_author_category,type_category,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(s_authorcategory.nextval,pvTypeCategory,NULL,NULL,NULL,NULL);
COMMIT;
END insert_author_category;

CREATE OR REPLACE PROCEDURE insert_authorxarticle(pnidAuthor in NUMBER,pnidArticle in Number)
AS
BEGIN
INSERT INTO authorxarticle(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (pnidAuthor,pnidArticle,NULL,NULL,NULL,NULL);
COMMIT;
END insert_authorxarticle;

CREATE OR REPLACE PROCEDURE insert_availability (pvdescription in VARCHAR2)
AS
BEGIN
INSERT INTO availabilitypr (id_availability,description_availability,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(s_availabilitypr.nextval,pvdescription,NULL,NULL,NULL,NULL);
COMMIT;
END insert_availability;

CREATE OR REPLACE PROCEDURE insert_campus(pvName IN VARCHAR2, pidCollege IN NUMBER,pidDistrict IN NUMBER)
AS
BEGIN
INSERT INTO campus(id_campus,name_campus,id_university,id_district,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(s_campus.nextval,pvName,pidCollege,pidDistrict,NULL,NULL,NULL,NULL);
COMMIT;
END insert_campus;

CREATE OR REPLACE PROCEDURE insert_canton(pvName IN VARCHAR2,pidArea in NUMBER)
AS
BEGIN
INSERT INTO canton(id_canton,name_canton,id_area,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(s_canton.nextval,pvName,pidArea,NULL,NULL,NULL,NULL);
COMMIT;
END  insert_canton;

CREATE OR REPLACE PROCEDURE insert_catalog (pidNewspaper IN NUMBER,pvDescription in VARCHAR2)
AS
BEGIN
INSERT INTO catalog(id_catalog,id_newspaper,description_catalog,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(s_catalog.nextval,pidNewspaper,pvDescription,NULL,NULL,NULL,NULL);
COMMIT;
END  insert_catalog;

CREATE OR REPLACE PROCEDURE insert_college(pvName IN VARCHAR2)
AS
BEGIN
INSERT INTO college(id_college,name_college,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_college.nextval,pvName,NULL,NULL,NULL,NULL);
COMMIT;
END insert_college;

CREATE OR REPLACE PROCEDURE update_administrative(pidDedication in NUMBER,pidPerson IN number)
AS
BEGIN
    update administrative
    set id_dedication = pidDedication
    where pidPerson = administrative.id_person;
    COMMIT;
END update_administrative;

CREATE OR REPLACE PROCEDURE update_administrator(pidPerson in NUMBER,pvnewPass in NUMBER)
AS
BEGIN
    update administrator
    set password_admin = pvnewPass
    where administrator.id_person = pidPerson;
    COMMIT;
END update_administrator;

CREATE OR REPLACE PROCEDURE update_article_title(pvTitle in Varchar2, pidArticle in NUMBER)
AS
BEGIN
    update article
    set title_article = pvTitle
    where article.id_article = pidArticle;
    COMMIT;
END update_article_title;

CREATE OR REPLACE PROCEDURE update_article_note(pvText in VARCHAR2,pidarticle in NUMBER)
AS
BEGIN
    update article
    set text_note = pvText
    where article.id_article = pidarticle;
    COMMIT;
END update_article_note;

CREATE OR REPLACE PROCEDURE update_article_date(pvDate in VARCHAR2,pidarticle in NUMBER)
as
BEGIN
    update article
    set publication_date = TO_DATE(pvDate)
    where article.id_article = pidarticle;
    COMMIT;
END  update_article_date;

CREATE OR REPLACE PROCEDURE update_article_status(pnewStatus in NUMBER,pidarticle in NUMBER)
as
BEGIN
    update article
    set article.id_status_article = pnewStatus
    where article.id_article = pidarticle;
    COMMIT;
END  update_article_status;

CREATE OR REPLACE PROCEDURE update_article_newspaper(pNewNewspaper in NUMBER, pidarticle in NUMBER)
AS
BEGIN
    update article
    set article.id_dig_news = pNewNewspaper
    where article.id_article = pidarticle;
    COMMIT;
END update_article_newspaper;

CREATE OR REPLACE PROCEDURE update_article_category(pnewCategory in number,pidarticle in number)
as
BEGIN
    update article
    set article.id_art_cat = pnewCategory
    where article.id_article = pidarticle;
    COMMIT;
END update_article_category;

CREATE OR REPLACE PROCEDURE update_article_committe(pnewCommitte in number,pidarticle in number)
as
begin
    update article
    set article.id_committe_art = pnewCommitte
    where article.id_article = pidarticle;
    COMMIT;
END update_article_committe;

CREATE OR REPLACE PROCEDURE update_article_category_name(pcName in varchar2, pidcategory in Number)
AS
BEGIN
    update articlecategory
    set name_category = pcName
    where articlecategory.id_article_category = pidcategory;
    COMMIT;
END update_article_category_name;

CREATE OR REPLACE PROCEDURE update_article_cat_descrp(pcDescription in varchar2, pidcategory in number)
as
begin
    update articlecategory
    set articlecategory.description_category = pcDescription
    where articlecategory.id_article_category = pidcategory;
    COMMIT;
END update_article_cat_descrp;

CREATE OR REPLACE PROCEDURE update_author_category(pnewCategory in number, pidperson in number)
AS
begin
    update author
    set author.id_author_cathegory = pnewCategory
    where author.id_person = pidperson;
    COMMIT;
END update_author_category;

CREATE OR REPLACE PROCEDURE update_authorcategory_type(pnewType in VARCHAR2, pidauthorcategory in number)
AS
begin
    update authorcategory
    set authorcategory.type_category = pnewType
    where authorcategory.id_author_category = pidauthorcategory;
    COMMIT;
END update_authorcategory_type;

CREATE OR REPLACE PROCEDURE update_availabilitypr_descrp(pnewDescription in VARCHAR2, pidAvailability in number)
AS
BEGIN
    update availabilitypr
    set availabilitypr.description_availability = pnewDescription
    where availabilitypr.id_availability = pidAvailability;
    COMMIT;
END update_availabilitypr_descrp;

CREATE OR REPLACE PROCEDURE update_campus_name(pName in varchar2,pidcampus in number)
AS
BEGIN
    update campus
    set campus.name_campus = pName
    where campus.id_campus = pidcampus;
    COMMIT;
END  update_campus_name;

CREATE OR REPLACE PROCEDURE update_campus_university(pnewUniversity in NUMBER,pidcampus in NUMBER)
AS
BEGIN
    update campus
    set campus.id_university = pnewUniversity
    where campus.id_campus = pidcampus;
    COMMIT;
END update_campus_university;

CREATE OR REPLACE PROCEDURE update_campus_district(pnewDistrict in number, pidcampus in number)
AS
BEGIN
    update campus
    set campus.id_district = pnewDistrict
    where campus.id_campus = pidcampus;
    COMMIT;
END update_campus_district;

CREATE OR REPLACE PROCEDURE update_canton_name(pnewName in varchar2, pidcanton in NUMBER)
AS
begin
    update canton
    set name_canton = pnewName
    where canton.id_canton = pidcanton;
    COMMIT;
END update_canton_name;

CREATE OR REPLACE PROCEDURE update_canton_area(pnewarea in number, pidcanton in number)
as
begin
    update canton
    set canton.id_area = pnewarea
    where canton.id_canton = pidcanton;
    COMMIT;
END update_canton_area;

CREATE OR REPLACE PROCEDURE update_catalog_newspaper(pnewPaper in number, pidcatalog in number)
as
begin
    update catalog
    set catalog.id_newspaper = pnewPaper
    where catalog.id_catalog = pidcatalog;
    COMMIT;
END update_catalog_newspaper;

CREATE OR REPLACE PROCEDURE update_catalog_description(pnewDescription in VARCHAR2, pidcatalog in number)
as
begin
    update catalog
    set catalog.description_catalog = pnewDescription
    where catalog.id_catalog = pidcatalog;
    COMMIT;
END update_catalog_description;

CREATE OR REPLACE PROCEDURE update_college_name(pnewName in varchar2, pidcollege in number)
AS
BEGIN
    update college 
    set college.name_college = pnewName
    where college.id_college = pidcollege;
    COMMIT;
END update_college_name;



--DELETES
CREATE OR REPLACE PROCEDURE delete_administrative(pidadministrative in number)
as
begin
    delete from administrative
    where administrative.id_person = pidadministrative;
    COMMIT;
END delete_administrative;

CREATE OR REPLACE PROCEDURE delete_administrator(pidadministrator in number)
as
begin
    delete from administrator
    where administrator.id_person = pidadministrator;
    COMMIT;
END delete_administrator;

CREATE OR REPLACE PROCEDURE delete_article(pidarticle in NUMBER)
AS
BEGIN
    delete from article
    where article.id_article = pidarticle;
    COMMIT;
END  delete_article;

CREATE OR REPLACE PROCEDURE delete_articlecategory(pidarticlecategory in number)
as
begin
    delete from articlecategory
    where articlecategory.id_article_category = pidarticlecategory;
    COMMIT;
END delete_articlecategory;

CREATE OR REPLACE PROCEDURE delete_author(pidauthor in number)
as
begin
    delete from author
    where author.id_person = pidauthor;
    commit;
END delete_author;

CREATE OR REPLACE PROCEDURE delete_author_category(pidAuthorcategory in number)
as
begin
    delete from authorcategory
    where authorcategory.id_author_category = pidAuthorcategory;
    commit;
end  delete_author_category;

CREATE OR REPLACE PROCEDURE delete_authorxarticle_author(pidauthor in number)
AS
begin
    delete from authorxarticle
    where authorxarticle.id_author_autart = pidauthor;
    commit;
end delete_authorxarticle_author;

CREATE OR REPLACE PROCEDURE delete_authorxarticle_article(pidarticle in number)
as
begin
    delete from authorxarticle
    where authorxarticle.id_article_autart = pidarticle;
    commit;
end delete_authorxarticle_article;

CREATE OR REPLACE PROCEDURE delete_availability(pidavailability in number)
as
begin
    delete from availabilitypr
    where availabilitypr.id_availability = pidavailability;
    commit;
end delete_availability;

CREATE OR REPLACE PROCEDURE delete_campus(idcampus in number)
as
begin
 delete from campus
 where campus.id_campus = idcampus;
 commit;
end delete_campus;

CREATE OR REPLACE PROCEDURE delete_canton(pidcanton in number)
as
begin
    delete from canton
    where canton.id_canton = pidcanton;
    commit;
end delete_canton;

CREATE OR REPLACE PROCEDURE delete_catalog(pidcatalog in number)
as
begin
    delete from catalog
    where catalog.id_catalog = pidcatalog;
    commit;
end delete_catalog;

CREATE OR REPLACE PROCEDURE delete_college(pidcollege in number)
as
begin
    delete from college
    where college.id_college = pidcollege;
    commit;
end delete_college;


--TRIGGERS
CREATE OR REPLACE TRIGGER before_update_administrative
before insert or update of id_dedication
on administrative
for each row
BEGIN
    INSERT INTO logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'Change of Dedication',(SELECT description_dedication from dedication
    where :old.id_dedication = dedication.id_dedication),(SELECT description_dedication from dedication
    where :new.id_dedication = dedication.id_dedication));
    commit;
END before_update_administrative;

CREATE OR REPLACE TRIGGER before_update_administrator
BEFORE INSERT OR UPDATE OF password_admin
on administrator
for each row
begin 
    INSERT INTO logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'PASSWORD CHANGE',:old.password_admin,:new.password_admin);
    commit;
end before_update_administrator;

CREATE OR REPLACE TRIGGER before_update_article_title
before insert or update of title_article
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'TITLE CHANGE',:old.title_article,:new.title_article);
    commit;
END before_update_article_title;

CREATE OR REPLACE TRIGGER before_update_article_note
before insert or update of text_note
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NOTE CHANGE',:old.text_note,:new.text_note);
    commit;
end before_update_article_note;

CREATE OR REPLACE TRIGGER before_update_article_date
before insert or update of publication_date
on article
for each row
BEGIN
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'PUBLICATION DATE CHANGE',CAST(:old.publication_date as varchar2(1000)),
    cast(:new.publication_date as Varchar2(1000)));
    commit;
end before_update_article_date;
    
CREATE OR REPLACE TRIGGER before_update_article_status
before insert or update of id_status_article
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NEW ARTICLE STATUS',(SELECT name_status from status
    where :old.id_status_article = status.id_status),(SELECT  name_status from status
    where :new.id_status_article = status.id_status));
    commit;
end before_update_article_status;

CREATE OR REPLACE TRIGGER before_update_article_paper
before insert or update of id_dig_news
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NEWSPAPER CHANGED',(SELECT name_digital_newspaper from digitalnewspaper
    where :old.id_dig_news = digitalnewspaper.id_digital_newspaper),(SELECT  name_digital_newspaper from digitalnewspaper
    where :new.id_dig_news = digitalnewspaper.id_digital_newspaper));
    commit;
end before_update_article_paper;

CREATE OR REPLACE TRIGGER before_update_article_category
before insert or update of id_art_cat
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'CATEGORY CHANGED',(SELECT name_category from articlecategory
    where :old.id_art_cat = articlecategory.id_article_category),(SELECT name_category from articlecategory
    where :new.id_art_cat = articlecategory.id_article_category));
    commit;
end before_update_article_category;

CREATE OR REPLACE TRIGGER before_update_article_committe
before insert or update of id_committe_art
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'COMMITTE CHANGED',(SELECT description_committe from committe
    where :old.id_committe_art = committe.id_committe),(SELECT description_committe from committe
    where :new.id_committe_art = committe.id_committe));
    commit;
END before_update_article_committe;

CREATE OR REPLACE TRIGGER before_update_article_cat_name
before insert or update of name_category
on articlecategory
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.name_category,:new.name_category);
    commit;
end before_update_article_cat_name;

CREATE OR REPLACE TRIGGER before_update_artcat_descrp
before insert or update of description_category
on articlecategory
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'DESCRIPTION CHANGED',:old.description_category,:new.description_category);
    commit;
END before_update_artcat_descrp;

CREATE OR REPLACE TRIGGER before_update_author_category
before insert or update of id_author_cathegory
on author
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'CATEGORY CHANGED',(SELECT type_category from authorcategory
    where :old.id_author_cathegory = authorcategory.id_author_category),(SELECT type_category from authorcategory
    where :new.id_author_cathegory = authorcategory.id_author_category));
    commit;
END before_update_author_category;

CREATE OR REPLACE TRIGGER before_update_authorcat_type
before insert or update of type_category
on authorcategory
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'TYPE CHANGED',:old.type_category,:new.type_category);
    commit;
END  before_update_authorcat_type;

CREATE OR REPLACE TRIGGER before_update_available_descrp
before insert or update of description_availability
on availabilitypr
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'AVAILABILITY DESCR CAHNGED',:old.description_availability,
    :new.description_availability);
    commit;
end  before_update_available_descrp;

CREATE OR REPLACE TRIGGER before_update_campus_name
before insert or update of name_campus
on campus
for each row
begin
     insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.name_campus,
    :new.name_campus);
    commit;
end before_update_campus_name;

CREATE OR REPLACE TRIGGER before_update_campus_uni
before insert or update of id_university
on campus
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'COLLEGE CHANGED',(SELECT name_college from college
    where :old.id_university = college.id_college),(SELECT name_college from college
    where :new.id_university = college.id_college));
    commit;
END before_update_campus_uni;

CREATE OR REPLACE TRIGGER before_update_campus_district
before insert or update of id_district
on campus
for each row
begin
     insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'DISTRICT CHANGED',(SELECT name_district from district
    where :old.id_district = district.id_district),(SELECT name_district from district
    where :new.id_district = district.id_district));
    commit;
end  before_update_campus_district;

CREATE OR REPLACE TRIGGER before_update_canton_name
before insert or update of name_canton
on canton
for each row
begin
    insert into logdb (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.name_canton,
    :new.name_canton);
    commit;
end before_update_canton_name;

CREATE OR REPLACE TRIGGER before_update_canton_area
before insert or update of id_area
on canton
for each row
begin
 insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'AREA CHANGED',(SELECT name_province from province
    where :old.id_area = province.id_province),(SELECT name_province from province
    where :new.id_area = province.id_province));
    commit;
end before_update_canton_area;
    
CREATE OR REPLACE TRIGGER before_update_catalog_news
before insert or update of id_newspaper
on catalog
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NEWSPAPER CHANGED',(SELECT name_digital_newspaper from digitalnewspaper
    where :old.id_newspaper = digitalnewspaper.id_digital_newspaper),(SELECT name_digital_newspaper from digitalnewspaper
    where :new.id_newspaper = digitalnewspaper.id_digital_newspaper));
    commit;
end before_update_catalog_news;

CREATE OR REPLACE TRIGGER before_up_catalog_descr
before insert or update of description_catalog
on catalog
for each row
begin
    insert into logdb (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.description_catalog,
    :new.description_catalog);
    commit;
end before_up_catalog_descr;

CREATE OR REPLACE TRIGGER before_update_college_name
before insert or update of name_college
on college
for each row
begin
    insert into logdb (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.name_college,
    :new.name_college);
    commit;
END  before_update_college_name ;

CREATE OR REPLACE Function get_administrative_name(pnAdministrative in NUMBER) return VARCHAR2
IS
    pName VARCHAR2(1000);
BEGIN
    select first_name||' '||second_name||' '||first_surname||' '||second_surname
    into pName
    from person
    where pnAdministrative = person.id_person;
    return (pName);
END;

CREATE OR REPLACE FUNCTION get_administrative_dedication(pnAdministrative in Number) return VARCHAR2
IS
    pDedication VARCHAR(100);
BEGIN
    SELECT description_dedication 
    into pDedication
    from dedication
    inner join administrative
    On administrative.id_dedication = dedication.id_dedication
    where pnAdministrative = administrative.id_person;
    return pDedication;
END;

CREATE OR REPLACE FUNCTION get_administrator_name(pnAdmin in NUMBER) return VARCHAR2
IS
    pName VARCHAR2(1000);
BEGIN
    select first_name||' '||second_name||' '||first_surname||' '||second_surname
    into pName
    from person
    where pnAdmin = person.id_person;
    return (pName);
END;

CREATE OR REPLACE FUNCTION get_administrator_password(pnAdmin in Number) return VARCHAR2
IS
    pvPassword VARCHAR2(1000);
BEGIN 
    select password_admin
    into pvPassword
    from administrator
    where pnAdmin = administrator.id_person;
    return pvPassword;
    EXCEPTION
        when no_data_found then
            dbms_output.put_line('Administrator Not Found');
END;

CREATE OR REPLACE PROCEDURE get_articles_names (pcArticleCursor out SYS_REFCURSOR)
AS
BEGIN
 OPEN pcArticleCursor for
 SELECT title_article
 from article;
END;

    
    
    

    
    
    
    





    
    
    

    

    

    














    