CREATE TABLE person(
    id_person number(15) CONSTRAINT person_idperson_nn NOT NULL,
    identification_card NUMBER(9)CONSTRAINT person_identificationcard_nn NOT NULL,
    first_name VARCHAR2(30) CONSTRAINT person_firstname_nn NOT NULL,
    second_name VARCHAR2(30),
    first_surname VARCHAR2(30) CONSTRAINT person_firstsurname_nn NOT NULL,
    second_surname VARCHAR2(30) CONSTRAINT person_secondname_nn NOT NULL,
    datebirth DATE CONSTRAINT person_datebirth_nn NOT NULL,
    id_quad NUMBER(15) CONSTRAINT person_idquad_nn NOT NULL,
    id_council NUMBER(15),
    type_gender VARCHAR2(20) CONSTRAINT person_typegender_nn NOT NULL,
    id_direction NUMBER(15) CONSTRAINT person_iddirection_nn NOT NULL
);