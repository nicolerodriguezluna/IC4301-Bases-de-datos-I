CREATE TABLE product
(
    id_product NUMBER(15) CONSTRAINT product_idproduct_nn NOT NULL,
    cost_product NUMBER(7) CONSTRAINT product_costproduct_nn NOT NULL,
    description_product VARCHAR2(100) CONSTRAINT product_descrp_nn NOT NULL,
    id_catalog_pr NUMBER(15) CONSTRAINT product_idcatalog_nn NOT NULL,
    id_availability NUMBER(15) CONSTRAINT product_availability_nn NOT NULL
);