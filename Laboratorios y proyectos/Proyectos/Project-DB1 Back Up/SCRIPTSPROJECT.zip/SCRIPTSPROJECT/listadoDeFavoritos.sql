CREATE OR REPLACE PROCEDURE get_user_favourites(pIdUser IN NUMBER, pCursorFavourite OUT SYS_REFCURSOR)
AS
  BEGIN
    OPEN pCursorFavourite for
    SELECT title_article,publication_date
    from article
    inner join favourite
    ON article.id_article = favourite.id_article_fav
    inner join userdb
    ON userdb.id_person =  favourite.id_user_fav
    where userdb.id_person = pIdUser;
  END;
