CREATE TABLE CAMPUS(
    id_campus NUMBER(15) CONSTRAINT campus_idcampus_nn NOT NULL,
    name_campus NUMBER(15) CONSTRAINT campus_campusname_nn NOT NULL,
    id_university NUMBER(15) CONSTRAINT campus_iduniversity_nn NOT NULL
);