CREATE OR REPLACE PROCEDURE delete_committee(pidCommittee IN NUMBER) AS
BEGIN
    DELETE FROM committe
    WHERE committe.id_committe = pidCommittee;
    COMMIT;
END delete_committee;

CREATE OR REPLACE PROCEDURE delete_country(pidCountry IN NUMBER) AS
BEGIN
    DELETE FROM country
    WHERE country.id_country = pidCountry;
    COMMIT;
END delete_country;

CREATE OR REPLACE PROCEDURE delete_dedication(pidDedication IN NUMBER) AS
BEGIN
    DELETE FROM dedication
    WHERE dedication.id_dedication = pidDedication;
    COMMIT;
END delete_dedication;

CREATE OR REPLACE PROCEDURE delete_digital_newspaper(pidDigitalNewspaper IN NUMBER) AS
BEGIN
    DELETE FROM digitalnewspaper
    WHERE digitalnewspaper.id_digital_newspaper = pidDigitalNewspaper;
    COMMIT;
END delete_digital_newspaper;

CREATE OR REPLACE PROCEDURE delete_district(pidDistrict IN NUMBER) AS
BEGIN
    DELETE FROM district
    WHERE district.id_district = pidDistrict;
    COMMIT;
END delete_district;

CREATE OR REPLACE PROCEDURE delete_email(pidEmail IN NUMBER) AS
BEGIN
    DELETE FROM email
    WHERE email.id_email = pidEmail;
    COMMIT;
END delete_email;


CREATE OR REPLACE PROCEDURE delete_favourite(pidArtRev IN NUMBER, pidUserRev IN NUMBER) AS
BEGIN
    DELETE FROM favourite
    WHERE favourite.id_user_fav = pidUserRev AND favourite.id_article_fav = pidArtRev;
    COMMIT;
END delete_favourite;

CREATE OR REPLACE PROCEDURE delete_gender(pidGender IN NUMBER) AS
BEGIN
    DELETE FROM gender
    WHERE gender.id_gender = pidGender;
    COMMIT;
END delete_gender;

CREATE OR REPLACE PROCEDURE delete_logDB(pidLogDB IN NUMBER) AS
BEGIN
    DELETE FROM logDB
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END delete_logDB;

CREATE OR REPLACE PROCEDURE delete_neighbour(pidNeighbour IN NUMBER) AS
BEGIN
    DELETE FROM neighbour
    WHERE neighbour.id_person = pidNeighbour;
    COMMIT;
END delete_neighbour;

CREATE OR REPLACE PROCEDURE delete_parameterDb(pidParameterDb IN NUMBER) AS
BEGIN
    DELETE FROM parameterDB
    WHERE parameterDb.id_parameter = pidParameterDb;
    COMMIT;
END delete_parameterDb;

CREATE OR REPLACE PROCEDURE delete_person(pidPerson IN NUMBER) AS
BEGIN
    DELETE FROM person
    WHERE person.id_person = pidPerson;
    COMMIT;
END delete_person;


--1
create or replace PROCEDURE insert_committee(pnameCommittee IN VARCHAR2) AS
BEGIN
    INSERT INTO committe(id_committe, description_committe, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_committe.nextval, pnameCommittee, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_committee;
--2
create or replace PROCEDURE insert_country(pnameCountry IN VARCHAR2) AS
BEGIN
    INSERT INTO country(id_country, name_country, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_country.nextval, pnameCountry, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_country;
--3
CREATE OR REPLACE PROCEDURE insert_dedication(pdescriptionDedication IN VARCHAR2) AS
BEGIN
    INSERT INTO dedication(id_dedication, description_dedication, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_dedication.nextval, pdescriptionDedication, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_dedication;
--4
CREATE OR REPLACE PROCEDURE insert_digital_newspaper(pname_digital_newspaper IN VARCHAR2, pidQuad IN NUMBER) AS
BEGIN
    INSERT INTO digitalNewspaper(id_digital_newspaper, name_digital_newspaper, id_quad,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_digitalNewspaper.nextval, pname_digital_newspaper, pidQuad, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_digital_newspaper;
--5
CREATE OR REPLACE PROCEDURE insert_district(pnameDistrict IN VARCHAR2, pidSector IN NUMBER) AS
BEGIN
    INSERT INTO district(id_district, name_district, id_sector, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_district.nextval, pnameDistrict, pidSector ,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_district; 
--6
CREATE OR REPLACE PROCEDURE insert_email(pAdressEmail IN VARCHAR2, pidPerson in NUMBER) AS
BEGIN
    INSERT INTO email(id_email, address_email, id_person_mail, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_email.nextval, pAdressEmail, pidPerson, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_email; 
--7
CREATE OR REPLACE PROCEDURE insert_favourite(pidArticleFav IN NUMBER, pidUserFav IN NUMBER, pDateFavourite IN VARCHAR2) AS
BEGIN
    INSERT INTO favourite(id_article_fav,id_user_fav,date_favourite, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidArticleFav, pidUserFav, pDateFavourite, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_favourite; 
--8
CREATE OR REPLACE PROCEDURE insert_gender(pTypeGender IN VARCHAR2) AS
BEGIN
    INSERT INTO gender(id_gender, type_gender,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_gender.nextval, pTypeGender,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_gender; 
--9
CREATE OR REPLACE PROCEDURE insert_logDB(pChangeDescription in VARCHAR2, pPreviousText in VARCHAR2, pCurrentText in VARCHAR2) AS
BEGIN
    INSERT INTO logdb(id_log,systemdate, time_log, change_descrp, previous_text,current_text,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, pChangeDescription, pPreviousText, pCurrentText,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_logDB; 
--10
CREATE OR REPLACE PROCEDURE insert_neighbour(pidPerson IN NUMBER) AS
BEGIN
    INSERT INTO neighbour(id_person,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidPerson,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_neighbour; 
--11
CREATE OR REPLACE PROCEDURE insert_ParameterDb(pnameParameter IN VARCHAR2,pdescriptionParameter IN VARCHAR2,pvalueParameter IN NUMBER, proute IN VARCHAR2) AS
BEGIN
    INSERT INTO ParameterDb(id_Parameter,name_parameter, description_parameter, value_parameter, route,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_parameter.nextval, pnameParameter, pdescriptionParameter, pvalueParameter, proute, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_ParameterDb; 
--12
CREATE OR REPLACE PROCEDURE insert_person(pidentifyCard IN NUMBER, pfirstName IN VARCHAR2,psecondName IN VARCHAR2, pfirstSurname IN VARCHAR2, psecondSurname IN VARCHAR2, pdatebirth IN VARCHAR2, pidQuad IN NUMBER, pidGender IN NUMBER, pexactLocalitation in VARCHAR2, pidDistrict in NUMBER) AS
BEGIN
    INSERT INTO person(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
    VALUES(s_person.nextval, pidentifyCard, pfirstName,psecondName, pfirstSurname, psecondSurname, pdatebirth, pidQuad, pidGender, pexactLocalitation, pidDistrict, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_person; 

CREATE OR REPLACE PROCEDURE update_committee_description(pidCommittee IN NUMBER, pNewDescriptionCommittee IN VARCHAR2) AS
BEGIN
    UPDATE committe
    SET committe.description_committe = pNewDescriptionCommittee
    WHERE committe.id_committe= pidCommittee;
    COMMIT;
END update_committee_description;

CREATE OR REPLACE PROCEDURE update_country_name(pidCountry IN NUMBER, pNewNameCountry IN NUMBER) AS
BEGIN
    UPDATE country
    SET country.name_country = pNewNameCountry
    WHERE country.id_country = pidCountry;
    COMMIT;
END update_country_name;

CREATE OR REPLACE PROCEDURE update_dedication_description(pidDedication  IN NUMBER, pNewDescriptionDadication IN VARCHAR2) AS
BEGIN
    UPDATE dedication
    SET dedication.description_dedication = pNewDescriptionDadication
    WHERE dedication.id_dedication = pidDedication;
    COMMIT;
END update_dedication_description;

CREATE OR REPLACE PROCEDURE update_digitalNewspaper_name(pidDigitalNewspaper IN NUMBER, pNewNameDigital IN VARCHAR2) AS
BEGIN
    UPDATE digitalnewspaper
    SET digitalnewspaper.name_digital_newspaper = pNewNameDigital
    WHERE digitalnewspaper.id_digital_newspaper = pidDigitalNewspaper;
    COMMIT;
END update_digitalNewspaper_name;

CREATE OR REPLACE PROCEDURE update_digitalNewspaper_quad(pidDigitalNewspaper IN NUMBER, pNewIdQuad IN NUMBER) AS
BEGIN
    UPDATE digitalnewspaper
    SET digitalnewspaper.id_quad = pNewIdQuad
    WHERE digitalnewspaper.id_digital_newspaper = pidDigitalNewspaper;
    COMMIT;
END update_digitalNewspaper_quad;


CREATE OR REPLACE PROCEDURE update_district_name(pidDistrict IN NUMBER, pNewNameDistrict IN VARCHAR2) AS
BEGIN
    UPDATE district
    SET district.name_district = pNewNameDistrict
    WHERE district.id_district = pidDistrict;
    COMMIT;
END update_district_name;

CREATE OR REPLACE PROCEDURE update_district_sector(pidDistrict IN NUMBER, pNewIdSector IN NUMBER) AS
BEGIN
    UPDATE district
    SET district.id_sector = pNewIdSector
    WHERE district.id_sector = pidDistrict;
    COMMIT;
END update_district_name;


CREATE OR REPLACE PROCEDURE update_email_address(pidEmail IN NUMBER, pNewAddress IN VARCHAR2) AS
BEGIN
    UPDATE email
    SET email.address_email = pNewAddress
    WHERE email.id_email = pidEmail;
    COMMIT;
END update_email_address;

CREATE OR REPLACE PROCEDURE update_favourite_date_favourite(pidArtRev IN NUMBER, pidUserRev IN NUMBER, pNewDateFavourite IN VARCHAR2) AS
BEGIN
    UPDATE favourite
    SET favourite.date_favourite = To_date(pNewDateFavourite,'YY-MM-DD')
    WHERE favourite.id_user_fav = pidUserRev AND favourite.id_article_fav = pidArtRev;
    COMMIT;
END update_favourite_date_favourite;

CREATE OR REPLACE PROCEDURE update_gender_type_gender(pidGender IN NUMBER, pNewTypeGender IN VARCHAR2) AS
BEGIN
    UPDATE gender
    SET gender.type_gender = pNewTypeGender
    WHERE gender.id_gender = pidGender;
    COMMIT;
END update_gender_type_gender;

CREATE OR REPLACE PROCEDURE update_logDB_change_descp(pidLogDB IN NUMBER, pNewChangeDescription IN VARCHAR2) AS
BEGIN
    UPDATE logDB
    SET logDB.change_descrp = pNewChangeDescription
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END update_logDB_change_descp;

CREATE OR REPLACE PROCEDURE update_logDB_previous_text(pidLogDB IN NUMBER, pNewPreviousText IN VARCHAR2) AS
BEGIN
    UPDATE logDB
    SET logDB.previous_text = pNewPreviousText
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END update_logDB_previous_text;

CREATE OR REPLACE PROCEDURE update_logDB_current_text(pidLogDB IN NUMBER, pNewCurrentText IN VARCHAR2) AS
BEGIN
    UPDATE logDB
    SET logDB.current_text = pNewCurrentText
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END update_logDB_current_text;

CREATE OR REPLACE PROCEDURE update_parameter_name(pidParameter IN NUMBER, pNewNameParameter IN VARCHAR2) AS
BEGIN
    UPDATE parameterDB
    SET parameterDB.name_parameter = pNewNameParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_name;

CREATE OR REPLACE PROCEDURE update_parameter_description(pidParameter IN NUMBER, pNewDescriptionParameter IN VARCHAR2) AS
BEGIN
    UPDATE parameterDB
    SET parameterDB.description_parameter = pNewDescriptionParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_description;

CREATE OR REPLACE PROCEDURE update_parameter_value(pidParameter IN NUMBER, pNewValueParameter IN NUMBER) AS
BEGIN
    UPDATE parameterDB
    SET parameterDB.value_parameter = pNewValueParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_value;

CREATE OR REPLACE PROCEDURE update_parameter_route(pidParameter IN NUMBER, pNewRoute IN VARCHAR2) AS
BEGIN
    UPDATE parameterDB
    SET parameterDB.route = pNewRoute
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_route;


CREATE OR REPLACE PROCEDURE update_person_identitycard(pidPerson IN NUMBER, pNewIdentificationCard IN NUMBER) AS
BEGIN
    UPDATE person
    SET person.identification_card = pNewIdentificationCard
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_identitycard;


CREATE OR REPLACE PROCEDURE update_person_first_name(pidPerson IN NUMBER, pNewFirstName IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.first_name = pNewFirstName
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_first_name;

CREATE OR REPLACE PROCEDURE update_person_second_name(pidPerson IN NUMBER, pNewSecondName IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.second_name  = pNewSecondName
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_second_name;

CREATE OR REPLACE PROCEDURE update_person_first_surname(pidPerson IN NUMBER, pNewFirstSurname IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.first_surname = pNewFirstSurname
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_first_surname;


CREATE OR REPLACE PROCEDURE update_person_second_surname(pidPerson IN NUMBER, pNewSecondSurname IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.second_surname = pNewSecondSurname
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_second_surname;

CREATE OR REPLACE PROCEDURE update_person_datebirth(pidPerson IN NUMBER, pNewDatebirth IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.datebirth = to_date(pNewDatebirth,'YY-MM-DD')
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_datebirth;


CREATE OR REPLACE PROCEDURE update_person_quad(pidPerson IN NUMBER, pNewIdQuad IN NUMBER) AS
BEGIN
    UPDATE person
    SET person.id_quad = pNewIdQuad
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_quad;

CREATE OR REPLACE PROCEDURE update_person_gender(pidPerson IN NUMBER, pNewIdGender IN NUMBER) AS
BEGIN
    UPDATE person
    SET person.id_gender = pNewIdGender
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_gender;

CREATE OR REPLACE PROCEDURE update_person_localitation(pidPerson IN NUMBER, pNewExactLocalitation IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.exact_location = pNewExactLocalitation
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_localitation;

CREATE OR REPLACE PROCEDURE update_person_district(pidPerson IN NUMBER, pNewIdDistrict IN NUMBER) AS
BEGIN
    UPDATE person
    SET person.id_district = pNewIdDistrict
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_district;