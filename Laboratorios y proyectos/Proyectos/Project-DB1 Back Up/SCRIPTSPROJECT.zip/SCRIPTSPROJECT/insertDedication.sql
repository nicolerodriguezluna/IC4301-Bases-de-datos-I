INSERT INTO dedication
(id_dedication,description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_dedication.nextval,'Docente',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO dedication
(id_dedication,description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_dedication.nextval,'Director',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO dedication
(id_dedication,description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_dedication.nextval,'Coordinador',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO dedication
(id_dedication,description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_dedication.nextval,'Secretariado',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO dedication
(id_dedication,description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_dedication.nextval,'Receptionista',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO dedication
(id_dedication,description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_dedication.nextval,'Tesorer�a',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO dedication
(id_dedication,description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_dedication.nextval,'Investigador',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



