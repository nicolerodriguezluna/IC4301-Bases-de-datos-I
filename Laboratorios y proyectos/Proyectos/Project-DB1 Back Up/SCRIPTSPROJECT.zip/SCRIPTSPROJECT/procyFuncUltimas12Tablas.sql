/*Get person x committe recieves an id person to return the commite with that id, if not send an id 
will return all data.
Returns:
- id person
- id committe
*/
--Already in Java
CREATE OR REPLACE PROCEDURE get_people_bycommittee(pIdCommittee IN NUMBER, pCursorPerXCom OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorPerXCom for
    SELECT  person.id_person,first_name,second_name,first_surname,
    second_surname,identification_card,datebirth, id_quad, id_gender, exact_location, id_district
    FROM person
    inner join personxcommitte pxc
    On person.id_person = pxc.id_person
    WHERE pxc.id_committe = pIdCommittee
    order by(first_name);
END;

--Returns personxcommitte
CREATE OR REPLACE PROCEDURE get_personxcommitte(pCursorPerXCom OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorPerXCom for
    SELECT id_person,id_committe
    from personxcommitte;
END;

--Already in java
CREATE OR REPLACE PROCEDURE get_all_phones(pCursorPhones out sys_refcursor)
AS
BEGIN
    OPEN pCursorPhones for
    select id_phone,number_phone,id_person,id_phone_category
    from phone;
END;

--Already in java
--Returns cursor with all phones of a person.
CREATE OR REPLACE PROCEDURE get_person_phones(pidPerson in number,pCursorPhones out sys_refcursor)
AS
BEGIN
    OPEN pCursorPhones for
    select id_phone,number_phone,id_person,id_phone_category
    from phone
    where id_person =pidPerson;
END;

/*Get phone recieves an id to return the phone with that id, if not send an id 
will return all phones.
Returns:
- id phone
- id from the person
- number phone
- description of the category phone
*/
--Gets specific phone
CREATE OR REPLACE PROCEDURE get_phone(pId IN NUMBER, pCursorPhone OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorPhone for
    SELECT p.id_phone, id_person ,p.number_phone, ph.description_category
    FROM phone p
    INNER JOIN phonecategory ph
    ON p.id_phone_category = ph.id_category
    WHERE p.id_phone = pId;
END;

/*Get phonecategory recieves an id to return the phonecategory with that id, if not send an id 
will return all phonecategories.
Returns:
- id phonecategory
- name category
*/
--Already in Java
--Returns cursor with specific phone category
CREATE OR REPLACE PROCEDURE get_phonecategory(pId IN NUMBER, pCursorCategory OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorCategory for
    SELECT p.id_category, p.description_category
    FROM phonecategory p
    WHERE p.id_category = pId;
END;

--Get all categories
--Already in java
CREATE OR REPLACE PROCEDURE get_phonecategories(pCursorCategory OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorCategory for
    SELECT p.id_category, p.description_category
    FROM phonecategory p;
END;

/*Get photos from the articles, recieves an id to return the photo for a specific article with that id, if not sent an id 
will return all photos from articles.
Returns:
- id photo
- id article
- route from the photo 
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_photo_article(pId IN NUMBER, pCursorArticle OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorArticle for
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo p
    WHERE p.id_article = pId;
END;


--Returns all the photos
--Already in java
CREATE OR REPLACE PROCEDURE get_photos(pCursorArticle OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorArticle for
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo p;
END;


/*Get photos from the product, recieves an id to return the photo for a specific product with that id, if not send an id 
will return all product photos.
Returns:
- id photo
- id product
- route from the photo 
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_photo_product(pId IN NUMBER, pCursorPhoto OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorPhoto for
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo p
    WHERE p.id_product = pId;
END;

/*Get photos from the user, recieves an id to return the photo for a specific user with that id, if not send an id 
will return all photos from user.
Returns:
- id photo
- id user
- route from the photo 
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_photo_user(pId IN NUMBER, pCursorPhoto OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorPhoto for
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo p
    WHERE p.id_user = pId;
END;


/*Get products, recieves an id to return the product with that id, if not sent an id 
will return all products.
Returns:
- id product
- cost product
- description product 
- id catalog pr
_ id availabilty
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_product(pId IN NUMBER, pCursorProduct OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProduct for
    SELECT id_product, cost_product, description_product,
    id_catalog_pr, id_availability
    FROM product 
    WHERE id_product = pId;
END;

--Gets all the products
CREATE OR REPLACE PROCEDURE get_products(pCursorProduct OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProduct for
    SELECT id_product, cost_product, description_product,
    id_catalog_pr, id_availability
    FROM product
    order by(cost_product) desc;
END;

/*Get products x authors, can recieves an id product or id author to return the products with that id, if not sent an id 
will return all products.
Returns:
- id product
- id author
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_productxauthor(pIdProduct IN NUMBER, pIdAuthor IN NUMBER, pCursorProXAut OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProXAut for
    SELECT pxa.id_product_pa, pxa.id_author_pa
    FROM productxauthor pxa
    WHERE pxa.id_product_pa = pIdProduct AND pxa.id_author_pa = pIdAuthor;
END;

--Returns the authors that purchased a determined product
CREATE OR REPLACE PROCEDURE get_productxauthor_byproduct(pIdProduct IN NUMBER, pCursorProXAut OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProXAut for
    SELECT id_person,id_author_cathegory
    FROM author
    inner join productxauthor pxa
    on author.id_person = pxa.id_author_pa
    WHERE pxa.id_product_pa = pIdProduct;
END;

--Returns the products purchased by a determined author
CREATE OR REPLACE PROCEDURE get_productxauthor_byauthor(pIdAuthor IN NUMBER, pCursorProXAut OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProXAut for
    SELECT id_product,cost_product,description_product,id_catalog_pr,id_availability
    FROM product
    inner join productxauthor pxa
    on product.id_product = pxa.id_product_pa
    WHERE pxa.id_author_pa = pIdAuthor;
END;

/*Get professor, recieves an id to return the professor with that id, if not sent an id 
will return all professors.
Returns:
- id person 
- id dedication
- name dedication
*/
CREATE OR REPLACE PROCEDURE get_professor(pId IN NUMBER, pCursorProfessor OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProfessor for
    SELECT id_person, id_dedication
    FROM professor 
    WHERE id_person = pId;
END;

--Returns a cursor with al proffesors
CREATE OR REPLACE PROCEDURE get_professors(pCursorProfessor OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProfessor for
    SELECT id_person, id_dedication
    FROM professor;
END;

/*Get provinces, recieves an id to return the province with that id, if not sent an id 
will return all provinces.
Returns:
- id province
- name province
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_province(pId IN NUMBER, pCursorProvince OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProvince for
    SELECT p.id_province, p.name_province 
    FROM province p
    WHERE p.id_province = pId;
END;

--Returns All Provinces
CREATE OR REPLACE PROCEDURE get_provinces(pId IN NUMBER, pCursorProvince OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProvince for
    SELECT p.id_province, p.name_province 
    FROM province p
    WHERE p.id_province = pId;
END;



/*Get reviews, recieves an id to return the review with that id, if not sent an id 
will return all reviews.
Returns:
- id_article_review
- id from the user who did that review
- description from the review
- stars
*/
CREATE OR REPLACE PROCEDURE get_reviews(pCursorReviews OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorReviews for
    SELECT r.id_article_rev, id_user_rev ,r.description_review, r.stars  
    FROM review r;
END;

--Returns reviews of a determined article
CREATE OR REPLACE PROCEDURE get_reviews_byarticle(pId IN NUMBER, pCursorReviews OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorReviews for
    SELECT r.id_article_rev, id_user_rev ,r.description_review, r.stars  
    FROM review r
    WHERE r.id_article_rev = pId;
END;

/*Get status, recieves an id to return the status with that id, if not sent an id 
will return all status.
Returns:
- id_status
- status name */
CREATE OR REPLACE PROCEDURE get_status(idStatus in number,pCursorStatus OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorStatus for
    SELECT id_status, name_status
    FROM status
    where id_status = idStatus;
END;

--Returns all statuses
--Already in java
CREATE OR REPLACE PROCEDURE get_statuses(pCursorStatus OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorStatus for
    SELECT id_status, name_status
    FROM status;
END;

/*Get students, recieves an id to return the student with that id, if not id is sent
will return all students.
Returns:
- id_person of the student
- student card */
CREATE OR REPLACE PROCEDURE get_student(pId IN NUMBER, pCursorStudent OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorStudent for
    SELECT id_person, student_card
    FROM student 
    WHERE id_person = pId;
END;

--Returns all students
--Already in java
CREATE OR REPLACE PROCEDURE get_students(pCursorStudent OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorStudent for
    SELECT id_person, student_card
    FROM student;
END;

/*Get users, recieves an id to return the user with that id, if not sent an id 
will return all users.
Returns:
- id_person of the user
- user password */
CREATE OR REPLACE PROCEDURE get_users(pCursorUser OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorUser for
    SELECT u.id_person, u.password_user
    from userdb u;
END;

--Returns a specific user
--Already in java
CREATE OR REPLACE PROCEDURE get_user(pidUser in number,pCursorUser OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorUser for
    SELECT u.id_person, u.password_user
    from userdb u
    where u.id_person = pidUser;
END;

