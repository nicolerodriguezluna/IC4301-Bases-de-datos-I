ALTER TABLE administrative
ADD CONSTRAINT fk_administrative_idperson FOREIGN KEY (id_person) REFERENCES person (id_person)
ADD CONSTRAINT fk_administrative_iddedication FOREIGN KEY (id_dedication) REFERENCES person(id_person)

