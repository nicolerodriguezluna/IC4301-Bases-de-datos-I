CREATE OR REPLACE PROCEDURE get_news_date(pCursorNews out SYS_REFCURSOR) AS
BEGIN
        OPEN pCursorNews for
        SELECT  first_name||' '||second_name||' '||first_surname||' '||second_surname as name,title_article,publication_date,name_status,name_category
        from article
        inner join status
        On article.id_status_article = status.id_status
        inner join articlecategory
        On article.id_art_cat = articlecategory.id_article_category
        inner join authorxarticle
        On authorxarticle.id_article_autart = article.id_article
        inner join author
        On author.id_person = authorxarticle.id_author_autart
        inner join person
        ON author.id_person = person.id_person
        ORDER BY(publication_date);
END;