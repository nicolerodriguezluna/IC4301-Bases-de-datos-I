INSERT INTO product
(id_product,cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_product.nextval,50,'Art�culo del Espacio',0,1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO product
(id_product,cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_product.nextval,50,'Una breve Historia de Todo',0,1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO product
(id_product,cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_product.nextval,75,'Genios de la Historia',0,0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO product
(id_product,cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_product.nextval,100,'Kit Molecular',1,1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO product
(id_product,cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_product.nextval,80,'Probetas',1,1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO product
(id_product,cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_product.nextval,30,'Art�culo de Rob�tica',1,0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO product
(id_product,cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_product.nextval,200,'Telescopio',2,1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO product
(id_product,cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_product.nextval,150,'Tabla Peri�dica',2,1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO product
(id_product,cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_product.nextval,150,'Art�culo Inteligencia Artificial',2,1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

