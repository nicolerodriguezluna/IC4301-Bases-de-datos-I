CREATE TABLE photo
(
    id_photo NUMBER(38) CONSTRAINT photo_idphoto_nn NOT NULL,
    id_article NUMBER(15),
    id_person NUMBER(15)
);