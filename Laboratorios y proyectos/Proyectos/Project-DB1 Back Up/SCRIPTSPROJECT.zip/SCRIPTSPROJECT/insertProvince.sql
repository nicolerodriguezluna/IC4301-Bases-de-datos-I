INSERT INTO province(id_nation, id_province, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_province.nextval, 'San Jos�',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO province(id_nation, id_province, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_province.nextval, 'Alajuela',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO province(id_nation, id_province, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_province.nextval, 'Cartago',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO province(id_nation, id_province, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_province.nextval, 'Heredia',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO province(id_nation, id_province, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_province.nextval, 'Guanacaste',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO province(id_nation, id_province, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_province.nextval , 'Puntarenas',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO province(id_nation, id_province, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_province.nextval, 'Lim�n',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

