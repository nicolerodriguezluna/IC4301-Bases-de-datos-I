CREATE TABLE author(
    id_person NUMBER(15) CONSTRAINT author_idperson_nn NOT NULL,
    id_author_cathegory NUMBER(15) CONSTRAINT author_idauthorcategory_nn NOT NULL
);