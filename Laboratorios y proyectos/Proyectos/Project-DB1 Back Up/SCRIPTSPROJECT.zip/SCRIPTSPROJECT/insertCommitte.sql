insert into committe
(id_committe,description_committe, creationDate, userId, lastModifyDate, lastModifyBy,id_campus)
values (s_committe.nextval,'ComiTEC', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT',1);

insert into committe
(id_committe,description_committe, creationDate, userId, lastModifyDate, lastModifyBy,id_campus)
values (s_committe.nextval,'UCRevisa', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT',5);

insert into committe
(id_committe,description_committe, creationDate, userId, lastModifyDate, lastModifyBy,id_campus)
values (s_committe.nextval,'UNAprobado', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT',9);





