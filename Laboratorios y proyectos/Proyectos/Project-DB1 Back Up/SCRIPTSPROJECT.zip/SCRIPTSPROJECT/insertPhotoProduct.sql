insert into photo
(id_photo,id_article,route)
VALUES(35,NULL,(select route from parameterdb where id_parameter = 0)||'\astronautArticle.jpg');

insert into photo
(id_photo,id_article,route)
VALUES(36,NULL,(select route from parameterdb where id_parameter = 0)||'\briefhistoryofeverything.jpg');

insert into photo
(id_photo,id_article,route)
VALUES(37,NULL,(select route from parameterdb where id_parameter = 0)||'\einsteinArticle.jpg');

insert into photo
(id_photo,id_article,route)
VALUES(38,NULL,(select route from parameterdb where id_parameter = 0)||'\kitMolecular.jpg');

insert into photo
(id_photo,id_article,route)
VALUES(39,NULL,(select route from parameterdb where id_parameter = 0)||'\probetas.jpg');

insert into photo
(id_photo,id_article,route)
VALUES(40,NULL,(select route from parameterdb where id_parameter = 0)||'\robotArticle.jpg');

insert into photo
(id_photo,id_article,route)
VALUES(41,NULL,(select route from parameterdb where id_parameter = 0)||'\telescopio.jpg');

insert into photo
(id_photo,id_article,route)
VALUES(42,NULL,(select route from parameterdb where id_parameter = 0)||'\tablaPeriodica.jpg');

insert into photo
(id_photo,id_article,route)
VALUES(43,NULL,(select route from parameterdb where id_parameter = 0)||'\articleIA.jpg');