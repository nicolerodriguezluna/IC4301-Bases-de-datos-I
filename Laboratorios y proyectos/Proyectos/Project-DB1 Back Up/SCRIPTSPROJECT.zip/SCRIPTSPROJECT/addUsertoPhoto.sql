ALTER table photo
add id_userdb NUMBER(15) CONSTRAINt photo_iduserdb_nn NOT NULL