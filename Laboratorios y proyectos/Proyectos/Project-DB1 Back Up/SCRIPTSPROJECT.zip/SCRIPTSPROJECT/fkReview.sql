ALTER TABLE review
ADD CONSTRAINT fk_review_idarticle FOREIGN KEY (id_article_rev) REFERENCES article(id_article)
ADD CONSTRAINT fk_review_iduser FOREIGN KEY (id_user_rev) REFERENCES userdb(id_user)
