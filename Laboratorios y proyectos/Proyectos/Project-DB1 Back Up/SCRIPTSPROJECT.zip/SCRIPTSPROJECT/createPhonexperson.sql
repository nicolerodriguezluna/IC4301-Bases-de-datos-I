CREATE TABLE phonexperson
(
 number_phone NUMBER(8) CONSTRAINT phoneperson_number_nn NOT NULL,
 id_person_pp number(15) CONSTRAINT phoneperson_idperson_nn NOT NULL
);