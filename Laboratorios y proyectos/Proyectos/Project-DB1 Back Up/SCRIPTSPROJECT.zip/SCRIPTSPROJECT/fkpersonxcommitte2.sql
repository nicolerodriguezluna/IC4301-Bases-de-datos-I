ALTER TABLE personxcommitte
add constraint fk_perxcomm_idcomm foreign key (id_committe) references committe(id_committe)
