SELECT title_article,name_category
from article
inner join articlecategory
ON id_art_cat = id_article_category
GROUP BY (title_article,name_category);

