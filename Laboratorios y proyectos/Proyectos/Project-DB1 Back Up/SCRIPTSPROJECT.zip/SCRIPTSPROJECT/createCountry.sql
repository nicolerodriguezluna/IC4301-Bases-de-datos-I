CREATE TABLE COUNTRY
(
    id_country NUMBER(3) CONSTRAINT country_idcountry_nn NOT NULL,
    name_country VARCHAR2(60) CONSTRAINT country_namecountry_nn NOT NULL
);