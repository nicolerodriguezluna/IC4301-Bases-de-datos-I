INSERT INTO college
(id_college,name_college, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_college.nextval,'Instituto Tecnol�gico de Costa Rica', SYSDATE, 'BDPROJECT',SYSDATE, 'BDPROJECT');

INSERT INTO college
(id_college,name_college, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_college.nextval,'Universidad de Costa Rica', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO college
(id_college,name_college, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_college.nextval,'Universidad Nacional', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');
