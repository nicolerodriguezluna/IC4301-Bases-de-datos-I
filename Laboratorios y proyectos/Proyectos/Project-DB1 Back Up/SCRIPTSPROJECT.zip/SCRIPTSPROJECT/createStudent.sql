CREATE TABLE student(
    id_person number(15) CONSTRAINT student_idperson_nn NOT NULL,
    student_card number(10) CONSTRAINT student_studentcard_nn NOT NULL
);