INSERT INTO Authorcategory
(id_author_category,type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_authorcategory.nextval,'Ciencias de la Computaci�n', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO Authorcategory
(id_author_category,type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_authorcategory.nextval,'Matem�ticas', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO Authorcategory
(id_author_category,type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_authorcategory.nextval,'Ciencia', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO Authorcategory
(id_author_category,type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_authorcategory.nextval,'Arte', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO Authorcategory
(id_author_category,type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_authorcategory.nextval,'Biolog�a', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO Authorcategory
(id_author_category,type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_authorcategory.nextval,'Deportes', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO Authorcategory
(id_author_category,type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_authorcategory.nextval,'Medicina', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO Authorcategory
(id_author_category,type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_authorcategory.nextval,'Qu�mica', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO Authorcategory
(id_author_category,type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_authorcategory.nextval,'F�sica', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

