ALTER TABLE authorxarticle
ADD CONSTRAINT fk_arthorxarticle_author FOREIGN KEY ( id_author_autart) REFERENCES author(id_person)
ADD CONSTRAINT fk_arthorxarticle_art FOREIGN KEY ( id_article_autart) REFERENCES article(id_article)
