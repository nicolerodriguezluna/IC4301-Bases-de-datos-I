ALTER TABLE DigitalNewspaper
ADD Constraint fk_DigitalNewsPaper_idcampus FOREIGN KEY (id_quad) REFERENCES campus(id_campus)
