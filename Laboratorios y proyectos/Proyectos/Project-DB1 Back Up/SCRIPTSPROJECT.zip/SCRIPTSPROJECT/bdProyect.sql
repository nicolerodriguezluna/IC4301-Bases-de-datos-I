CREATE USER bdproject
IDENTIFIED BY bdproject
DEFAULT TABLESPACE bdproject_data 
QUOTA 10M ON bdproject_data 
TEMPORARY TABLESPACE temp
QUOTA 5M ON system ;
--PROFILE app_user 
--PASSWORD EXPIRE;