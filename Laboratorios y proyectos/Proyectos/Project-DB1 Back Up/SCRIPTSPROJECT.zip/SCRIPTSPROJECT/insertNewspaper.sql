INSERT INTO digitalnewspaper
(id_digital_newspaper,name_digital_newspaper,id_quad, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_digitalnewspaper.nextval,'Hoy en el Tec',1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO digitalnewspaper
(id_digital_newspaper,name_digital_newspaper,id_quad, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_digitalnewspaper.nextval,'Noticias UCR',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO digitalnewspaper
(id_digital_newspaper,name_digital_newspaper,id_quad, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_digitalnewspaper.nextval,'UNA Comunica',9,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

