create or replace TRIGGER before_update_art_pub_date
before insert or update of publication_date
on article
for each row
BEGIN
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES (s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'PUBLICATION DATE CHANGE',CAST(:old.publication_date AS VARCHAR2(1000)),
    CAST(:new.publication_date AS VARCHAR2(1000)));
end before_update_art_pub_date;