CREATE TABLE district(
 id_district NUMBER(15) CONSTRAINT district_iddistrict_n NOT NULL,
 name_district VARCHAR2(100) CONSTRAINT district_namedistrict_nn NOT NULL,
 id_sector NUMBER(15) CONSTRAINT district_idsector_nn NOT NULL
);