INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'San Jos�', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Acosta', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Alajuelita', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Aserr�', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Curridabat', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Desamparados', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Dota', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Escaz�', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Goicoechea', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Le�n Cort�s', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Montes de Oca', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Mora', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Moravia', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'P�rez Zeled�n', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Puriscal', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Santa Ana', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Tarraz�', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Tib�s', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'Turrubares', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(0, s_canton.nextval, 'V�zques de Coronado', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3, s_canton.nextval, 'Cartago', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3, s_canton.nextval, 'Para�so', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3, s_canton.nextval, 'La Uni�n', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3, s_canton.nextval, 'Jimen�z', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3, s_canton.nextval, 'Turrialba', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3, s_canton.nextval, 'Alvarado', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3, s_canton.nextval, 'Oreamuno', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3, s_canton.nextval, 'El Guarco', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Puntarenas', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');
INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Esparza', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Buenos Aires', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Montes de Oro', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Osa', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Quepos', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Golfito', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Coto Brus', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Parrita', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Corredores', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Garabito', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Monteverde', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5, s_canton.nextval, 'Puerto Jim�nez', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1 ,s_canton.nextval, 'Alajuela', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1, s_canton.nextval, 'San Ram�n', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval, 'Grecia', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval, 'San Mateo', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1, s_canton.nextval, 'Atenas', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval, 'Naranjo', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval, 'Palmares', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval, 'Po�s', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1, s_canton.nextval, 'Orotina', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval, 'San Carlos', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval,  'Zarcero', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval, 'Sarch�', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval, 'Upala', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval, 'Los Chiles', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval, 'Guatuso', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,s_canton.nextval, 'R�o Cuarto', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, s_canton.nextval, 'Heredia', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, s_canton.nextval, 'Barva', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, s_canton.nextval, 'Bel�n', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, s_canton.nextval, 'Flores', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, s_canton.nextval, 'San Isidro', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, s_canton.nextval, 'San Pablo', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, s_canton.nextval, 'San Rafael', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, s_canton.nextval, 'Santa B�rbara', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, s_canton.nextval, 'Santo Domingo', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, s_canton.nextval, 'Sarapiqu�', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4, s_canton.nextval, 'Liberia', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4, s_canton.nextval, 'Nicoya', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4, s_canton.nextval, 'Santa Cruz', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,s_canton.nextval, 'Bagaces', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,s_canton.nextval, 'Carrillo', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,s_canton.nextval, 'Ca�as', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,s_canton.nextval, 'Albangares', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,s_canton.nextval, 'Tilar�n', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,s_canton.nextval, 'Nandayure', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4, s_canton.nextval, 'La Cruz', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,s_canton.nextval, 'Hojancha', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,s_canton.nextval, 'Lim�n', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,s_canton.nextval, 'Pococ�', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,s_canton.nextval, 'Siquirres', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,s_canton.nextval, 'Talamanca', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,s_canton.nextval, 'Matina', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

INSERT INTO canton(id_area, id_canton, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,s_canton.nextval, 'Gu�cimo', SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

