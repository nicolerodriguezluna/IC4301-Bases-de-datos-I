CREATE OR REPLACE PROCEDURE get_authors_byage_gender(pidGender in number,pCursorAuthors out sys_refcursor)
AS
    BEGIN
    OPEN pCursorAuthors for
    SELECT '0-18' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 0 AND 18 and person.id_gender = pidGender
    UNION
    SELECT '19-30' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 19 AND 30 and person.id_gender = pidGender
    UNION
     SELECT '31-45' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 31 AND 45 and person.id_gender = pidGender
    UNION
     SELECT '45-60' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 45 AND 60 and person.id_gender = pidGender
    UNION
     SELECT '61-75' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 61 AND 75 and person.id_gender = pidGender
    UNION
    SELECT '75-' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (trunc(sysdate - person.datebirth)/365)>75 and person.id_gender = pidGender;
END;
    