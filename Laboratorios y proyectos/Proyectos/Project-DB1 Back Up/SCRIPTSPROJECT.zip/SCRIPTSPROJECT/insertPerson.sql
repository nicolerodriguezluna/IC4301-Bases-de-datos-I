INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,119560234,'Melissa', 'Laura', 'Zarate', 'L�pez',DATE '1998-04-15',0,0,'Torre A - Centro Corporativo Internacional, en Barrio don Bosco, avenida 8, calles 26 y 28', 0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,202678512,'Catalina', 'Mar�a', 'Santana', 'Hern�ndez',DATE '1986-05-16',1,0, 'cerca del pueblo de Ujarr�s a lo largo de la carretera nacional 225 en el curso medio del r�o Reventaz�n, en el valle de Ujarr�s', 243,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,705689412,'Alejandro', 'Sebastian', 'Fern�ndez', 'Ortiz',DATE '2007-09-13',2,1,'4.8km noroeste de la Iglesia Cat�lica de La Fortuna', 313,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,306872354,'Paula', 'Liliana', 'Perez', 'L�pez',DATE '1998-02-13',3,0,'150 metros sureste de la municipalidad de la Fortuna de San Carlos', 313,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,603154786,'Ariana', 'Vanessa', 'Gonzalez', 'Molina',DATE '2005-11-11',4,0, '50 metros norte del restaurante  El Bamb�, Pocora Lim�n', 470,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,452618723,'Isabel', 'Rosaura', 'Torres', 'Benavides',DATE '1970-02-19',5,0,'1 kil�metro al oeste de la agencia del Banco Nacional, Provincia de Alajuela, San Ram�n', 145,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,514896458,'Kenneth', 'Ricardo', 'Ibarra', 'Vargas',DATE '1999-08-17',6,1,'100 metros de la farmacia Value, Provincia de Cartago, Para�so',130,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,789630412,'Jezabel', 'Hillary', 'Morales', 'Barrera',DATE '2007-10-27',7,0, '200 metros de la bomba La Tica, Barreal Heredia',370,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,402569871,'Luis', 'Roberto', 'Rivera', 'Moaraga',DATE '2002-12-16',8,1,'200 metros este de la municipalidad de Heredia',351,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,118670120,'Jeffrey','Daniel','Leiva','Cascante',DATE '2003-03-21',9,1,'De la universidad nacional campus sarapiqu� 100 metros este 100 metros sur de la universidad nacional campus sarapiqu� Heredia Horquetas',395,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,119872619,'Esteban','Alfredo','Perez','Caceres',DATE '2000-04-22',10,1,'Calle Rosales, Provincia de Alajuela, Alajuela',235,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,290871627,'Andres','Eduardo','Villalobos','Sandi',DATE '1987-12-31',0,1,'Calles 8, diagonal a la soda Las Delicias, Av 9, Am�n, San Jos�', 0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,390812345,'Francisco','Franco','Sanchez','Ruben',DATE '1999-01-12',1,1,'Calle 16, Avenida 13., 1 km Suroeste de la Bas�lica de los �ngeles., Provincia de Cartago, Cartago',122,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,568909876,'Hilda','Heriberta','Robles','Torres',DATE '1989-09-09',2,0,'500 metros del polideportivo de San Carlos,Provincia de Alajuela, San Carlos',313,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,435678901,'Carlos','Humberto','Flores','Valerio',DATE '1998-07-07',3,1,'250 metros del Multicentro,Av. 4, Lim�n',78,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,189098762,'James','Kevin','Valverde','Alpizar',DATE '2000-09-01',4,1,'800 metros de la entrada sur de la Ciudad Universitaria Rodrigo Facio Brenes, San Jos�, San Pedro',66,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,198098765,'Pedro','Pablo','Matarrita','Smith', DATE '1996-12-03',5,1,'600 metros de la  Iglesia de Alajuela, Provincia de Alajuela, San Ram�n', 249,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,345987654,'Rachell','Maria','Bermudez','Salazar',DATE '1998-03-10',6,0,'100 metros diagonal del Mall Para�so de Cartago, Para�so Cartago', 133,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,478985748,'Mariana','Steffany','Orozco','Campos',DATE '2003-05-27',7,0,'1 km al este del Mall Oxigeno', 360,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_person.nextval,119845679,'Jeffry', 'Alexander', 'Avil�s', 'Figueroa',DATE '1989-06-14',8, 1,'1 km al sur de los Tribunales de Justicia de Heredia',351,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');
