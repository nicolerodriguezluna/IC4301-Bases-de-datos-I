create or replace PROCEDURE insert_user(pPassUser IN VARCHAR2, pidPerson IN NUMBER) AS
BEGIN
    INSERT INTO userdb(id_User, password_user, id_person, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_user.nextval, pPassUser, pidPerson, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_user;

create or replace PROCEDURE insert_student(pidPerson IN NUMBER, pstudentCard IN NUMBER) AS
BEGIN
    INSERT INTO student(id_person, student_card, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidPerson, pstudentCard, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_student;

CREATE OR REPLACE PROCEDURE insert_status(pnameStatus VARCHAR2) AS
BEGIN
    INSERT INTO status(id_status, name_status, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_status.nextval, pnameStatus, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_status;

CREATE OR REPLACE PROCEDURE insert_review(pdescription IN VARCHAR2, pid_article_rev IN NUMBER, pid_user_rev IN NUMBER) AS
BEGIN
    INSERT INTO review(description_review, id_article_rev, id_user_rev,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pdescription, pid_article_rev, pid_user_rev, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_review;

CREATE OR REPLACE PROCEDURE insert_province(pname IN VARCHAR2, pidNation IN NUMBER) AS
BEGIN
    INSERT INTO province(id_province, name_province, id_nation, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_province.nextval, pname, pidNation ,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_province; 

CREATE OR REPLACE PROCEDURE insert_professor(pidDedication IN NUMBER, pidPerson IN NUMBER) AS
BEGIN
    INSERT INTO professor(id_dedication, id_person, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidDedication, pidPerson,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_professor; 

CREATE OR REPLACE PROCEDURE insert_productxauthor(pidProPa IN NUMBER, pidAutPa IN NUMBER) AS
BEGIN
    INSERT INTO productxauthor(id_product_pa, id_author_pa, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidProPa, pidAutPa, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_productxauthor; 

CREATE OR REPLACE PROCEDURE insert_product(pidProduct IN NUMBER, pCost IN NUMBER, pdescription IN VARCHAR2, 
pidCatalog IN NUMBER, pidAvailability IN NUMBER) AS
BEGIN
    INSERT INTO product(id_product, cost_product, description_product, id_catalog_pr, id_availability,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_product.nextval, pcost, pdescription, pidcatalog, pidavailability, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_product; 

CREATE OR REPLACE PROCEDURE insert_photo_article(proute IN VARCHAR2,pidArticle IN NUMBER) AS
BEGIN
    INSERT INTO photo(id_photo,route, id_article, id_user, id_product,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_photo.nextval, proute, pidArticle, NULL, NULL, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_photo_article; 

CREATE OR REPLACE PROCEDURE insert_photo_user(proute IN VARCHAR2,pidUser IN NUMBER) AS
BEGIN
    INSERT INTO photo(id_photo,route, id_article, id_user, id_product,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_photo.nextval, proute, NULL, pidUser, NULL, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_photo_user; 

CREATE OR REPLACE PROCEDURE insert_photo_product(proute IN VARCHAR2,pidProduct IN NUMBER) AS
BEGIN
    INSERT INTO photo(id_photo,route, id_article, id_user, id_product,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_photo.nextval, proute, NULL, NULL, pidProduct, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_photo_product; 

CREATE OR REPLACE PROCEDURE insert_phoneCategory(pdescription IN VARCHAR2) AS
BEGIN
    INSERT INTO phoneCategory(id_category, description_category,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_phcategory.nextval, pdescription, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_phoneCategory; 

CREATE OR REPLACE PROCEDURE insert_phone(pnumber IN NUMBER, pidPerson IN NUMBER, pidPhoneCategory IN NUMBER) AS
BEGIN
    INSERT INTO phone(id_phone, number_phone, id_person, id_phone_category, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_phone.nextval, pnumber, pidPerson, pidPhoneCategory, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_phone; 

CREATE OR REPLACE PROCEDURE insert_personxcommitte(pidCommitte IN NUMBER, pidPerson IN NUMBER) AS
BEGIN
    INSERT INTO personxcommitte(id_committe, id_person, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidCommitte, pidPerson, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_personxcommitte; 

CREATE OR REPLACE PROCEDURE update_user(pidUser IN NUMBER, pNewPass IN VARCHAR2) AS
BEGIN
    UPDATE userdb
    SET password_user = pNewPass
    WHERE pidUser = id_user;
    COMMIT;
END update_user;

CREATE OR REPLACE PROCEDURE update_student(pidPerson IN NUMBER, pNewStudCard IN NUMBER) AS
BEGIN
    UPDATE student
    SET student_card = pNewStudCard
    WHERE pidPerson = id_person;
    COMMIT;
END update_student;

CREATE OR REPLACE PROCEDURE update_status(pidStatus  IN NUMBER, pNewStatus IN VARCHAR2) AS
BEGIN
    UPDATE status
    SET name_status = pNewStatus
    WHERE pidStatus = id_status;
    COMMIT;
END update_status;

CREATE OR REPLACE PROCEDURE update_review(pidArtRev IN NUMBER, pidUserRev IN NUMBER, pNewDescription IN VARCHAR2) AS
BEGIN
    UPDATE review
    SET description_review = pNewDescription
    WHERE pidUserRev = id_user_rev AND pidArtRev = id_article_rev;
    COMMIT;
END update_review;

CREATE OR REPLACE PROCEDURE update_province(pidProvince IN NUMBER, pNewName IN VARCHAR2) AS
BEGIN
    UPDATE province
    SET name_province = pNewName
    WHERE pidProvince = id_province;
    COMMIT;
END update_province;

CREATE OR REPLACE PROCEDURE update_professor(pidPerson IN NUMBER, pNewDedication IN NUMBER) AS
BEGIN
    UPDATE professor
    SET id_dedication = pNewDedication
    WHERE pidPerson = id_person;
    COMMIT;
END update_professor;

CREATE OR REPLACE PROCEDURE update_product(pidProduct IN NUMBER, pNewCost IN NUMBER, pNewDescription IN VARCHAR2) AS
BEGIN
    UPDATE product
    SET cost_product = pNewCost, 
        description_product = pNewDescription
    WHERE pidProduct = id_product;
    COMMIT;
END update_product;

CREATE OR REPLACE PROCEDURE update_product_description(pidProduct IN NUMBER, pNewDescription IN VARCHAR2) AS
BEGIN
    UPDATE product
    SET  description_product = pNewDescription
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_description;

CREATE OR REPLACE PROCEDURE update_product_cost(pidProduct IN NUMBER, costProduct in number) AS
BEGIN
    UPDATE product
    SET  cost_product = costProduct
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_cost;

CREATE OR REPLACE PROCEDURE update_product_catalog(pidProduct IN NUMBER, idCatalog in number) AS
BEGIN
    UPDATE product
    SET  id_catalog_pr = idCatalog
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_catalog;

CREATE OR REPLACE PROCEDURE update_product_availability(pidProduct IN NUMBER, idCatalog in number) AS
BEGIN
    UPDATE product
    SET  id_catalog_pr = idCatalog
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_availability;


CREATE OR REPLACE PROCEDURE update_photo(pidPhoto IN NUMBER, pNewRoute IN NUMBER) AS
BEGIN
    UPDATE photo
    SET route = pnewRoute
    WHERE pidPhoto = id_photo;
    COMMIT;
END update_photo;

CREATE OR REPLACE PROCEDURE update_phoneCategory(pidCategory IN NUMBER, pNewDescription IN VARCHAR2) AS
BEGIN
    UPDATE phonecategory
    SET description_category = pNewDescription
    WHERE pidCategory = id_category;
    COMMIT;
END update_phoneCategory;

CREATE OR REPLACE PROCEDURE update_phone(pidPhone IN NUMBER, pNewNumber IN NUMBER) AS
BEGIN
    UPDATE phone
    SET number_phone = pNewNumber
    WHERE pidPhone = id_phone;
    COMMIT;
END update_phone;

CREATE OR REPLACE PROCEDURE delete_user(pidUser IN NUMBER) AS
BEGIN
    DELETE FROM userdb
    WHERE id_user = pidUser;
    COMMIT;
END delete_user;

CREATE OR REPLACE PROCEDURE delete_student(pidPerson IN NUMBER) AS
BEGIN
    DELETE FROM student
    WHERE id_person = pidPerson;
    COMMIT;
END delete_student;

CREATE OR REPLACE PROCEDURE delete_status(pidStatus  IN NUMBER) AS
BEGIN
    DELETE FROM status
    WHERE id_status = pidStatus;
    COMMIT;
END delete_status;

CREATE OR REPLACE PROCEDURE delete_review(pidArtRev IN NUMBER, pidUserRev IN NUMBER) AS
BEGIN
    DELETE FROM review
    WHERE id_user_rev = pidUserRev AND id_article_rev = pidArtRev;
    COMMIT;
END delete_review;

CREATE OR REPLACE PROCEDURE delete_province(pidProvince IN NUMBER) AS
BEGIN
    DELETE FROM province
    WHERE id_province = pidProvince;
    COMMIT;
END delete_province;

CREATE OR REPLACE PROCEDURE delete_professor(pidPerson IN NUMBER) AS
BEGIN
    DELETE FROM professor
    WHERE id_person = pidPerson;
    COMMIT;
END delete_professor;

CREATE OR REPLACE PROCEDURE delete_product(pidProduct IN NUMBER) AS
BEGIN
    DELETE FROM product
    WHERE id_product = pidProduct;
    COMMIT;
END delete_product;

CREATE OR REPLACE PROCEDURE delete_photo(pidPhoto IN NUMBER) AS
BEGIN
    DELETE FROM photo
    WHERE id_photo = pidPhoto;
    COMMIT;
END delete_photo;

CREATE OR REPLACE PROCEDURE delete_phoneCategory(pidCategory IN NUMBER) AS
BEGIN
    DELETE FROM phonecategory
    WHERE id_category = pidCategory;
    COMMIT;
END delete_phoneCategory;

CREATE OR REPLACE PROCEDURE delete_phone(pidPhone IN NUMBER) AS
BEGIN
    DELETE FROM phone
    WHERE id_phone = pidPhone;
    COMMIT;
END delete_phone;

CREATE OR REPLACE PROCEDURE delete_personxcommitte(pidPerson IN NUMBER, pidCommitte IN NUMBER) AS
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_person = pidPerson AND id_committe = pidCommitte;
    COMMIT;
END delete_personxcommitte;

CREATE OR REPLACE PROCEDURE delete_personxcommitte_person(pidPerson IN number) AS
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_person = pidPerson;
    COMMIT;
END delete_personxcommitte_person;

CREATE OR REPLACE PROCEDURE delete_personxcommitte_comm(pidCommittee IN number) AS
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_committe = pidCommittee;
    COMMIT;
END delete_personxcommitte_comm;