ALTER TABLE userdb
ADD user_name VARCHAR2(1000) CONSTRAINT user_name_nn NOT NULL;
