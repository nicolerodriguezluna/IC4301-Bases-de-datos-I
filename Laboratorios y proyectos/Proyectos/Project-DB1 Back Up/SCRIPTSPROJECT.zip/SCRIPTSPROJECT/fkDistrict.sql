ALTER TABLE district
ADD CONSTRAINT fk_district_idCanton FOREIGN KEY (id_sector) REFERENCES canton (id_canton)
