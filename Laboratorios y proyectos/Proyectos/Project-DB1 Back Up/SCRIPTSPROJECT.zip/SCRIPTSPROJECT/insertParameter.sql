INSERT INTO parameterdb
(id_parameter,name_parameter,description_parameter,value_parameter,route)
VALUES(s_parameter.nextval,'Photos','User and article photos',NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb');