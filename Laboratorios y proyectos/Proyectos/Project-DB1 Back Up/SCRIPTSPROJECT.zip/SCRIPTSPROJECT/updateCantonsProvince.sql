update canton
set id_area = 3
where id_area = 2;

update canton
set id_area = 2
where id_area = 3;

update canton
set id_area = 3
where id_canton between 57 and 66;