
CREATE OR REPLACE PROCEDURE get_administratives(pCursorAdministrative out sys_refcursor)
AS
BEGIN
    Open pCursorAdministrative for
    select administrative.id_person,id_dedication
    from administrative;
END;--

--Already in Java
CREATE OR REPLACE PROCEDURE get_administrative(pId in number,pCursorAdministrative out sys_refcursor)
AS
BEGIN
    OPEN pCursorAdministrative for
    select administrative.id_person,id_dedication
    from administrative
    where administrative.id_person = pId;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_administrators(pCursorAdministrator out sys_refcursor)
AS
BEGIN
    OPEN pCursorAdministrator for
    SELECT administrator.id_person,password_admin
    from administrator;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_Administrator(pId in Number,pCursorAdministrator out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAdministrator for
    select administrator.id_person,password_admin
    from administrator
    where administrator.id_person = pId;
END;--

--Get article by author is the same as get authorxarticle

--Already in Java
CREATE OR REPLACE PROCEDURE get_article_bydate(pDate in Date,pCursorNews out sys_refcursor)
AS
BEGIN
    OPEN pCursorNews for
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    where article.publication_date = TO_DATE(pDate,'YYYY-MM-DD') and id_status_article=0;
END;

--Already in Java
CREATE OR REPLACE PROCEDURE get_article_bycategory(pIdCategory in NUMBER, pCursorNews out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorNews for
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    where article.id_art_cat = pIdCategory and id_status_article=0;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_article_bycategory_admin(pIdCategory in NUMBER, pCursorNews out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorNews for
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    where article.id_art_cat = pIdCategory;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_article_fullsearch(pidAuthor IN number,pArticleCategory IN number,pDate IN DATE,pCursorNews out SYS_REFCURSOR)
AS
  BEGIN
    OPEN pCursorNews for
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    inner join articlecategory
    on article.id_art_cat = articlecategory.id_article_category
    inner join authorxarticle
    ON authorxarticle.id_article_autart = article.id_article
    where articlecategory.id_article_category = pArticleCategory AND article.publication_date = TO_DATE(pDate,'YYYY-MM-DD') AND authorxarticle.id_author_autart = pidAuthor
    order by(title_article);
 END;

CREATE OR REPLACE PROCEDURE get_articlecategories(pCursorCategories out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorCategories for
    select id_article_category,name_category,description_category
    from articlecategory;
END;--

--CREATE OR REPLACE PROCEDURE get_articlecategory_descr(pIdCategory in NUMBER,pCursorDescription out sys_refcursor)
--AS
--BEGIN
  --  OPEN pCursorDescription for
    --SELECT description_category
    --from articlecategory
    --where id_article_category = pIdCategory;
--END;

--Already in Java
CREATE OR REPLACE PROCEDURE get_authors(pCursorAuthors out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthors for
    SELECT author.id_person,id_author_cathegory
    from author;
END;--

--Already in Java
CREATE OR REPLACE PROCEDURE get_author_categories(pCursorAuthorCategories out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthorCategories for
    SELECT id_author_category,type_category
    from authorcategory;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_author_bycategory(pIdCategory in NUMBER,pCursorAuthorCategories out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthorCategories for
    SELECT author.id_person,id_author_cathegory
    from author
    inner join person
    on person.id_person = author.id_person
    where id_author_cathegory = pIdCategory;
END;--

--Already in java as getArticleByAuthor
CREATE OR REPLACE PROCEDURE get_articles_byauthor(pIdAuthor in NUMBER,pCursorArticle out sys_refcursor)
AS
BEGIN
    OPEN pCursorArticle for
    SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    inner join authorxarticle
    on article.id_article = authorxarticle.id_article_autart
    where authorxarticle.id_author_autart = pIdAuthor  and id_status_article=0;
END;--

--Returns all contents from authorxarticles
CREATE OR REPLACE PROCEDURE get_authorxarticle(pCursorArticle out sys_refcursor)
AS
BEGIN
    OPEN pCursorArticle for
    SELECT id_author_autart, id_article_autart
    from authorxarticle;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_availability(pCursorAvailability out sys_refcursor)
AS
BEGIN
    OPEN pCursorAvailability for
    SELECT id_availability,description_availability
    from availabilitypr;
END;--

CREATE OR REPLACE PROCEDURE get_campus(pCursorCampus out sys_refcursor)
AS
BEGIN
    OPEN pCursorCampus for
    select id_campus,name_campus,id_university,id_district
    from campus;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_campusbycollege(pIdCollege in number,pCursorCampus out sys_refcursor)
AS
BEGIN
    OPEN pCursorCampus for
    select  id_campus,name_campus,id_university,id_district
    from campus
    where id_university = pIdcollege;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_canton_byarea(pIdArea in number, pCursorCantons out sys_refcursor)
AS
BEGIN
    OPEN pCursorCantons for
    select id_canton,name_canton,id_area
    from canton
    where id_area = pIdArea;
END;--

create or replace PROCEDURE get_canton(pnIdCanton IN NUMBER, pCursorCanton OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorCanton for
    SELECT id_canton,name_canton,id_area
    FROM canton
    WHERE id_canton = pnidcanton;
END;

create or replace PROCEDURE get_cantons(pCursorCantons out sys_refcursor)
AS
BEGIN
    OPEN pCursorCantons for
    select id_canton,name_canton,id_area
    from canton;
END;

--Already in java
CREATE OR REPLACE PROCEDURE get_catalogs(pCursorCatalogs out sys_refcursor)
as
begin
    open pCursorCatalogs for
    select id_catalog,id_newspaper,description_catalog
    from catalog;
END;--

--Already in Java
CREATE OR REPLACE PROCEDURE get_catalogs_byPaper(pidNPaper in number,pCursorCatalogs out sys_refcursor)
as
begin
    open pCursorCatalogs for
    select id_catalog,id_newspaper,description_catalog
    from catalog
    where id_newspaper = pidNPaper;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_catalog(pidCatalog in number,pCursorCatalog out sys_refcursor)
AS
BEGIN
    OPEN pCursorCatalog for
    select id_catalog,id_newspaper,description_catalog
    from catalog
    where id_catalog = pidCatalog;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_colleges(pCursorColleges out sys_refcursor)
AS
BEGIN
    OPEN pCursorColleges for
    select id_college,name_college
    from college;
END;--

CREATE OR REPLACE PROCEDURE get_committees(pCursorCommittees out sys_refcursor)
AS
BEGIN
    Open pCursorcommittees for
    select id_committe,description_committe,id_campus
    from committe
    ORDER BY(description_committe)desc;
END get_committees;

CREATE OR REPLACE PROCEDURE get_committee(pidCommittee in number, pCursorCommittee out sys_refcursor)
AS
BEGIN
    Open pCursorcommittee for
    select id_committe,description_committe,id_campus
    from committe
    where id_committe = pidCommittee;
END;
    
CREATE OR REPLACE PROCEDURE get_countries(pCursorCountries out sys_refcursor)
AS
BEGIN
    Open pCursorCountries for
    select id_country,name_country
    from country
    ORDER BY(name_country)desc;
END;

CREATE OR REPLACE PROCEDURE get_country(pindCountry in number, pCursorCountry out sys_refcursor)
AS
BEGIN
    Open pCursorCountry for
    select id_country,name_country
    from country
    where id_country = pindCountry;
END;

CREATE OR REPLACE PROCEDURE get_dedications(pCursorDedications out sys_refcursor)
AS
BEGIN
    Open pCursorDedications for
    select id_dedication,description_dedication
    from dedication
    ORDER BY(description_dedication)desc;
END;


CREATE OR REPLACE PROCEDURE get_dedication(pindDedication in Number, pCursorDedication out sys_refcursor)
AS
BEGIN
    Open pCursorDedication for
    select id_dedication,description_dedication
    from dedication
    where id_dedication = pindDedication;
END;


CREATE OR REPLACE PROCEDURE get_digital_newspapers(pCursorDigitalNewsPapers out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorDigitalNewsPapers for
    SELECT id_digital_newspaper,name_digital_newspaper,id_quad
    from digitalnewspaper
    ORDER BY(name_digital_newspaper)desc;
END;

CREATE OR REPLACE PROCEDURE get_digital_newspaper(pinDNewspaper in Number, pCursorDigitalNewsPaper out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorDigitalNewsPaper for
    SELECT id_digital_newspaper,name_digital_newspaper,id_quad
    from digitalnewspaper
    where id_digital_newspaper = pinDNewspaper;
END;

CREATE OR REPLACE PROCEDURE get_districts(pCursorDistricts out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorDistricts for
    SELECT id_district,name_district,id_sector
    from district
    ORDER BY(name_district)desc;
END;

CREATE OR REPLACE PROCEDURE get_district(pidDistrict in number, pCursorDistrict out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorDistrict for
    SELECT id_district,name_district,id_sector
    from district
    where id_district = pidDistrict;
END;

CREATE OR REPLACE PROCEDURE get_emails(pCursorEmails out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorEmails for
    SELECT id_email,address_email,id_person_mail
    from email
    ORDER BY(address_email)desc;
END;

CREATE OR REPLACE PROCEDURE get_emails_person(pidPerson in number, pCursorEmail out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorEmail for
    SELECT id_email,address_email,id_person_mail
    from email
    where id_person_mail = pidPerson
    ORDER BY(address_email);
END;

CREATE OR REPLACE PROCEDURE get_genders(pCursorGenders out sys_refcursor)
AS
BEGIN
    Open pCursorGenders for
    select id_gender,type_gender
    from gender
    ORDER BY(type_gender)desc;
END;

CREATE OR REPLACE PROCEDURE get_gender(pidGender in number, pCursorGender out sys_refcursor)
AS
BEGIN
    Open pCursorGender for
    select id_gender,type_gender
    from gender
    where id_gender = pidGender
    ORDER BY(type_gender);
END;



CREATE OR REPLACE PROCEDURE get_logdbs(pCursorLogDBs out sys_refcursor)
AS
BEGIN
    Open pCursorLogDBs for
    select id_log,systemdate, time_log, change_descrp, previous_text, current_text
    from logdb
    order by(systemdate)desc;
END;


CREATE OR REPLACE PROCEDURE get_logdb(pidLogdb in number, pCursorLogDB out sys_refcursor)
AS
BEGIN
    Open pCursorLogDB for
    select id_log,systemdate, time_log, change_descrp, previous_text, current_text
    from logdb
    where id_log = pidLogdb;
END;

CREATE OR REPLACE PROCEDURE get_parameters(pCursorParameters out sys_refcursor)
AS
BEGIN
    Open pCursorParameters for
    select id_parameter,name_parameter, description_parameter, value_parameter, route
    from parameterdb
    ORDER BY(name_parameter)desc;
END;



CREATE OR REPLACE PROCEDURE get_parameter(pindParameter in number, pCursorParameter out sys_refcursor)
AS
BEGIN
    Open pCursorParameter for
    select id_parameter,name_parameter, description_parameter, value_parameter, route
    from parameterdb
    where id_parameter = pindParameter;
END;



create or replace PROCEDURE get_people(pCursorPeople out sys_refcursor)
AS
BEGIN
    Open pCursorPeople for
    select id_person,first_name,second_name,first_surname,
    second_surname,identification_card,datebirth, id_quad, id_gender, exact_location, id_district
    from person
    ORDER BY(first_name)desc;
END;



CREATE OR REPLACE PROCEDURE get_person(pidPerson in number, pCursorPerson out sys_refcursor)
AS
BEGIN
    Open pCursorPerson for
    select person.id_person,first_name,second_name,first_surname,second_surname,identification_card,datebirth
    from person
    where person.id_person = pidPerson;
END;

/*Get person x committe recieves an id person to return the commite with that id, if not send an id 
will return all data.
Returns:
- id person
- id committe
*/
--Already in Java
CREATE OR REPLACE PROCEDURE get_people_bycommittee(pIdCommittee IN NUMBER, pCursorPerXCom OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorPerXCom for
    SELECT  person.id_person,first_name,second_name,first_surname,
    second_surname,identification_card,datebirth, id_quad, id_gender, exact_location, id_district
    FROM person
    inner join personxcommitte pxc
    On person.id_person = pxc.id_person
    WHERE pxc.id_committe = pIdCommittee
    order by(first_name);
END;

--Returns personxcommitte
CREATE OR REPLACE PROCEDURE get_personxcommitte(pCursorPerXCom OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorPerXCom for
    SELECT id_person,id_committe
    from personxcommitte;
END;

--Already in java
CREATE OR REPLACE PROCEDURE get_all_phones(pCursorPhones out sys_refcursor)
AS
BEGIN
    OPEN pCursorPhones for
    select id_phone,number_phone,id_person,id_phone_category
    from phone;
END;

--Already in java
--Returns cursor with all phones of a person.
CREATE OR REPLACE PROCEDURE get_person_phones(pidPerson in number,pCursorPhones out sys_refcursor)
AS
BEGIN
    OPEN pCursorPhones for
    select id_phone,number_phone,id_person,id_phone_category
    from phone
    where id_person =pidPerson;
END;

/*Get phone recieves an id to return the phone with that id, if not send an id 
will return all phones.
Returns:
- id phone
- id from the person
- number phone
- description of the category phone
*/
--Gets specific phone
CREATE OR REPLACE PROCEDURE get_phone(pId IN NUMBER, pCursorPhone OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorPhone for
    SELECT p.id_phone, id_person ,p.number_phone, ph.description_category
    FROM phone p
    INNER JOIN phonecategory ph
    ON p.id_phone_category = ph.id_category
    WHERE p.id_phone = pId;
END;

/*Get phonecategory recieves an id to return the phonecategory with that id, if not send an id 
will return all phonecategories.
Returns:
- id phonecategory
- name category
*/
--Already in Java
--Returns cursor with specific phone category
CREATE OR REPLACE PROCEDURE get_phonecategory(pId IN NUMBER, pCursorCategory OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorCategory for
    SELECT p.id_category, p.description_category
    FROM phonecategory p
    WHERE p.id_category = pId;
END;

--Get all categories
--Already in java
CREATE OR REPLACE PROCEDURE get_phonecategories(pCursorCategory OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorCategory for
    SELECT p.id_category, p.description_category
    FROM phonecategory p;
END;

/*Get photos from the articles, recieves an id to return the photo for a specific article with that id, if not sent an id 
will return all photos from articles.
Returns:
- id photo
- id article
- route from the photo 
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_photo_article(pId IN NUMBER, pCursorArticle OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorArticle for
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo p
    WHERE p.id_article = pId;
END;


--Returns all the photos
--Already in java
CREATE OR REPLACE PROCEDURE get_photos(pCursorArticle OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorArticle for
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo p;
END;


/*Get photos from the product, recieves an id to return the photo for a specific product with that id, if not send an id 
will return all product photos.
Returns:
- id photo
- id product
- route from the photo 
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_photo_product(pId IN NUMBER, pCursorPhoto OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorPhoto for
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo p
    WHERE p.id_product = pId;
END;

/*Get photos from the user, recieves an id to return the photo for a specific user with that id, if not send an id 
will return all photos from user.
Returns:
- id photo
- id user
- route from the photo 
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_photo_user(pId IN NUMBER, pCursorPhoto OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorPhoto for
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo p
    WHERE p.id_user = pId;
END;


/*Get products, recieves an id to return the product with that id, if not sent an id 
will return all products.
Returns:
- id product
- cost product
- description product 
- id catalog pr
_ id availabilty
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_product(pId IN NUMBER, pCursorProduct OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProduct for
    SELECT id_product, cost_product, description_product,
    id_catalog_pr, id_availability
    FROM product 
    WHERE id_product = pId;
END;

--Gets all the products
CREATE OR REPLACE PROCEDURE get_products(pCursorProduct OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProduct for
    SELECT id_product, cost_product, description_product,
    id_catalog_pr, id_availability
    FROM product
    order by(cost_product) desc;
END;

CREATE OR REPLACE PROCEDURE get_products_byCollege(pidCollege in number,pCursorProduct OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProduct for
    SELECT id_product, cost_product, description_product,
    id_catalog_pr, id_availability
    FROM product
    inner join catalog
    on catalog.id_catalog = product.id_catalog_pr
    inner join digitalnewspaper
    on digitalnewspaper.id_digital_newspaper = catalog.id_newspaper
    inner join campus
    on digitalnewspaper.id_quad = campus.id_campus
    inner join college
    on college.id_college = campus.id_university
    where college.id_college = pidCollege;
END;

/*Get products x authors, can recieves an id product or id author to return the products with that id, if not sent an id 
will return all products.
Returns:
- id product
- id author
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_productxauthor(pIdProduct IN NUMBER, pIdAuthor IN NUMBER, pCursorProXAut OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProXAut for
    SELECT pxa.id_product_pa, pxa.id_author_pa
    FROM productxauthor pxa
    WHERE pxa.id_product_pa = pIdProduct AND pxa.id_author_pa = pIdAuthor;
END;

--Returns the authors that purchased a determined product
CREATE OR REPLACE PROCEDURE get_productxauthor_byproduct(pIdProduct IN NUMBER, pCursorProXAut OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProXAut for
    SELECT id_person,id_author_cathegory
    FROM author
    inner join productxauthor pxa
    on author.id_person = pxa.id_author_pa
    WHERE pxa.id_product_pa = pIdProduct;
END;

--Returns the products purchased by a determined author
CREATE OR REPLACE PROCEDURE get_productxauthor_byauthor(pIdAuthor IN NUMBER, pCursorProXAut OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProXAut for
    SELECT id_product,cost_product,description_product,id_catalog_pr,id_availability
    FROM product
    inner join productxauthor pxa
    on product.id_product = pxa.id_product_pa
    WHERE pxa.id_author_pa = pIdAuthor;
END;

/*Get professor, recieves an id to return the professor with that id, if not sent an id 
will return all professors.
Returns:
- id person 
- id dedication
- name dedication
*/
CREATE OR REPLACE PROCEDURE get_professor(pId IN NUMBER, pCursorProfessor OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProfessor for
    SELECT id_person, id_dedication
    FROM professor 
    WHERE id_person = pId;
END;

--Returns a cursor with al proffesors
CREATE OR REPLACE PROCEDURE get_professors(pCursorProfessor OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProfessor for
    SELECT id_person, id_dedication
    FROM professor;
END;

/*Get provinces, recieves an id to return the province with that id, if not sent an id 
will return all provinces.
Returns:
- id province
- name province
*/
--Already in java
CREATE OR REPLACE PROCEDURE get_province(pId IN NUMBER, pCursorProvince OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProvince for
    SELECT p.id_province, p.name_province,p.id_nation
    FROM province p
    WHERE p.id_province = pId;
END;

--Returns All Provinces
CREATE OR REPLACE PROCEDURE get_provinces(pId IN NUMBER, pCursorProvince OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProvince for
    SELECT p.id_province, p.name_province 
    FROM province p
    WHERE p.id_province = pId;
END;



/*Get reviews, recieves an id to return the review with that id, if not sent an id 
will return all reviews.
Returns:
- id_article_review
- id from the user who did that review
- description from the review
- stars
*/
CREATE OR REPLACE PROCEDURE get_reviews(pCursorReviews OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorReviews for
    SELECT r.id_article_rev, id_user_rev ,r.description_review, r.stars  
    FROM review r;
END;

--Returns reviews of a determined article
CREATE OR REPLACE PROCEDURE get_reviews_byarticle(pId IN NUMBER, pCursorReviews OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorReviews for
    SELECT r.id_article_rev, id_user_rev ,r.description_review, r.stars  
    FROM review r
    WHERE r.id_article_rev = pId;
END;

/*Get status, recieves an id to return the status with that id, if not sent an id 
will return all status.
Returns:
- id_status
- status name */
CREATE OR REPLACE PROCEDURE get_status(idStatus in number,pCursorStatus OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorStatus for
    SELECT id_status, name_status
    FROM status
    where id_status = idStatus;
END;

--Returns all statuses
--Already in java
CREATE OR REPLACE PROCEDURE get_statuses(pCursorStatus OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorStatus for
    SELECT id_status, name_status
    FROM status;
END;

/*Get students, recieves an id to return the student with that id, if not id is sent
will return all students.
Returns:
- id_person of the student
- student card */
CREATE OR REPLACE PROCEDURE get_student(pId IN NUMBER, pCursorStudent OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorStudent for
    SELECT id_person, student_card
    FROM student 
    WHERE id_person = pId;
END;

--Returns all students
--Already in java
CREATE OR REPLACE PROCEDURE get_students(pCursorStudent OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorStudent for
    SELECT id_person, student_card
    FROM student;
END;

/*Get users, recieves an id to return the user with that id, if not sent an id 
will return all users.
Returns:
- id_person of the user
- user password */
create or replace PROCEDURE get_users(pCursorUser OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorUser for
    SELECT u.id_user,u.password_user,u.id_person,u.user_name
    from userdb u;
END;

--Returns a specific user
--Already in java
create or replace PROCEDURE get_user(pidUser in number,pCursorUser OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorUser for
    SELECT u.id_person, u.password_user,u.user_name,u.id_user
    from userdb u
    where u.id_person = pidUser;
END;


CREATE OR REPLACE PROCEDURE get_articles(pCursorNews out sys_refcursor)
AS
BEGIN
    OPEN pCursorNews for
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article;
END;

create or replace PROCEDURE get_district_byarea(pidCanton in number, pCursorDistrict out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorDistrict for
    SELECT id_district,name_district,id_sector
    from district
    where id_sector = pidCanton;
END get_district_byarea;

CREATE OR REPLACE PROCEDURE get_last_news(pCursorArticles out sys_refcursor)
AS
BEGIN
    OPEN pCursorArticles for
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from(select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
         from article
         order by publication_date desc)
    where rownum<=10 and id_status_article = 0;
END get_last_news;

create or replace PROCEDURE get_reviews_article(pidArticle number,pCursorReviews OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorReviews for
    SELECT r.id_article_rev, id_user_rev ,r.description_review, r.stars  
    FROM review r
    where r.id_article_rev = pidArticle;
END;

create or replace PROCEDURE get_author_byarticle(pIdArticle in NUMBER,pCursorArticle out sys_refcursor)
AS
BEGIN
    OPEN pCursorArticle for
    SELECT author.id_person,author.id_author_cathegory
    from author
    inner join person
    on author.id_person = person.id_person
    inner join authorxarticle
    on author.id_person = authorxarticle.id_author_autart
    where authorxarticle.id_article_autart = pIdArticle;
END;--

CREATE OR REPLACE PROCEDURE get_most_viewed(pCursorMostViewed out sys_refcursor)
AS
BEGIN 
    OPEN pCursorMostViewed for
    SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from (SELECT count(id_article_rev) as total,id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
          from article 
          inner join review
          on article.id_article = review.id_article_rev 
          group by id_article, title_article, text_note, publication_date, id_status_article,id_dig_news, id_art_cat, id_committe_art
          Order by total desc)
    where rownum <=10 and id_status_article = 0;
END;


CREATE OR REPLACE PROCEDURE get_newspapers_byCollege(pidCollege in number,pCursorNews out sys_refcursor)
AS
BEGIN
    OPEN pCursorNews for
    SELECT digitalnewspaper.id_digital_newspaper,digitalnewspaper.name_digital_newspaper,digitalnewspaper.id_quad
    from digitalnewspaper
    inner join campus
    on campus.id_campus = digitalnewspaper.id_quad
    inner join college
    on campus.id_university = college.id_college
    where college.id_college = pidCollege;
END;

CREATE OR REPLACE PROCEDURE get_college_byauthor(pidAuthor in number,pCursorNews out sys_refcursor)
AS
BEGIN
    OPEN pCursorNews for
    SELECT id_college,name_college
    from college
    inner join campus
    on college.id_college = campus.id_university
    inner join person
    on person.id_quad = campus.id_campus
    inner join author
    on person.id_person = author.id_person
    where author.id_person = pidAuthor;
END;

create or replace PROCEDURE get_committe_byCampus(pCampus in number, pCursorCommittee out sys_refcursor)
AS
BEGIN 
OPEN pCursorCommittee for
Select committe.id_committe,committe.description_committe,id_campus
from committe
where committe.id_campus = pCampus;
END get_committe_byCampus;


create or replace PROCEDURE get_committe_byAuthor(pidAuthor in number, pCursorCommittee out sys_refcursor)
AS
BEGIN 
OPEN pCursorCommittee for
Select committe.id_committe,committe.description_committe,id_campus
from author
inner join person
on author.id_person = person.id_person
inner join committe
on committe.id_campus = person.id_quad
where author.id_person = pidAuthor;
END;

    
create or replace PROCEDURE get_user_person(pidUser in number, pCursorPerson out sys_refcursor)
as
begin
open pCursorPerson for
select id_person,first_name,second_name,first_surname,second_surname,identification_card,datebirth,id_quad,id_gender,exact_location,id_district
from(select person.id_person,first_name,second_name,first_surname,second_surname,identification_card,datebirth,id_quad,id_gender,exact_location,id_district
    from person
    inner join userdb
    on person.id_person = userdb.id_person
    where userdb.id_user = pidUser)
where rownum<=1;
END;

CREATE OR REPLACE PROCEDURE get_articles_byCommittee(pidCommittee in number, pCursorArticles out sys_refcursor)
AS
BEGIN 
    OPEN pCursorArticles for
    SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from (SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
          from article
          where article.id_committe_art = pidCommittee)
    Order by publication_date desc;
END;

create or replace PROCEDURE get_user_favourites(pIdUser iN NUMBER, pCursorFavourite OUT SYS_REFCURSOR)
AS
  BEGIN
    OPEN pCursorFavourite for
    SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    inner join favourite
    ON article.id_article = favourite.id_article_fav
    inner join userdb
    ON userdb.id_person =  favourite.id_user_fav
    where userdb.id_user = pIdUser;
  END;
  
CREATE OR REPLACE PROCEDURE list_most_liked_news
AS
    CURSOR topLikedNews
    is
        SELECT count(id_article_fav)as favArticle,article.title_article
        from favourite
        inner join article
        on article.id_article = favourite.id_article_fav
        group by article.title_article
        order by favArticle desc;
    BEGIN
        FOR i in topLikedNews LOOP
            dbms_output.put_line(i.favArticle||' '||i.title_article);
        END LOOP;
END list_most_liked_news;


Create or replace PROCEDURE get_usersByPerson(pnIdPerson in number, pCursorUsers out sys_refcursor)
AS
BEGIN
    OPEN pCursorUsers for
    select id_person, id_user, user_name, password_user
    from userdb
    where id_person = pnIdPerson;
END;

create or replace PROCEDURE get_products_byCampus(pidCampus in number,pCursorProduct OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorProduct for
    SELECT id_product, cost_product, description_product,
    id_catalog_pr, id_availability
    FROM product
    inner join catalog
    on catalog.id_catalog = product.id_catalog_pr
    inner join digitalnewspaper
    on digitalnewspaper.id_digital_newspaper = catalog.id_newspaper
    inner join campus
    on digitalnewspaper.id_quad = campus.id_campus
    where campus.id_campus = pidCampus;
END;

create or replace PROCEDURE update_photo_article(pidArticle IN NUMBER, pNewRoute IN VARCHAR2) AS
BEGIN
    UPDATE photo
    SET route = pnewRoute
    WHERE id_article = pidArticle;
    COMMIT;
END update_photo_article;

create or replace PROCEDURE get_province_bycountry(pIdCountry in number, pCursorProvinces out sys_refcursor)
AS
BEGIN
    OPEN pCursorProvinces for
    select id_province, name_province, id_nation
    from province
    where id_nation = pidcountry;
END;

create or replace PROCEDURE update_photo_product(pidProduct IN NUMBER, pNewRoute IN VARCHAR2) AS
BEGIN
    UPDATE photo
    SET route = pnewRoute
    WHERE id_product = pidProduct;
    COMMIT;
END update_photo_product;

