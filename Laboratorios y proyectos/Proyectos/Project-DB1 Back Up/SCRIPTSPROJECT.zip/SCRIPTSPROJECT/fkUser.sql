ALTER TABLE userdb
ADD CONSTRAINT fk_user_idphoto FOREIGN KEY (id_photo) REFERENCES photo (id_photo)
ADD CONSTRAINT fk_user_idperson FOREIGN KEY (id_person) REFERENCES person (id_person)
ADD CONSTRAINT fk_user_idlog FOREIGN KEY (id_log) REFERENCES logdb (id_log)
