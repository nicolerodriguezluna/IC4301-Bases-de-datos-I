CREATE OR REPLACE PROCEDURE get_avg_review(pCursorAverage OUT SYS_REFCURSOR)
AS
  BEGIN
    OPEN pCursorAverage for 
    SELECT CAST(AVG(stars) AS DECIMAL(10,2)) as average_stars,first_name||' '||second_name||' '||first_surname||' '||second_surname as complete_name 
    from review
    inner join authorxarticle
    On authorxarticle.id_article_autart = review.id_article_rev
    inner join person
    ON authorxarticle.id_author_autart = person.id_person
    group by first_name||' '||second_name||' '||first_surname||' '||second_surname
    ORDER BY average_stars;
 END;