create or replace TRIGGER bdproject.before_insert_administrative
before insert on bdproject.administrative
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_administrative;

create or replace TRIGGER bdproject.before_insert_administrator
before insert on bdproject.administrator
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_administrator;

create or replace TRIGGER bdproject.before_insert_article
before insert on bdproject.article
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_article;

create or replace TRIGGER bdproject.before_insert_articlecategory
before insert on bdproject.articlecategory
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_articlecategory;

create or replace TRIGGER bdproject.before_insert_author
before insert on bdproject.author
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_author;

create or replace TRIGGER bdproject.before_insert_authorcategory
before insert on bdproject.authorcategory
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_authorcategory;

create or replace TRIGGER bdproject.before_insert_authorxarticle
BEFORE insert on bdproject.authorxarticle
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_authorxarticle;

create or replace TRIGGER bdproject.before_insert_availabilitypr
BEFORE INSERT ON bdproject.availabilitypr
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_availabilitypr;

create or replace TRIGGER bdproject.before_insert_campus
BEFORE INSERT ON bdproject.campus
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_campus;

create or replace TRIGGER before_insert_campus_district
before update of id_district
on campus
for each row
begin
     insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'DISTRICT CHANGED',(SELECT name_district from district
    where :old.id_district = district.id_district),(SELECT name_district from district
    where :new.id_district = district.id_district));
    commit;
end  before_update_campus_district;

create or replace TRIGGER bdproject.before_insert_canton
before insert on bdproject.canton
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_canton;

create or replace TRIGGER bdproject.before_insert_catalog
before insert on bdproject.catalog
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_catalog;


create or replace TRIGGER bdproject.before_insert_college
before insert on bdproject.college
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_college;

create or replace TRIGGER bdproject.before_insert_committe
before insert on bdproject.committe
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_committe;

create or replace TRIGGER bdproject.before_insert_country
before insert on bdproject.country
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_country;

create or replace TRIGGER bdproject.before_insert_dedication
before insert on bdproject.dedication
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_dedication;

create or replace TRIGGER bdproject.before_insert_digitalNewspaper
before insert on bdproject.digitalNewspaper
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_digitalNewspaper;

create or replace TRIGGER bdproject.before_insert_district
before insert on bdproject.district
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_district;

create or replace TRIGGER bdproject.before_insert_email
before insert on bdproject.email
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_email;

create or replace TRIGGER bdproject.before_insert_favourite
before insert on bdproject.favourite
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_favourite;

create or replace TRIGGER bdproject.before_insert_gender
before insert on bdproject.gender
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_gender;

create or replace TRIGGER bdproject.before_insert_logdb
before insert on bdproject.logdb
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_logdb;

create or replace TRIGGER bdproject.before_insert_neighbour
before insert on bdproject.neighbour
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_neighbour;

create or replace TRIGGER bdproject.before_insert_parameterdb
before insert on bdproject.parameterdb
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_parameterdb;

create or replace TRIGGER bdproject.before_insert_person
before insert on bdproject.person
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_person;

create or replace TRIGGER bdproject.before_insert_personxcommitte
before insert on bdproject.personxcommitte
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_personxcommitte;

create or replace TRIGGER bdproject.before_insert_phone
before insert on bdproject.phone
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_phone;

create or replace TRIGGER bdproject.before_insert_phonecategory
before insert on bdproject.phonecategory
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_phonecategory;

create or replace TRIGGER bdproject.before_insert_photo
before insert on bdproject.photo
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_photo;

create or replace TRIGGER bdproject.before_insert_product
before insert on bdproject.product
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_product;

create or replace TRIGGER bdproject.before_insert_productxauthor
before insert on bdproject.productxauthor
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_productxauthor;

create or replace TRIGGER bdproject.before_insert_professor
before insert on bdproject.professor
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_professor;

create or replace TRIGGER bdproject.before_insert_province
before insert on bdproject.province
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_province;

create or replace TRIGGER bdproject.before_insert_review
before insert on bdproject.review
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_review;

create or replace TRIGGER bdproject.before_insert_status
before insert on bdproject.status
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_status;

create or replace TRIGGER bdproject.before_insert_student
before insert on bdproject.student
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_student;

create or replace TRIGGER bdproject.before_insert_user
before insert on bdproject.userdb
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_user;

create or replace TRIGGER before_up_catalog_descr
before insert or update of description_catalog
on catalog
for each row
begin
    insert into logdb (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.description_catalog,
    :new.description_catalog);
end before_up_catalog_descr;

create or replace TRIGGER before_update_administrative
before insert or update of id_dedication
on administrative
for each row
BEGIN
    INSERT INTO logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'Change of Dedication',(SELECT description_dedication from dedication
    where :old.id_dedication = dedication.id_dedication),(SELECT description_dedication from dedication
    where :new.id_dedication = dedication.id_dedication));
END before_update_administrative;

create or replace TRIGGER before_update_administrator
BEFORE INSERT OR UPDATE OF password_admin
on administrator
for each row
begin 
    INSERT INTO logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'PASSWORD CHANGE',:old.password_admin,:new.password_admin);
end before_update_administrator;

create or replace TRIGGER before_update_art_pub_date
before insert or update of publication_date
on article
for each row
BEGIN
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES (s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'PUBLICATION DATE CHANGE',CAST(:old.publication_date AS VARCHAR2(1000)),
    CAST(:new.publication_date AS VARCHAR2(1000)));
end before_update_art_pub_date;

create or replace TRIGGER before_update_artcat_descrp
before insert or update of description_category
on articlecategory
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'DESCRIPTION CHANGED',:old.description_category,:new.description_category);
END before_update_artcat_descrp;

create or replace TRIGGER bdproject.before_update_article
before update on bdproject.article
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_article;

create or replace TRIGGER before_update_article_cat_name
before insert or update of name_category
on articlecategory
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.name_category,:new.name_category);
end before_update_article_cat_name;

create or replace TRIGGER before_update_article_category
before insert or update of id_art_cat
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'CATEGORY CHANGED',(SELECT name_category from articlecategory
    where :old.id_art_cat = articlecategory.id_article_category),(SELECT name_category from articlecategory
    where :new.id_art_cat = articlecategory.id_article_category));
end before_update_article_category;

create or replace TRIGGER before_update_article_committe
before insert or update of id_committe_art
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'COMMITTE CHANGED',(SELECT description_committe from committe
    where :old.id_committe_art = committe.id_committe),(SELECT description_committe from committe
    where :new.id_committe_art = committe.id_committe));
END before_update_article_committe;

create or replace TRIGGER before_update_article_date
before insert or update of publication_date
on article
for each row
BEGIN
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'PUBLICATION DATE CHANGE',CAST(:old.publication_date as varchar2(1000)),
    cast(:new.publication_date as Varchar2(1000)));
end before_update_article_date;

create or replace TRIGGER before_update_article_note
before insert or update of text_note
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NOTE CHANGE',:old.text_note,:new.text_note);
end before_update_article_note;

create or replace TRIGGER before_update_article_paper
before insert or update of id_dig_news
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NEWSPAPER CHANGED',(SELECT name_digital_newspaper from digitalnewspaper
    where :old.id_dig_news = digitalnewspaper.id_digital_newspaper),(SELECT  name_digital_newspaper from digitalnewspaper
    where :new.id_dig_news = digitalnewspaper.id_digital_newspaper));
end before_update_article_paper;

create or replace TRIGGER before_update_article_status
before insert or update of id_status_article
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NEW ARTICLE STATUS',(SELECT name_status from status
    where :old.id_status_article = status.id_status),(SELECT  name_status from status
    where :new.id_status_article = status.id_status));
end before_update_article_status;

create or replace TRIGGER before_update_article_title
before insert or update of title_article
on article
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'TITLE CHANGE',:old.title_article,:new.title_article);
END before_update_article_title;

create or replace TRIGGER bdproject.before_update_articlecategory
before update on bdproject.articlecategory
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_articlecategory;

create or replace TRIGGER bdproject.before_update_author
before update on bdproject.author
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_author;

create or replace TRIGGER before_update_author_category
before insert or update of id_author_cathegory
on author
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'CATEGORY CHANGED',(SELECT type_category from authorcategory
    where :old.id_author_cathegory = authorcategory.id_author_category),(SELECT type_category from authorcategory
    where :new.id_author_cathegory = authorcategory.id_author_category));
END before_update_author_category;
create or replace TRIGGER before_update_authorcat_type
before insert or update of type_category
on authorcategory
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'TYPE CHANGED',:old.type_category,:new.type_category);
    commit;
END  before_update_authorcat_type;

create or replace TRIGGER bdproject.before_update_authorcategory
before update on bdproject.authorcategory
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_authorcategory;

create or replace TRIGGER bdproject.before_update_authorxarticle
BEFORE UPDATE ON bdproject.authorxarticle
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_authorxarticle;

create or replace TRIGGER bdproject.before_update_availabilitypr
BEFORE UPDATE ON bdproject.availabilitypr
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_availabilitypr;

create or replace TRIGGER before_update_available_descrp
before insert or update of description_availability
on availabilitypr
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'AVAILABILITY DESCR CAHNGED',:old.description_availability,
    :new.description_availability);
end  before_update_available_descrp;

create or replace TRIGGER bdproject.before_update_campus
BEFORE UPDATE ON bdproject.campus
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_campus;

create or replace TRIGGER before_update_campus_district
before insert or update of id_district
on campus
for each row
begin
     insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'DISTRICT CHANGED',(SELECT name_district from district
    where :old.id_district = district.id_district),(SELECT name_district from district
    where :new.id_district = district.id_district));
end  before_update_campus_district;

create or replace TRIGGER before_update_campus_name
before insert or update of name_campus
on campus
for each row
begin
     insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.name_campus,
    :new.name_campus);
end before_update_campus_name;

create or replace TRIGGER before_update_campus_uni
before insert or update of id_university
on campus
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'COLLEGE CHANGED',(SELECT name_college from college
    where :old.id_university = college.id_college),(SELECT name_college from college
    where :new.id_university = college.id_college));
END before_update_campus_uni;

create or replace TRIGGER bdproject.before_update_canton
before update on bdproject.canton
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_canton;

create or replace TRIGGER before_update_canton_area
before insert or update of id_area
on canton
for each row
begin
 insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'AREA CHANGED',(SELECT name_province from province
    where :old.id_area = province.id_province),(SELECT name_province from province
    where :new.id_area = province.id_province));
end before_update_canton_area;

create or replace TRIGGER before_update_canton_name
before insert or update of name_canton
on canton
for each row
begin
    insert into logdb (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.name_canton,
    :new.name_canton);
end before_update_canton_name;

create or replace TRIGGER bdproject.before_update_catalog
before update on bdproject.catalog
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_catalog;

create or replace TRIGGER before_update_catalog_descrp
before insert or update of description_catalog
on catalog
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'DESCRIPTION CHANGED',:old.description_catalog,:new.description_catalog);
end before_update_catalog_descrp;

create or replace TRIGGER before_update_catalog_news
before insert or update of id_newspaper
on catalog
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NEWSPAPER CHANGED',(SELECT name_digital_newspaper from digitalnewspaper
    where :old.id_newspaper = digitalnewspaper.id_digital_newspaper),(SELECT name_digital_newspaper from digitalnewspaper
    where :new.id_newspaper = digitalnewspaper.id_digital_newspaper));
end before_update_catalog_news;

create or replace TRIGGER bdproject.before_update_college
before update on bdproject.college
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_college;

create or replace TRIGGER before_update_college_name
before insert or update of name_college
on college
for each row
begin
    insert into logdb (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.name_college,
    :new.name_college);
END  before_update_college_name;

create or replace TRIGGER bdproject.before_update_committe
before update on bdproject.committe
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_committe;

create or replace TRIGGER before_update_committe_descrp
before insert or update of description_committe
on committe
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'DESCRIPTION CHANGED',:old.description_committe,:new.description_committe);
end before_update_committe_descrp;

create or replace TRIGGER bdproject.before_update_country
before update on bdproject.country
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_country;

create or replace TRIGGER before_update_country_name
before insert or update of name_country
on country
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.name_country,:new.name_country);
end before_update_country_name;

create or replace TRIGGER before_update_dedi_descrp
before insert or update of description_dedication
on dedication
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'DESCRIPTION CHANGED',:old.description_dedication,:new.description_dedication);
end before_update_dedi_descrp;

create or replace TRIGGER bdproject.before_update_dedication
before update on bdproject.dedication
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_dedication;

create or replace TRIGGER bdproject.before_update_digitalNewspaper
before update on bdproject.digitalNewspaper
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_digitalNewspaper;

create or replace TRIGGER bdproject.before_update_district
before update on bdproject.district
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_district;

--Email

create or replace TRIGGER bdproject.before_update_email
before update on bdproject.email
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_email;

create or replace TRIGGER bdproject.before_update_favourite
before update on bdproject.favourite
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_favourite;

create or replace TRIGGER bdproject.before_update_gender
before update on bdproject.gender
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_gender;

create or replace TRIGGER bdproject.before_update_logdb
before update on bdproject.logdb
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_logdb;

create or replace TRIGGER before_update_name_dignews
before insert or update of name_digital_newspaper
on digitalnewspaper
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'NAME CHANGED',:old.name_digital_newspaper,:new.name_digital_newspaper);
end before_update_name_dignews;

create or replace TRIGGER bdproject.before_update_neighbour
before update on bdproject.neighbour
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_neighbour;

create or replace TRIGGER bdproject.before_update_parameterdb
before update on bdproject.parameterdb
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_parameterdb;

create or replace TRIGGER bdproject.before_update_person
before update on bdproject.person
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_person;

create or replace TRIGGER bdproject.before_update_personxcommitte
before update on bdproject.personxcommitte
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_personxcommitte;

create or replace TRIGGER bdproject.before_update_phone
before update on bdproject.phone
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_phone;

create or replace TRIGGER bdproject.before_update_phonecategory
before update on bdproject.phonecategory
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_phonecategory;

create or replace TRIGGER bdproject.before_update_photo
before update on bdproject.photo
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_photo;

create or replace TRIGGER bdproject.before_update_product
before update on bdproject.product
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_product;

create or replace TRIGGER bdproject.before_update_productxauthor
before update on bdproject.productxauthor
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_productxauthor;

create or replace TRIGGER bdproject.before_update_professor
before update on bdproject.professor
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_professor;

create or replace TRIGGER bdproject.before_update_province
before update on bdproject.province
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_province;

create or replace TRIGGER bdproject.before_update_review
before update on bdproject.review
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_review;

create or replace TRIGGER bdproject.before_update_status
before update on bdproject.status
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_status;

create or replace TRIGGER bdproject.before_update_student
before update on bdproject.student
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_student;

create or replace TRIGGER bdproject.before_update_user
before update on bdproject.userdb
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_user;

CREATE OR REPLACE TRIGGER bdproject.before_update_username
before update of user_name
on userdb
for each row
begin
    insert into logdb
    (id_log,systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'USERNAME CHANGED',:old.user_name,:new.user_name);
end before_update_username;

