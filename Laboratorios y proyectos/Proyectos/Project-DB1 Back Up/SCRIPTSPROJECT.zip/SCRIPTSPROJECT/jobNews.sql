BEGIN
DBMS_SCHEDULER.create_job(
    job_name => 'MostLikedNews',
    job_type => 'PLSQL_BLOCK',
    job_action => 'BEGIN list_most_liked_news; END;',
    start_date => SYSDATE,
    repeat_interval => 'FREQ=DAILY;BYHOUR=1;BYMINUTE=0',
    end_date => NULL,
    enabled =>True,
    comments => 'Project JOB'
);
END;