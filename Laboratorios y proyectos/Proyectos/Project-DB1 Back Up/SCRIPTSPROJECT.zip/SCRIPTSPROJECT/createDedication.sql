CREATE TABLE dedication
(
    id_dedication NUMBER(15) CONSTRAINT dedication_iddedication_nn NOT NULL,
    description_dedication VARCHAR2(30) CONSTRAINT dedication_descrp_nn NOT NULL
)