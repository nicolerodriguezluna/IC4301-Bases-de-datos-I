CREATE TABLE articleCategory
(
    id_article_category NUMBER(15) CONSTRAINT artcat_idartcat_nn NOT NULL,
    name_category VARCHAR2(30) CONSTRAINT artcat_namecat_nn NOT NULL,
    description_category VARCHAR2(1000) CONSTRAINT artcat_descrp_nn NOT NULL
)