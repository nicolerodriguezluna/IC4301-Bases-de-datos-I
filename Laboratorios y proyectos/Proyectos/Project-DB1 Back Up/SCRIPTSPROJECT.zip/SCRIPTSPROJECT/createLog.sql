CREATE TABLE logDB
(
    id_log NUMBER(15) CONSTRAINT logDB_idlog_nn NOT NULL,
    systemdate DATE CONSTRAINT logDB_systemdate_nn NOT NULL,
    time_log TIMESTAMP CONSTRAINT logDB_time_nn NOT NULL,
    change_descrp VARCHAR2(100) CONSTRAINT logDB_changedescrp_nn NOT NULL,
    previous_text VARCHAR2(4000) CONSTRAINT logDB_previoustext_nn NOT NULL,
    current_text VARCHAR2(4000) constraint logdb_current_text_nn NOT NULL
);