CREATE OR REPLACE PROCEDURE get_topn_authors_college(pTopn in number,pidCollege in Number, pCursorAuthors OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthors for
    Select count_articles,full_name
    from (select count(id_article_autart) as count_articles,first_name||' '||second_name||' '||first_surname||' '||second_surname as full_name
          from authorxarticle
          inner join person
          on person.id_person = authorxarticle.id_author_autart
          inner join campus
          on person.id_quad = campus.id_campus
          inner join college
          on campus.id_university = college.id_college
          where college.id_college = pidCollege
          group by(id_author_autart,first_name||' '||second_name||' '||first_surname||' '||second_surname)
          order by count_articles desc)
    where rownum<=pTopn;
END;

