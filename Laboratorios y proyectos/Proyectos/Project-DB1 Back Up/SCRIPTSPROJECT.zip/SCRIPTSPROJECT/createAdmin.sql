create table administrator
(
    id_person number(15) CONSTRAINT administrator_idperson_nn NOT NULL
);