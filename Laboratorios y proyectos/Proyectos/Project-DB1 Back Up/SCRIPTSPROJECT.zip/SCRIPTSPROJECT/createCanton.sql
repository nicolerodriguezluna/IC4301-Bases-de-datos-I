CREATE TABLE Canton(
    id_canton NUMBER(15) CONSTRAINT canton_idcanton_nn NOT NULL,
    name_canton VARCHAR2(100) CONSTRAINT canton_namecanton_nn NOT NULL,
    id_area NUMBER(15) CONSTRAINT canton_idarea_nn NOT NULL
);