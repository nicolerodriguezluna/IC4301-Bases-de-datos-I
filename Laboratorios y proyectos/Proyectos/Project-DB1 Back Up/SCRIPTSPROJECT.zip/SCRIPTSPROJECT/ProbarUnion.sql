    SELECT '0-18' as rango,count(1)
    from person
    inner join author
    on person.id_person = author.id_person
    inner join gender
    On person.id_gender = gender.id_gender
    inner join campus
    On campus.id_campus = person.id_quad
    inner join college
    on campus.id_university = college.id_college
    inner join authorxarticle
    on author.id_person = authorxarticle.id_author_autart
    inner join article
    on article.id_article = authorxarticle.id_article_autart
    inner join articlecategory
    on article.id_art_cat = articlecategory.id_article_category
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 0 AND 18 and college.id_college =NVL(NULL,college.id_college) 
           and gender.id_gender =NVL(NULL,gender.id_gender) 
           and articlecategory.id_article_category=NVL(0,articlecategory.id_article_category)
    UNION
    SELECT '19-30' as rango,count(1)
    from person
    inner join author
    on person.id_person = author.id_person
    inner join gender
    On person.id_gender = gender.id_gender
    inner join campus
    On campus.id_campus = person.id_quad
    inner join college
    on campus.id_university = college.id_college
    inner join authorxarticle
    on author.id_person = authorxarticle.id_author_autart
    inner join article
    on article.id_article = authorxarticle.id_article_autart
    inner join articlecategory
    on article.id_art_cat = articlecategory.id_article_category
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 19 AND 30 and college.id_college =NVL(NULL,college.id_college) 
           and gender.id_gender =NVL(NULL,gender.id_gender) 
           and articlecategory.id_article_category=NVL(0,articlecategory.id_article_category)
    UNION
    SELECT '31-45' as rango,count(1)
    from person
    inner join author
    on person.id_person = author.id_person
    inner join gender
    On person.id_gender = gender.id_gender
    inner join campus
    On campus.id_campus = person.id_quad
    inner join college
    on campus.id_university = college.id_college
    inner join authorxarticle
    on author.id_person = authorxarticle.id_author_autart
    inner join article
    on article.id_article = authorxarticle.id_article_autart
    inner join articlecategory
    on article.id_art_cat = articlecategory.id_article_category
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 31 AND 45 and college.id_college =NVL(NULL,college.id_college) 
           and gender.id_gender =NVL(NULL,gender.id_gender) 
           and articlecategory.id_article_category=NVL(0,articlecategory.id_article_category)
    UNION
    SELECT '45-60' as rango,count(1)
    from person
    inner join author
    on person.id_person = author.id_person
    inner join gender
    On person.id_gender = gender.id_gender
    inner join campus
    On campus.id_campus = person.id_quad
    inner join college
    on campus.id_university = college.id_college
    inner join authorxarticle
    on author.id_person = authorxarticle.id_author_autart
    inner join article
    on article.id_article = authorxarticle.id_article_autart
    inner join articlecategory
    on article.id_art_cat = articlecategory.id_article_category
     where (trunc(sysdate - person.datebirth)/365) BETWEEN 45 AND 60 and college.id_college =NVL(NULL,college.id_college) 
           and gender.id_gender =NVL(NULL,gender.id_gender) 
           and articlecategory.id_article_category=NVL(0,articlecategory.id_article_category)
    UNION
    SELECT '61-75' as rango,count(1)
    from person
    inner join author
    on person.id_person = author.id_person
    inner join gender
    On person.id_gender = gender.id_gender
    inner join campus
    On campus.id_campus = person.id_quad
    inner join college
    on campus.id_university = college.id_college
    inner join authorxarticle
    on author.id_person = authorxarticle.id_author_autart
    inner join article
    on article.id_article = authorxarticle.id_article_autart
    inner join articlecategory
    on article.id_art_cat = articlecategory.id_article_category
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 61 AND 75 and college.id_college =NVL(NULL,college.id_college) 
           and gender.id_gender =NVL(NULL,gender.id_gender) 
           and articlecategory.id_article_category=NVL(0,articlecategory.id_article_category)
    UNION
    SELECT '75-' as rango,count(1)
    from person
    inner join author
    on person.id_person = author.id_person
    inner join gender
    On person.id_gender = gender.id_gender
    inner join campus
    On campus.id_campus = person.id_quad
    inner join college
    on campus.id_university = college.id_college
    inner join authorxarticle
    on author.id_person = authorxarticle.id_author_autart
    inner join article
    on article.id_article = authorxarticle.id_article_autart
    inner join articlecategory
    on article.id_art_cat = articlecategory.id_article_category
    where (trunc(sysdate - person.datebirth)/365) >75 and college.id_college =NVL(NULL,college.id_college) 
           and gender.id_gender =NVL(NULL,gender.id_gender) 
           and articlecategory.id_article_category=NVL(0,articlecategory.id_article_category);