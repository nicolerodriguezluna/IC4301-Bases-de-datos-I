ALTER TABLE email
ADD CONSTRAINT fk_email_idperson FOREIGN KEY (id_person_mail) REFERENCES person(id_person)
