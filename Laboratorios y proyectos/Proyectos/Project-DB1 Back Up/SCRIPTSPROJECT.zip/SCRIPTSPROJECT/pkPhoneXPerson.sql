ALTER TABLE phonexperson 
ADD CONSTRAINT pk_phonexperson PRIMARY KEY (number_phone, id_person_pp)
USING INDEX
TABLESPACE bdproject_ind PCTFREE 20
STORAGE (INITIAL 10K NEXT 10K PCTINCREASE 0)
