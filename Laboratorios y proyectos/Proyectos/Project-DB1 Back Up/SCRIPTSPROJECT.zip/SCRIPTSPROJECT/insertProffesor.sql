insert into professor
(id_person,id_dedication, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (13,0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into professor
(id_person,id_dedication, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (14,0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

