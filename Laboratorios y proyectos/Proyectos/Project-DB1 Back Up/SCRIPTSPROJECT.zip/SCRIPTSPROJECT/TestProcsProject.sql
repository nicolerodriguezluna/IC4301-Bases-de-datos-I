DECLARE
vcTitle VARCHAR2(1000);
vnNumber NUMBER;
vcTextNote VARCHAR2(4000);
vcPublication VARCHAR2(1000);
pCursorCategories SYS_REFCURSOR;
BEGIN
    get_article_bydate('2022-08-16',pCursorCategories);
    LOOP
        FETCH pCursorCategories
        INTO vcTitle,vcTextNote,vcPublication;
        EXIT WHEN pCursorCategories%NOTFOUND;
        dbms_output.put_line(vcTitle||' '||vcTextNote||' '||vcPublication);
    END LOOP;
    CLOSE pCursorCategories;
END;