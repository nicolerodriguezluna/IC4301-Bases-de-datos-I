DECLARE
 vDedication VARCHAR2(1000);
BEGIN
    vDedication:= get_administrative_dedication(15);
    dbms_output.put_line(vDedication);
END;