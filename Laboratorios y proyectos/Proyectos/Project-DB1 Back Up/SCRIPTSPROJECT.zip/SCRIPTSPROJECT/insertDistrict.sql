INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Carmen',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Catedral',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');
INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Hatillo',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Hospital',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'La Uruca',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Mata Redonda',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Merced',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Pavas',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Francisco de dos R�os',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Sebasti�n',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Zapote',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');




INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Cangrejal',1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Guaitil',1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Palmichal',1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Sabanillas',1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Ignacio',1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Alajuelita',2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Concepci�n',2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Antonio',2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Felipe',2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Josecito',2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Aserr�',3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Legua',3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Monterrey',3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Salitrillos',3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Gabriel',3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Tarbaca',3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Vuelta de Jorco',3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Curridabat',4,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Granadilla',4,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'S�nchez',4,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Tirrases',4,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Damas',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Desamparados',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Frailes',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Gravilias',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Los Guido',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Patarr�',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Rosario',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Antonio',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Crist�bal',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Juan de Dios',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Miguel',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Rafael Abajo',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Rafael Arriba',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Copey',6,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Jard�n',6,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Santa Mar�a',6,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Escaz�',7,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Antonio',7,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Rafael',7,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');




INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Calle Blancos',8,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Guadalupe',8,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Ip�s',8,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Mata de Pl�tano',8,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Purral',8,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Rancho Redondo',8,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Francisco',8,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Pablo',9,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Andr�s',9,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Llano Bonito',9,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Isidro',9,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Santa Cruz',9,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Antonio',9,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Mercedes',10,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Sabanilla',10,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Pedro',10,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Rafael',10,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Cuidad Col�n',11,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Guayabo',11,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Jaris',11,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Picagres',11,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Piedras Negras',11,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Tabarcia',11,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Jer�nimo',12,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Vicente',12,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Trinidad',12,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Isidro de El General',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Bar�',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Caj�n',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Daniel Flores',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'El General',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'La Amistad',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'P�ramo',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Pejibaye',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Platanares',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'R�o Nuevo',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Rivas',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Pedro',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Barbacoas',14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Candelarita',14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Chires',14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Desamparaditos',14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Grifo Alto',14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Mercedes Sur',14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Antonio',14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Rafael',14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Santiago',14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Brasil',15,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Piedades',15,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Pozos',15,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Salitral',15,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Santa Ana',15,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Uruca',15,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Carlos',16,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Lorenzo',16,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Marcos',16,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Anselmo Llorente',17,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Cinco Esquinas',17,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Colima',17,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Le�n XIII',17,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Juan',17,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Carara',18,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Juan de Mata',18,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Luis',18,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Pablo',18,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Pedro',18,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Cascajal',19,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Dulce Nombre de Jes�s',19,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Patalillo',19,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Isidro',19,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Rafael',19,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Oriental' ,20,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Occidental' ,20,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Carmen' ,20,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Nicol�s',20,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Aguacaliente' ,20,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Guadalupe' ,20,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Corralillo' ,20,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tierra Blanca' ,20,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Dulce Nombre' ,20,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Llano Grande' ,20,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Quebradilla' ,20,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Para�so' ,21,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santiago' ,21,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Orosi' ,21,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cach�',21,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Llanos de Santa Luc�a' ,21,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Birrisito' ,21,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tres R�os' ,22,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Diego' ,22,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Juan' ,22,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Rafael' ,22,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Concepci�n' ,22,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Dulce Nombre' ,22,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Ram�n' ,22,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'R�o Azul' ,22,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Juan Vi�as',23,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tucurrique' ,23,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pejibaye' ,23,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Victoria' ,23,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Turrialba' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Suiza' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Peralta' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Cruz' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Teresita' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pavones' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tuis' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tayutic' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Rosa' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tres Equis' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Isabel' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Chirrip�' ,24,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pacayas' ,25,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cervantes' ,25,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Capellades' ,25,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Rafael' ,26,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cot' ,26,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Potrero Cerrado' ,26,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cipreses' ,26,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Rosa' ,26,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'El Tejar' ,27,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Isidro' ,27,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tobosi' ,27,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Patio de Agua' ,27,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Puntarenas' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pitahaya' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Chomes' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Lepanto' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Paquera' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Manzanillo' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Guacimal' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Barranca' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Isla del Coco' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'C�bano' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Chacarita' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Chira' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Acapulco' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'El Roble' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Arancibia' ,28,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');




INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Esp�ritu Santo' ,29,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Juan Grande' ,29,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Maracona' ,29,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Rafael' ,29,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Jer�nimo' ,29,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Caldera' ,29,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Buenos Aires' ,30,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Volc�n' ,30,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Potrero Grande' ,30,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Boruca' ,30,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pilas' ,30,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Colinas' ,30,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Ch�nguena' ,30,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Biolley' ,30,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Brunca' ,30,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Miramar' ,31,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Uni�n' ,31,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Isidro' ,31,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Puerto Cort�s' ,32,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Palmar' ,32,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Sierpe' ,32,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Piedras Blancas' ,32,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bah�a Ballena' ,32,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bah�a Drake' ,32,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Quepos' ,33,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Savegre' ,33,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Naranjito' ,33,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Golfito' ,34,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Guaycar�' ,34,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pav�n' ,34,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Vito' ,35,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Sabalito' ,35,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Agua Buena' ,35,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Limonsito' ,35,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pittier' ,35,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Gutierr�z Braun' ,35,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Parrita' ,36,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Corredor' ,37,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Cuesta' ,37,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Canoas' ,37,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Laurel' ,37,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Jac�' ,38,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'T�rcoles' ,38,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Monteverde' ,39,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Puerto Jim�nez' ,40,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Alajuela' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Jos�' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Carrizal' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Antonio' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Gu�cima' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Isidro' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Sabanilla' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Rafael' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'R�o Segundo' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Desamparados' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Turr�cares' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tambor' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Garita' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Sarapiqu�' ,41,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Ram�n' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santiago' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Juan' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Piedades Norte' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Piedades Sur' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Rafael' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Isidro' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, '�ngeles' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Alfaro' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Volio' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Concepci�n' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Zapotal' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pe�as Blancas' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Lorenzo' ,42,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Grecia' ,43,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Isidro' ,43,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Jos�' ,43,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Roque' ,43,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tacares' ,43,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Puente de Piedra' ,43,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bol�var' ,43,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Mateo' ,44,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Desmonte' ,44,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Jes�s Mar�a' ,44,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Labrador' ,44,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Atenas' ,45,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Jes�s' ,45,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Mercedes' ,45,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Isidro' ,45,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Concepci�n' ,45,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Jos�' ,45,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Eulalia' ,45,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Escobal' ,45,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Naranjo' ,46,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Miguel' ,46,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Jos�' ,46,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cirr� Sur' ,46,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Jer�nimo' ,46,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Juan' ,46,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'El Rosario' ,46,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Palmitos' ,46,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Palmares' ,47,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Zaragoza' ,47,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Buenos Aires' ,47,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santiago' ,47,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Candelaria' ,47,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Esquipulas' ,47,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Granja' ,47,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Pedro' ,48,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Juan' ,48,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Rafael' ,48,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Carrillos' ,48,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Sabanda Redonda' ,48,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Orotina' ,49,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'El Mastate' ,49,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Hacienda Vieja' ,49,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Coyolar' ,49,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Ceiba' ,49,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Quesada' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Florencia' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Buenavista' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Aguas Zarcas' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Venecia' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pital' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Fortuna' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Tigra' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Palmera' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Venado' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cutris' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Monterrey' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pocosol' ,50,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Zarcero' ,51,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Laguna' ,51,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tapesco' ,51,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Guadalupe' ,51,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Palmira' ,51,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Zapote' ,51,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Brisas' ,51,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Sarch� Norte'  ,52,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Sarch� Sur' ,52,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Toro Amarillo' ,52,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Pedro' ,52,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Rodr�guez' ,52,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Upala' ,53,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Aguas Claras' ,53,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Jos�' ,53,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bijagua' ,53,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Delicias' ,53,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Dos R�os' ,53,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Yolillal' ,53,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Canalete' ,53,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Los Chiles' ,54,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Ca�o Negro' ,54,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'El Amparo' ,54,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Jorge' ,54,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Rafael' ,55,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Buenavista' ,55,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cote' ,55,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Katira' ,55,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'R�o Cuarto' ,56,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Rita' ,56,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Isabel' ,56,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Heredia',57,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Mercedes',57,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Francisco',57,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Ulloa',57,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Varablanca',57,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Barva',58,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Jos� de la Monta�a',58,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Pablo',58,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Pedro',58,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Roque',58,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Santa Luc�a',58,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'La asunci�n',59,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'La Ribera',59,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Antonio',59,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Barrantes',60,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Llorente',60,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Joaqu�n',60,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Concepci�n',61,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Francisco',61,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Isidro',61,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Jos�',61,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Rinc�n de Sabanilla',62,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Pablo',62,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'�ngeles',63,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Concepci�n',63,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Josecito',63,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Rafael',63,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Santiago',63,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Jes�s',64,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Purab�',64,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Juan',64,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Pedro',64,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Santa B�rbara',64,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Santo Domingo',64,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Par�',65,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Paracito',65,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Miguel',65,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'San Vicente',65,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Santa Rosa',65,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Santo Domingo',65,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Santo Tom�s',65,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Tures',65,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Cure�a',66,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'La Virgen',66,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Las Horquetas',66,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Llanuras del Gaspar',66,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval,'Puerto Viejo',66,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Liberia' ,67,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Ca�as Dulces' ,67,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Mayorga' ,67,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Nacascolo' ,67,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Curuband�' ,67,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Nicoya' ,68,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Mansi�n' ,68,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Antonio' ,68,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Quebrada Honda' ,68,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'S�mara' ,68,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Nosara' ,68,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bel�n de Nosarita' ,68,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Cruz' ,69,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bols�n' ,69,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Veintisiete de Abril' ,69,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tempate' ,69,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cartagena' ,69,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cuajiniquil' ,69,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Diri�' ,69,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cabos Velas' ,69,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tamarindo' ,69,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bagaces' ,70,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Fortuna' ,70,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Mogote' ,70,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'R�o Naranjo' ,70,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Filadelfia' ,71,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Palmira' ,71,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Sardinal' ,71,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bel�n' ,71,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Ca�as' ,72,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Palmira' ,72,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Miguel' ,72,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bebedero' ,72,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Porozal' ,72,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Las Juntas' ,73,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Sierra' ,73,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Juan' ,73,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Colorado' ,73,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tilar�n' ,74,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Quebrada Grande' ,74,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tronadora' ,74,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Rosa' ,74,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'L�bano' ,74,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Tierras Morenas' ,74,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Arenal' ,74,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cabeceras' ,74,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Carmona' ,75,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Rita' ,75,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Zapotal' ,75,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'San Pablo' ,75,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Porvenir' ,75,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bejuco' ,75,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Cruz' ,76,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Cecilia' ,76,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Garita' ,76,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Santa Elena' ,76,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Hojancha' ,77,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Monte Romo' ,77,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Puerto Carrillo' ,77,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Huacas' ,77,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Matamb�' ,77,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Lim�n' ,78,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Valle La Estrella' ,78,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'R�o Blanco' ,78,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Matama' ,78,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Gu�piles' ,79,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Jim�nez' ,79,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Rita' ,79,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Roxana' ,79,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cariari' ,79,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Colorado' ,79,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');



INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'La Corona' ,79,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Siquirres' ,80,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pacuarito' ,80,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Florida' ,80,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Germania' ,80,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cairo' ,80,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Alegr�a' ,80,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Reventaz�n' ,80,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bratsi' ,81,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Sixaola' ,81,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Cahuita' ,81,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Telire' ,81,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Matina' ,82,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Bat�n' ,82,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Carrandi' ,82,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Gu�cimo' ,83,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Mercedes' ,83,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Pocora' ,83,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'R�o Jim�nez' ,83,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO DISTRICT
(id_district,name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_district.nextval, 'Duacar�' ,83,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');
