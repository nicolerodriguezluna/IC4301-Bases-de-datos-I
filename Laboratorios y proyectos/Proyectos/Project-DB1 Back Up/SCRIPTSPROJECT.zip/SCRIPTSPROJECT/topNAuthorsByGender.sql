CREATE OR REPLACE PROCEDURE get_topn_authors_gender(pTopn in number,pidGender in Number, pCursorAuthors OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthors for
    Select count_articles,full_name
    from (select count(id_article_autart) as count_articles,first_name||' '||second_name||' '||first_surname||' '||second_surname as full_name
          from authorxarticle
          inner join person
          on person.id_person = authorxarticle.id_author_autart
          inner join gender
          on person.id_gender = gender.id_gender
          where person.id_gender = pidGender
          group by(id_author_autart,first_name||' '||second_name||' '||first_surname||' '||second_surname)
          order by count_articles desc)
    where rownum<=pTopn;
END;

