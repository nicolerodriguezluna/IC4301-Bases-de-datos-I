SELECT title_article,publication_date,first_name,second_name,first_surname,second_surname,name_category
from article art --art is article
inner join authorxarticle autart --autart is authorxarticle
On art.id_article = autart.id_article_autart
inner join author aut --aut is author
On autart.id_author_autart = aut.id_person
inner join person p -- p is person
On p.id_person = aut.id_person
inner join articlecategory artcat --artcat is article category
ON art.id_art_cat = artcat.id_article_category
ORDER BY publication_date DESC; --Orders the query by descending order.
