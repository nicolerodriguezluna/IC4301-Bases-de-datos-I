create or replace FUNCTION get_author_spent_points(idAuthor in number) return integer
is
spentPoints number;
BEGIN
SELECT COALESCE(sum(cost_product),0)
into spentPoints
from product
inner join productxauthor
on productxauthor.id_product_pa = product.id_product
where productxauthor.id_author_pa = idAuthor;
return (spentPoints);
END;
