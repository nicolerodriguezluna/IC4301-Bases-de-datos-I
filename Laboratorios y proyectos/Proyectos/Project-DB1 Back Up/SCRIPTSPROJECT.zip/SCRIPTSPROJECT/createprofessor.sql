create table professor
(
    id_person number(15) CONSTRAINT professor_idperson_nn NOT NULL,
    id_dedication number(15) CONSTRAINT professor_iddedication_nn NOT NULL
);