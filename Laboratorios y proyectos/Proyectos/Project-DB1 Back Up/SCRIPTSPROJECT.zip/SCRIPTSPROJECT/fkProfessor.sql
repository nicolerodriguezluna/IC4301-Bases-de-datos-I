ALTER TABLE professor ADD CONSTRAINT fk_professor_idperson FOREIGN KEY (id_person) REFERENCES person (id_person)
