ALTER TABLE phonexperson
ADD CONSTRAINT fk_phonexperson_numberphone FOREIGN KEY (number_phone) REFERENCES phone(number_phone)
ADD CONSTRAINT fk_phonexperson_idpersonpp FOREIGN KEY (id_person_pp) REFERENCES person(id_person)
