INSERT INTO phonecategory
(id_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_phcategory.nextval,'Celular',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO phonecategory
(id_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_phcategory.nextval,'Casa',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO phonecategory
(id_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_phcategory.nextval,'Oficina',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT')
