declare
vcTitle VARCHAR2(1000);
vcPublicationDate DATE;
vcStatus VARCHAR2(1000);
vcNameCategory VARCHAR2(1000);
containsNews SYS_REFCURSOR;
BEGIN
    get_news_date(containsNews);
    LOOP
        FETCH containsNews
        INTO vcTitle,vcPublicationDate,vcStatus,vcNameCategory;
        EXIT WHEN containsNews%NOTFOUND;
        dbms_output.put_line(vcTitle||' '||vcPublicationDate||' '||vcStatus||''||vcNameCategory);
    END LOOP;
    CLOSE containsNews;
END;