ALTER TABLE committe
add description_committe VARCHAR2(100) CONSTRAINT commite_descr_nn NOT NULL;