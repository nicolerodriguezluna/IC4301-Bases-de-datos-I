SELECT job_name,job_class,operation,status from USER_SCHEDULER_JOB_LOG

Begin
  Dbms_Scheduler.Drop_Job (Job_Name => 'MostLikedNews');
END;