ALTER TABLE canton
ADD CONSTRAINT fk_canton_idprovince FOREIGN KEY (id_area) REFERENCES province (id_province)
