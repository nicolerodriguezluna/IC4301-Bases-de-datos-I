CREATE TABLE phoneType(
    id_phone_type NUMBER(4) CONSTRAINT id_phoneType_nn NOT NULL,
    description_type VARCHAR2(30) CONSTRAINT phoneType_description_nn NOT NULL,
    creationDate TIMESTAMP CONSTRAINT phoneType_crDate_nn NOT NULL,
    creationUser VARCHAR2(30) CONSTRAINT phoneType_crUser_nn NOT NULL,
    lastModifyDate TIMESTAMP  CONSTRAINT phoneType_lastModifydate_nn NOT NULL,
    lastModifyUser VARCHAR2(30) CONSTRAINT phoneType_lastModifyUser_nn NOT NULL
);

CREATE TABLE phone(
    id_phone NUMBER(15) CONSTRAINT phone_idphone_nn NOT NULL,
    number_phone NUMBER(8) CONSTRAINT phone_numberphone_nn NOT NULL,
    id_phone_type NUMBER(4) CONSTRAINT phone_phonetype_nn NOT NULL,
    id_person NUMBER(15) CONSTRAINT phone_idperson_nn NOT NULL,
    creationDate TIMESTAMP  CONSTRAINT phone_crDate_nn NOT NULL,
    creationUser VARCHAR2(30) CONSTRAINT phone_crUser_nn NOT NULL,
    lastModifyDate TIMESTAMP  CONSTRAINT phone_lastModifydate_nn NOT NULL,
    lastModifyUser VARCHAR2(30)CONSTRAINT phone_lastModifyUser_nn NOT NULL
);

CREATE TABLE person(
    id_person number(15) CONSTRAINT person_idperson_nn NOT NULL,
    name_person VARCHAR2(30) CONSTRAINT person_name_nn NOT NULL,
    last_name VARCHAR2(30) CONSTRAINT person_lastname_nn NOT NULL,
    salary NUMBER(38) CONSTRAINT person_salary_nn NOT NULL,
    creationDate TIMESTAMP  CONSTRAINT person_crDate_nn NOT NULL,
    creationUser VARCHAR2(30) CONSTRAINT person_crUser_nn NOT NULL,
    lastModifyDate TIMESTAMP  CONSTRAINT person_lastmodifydate_nn NOT NULL,
    lastModifyUser VARCHAR2(30) CONSTRAINT person_lastmodifyuser_nn NOT NULL
);