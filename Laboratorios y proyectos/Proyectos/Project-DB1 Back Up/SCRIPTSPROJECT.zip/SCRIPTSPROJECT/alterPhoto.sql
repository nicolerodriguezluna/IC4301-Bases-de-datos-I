alter table photo
add id_user NUMBER(15);

alter table photo
add id_product NUMBER(15);

ALTER TABLE PHOTO
ADD CONSTRAINT photo_iduser_fk foreign key (id_user) references userdb(id_user);

ALTER TABLE photo
ADD CONSTRAINT photo_idproduct_fk foreign key (id_product) references product(id_product);