INSERT INTO status
(id_status,name_status, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_status.nextval,'Aprobado',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO status
(id_status,name_status, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_status.nextval,'Pendiente',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO status
(id_status,name_status, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_status.nextval,'Rechazado',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');
