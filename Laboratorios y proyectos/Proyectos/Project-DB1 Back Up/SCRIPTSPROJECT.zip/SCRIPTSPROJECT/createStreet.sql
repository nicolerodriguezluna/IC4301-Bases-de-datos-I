CREATE TABLE street(
    id_street NUMBER(15) CONSTRAINT street_idstreet_nn NOT NULL,
    name_street VARCHAR2(100) CONSTRAINT street_namestreet_nn NOT NULL,
    id_location NUMBER(15) CONSTRAINT street_idlocation_nn NOT NULL
);