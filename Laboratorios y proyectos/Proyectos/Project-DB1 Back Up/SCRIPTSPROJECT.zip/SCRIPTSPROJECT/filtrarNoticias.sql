CREATE OR REPLACE PROCEDURE get_news_filter(pNameAuthor IN VARCHAR2,pArticleCategory IN VARCHAR2,pDate IN DATE,pCursorNews out SYS_REFCURSOR)
AS
  BEGIN
    OPEN pCursorNews for
    SELECT first_name||' '||second_name||' '||first_surname||' '||second_surname as name,description_category,title_article,publication_date
    from article
    inner join articlecategory
    on article.id_art_cat = articlecategory.id_article_category
    inner join authorxarticle
    ON authorxarticle.id_article_autart = article.id_article
    inner join author
    ON author.id_person = authorxarticle.id_author_autart
    inner join person
    ON author.id_person = person.id_person
    where articlecategory.name_category = pArticleCategory AND article.publication_date = pDate AND first_name||' '||second_name||' '||first_surname||' '||second_surname = pNameAuthor;
 END;
    
    