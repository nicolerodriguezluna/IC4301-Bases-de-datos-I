INSERT INTO availabilitypr
(id_availability,description_availability,creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_availabilitypr.nextval,'Disponible',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO availabilitypr
(id_availability,description_availability,creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_availabilitypr.nextval,'Agotado',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


