CREATE OR REPLACE FUNCTION get_author_total_points(idAuthor in number) return integer
is
totalPoints number;
BEGIN
    Select sum(stars)
    into totalPoints
    from review
    inner join article
    on review.id_article_rev = article.id_article
    inner join authorxarticle
    on authorxarticle.id_article_autart = article.id_article
    where authorxarticle.id_author_autart = idAuthor;
    return (totalPoints);
END;
    