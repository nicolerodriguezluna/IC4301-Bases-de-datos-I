CREATE TABLE availabilityPR
(
    id_availability NUMBER(1) CONSTRAINT availabilitypr_avai_nn NOT NULL,
    description_availability VARCHAR2(100) CONSTRAINT availabilitypr_descrp_nn NOT NULL
)