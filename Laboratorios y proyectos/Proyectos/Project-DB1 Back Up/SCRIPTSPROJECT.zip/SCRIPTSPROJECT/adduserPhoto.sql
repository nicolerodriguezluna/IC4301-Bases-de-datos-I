ALTER TABLE userDB
add id_photo NUMBER(38) CONSTRAINT userDB_idphoto_nn NOT NULL
