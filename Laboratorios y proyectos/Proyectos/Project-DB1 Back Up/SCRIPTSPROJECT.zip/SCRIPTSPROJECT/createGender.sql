CREATE TABLE gender
(
  id_gender NUMBER(15) CONSTRAINT gender_idgender_nn NOT NULL,
  type_gender VARCHAR2(20) CONSTRAINT gender_typegender_nn NOT NULL
);