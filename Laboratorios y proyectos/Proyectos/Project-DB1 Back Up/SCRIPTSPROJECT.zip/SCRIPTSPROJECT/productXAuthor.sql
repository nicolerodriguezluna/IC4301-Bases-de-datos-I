INSERT INTO productxauthor
(id_product_pa,id_author_pa)
VALUES (0,19);

INSERT INTO productxauthor
(id_product_pa,id_author_pa)
VALUES (1,19);

INSERT INTO productxauthor
(id_product_pa,id_author_pa)
VALUES (2,20);

INSERT INTO productxauthor
(id_product_pa,id_author_pa)
VALUES (3,20);