CREATE TABLE college
(
    id_college NUMBER(15) CONSTRAINT college_idcollege_nn NOT NULL,
    name_college VARCHAR2(100) CONSTRAINT college_namecollege_nn NOT NULL
    
);