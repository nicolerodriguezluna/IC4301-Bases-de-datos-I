CREATE OR REPLACE PROCEDURE get_author_articles(pCursorAuthorArticle out SYS_REFCURSOR)
AS
  BEGIN
     OPEN pCursorAuthorArticle FOR
     SELECT COUNT(id_article_autart) as totalArticle,first_name||' '||second_name||' '||first_surname||' '||second_surname as complete_name
     from authorxarticle
     inner join author
     On author.id_person = authorxarticle.id_author_autart
     inner join person
     on author.id_person = person.id_person 
     where author.id_person = authorxarticle.id_author_autart
     group by first_name||' '||second_name||' '||first_surname||' '||second_surname
     ORDER BY (totalArticle) DESC;
  END;