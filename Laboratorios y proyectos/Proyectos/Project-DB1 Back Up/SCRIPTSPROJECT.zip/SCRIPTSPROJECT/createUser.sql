CREATE TABLE userDB(
    id_user NUMBER(15) CONSTRAINT user_iduser_nn NOT NULL,
    password_user VARCHAR2(100) CONSTRAINT user_passworduser_nn NOT NULL,
    id_log NUMBER(15) CONSTRAINT user_idlog_nn NOT NULL,
    id_person NUMBER(15) CONSTRAINT user_idperson_nn NOT NULL
);