CREATE OR REPLACE PROCEDURE get_committees(pCursorCommittees out sys_refcursor)
AS
BEGIN
    Open pCursorcommittees for
    select id_committe,description_committe
    from committe
    ORDER BY(description_committe)desc;
END;

CREATE OR REPLACE PROCEDURE get_committee(pidCommittee in number, pCursorCommittee out sys_refcursor)
AS
BEGIN
    Open pCursorcommittee for
    select id_committe,description_committe
    from committe
    where id_committe = pidCommittee;
END;
    
CREATE OR REPLACE PROCEDURE get_countries(pCursorCountries out sys_refcursor)
AS
BEGIN
    Open pCursorCountries for
    select id_country,name_country
    from country
    ORDER BY(name_country)desc;
END;

CREATE OR REPLACE PROCEDURE get_country(pindCountry in number, pCursorCountry out sys_refcursor)
AS
BEGIN
    Open pCursorCountry for
    select id_country,name_country
    from country
    where id_country = pindCountry;
END;

CREATE OR REPLACE PROCEDURE get_dedications(pCursorDedications out sys_refcursor)
AS
BEGIN
    Open pCursorDedications for
    select id_dedication,description_dedication
    from dedication
    ORDER BY(description_dedication)desc;
END;


CREATE OR REPLACE PROCEDURE get_dedication(pindDedication in Number, pCursorDedication out sys_refcursor)
AS
BEGIN
    Open pCursorDedication for
    select id_dedication,description_dedication
    from dedication
    where id_dedication = pindDedication;
END;


CREATE OR REPLACE PROCEDURE get_digital_newspapers(pCursorDigitalNewsPapers out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorDigitalNewsPapers for
    SELECT id_digital_newspaper,name_digital_newspaper,id_quad
    from digitalnewspaper
    ORDER BY(name_digital_newspaper)desc;
END;

CREATE OR REPLACE PROCEDURE get_digital_newspaper(pinDNewspaper in Number, pCursorDigitalNewsPaper out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorDigitalNewsPaper for
    SELECT id_digital_newspaper,name_digital_newspaper,id_quad
    from digitalnewspaper
    where id_digital_newspaper = pinDNewspaper;
END;

CREATE OR REPLACE PROCEDURE get_districts(pCursorDistricts out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorDistricts for
    SELECT id_district,name_district,id_sector
    from district
    ORDER BY(name_district)desc;
END;

CREATE OR REPLACE PROCEDURE get_district(pidDistrict in number, pCursorDistrict out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorDistrict for
    SELECT id_district,name_district,id_sector
    from district
    where id_district = piDistrict;
END;

CREATE OR REPLACE PROCEDURE get_emails(pCursorEmails out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorEmails for
    SELECT id_email,address_email,id_person_mail
    from email
    ORDER BY(address_email)desc;
END;

CREATE OR REPLACE PROCEDURE get_emails_person(pidPerson in number, pCursorEmail out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorEmail for
    SELECT id_email,address_email,id_person_mail
    from email
    where id_person_mail = pidPerson
    ORDER BY(address_email);
END;

CREATE OR REPLACE PROCEDURE get_genders(pCursorGenders out sys_refcursor)
AS
BEGIN
    Open pCursorGenders for
    select id_gender,type_gender
    from gender
    ORDER BY(type_gender)desc;
END;

CREATE OR REPLACE PROCEDURE get_gender(pidGender in number, pCursorGender out sys_refcursor)
AS
BEGIN
    Open pCursorGender for
    select id_gender,type_gender
    from gender
    where id_gender = pidGender
    ORDER BY(type_gender);
END;



CREATE OR REPLACE PROCEDURE get_logdbs(pCursorLogDBs out sys_refcursor)
AS
BEGIN
    Open pCursorLogDBs for
    select id_log,systemdate, time_log, change_descrp, previous_text, current_text
    from logdb
    order by(systemdate)desc;
END;


CREATE OR REPLACE PROCEDURE get_logdb(pidLogdb in number, pCursorLogDB out sys_refcursor)
AS
BEGIN
    Open pCursorLogDB for
    select id_log,systemdate, time_log, change_descrp, previous_text, current_text
    from logdb
    where id_log = pidLogdb;
END;

CREATE OR REPLACE PROCEDURE get_parameters(pCursorParameters out sys_refcursor)
AS
BEGIN
    Open pCursorParameters for
    select id_parameter,name_parameter, description_parameter, value_parameter, route
    from parameterdb
    ORDER BY(name_parameter)desc;
END;



CREATE OR REPLACE PROCEDURE get_parameter(pindParameter in number, pCursorParameter out sys_refcursor)
AS
BEGIN
    Open pCursorParameter for
    select id_parameter,name_parameter, description_parameter, value_parameter, route
    from parameterdb
    where id_parameter = pindParameter;
END;



create or replace PROCEDURE get_people(pCursorPeople out sys_refcursor)
AS
BEGIN
    Open pCursorPeople for
    select id_person,first_name,second_name,first_surname,
    second_surname,identification_card,datebirth, id_quad, id_gender, exact_location, id_district
    from person
    ORDER BY(first_name)desc;
END;



CREATE OR REPLACE PROCEDURE get_person(pidPerson in number, pCursorPerson out sys_refcursor)
AS
BEGIN
    Open pCursorPerson for
    select person.id_person,first_name,second_name,first_surname,second_surname,identification_card,datebirth
    from person
    where person.id_person = pidPerson;
END;