INSERT INTO articlecategory
(id_article_category,name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_articlecategory.nextval,'Investigaci�n Cinet�fica','Esta categor�a incluye art�culos relacionados a distintas �reas de la ciencia ',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO articlecategory
(id_article_category,name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_articlecategory.nextval,'Trabajo Social','Esta categor�a incluye art�culos relacionados a distintas �reas del trabajo social',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO articlecategory
(id_article_category,name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_articlecategory.nextval,'Pol�tica','Esta categor�a incluye art�culos relacionados a distintas �reas de la pol�tica',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO articlecategory
(id_article_category,name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_articlecategory.nextval,'Cultura','Esta categor�a incluye art�culos relacionados a distintas �reas de cultura',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO articlecategory
(id_article_category,name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_articlecategory.nextval,'Deportes','Esta categor�a incluye art�culos relacionados a distintas �reas de deportes',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO articlecategory
(id_article_category,name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_articlecategory.nextval,'Sucesos','Esta categor�a incluye art�culos relacionados a distintas �reas de sucesos',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO articlecategory
(id_article_category,name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_articlecategory.nextval,'Opini�n','Esta categor�a incluye art�culos de opini�n sobre diversas materias',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO articlecategory
(id_article_category,name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_articlecategory.nextval,'Ofertas de Trabajo','Esta categor�a incluye art�culos sobre ofertas de trabajo',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT INTO articlecategory
(id_article_category,name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_articlecategory.nextval,'Eventos Sociales','Esta categor�a incluye art�culos de eventos sociales',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO articlecategory
(id_article_category,name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_articlecategory.nextval,'Eventos Ambientales','Esta categor�a incluye art�culos sobre eventos ambientales',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO articlecategory
(id_article_category,name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_articlecategory.nextval,'Eventos Deportivos','Esta categor�a incluye art�culos sobre eventos deportivos',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');