CREATE TABLE personXCommitte
(
    id_person NUMBER(15) CONSTRAINT perxcom_idperson_nn NOT NULL,
    id_committe Number(15) CONSTRAINT perxcom_idcomm_nn NOT NULL
)