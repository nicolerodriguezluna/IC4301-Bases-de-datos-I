CREATE OR REPLACE FUNCTION get_count_author_Two(pCollege IN VARCHAR2, pGender iN VARCHAR2, pTypeNews IN VARCHAR2)RETURN NUMBER
IS
  vnCountAuthor NUMBER(38);
BEGIN
    SELECT COUNT(*)
    into vnCountAuthor
    from person
    inner join author
    on person.id_person = author.id_person
    inner join gender
    On person.id_gender = gender.id_gender
    inner join authorxarticle
    ON authorxarticle.id_author_autart = person.id_person
    inner join article
    on authorxarticle.id_article_autart = article.id_article
    inner join articlecategory
    on article.id_art_cat = articlecategory.id_article_category
    inner join digitalnewspaper
    on article.id_dig_news = digitalnewspaper.id_digital_newspaper
    inner join campus
    on digitalnewspaper.id_quad = campus.id_campus
    inner join college
    on college.id_college = campus.id_university
    where ((sysdate - person.datebirth)/365) BETWEEN 19 AND 30  and college.name_college =NVL(pCollege,college.name_college) 
            and articlecategory.name_category = NVL(pTypeNews,articlecategory.name_category)
            and gender.type_gender =NVL(pGender,gender.type_gender);
    return(vnCountAuthor);
 end;