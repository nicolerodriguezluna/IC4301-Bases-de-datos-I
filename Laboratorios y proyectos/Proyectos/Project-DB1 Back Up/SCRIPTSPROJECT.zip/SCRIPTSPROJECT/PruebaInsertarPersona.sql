INSERT INTO person
(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_direction,id_gender)
VALUES(p_person.nextval,128765456,'Esteban','Francisco','Gonzales','Arias',DATE '2001-09-21',0,0,0);