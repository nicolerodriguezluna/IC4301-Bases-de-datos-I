BEGIN
    insert_professor(1,0);
END;