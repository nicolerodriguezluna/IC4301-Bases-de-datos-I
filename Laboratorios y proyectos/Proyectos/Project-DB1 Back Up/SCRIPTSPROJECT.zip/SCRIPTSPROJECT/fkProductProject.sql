ALTER TABLE product
ADD CONSTRAINT fk_product_catalog FOREIGN KEY (id_catalog_pr) REFERENCES catalog(id_catalog)
ADD CONSTRAINT fk_product_availability FOREIGN KEY (id_availability) REFERENCES availabilitypr(id_availability)
