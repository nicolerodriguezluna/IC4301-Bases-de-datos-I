CREATE OR REPLACE TRIGGER ge.beforeInsertPerson
BEFORE INSERT
ON ge.person
For each row
BEGIN
:new.creationuser:=USER;
:new.creationdate:=CURRENT_TIMESTAMP;
:new.lastmodifydate:=CURRENT_TIMESTAMP;
:new.lastmodifyuser:=USER;
END beforeInsertPerson;


CREATE OR REPLACE TRIGGER ge.beforeInsertPhone
BEFORE INSERT
ON ge.phone
For each row
BEGIN
:new.creationuser:=USER;
:new.creationdate:=CURRENT_TIMESTAMP;
:new.lastmodifydate:=CURRENT_TIMESTAMP;
:new.lastmodifyuser:=USER;
END beforeInsertPhone;

CREATE OR REPLACE TRIGGER ge.beforeInsertPhoneType
BEFORE INSERT
ON ge.phoneType
For each row
BEGIN
:new.creationuser:=USER;
:new.creationdate:=CURRENT_TIMESTAMP;
:new.lastmodifydate:=CURRENT_TIMESTAMP;
:new.lastmodifyuser:=USER;
END beforeInsertPhoneType;

CREATE OR REPLACE TRIGGER ge.beforeUpdateperson
BEFORE UPDATE
ON ge.person
FOR EACH ROW
BEGIN
:new.lastmodifydate:=CURRENT_TIMESTAMP;
:new.lastmodifyuser:=USER;
END beforeUpdateperson;

CREATE OR REPLACE TRIGGER ge.beforeUpdatephonetype
BEFORE UPDATE
ON ge.phonetype
FOR EACH ROW
BEGIN
:new.lastmodifydate:=CURRENT_TIMESTAMP;
:new.lastmodifyuser:=USER;
END beforeUpdatephonetype;

CREATE OR REPLACE TRIGGER ge.beforeUpdatephone
BEFORE UPDATE
ON ge.phone
FOR EACH ROW
BEGIN
:new.lastmodifydate:=CURRENT_TIMESTAMP;
:new.lastmodifyuser:=USER;
END beforeUpdatephone;