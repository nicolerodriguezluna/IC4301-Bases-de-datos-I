ALTER TABLE productxauthor
ADD CONSTRAINT fk_productxauthor_productpa FOREIGN KEY ( id_product_pa) REFERENCES product(id_product)
ADD CONSTRAINT fk_productxauthor_authortpa FOREIGN KEY ( id_author_pa) REFERENCES author(id_person)

