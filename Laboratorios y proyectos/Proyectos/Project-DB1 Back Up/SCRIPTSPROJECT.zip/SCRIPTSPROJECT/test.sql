 --Already in java
 SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from (SELECT count(id_article_rev) as total,id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
          from article 
          inner join review
          on article.id_article = review.id_article_rev 
          group by id_article, title_article, text_note, publication_date, id_status_article,id_dig_news, id_art_cat, id_committe_art
          Order by total desc)
    where rownum <=10;
select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from(select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
         from article
         order by publication_date desc)
    where rownum<=10 and id_status_article = 0;
    
     SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from (SELECT count(id_article_rev) as total,id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
          from article 
          inner join review
          on article.id_article = review.id_article_rev 
          group by id_article, title_article, text_note, publication_date, id_status_article,id_dig_news, id_art_cat, id_committe_art
          Order by total desc)
    where rownum <=10;
 
 
 Select sum(stars)
    into totalPoints
    from review
    inner join article
    on review.id_article_rev = article.id_article
    inner join authorxarticle
    on authorxarticle.id_article_autart = article.id_article
    where authorxarticle.id_author_autart = idAuthor;
    return (totalPoints);
declare
id_article NUMBER;
title_article VARCHAR(1000);
text_note VARCHAR2(1000);
publication_date DATE;
id_status_article NUMBER;
id_dig_news NUMBER;
id_art_cat NUMBER;
id_committe_art NUMBER;
containsArticlexCollege SYS_REFCURSOR;
BEGIN
    get_user_favourites(0,containsArticlexCollege);
    LOOP
        FETCH containsArticlexCollege
        INTO id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art;
        EXIT WHEN containsArticlexCollege%NOTFOUND;
        dbms_output.put_line(id_article||' '||title_article||' '||text_note||' '||publication_date||' '||id_status_article||' '||id_dig_news||' '||id_art_cat||' '||id_committe_art);
    END LOOP;
    CLOSE containsArticlexCollege;
END;

SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    inner join favourite
    ON article.id_article = favourite.id_article_fav
    inner join userdb
    ON userdb.id_person =  favourite.id_user_fav
    where userdb.id_person = 0;
    
 select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from(select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
         from article
         order by publication_date desc)
    where rownum<=10 and id_status_article = 0;
 create or replace PROCEDURE delete_committee(pidCommittee IN NUMBER) AS
BEGIN
    DELETE FROM committe
    WHERE committe.id_committe = pidCommittee;
    COMMIT;
END delete_committee;
 
 
 SELECT id_person,id_committe
    from personxcommitte;
 
 
 
 SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from (SELECT count(id_article_rev) as total,id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
          from article 
          inner join review
          on article.id_article = review.id_article_rev 
          group by id_article, title_article, text_note, publication_date, id_status_article,id_dig_news, id_art_cat, id_committe_art
          Order by total desc)
where rownum <=10;

SELECT count(id_article_rev) as total,id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
          from article 
          inner join review
          on article.id_article = review.id_article_rev 
          group by id_article, title_article, text_note, publication_date, id_status_article,id_dig_news, id_art_cat, id_committe_art
          Order by total desc;
SELECT COUNT(1) as countAuthors,name_college
        from author
        inner join person
        On author.id_person = person.id_person
        inner join campus
        ON person.id_quad = campus.id_campus
        inner join college
        On college.id_college = campus.id_university
        group by name_college;

DECLARE
spentPoints number;
begin
 spentPoints:=get_author_spent_points(0);
 dbms_output.put_line(spentPoints);
 END;
DECLARE
spentPoints number;
begin
 spentPoints:=get_author_spent_points(0);
 dbms_output.put_line(spentPoints);
 END;
 
 SELECT sum(cost_product) as exchanged
    from product
    inner join productxauthor
    on productxauthor.id_product_pa = product.id_product
    where productxauthor.id_author_pa = 0;
    
insert into productxauthor (id_product_pa,id_author_pa)
VALUES(0,0);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(0,0);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(0,0);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(0,0);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(0,0);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(0,19);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(0,19);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(0,19);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(2,19);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(2,19);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(2,19);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(2,19);

insert into productxauthor (id_product_pa,id_author_pa)
VALUES(1,19);
insert into productxauthor (id_product_pa,id_author_pa)
VALUES(1,19);
insert into productxauthor (id_product_pa,id_author_pa)
VALUES(1,19);
insert into productxauthor (id_product_pa,id_author_pa)
VALUES(1,19);
insert into productxauthor (id_product_pa,id_author_pa)
VALUES(1,19);

 SELECT description_product,cost_product,TotalCount
    from (SELECT description_product,cost_product,count(id_product_pa) as TotalCount from product
          inner join productxauthor
          on productxauthor.id_product_pa = product.id_product 
          group by description_product, cost_product
          order by TotalCount desc)
    where rownum<=10;


SELECT sum(cost_product)
           from product
           inner join productxauthor
           on productxauthor.id_product_pa = product.id_product
           where productxauthor.id_author_pa = 0;
 Select sum(stars)
    from review
    inner join article
    on review.id_article_rev = article.id_article
    inner join authorxarticle
    on authorxarticle.id_article_autart = article.id_article
    where authorxarticle.id_author_autart = 0;
 SELECT COUNT(1) as countAuthors,name_college
        from author
        inner join person
        On author.id_person = person.id_person
        inner join campus
        ON person.id_quad = campus.id_campus
        inner join college
        On college.id_college = campus.id_university
        group by name_college;
 SELECT description_product,cost_product,count(id_product_pa)as TotalCount
    from product
    inner join productxauthor
    on productxauthor.id_product_pa = product.id_product 
    group by description_product, cost_product
    order by TotalCount desc;

declare
vnphoneNumber NUMBER;
vnPercentage NUMBER;
vcName VARCHAR2(1000);
containsArticlexCollege SYS_REFCURSOR;
BEGIN
    get_topn_authors_category(4,0,containsArticlexCollege);
    LOOP
        FETCH containsArticlexCollege
        INTO vnphoneNumber,vcName;
        EXIT WHEN containsArticlexCollege%NOTFOUND;
        dbms_output.put_line(vnphoneNumber||' '||vcName);
    END LOOP;
    CLOSE containsArticlexCollege;
END;


--SELECT b.id, 1/total_products, b.price/a.total_price
--from
  --  (SELECT id, count(*) as total_products,sum(price) as total_price from product)a,
    --(SELECT id,price from product)b
--ORDER BY(b.id);


   CREATE SEQUENCE  "BDPROJECT"."S_PHOTO"  MINVALUE 0 MAXVALUE 999999999999999 INCREMENT BY 1 START WITH 44 NOCACHE  NOORDER  NOCYCLE ;
 
begin 
list_most_liked_news;
END;

UPDATE userdb
SET password_user = 'cachorro23'
where id_user = 0

BEGIN
insert_user('Mentira54','Cachorro28',9);
end;

SELECT id_product, cost_product, description_product,
    id_catalog_pr, id_availability
    FROM product
    inner join catalog
    on catalog.id_catalog = product.id_catalog_pr
    inner join digitalnewspaper
    on digitalnewspaper.id_digital_newspaper = catalog.id_newspaper
    inner join campus
    on digitalnewspaper.id_quad = campus.id_campus
    where campus.id_campus = 1;
    
    
    Select a.total-b.exchanged
    from (Select sum(stars) as total
          from review
          inner join article
          on review.id_article_rev = article.id_article
          inner join authorxarticle
          on authorxarticle.id_article_autart = article.id_article
          where authorxarticle.id_author_autart = 0)a,
          (SELECT sum(cost_product) as exchanged
           from product
           inner join productxauthor
           on productxauthor.id_product_pa = product.id_product
           where productxauthor.id_author_pa = 0)b;


    SELECT sum(cost_product) as exchanged
    from product
    inner join productxauthor
    on productxauthor.id_product_pa = product.id_product
    where productxauthor.id_author_pa = 0;