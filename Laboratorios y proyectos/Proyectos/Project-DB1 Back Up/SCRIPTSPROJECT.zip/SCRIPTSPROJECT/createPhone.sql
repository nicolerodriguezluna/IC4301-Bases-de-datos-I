CREATE TABLE phone
(
    id_phone NUMBER(15) CONSTRAINT phone_idphone_nn NOT NULL,
    number_phone NUMBER(8) CONSTRAINT phone_numberphone_nn NOT NULL
);