ALTER TABLE favourite
ADD date_favourite DATE CONSTRAINT favourite_date_nn NOT NULL;