ALTER TABLE person
add id_ubication NUMBER(15) CONSTRAINT person_idubication_nn NOT NULL