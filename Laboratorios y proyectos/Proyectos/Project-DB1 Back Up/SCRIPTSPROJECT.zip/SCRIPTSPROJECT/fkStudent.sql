ALTER TABLE student ADD CONSTRAINT fk_student_idperson FOREIGN KEY (id_person) references person(id_person)

