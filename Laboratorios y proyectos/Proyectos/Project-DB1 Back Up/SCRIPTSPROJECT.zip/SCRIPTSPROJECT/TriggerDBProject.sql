--Administrative
CREATE OR REPLACE TRIGGER bdproject.before_insert_administrative
before insert on bdproject.administrative
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_administrative;

CREATE OR REPLACE TRIGGER bdproject.before_update_administrative
before update on bdproject.administrative
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_administrative;

--Administrator
CREATE OR REPLACE TRIGGER bdproject.before_insert_administrator
before insert on bdproject.administrator
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_administrator;

CREATE OR REPLACE TRIGGER bdproject.before_update_administrator
before update on bdproject.administrator
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_administrator;

--ARTICLE
CREATE OR REPLACE TRIGGER bdproject.before_insert_article
before insert on bdproject.article
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_article;

CREATE OR REPLACE TRIGGER bdproject.before_update_article
before update on bdproject.article
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_article;

--ARTICLE CATEGORY
CREATE OR REPLACE TRIGGER bdproject.before_insert_articlecategory
before insert on bdproject.articlecategory
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_articlecategory;

CREATE OR REPLACE TRIGGER bdproject.before_update_articlecategory
before update on bdproject.articlecategory
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_articlecategory;

--AUTHOR
CREATE OR REPLACE TRIGGER bdproject.before_insert_author
before insert on bdproject.author
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_author;

CREATE OR REPLACE TRIGGER bdproject.before_update_author
before update on bdproject.author
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_author;

--AUTHOR CATEGORY
CREATE OR REPLACE TRIGGER bdproject.before_insert_authorcategory
before insert on bdproject.authorcategory
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_authorcategory;

CREATE OR REPLACE TRIGGER bdproject.before_update_authorcategory
before update on bdproject.authorcategory
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_authorcategory;


--AUTHORXARTICLE
CREATE OR REPLACE TRIGGER bdproject.before_insert_authorxarticle
BEFORE insert on bdproject.authorxarticle
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_authorxarticle;

CREATE OR REPLACE TRIGGER bdproject.before_update_authorxarticle
BEFORE UPDATE ON bdproject.authorxarticle
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_authorxarticle;

--Availabilitypr
CREATE OR REPLACE TRIGGER bdproject.before_insert_availabilitypr
BEFORE INSERT ON bdproject.availabilitypr
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_availabilitypr;

CREATE OR REPLACE TRIGGER bdproject.before_update_availabilitypr
BEFORE UPDATE ON bdproject.availabilitypr
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_availabilitypr;

--Campus
CREATE OR REPLACE TRIGGER bdproject.before_insert_campus
BEFORE INSERT ON bdproject.campus
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_campus;

CREATE OR REPLACE TRIGGER bdproject.before_update_campus
BEFORE UPDATE ON bdproject.campus
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_campus;

--Canton
CREATE OR REPLACE TRIGGER bdproject.before_insert_canton
before insert on bdproject.canton
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_canton;

CREATE OR REPLACE TRIGGER bdproject.before_update_canton
before update on bdproject.canton
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_canton;

--Catalog
CREATE OR REPLACE TRIGGER bdproject.before_insert_catalog
before insert on bdproject.catalog
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_catalog;

CREATE OR REPLACE TRIGGER bdproject.before_update_catalog
before update on bdproject.catalog
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_catalog;

--College
CREATE OR REPLACE TRIGGER bdproject.before_insert_college
before insert on bdproject.college
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_college;

CREATE OR REPLACE TRIGGER bdproject.before_update_college
before update on bdproject.college
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_college;

--Commite
CREATE OR REPLACE TRIGGER bdproject.before_insert_committe
before insert on bdproject.committe
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_committe;

CREATE OR REPLACE TRIGGER bdproject.before_update_committe
before update on bdproject.committe
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_committe;

--Country
CREATE OR REPLACE TRIGGER bdproject.before_insert_country
before insert on bdproject.country
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_country;

CREATE OR REPLACE TRIGGER bdproject.before_update_country
before update on bdproject.country
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_country;

--Dedication
CREATE OR REPLACE TRIGGER bdproject.before_insert_dedication
before insert on bdproject.dedication
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_dedication;

CREATE OR REPLACE TRIGGER bdproject.before_update_dedication
before update on bdproject.dedication
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_dedication;

--DigitalNewspaper
CREATE OR REPLACE TRIGGER bdproject.before_insert_digitalNewspaper
before insert on bdproject.digitalNewspaper
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_digitalNewspaper;

CREATE OR REPLACE TRIGGER bdproject.before_update_digitalNewspaper
before update on bdproject.digitalNewspaper
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_digitalNewspaper;

--District

CREATE OR REPLACE TRIGGER bdproject.before_insert_district
before insert on bdproject.district
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_district;

CREATE OR REPLACE TRIGGER bdproject.before_update_district
before update on bdproject.district
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_district;

--Email

CREATE OR REPLACE TRIGGER bdproject.before_insert_email
before insert on bdproject.email
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_email;

CREATE OR REPLACE TRIGGER bdproject.before_update_email
before update on bdproject.email
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_email;


--Favourite
CREATE OR REPLACE TRIGGER bdproject.before_insert_favourite
before insert on bdproject.favourite
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_favourite;

CREATE OR REPLACE TRIGGER bdproject.before_update_favourite
before update on bdproject.favourite
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_favourite;

--GENDER
CREATE OR REPLACE TRIGGER bdproject.before_insert_gender
before insert on bdproject.gender
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_gender;

CREATE OR REPLACE TRIGGER bdproject.before_update_gender
before update on bdproject.gender
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_gender;

--LOGDB
CREATE OR REPLACE TRIGGER bdproject.before_insert_logdb
before insert on bdproject.logdb
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_logdb;

CREATE OR REPLACE TRIGGER bdproject.before_update_logdb
before update on bdproject.logdb
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_logdb;

--NEIGHBOUR
CREATE OR REPLACE TRIGGER bdproject.before_insert_neighbour
before insert on bdproject.neighbour
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_neighbour;

CREATE OR REPLACE TRIGGER bdproject.before_update_neighbour
before update on bdproject.neighbour
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_neighbour;

--PARAMETERDB
CREATE OR REPLACE TRIGGER bdproject.before_insert_parameterdb
before insert on bdproject.parameterdb
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_parameterdb;

CREATE OR REPLACE TRIGGER bdproject.before_update_parameterdb
before update on bdproject.parameterdb
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_parameterdb;

--PERSON
CREATE OR REPLACE TRIGGER bdproject.before_insert_person
before insert on bdproject.person
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_person;

CREATE OR REPLACE TRIGGER bdproject.before_update_person
before update on bdproject.person
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_person;

--PERSONXCOMMITTE
CREATE OR REPLACE TRIGGER bdproject.before_insert_personxcommitte
before insert on bdproject.personxcommitte
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_personxcommitte;

CREATE OR REPLACE TRIGGER bdproject.before_update_personxcommitte
before update on bdproject.personxcommitte
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_personxcommitte;

--PHONE
CREATE OR REPLACE TRIGGER bdproject.before_insert_phone
before insert on bdproject.phone
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_phone;

CREATE OR REPLACE TRIGGER bdproject.before_update_phone
before update on bdproject.phone
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_phone;

--PHONECATEGORY
CREATE OR REPLACE TRIGGER bdproject.before_insert_phonecategory
before insert on bdproject.phonecategory
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_phonecategory;

CREATE OR REPLACE TRIGGER bdproject.before_update_phonecategory
before update on bdproject.phonecategory
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_phonecategory;

--PHOTO
CREATE OR REPLACE TRIGGER bdproject.before_insert_photo
before insert on bdproject.photo
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_photo;

CREATE OR REPLACE TRIGGER bdproject.before_update_photo
before update on bdproject.photo
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_photo;

--PRODUCT
CREATE OR REPLACE TRIGGER bdproject.before_insert_product
before insert on bdproject.product
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_product;

CREATE OR REPLACE TRIGGER bdproject.before_update_product
before update on bdproject.product
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_product;

--PRODUCTXAUTHOR
CREATE OR REPLACE TRIGGER bdproject.before_insert_productxauthor
before insert on bdproject.productxauthor
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_productxauthor;

CREATE OR REPLACE TRIGGER bdproject.before_update_productxauthor
before update on bdproject.productxauthor
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_productxauthor;

--PROFESSOR
CREATE OR REPLACE TRIGGER bdproject.before_insert_professor
before insert on bdproject.professor
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_professor;

CREATE OR REPLACE TRIGGER bdproject.before_update_professor
before update on bdproject.professor
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_professor;

--PROVINCE
CREATE OR REPLACE TRIGGER bdproject.before_insert_province
before insert on bdproject.province
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_province;

CREATE OR REPLACE TRIGGER bdproject.before_update_province
before update on bdproject.province
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_province;


--REVIEW
CREATE OR REPLACE TRIGGER bdproject.before_insert_review
before insert on bdproject.review
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_review;

CREATE OR REPLACE TRIGGER bdproject.before_update_review
before update on bdproject.review
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_review;

--STATUS
CREATE OR REPLACE TRIGGER bdproject.before_insert_status
before insert on bdproject.status
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_status;

CREATE OR REPLACE TRIGGER bdproject.before_update_status
before update on bdproject.status
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_status;


--STUDENT
CREATE OR REPLACE TRIGGER bdproject.before_insert_student
before insert on bdproject.student
for each row
BEGIN 
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_student;

CREATE OR REPLACE TRIGGER bdproject.before_update_student
before update on bdproject.student
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_student;

--USERDB
CREATE OR REPLACE TRIGGER bdproject.before_insert_user
before insert on bdproject.userdb
for each row
BEGIN
:new.userid:= USER;
:new.creationdate:=SYSDATE;
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_insert_user;


CREATE OR REPLACE TRIGGER bdproject.before_update_user
before update on bdproject.userdb
for each row
BEGIN
:new.lastmodifydate:= SYSDATE;
:new.lastmodifyby:=USER;
END before_update_user;