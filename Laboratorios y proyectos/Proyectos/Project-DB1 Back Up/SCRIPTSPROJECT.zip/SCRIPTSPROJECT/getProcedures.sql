--Already in java
CREATE OR REPLACE PROCEDURE get_administratives(pCursorAdministrative out sys_refcursor)
AS
BEGIN
    Open pCursorAdministrative for
    select administrative.id_person,id_dedication
    from administrative;
END;--

--Already in Java
CREATE OR REPLACE PROCEDURE get_administrative(pId in number,pCursorAdministrative out sys_refcursor)
AS
BEGIN
    OPEN pCursorAdministrative for
    select administrative.id_person,id_dedication
    from administrative
    where administrative.id_person = pId;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_administrators(pCursorAdministrator out sys_refcursor)
AS
BEGIN
    OPEN pCursorAdministrator for
    SELECT administrator.id_person,password_admin
    from administrator;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_Administrator(pId in Number,pCursorAdministrator out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAdministrator for
    select administrator.id_person,password_admin
    from administrator
    where administrator.id_person = pId;
END;--

--Get article by author is the same as get authorxarticle

--Already in Java
CREATE OR REPLACE PROCEDURE get_article_bydate(pDate in Date,pCursorNews out sys_refcursor)
AS
BEGIN
    OPEN pCursorNews for
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    where article.publication_date = TO_DATE(pDate,'YYYY-MM-DD') and id_status_article=0;
END;

--Already in Java
CREATE OR REPLACE PROCEDURE get_article_bycategory(pIdCategory in NUMBER, pCursorNews out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorNews for
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    where article.id_art_cat = pIdCategory and id_status_article=0;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_article_bycategory_admin(pIdCategory in NUMBER, pCursorNews out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorNews for
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    where article.id_art_cat = pIdCategory;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_article_fullsearch(pidAuthor IN number,pArticleCategory IN number,pDate IN DATE,pCursorNews out SYS_REFCURSOR)
AS
  BEGIN
    OPEN pCursorNews for
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    inner join articlecategory
    on article.id_art_cat = articlecategory.id_article_category
    inner join authorxarticle
    ON authorxarticle.id_article_autart = article.id_article
    where articlecategory.id_article_category = pArticleCategory AND article.publication_date = TO_DATE(pDate,'YYYY-MM-DD') AND authorxarticle.id_author_autart = pidAuthor
    order by(title_article);
 END;

CREATE OR REPLACE PROCEDURE get_articlecategories(pCursorCategories out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorCategories for
    select id_article_category,name_category,description_category
    from articlecategory;
END;--

--CREATE OR REPLACE PROCEDURE get_articlecategory_descr(pIdCategory in NUMBER,pCursorDescription out sys_refcursor)
--AS
--BEGIN
  --  OPEN pCursorDescription for
    --SELECT description_category
    --from articlecategory
    --where id_article_category = pIdCategory;
--END;

--Already in Java
CREATE OR REPLACE PROCEDURE get_authors(pCursorAuthors out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthors for
    SELECT author.id_person,id_author_cathegory
    from author;
END;--

--Already in Java
CREATE OR REPLACE PROCEDURE get_author_categories(pCursorAuthorCategories out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthorCategories for
    SELECT id_author_category,type_category
    from authorcategory;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_author_bycategory(pIdCategory in NUMBER,pCursorAuthorCategories out SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthorCategories for
    SELECT author.id_person,id_author_cathegory
    from author
    inner join person
    on person.id_person = author.id_person
    where id_author_cathegory = pIdCategory;
END;--

--Already in java as getArticleByAuthor
CREATE OR REPLACE PROCEDURE get_articles_byauthor(pIdAuthor in NUMBER,pCursorArticle out sys_refcursor)
AS
BEGIN
    OPEN pCursorArticle for
    SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    inner join authorxarticle
    on article.id_article = authorxarticle.id_article_autart
    where authorxarticle.id_author_autart = pIdAuthor  and id_status_article=0;
END;--

--Returns all contents from authorxarticles
CREATE OR REPLACE PROCEDURE get_authorxarticle(pCursorArticle out sys_refcursor)
AS
BEGIN
    OPEN pCursorArticle for
    SELECT id_author_autart, id_article_autart
    from authorxarticle;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_availability(pCursorAvailability out sys_refcursor)
AS
BEGIN
    OPEN pCursorAvailability for
    SELECT id_availability,description_availability
    from availabilitypr;
END;--

CREATE OR REPLACE PROCEDURE get_campus(pCursorCampus out sys_refcursor)
AS
BEGIN
    OPEN pCursorCampus for
    select id_campus,name_campus,id_university,id_district
    from campus;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_campusbycollege(pIdCollege in number,pCursorCampus out sys_refcursor)
AS
BEGIN
    OPEN pCursorCampus for
    select  id_campus,name_campus,id_university,id_district
    from campus
    where id_university = pIdcollege;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_canton_byarea(pIdArea in number, pCursorCantons out sys_refcursor)
AS
BEGIN
    OPEN pCursorCantons for
    select id_canton,name_canton,id_area
    from canton
    where id_area = pIdArea;
END;--

--Already in java as getCantons
CREATE OR REPLACE PROCEDURE get_canton(pCursorCantons out sys_refcursor)
AS
BEGIN
    OPEN pCursorCantons for
    select id_canton,name_canton,id_area
    from canton;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_catalogs(pCursorCatalogs out sys_refcursor)
as
begin
    open pCursorCatalogs for
    select id_catalog,id_newspaper,description_catalog
    from catalog;
END;--

--Already in Java
CREATE OR REPLACE PROCEDURE get_catalogs_byPaper(pidNPaper in number,pCursorCatalogs out sys_refcursor)
as
begin
    open pCursorCatalogs for
    select id_catalog,id_newspaper,description_catalog
    from catalog
    where id_newspaper = pidNPaper;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_catalog(pidCatalog in number,pCursorCatalog out sys_refcursor)
AS
BEGIN
    OPEN pCursorCatalog for
    select id_catalog,id_newspaper,description_catalog
    from catalog
    where id_catalog = pidCatalog;
END;--

--Already in java
CREATE OR REPLACE PROCEDURE get_colleges(pCursorColleges out sys_refcursor)
AS
BEGIN
    OPEN pCursorColleges for
    select id_college,name_college
    from college;
END;--

    


    




    










    









