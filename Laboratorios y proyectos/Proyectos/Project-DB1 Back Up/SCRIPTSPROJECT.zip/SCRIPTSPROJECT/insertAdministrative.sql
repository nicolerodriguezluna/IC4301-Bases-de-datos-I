insert into administrative
(id_person,id_dedication, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(15,1, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');
insert into administrative
(id_person,id_dedication, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(16,2, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

