insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\camaron.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',0,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\amsiedad.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',1,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\asaltoLaNota.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',2,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\clemenciaporfa.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',3,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\companerosenverano.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',4,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\dobby.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',5,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\doraUno.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',6,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\entregadeactas.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',7,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\examendeanalisis.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',8,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\facha.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',9,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\fumigandobugs.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',10,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\impaktado.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',11,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\leyendoexamen.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',12,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\meperdonas.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',13,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\porfapaseme.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',14,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\revisiondeproyecto.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',15,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\semana16.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',16,NULL);


insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\semanaUno.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',17,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\viendoMiCodigo.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',18,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\chill.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',19,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,5,(select route from parameterdb where id_parameter = 0)||'\\arte.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,12,(select route from parameterdb where id_parameter = 0)||'\\aumentoIntereses.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',null,null);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,1,(select route from parameterdb where id_parameter = 0)||'\\casaVerde.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,4,(select route from parameterdb where id_parameter = 0)||'\\centrohistorico.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,8,(select route from parameterdb where id_parameter = 0)||'\\estudiantesTec.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,9,(select route from parameterdb where id_parameter = 0)||'\\farolesUcr.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,11,(select route from parameterdb where id_parameter = 0)||'\\feesUcr.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,7,(select route from parameterdb where id_parameter = 0)||'\\gemelas.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,10,(select route from parameterdb where id_parameter = 0)||'\\guiasEstandarizadas.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,0,(select route from parameterdb where id_parameter = 0)||'\\marchafees.jpeg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,14,(select route from parameterdb where id_parameter = 0)||'\\situacionEmpleo.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,2,(select route from parameterdb where id_parameter = 0)||'\\tallerVertical.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,3,(select route from parameterdb where id_parameter = 0)||'\\teatroagosto.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,13,(select route from parameterdb where id_parameter = 0)||'\\terremotoCinchona.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,6,(select route from parameterdb where id_parameter = 0)||'\\trabajo.png',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,NULL);

insert into photo(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\astronautArticle.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,0);

insert into photo(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\briefhistoryofeverything.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,1);

insert into photo(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\einsteinArticle.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,2);

insert into photo(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\kitMolecular.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,3);

insert into photo(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\probetas.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,4);

insert into photo(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\robotArticle.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,5);

insert into photo(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\telescopio.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,6);

insert into photo(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\tablaPeriodica.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,7);

insert into photo
(id_photo,id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(s_photo.nextval,NULL,(select route from parameterdb where id_parameter = 0)||'\\articleIA.jpg',SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT',NULL,8);
