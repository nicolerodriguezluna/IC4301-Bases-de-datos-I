CREATE TABLE committe
(
    id_committe NUMBER(15) CONSTRAINT committe_idcommitte_nn NOT NULL
)