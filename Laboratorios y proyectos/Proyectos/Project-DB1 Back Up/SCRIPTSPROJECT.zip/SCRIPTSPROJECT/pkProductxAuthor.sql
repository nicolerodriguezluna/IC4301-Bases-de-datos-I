ALTER TABLE productxauthor
ADD CONSTRAINT pk_productxauthor PRIMARY KEY (id_product_pa, id_author_pa)
USING INDEX
TABLESPACE bdproject_ind PCTFREE 20
STORAGE (INITIAL 10K NEXT 10K PCTINCREASE 0)
