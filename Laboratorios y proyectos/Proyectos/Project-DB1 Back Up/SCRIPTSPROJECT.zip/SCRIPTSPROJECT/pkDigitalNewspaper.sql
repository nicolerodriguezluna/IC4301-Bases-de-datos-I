ALTER TABLE digitalnewspaper
ADD CONSTRAINT pk_digitalnewspaper PRIMARY KEY (id_digital_newspaper)
USING INDEX
TABLESPACE bdproject_ind PCTFREE 20
STORAGE (INITIAL 10K NEXT 10K PCTINCREASE 0);
