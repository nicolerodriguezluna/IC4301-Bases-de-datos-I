ALTER TABLE committe
add id_campus number(15);