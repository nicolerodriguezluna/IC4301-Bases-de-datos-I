CREATE OR REPLACE trigger beforeUpdateUser
    before insert or update of password_user
    on userdb
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New password',:old.password_user, :new.password_user);
    END beforeUpdateUser;

CREATE OR REPLACE trigger beforeUpdateStudent
    before insert or update of student_card
    on student
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New Student Card',:old.student_card, :new.student_card);
    END beforeUpdateStudent;

CREATE OR REPLACE trigger beforeUpdateStatus
    before insert or update of name_status
    on status
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New Status Name',:old.name_status, :new.name_status);
    END beforeUpdateStatus;

CREATE OR REPLACE trigger beforeUpdateReview
    before insert or update of description_review
    on review
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New Review Description',:old.description_review, :new.description_review);
    END beforeUpdateReview;

CREATE OR REPLACE trigger beforeUpdateProvince
    before insert or update of name_province
    on province
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New Name Province',:old.name_province, :new.name_province);
    END beforeUpdateProvince;

CREATE OR REPLACE trigger beforeUpdateProfessor
    before insert or update of id_dedication
    on professor
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New Dedication Professor',:old.id_dedication, :new.id_dedication);
    END beforeUpdateProfessor;

CREATE OR REPLACE trigger beforeUpdateProductCost
    before insert or update of cost_product
    on product
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New Cost Product',:old.cost_product, :new.cost_product);
    END beforeUpdateProductCost;

CREATE OR REPLACE trigger beforeUpdateProductDescription
    before insert or update of description_product
    on product
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New Description Product',:old.description_product, :new.description_product);
    END beforeUpdateProductDescription;

CREATE OR REPLACE trigger beforeUpdatePhoto
    before insert or update of route
    on photo
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New Route Photo',:old.route, :new.route);
    END beforeUpdatePhoto;

CREATE OR REPLACE trigger beforeUpdatePhoneCategory
    before insert or update of description_category
    on phoneCategory
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New Phone Category',:old.description_category, :new.description_category);
    END beforeUpdatePhoneCategory;

CREATE OR REPLACE trigger beforeUpdatePhone
    before insert or update of number_phone
    on phone
    for each row
    BEGIN
        INSERT INTO logdb
        (id_log, systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, 'New Phone Number',:old.number_phone, :new.number_phone);
    END beforeUpdatePhone;

