CREATE OR REPLACE PROCEDURE get_products(pCursorProducts out SYS_REFCURSOR)
AS
  BEGIN
  OPEN pCursorProducts for
  SELECT description_product,cost_product,description_availability,description_catalog
  from product
  inner join availabilitypr
  ON product.id_availability = availabilitypr.id_availability
  inner join catalog
  ON catalog.id_catalog = product.id_catalog_pr;
  END;
    