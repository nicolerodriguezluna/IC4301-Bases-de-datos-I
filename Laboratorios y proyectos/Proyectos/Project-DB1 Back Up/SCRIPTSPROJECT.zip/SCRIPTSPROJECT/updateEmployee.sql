Update employeege
set birthday_employee = DATE '2003-05-27'
where id_person = 20;