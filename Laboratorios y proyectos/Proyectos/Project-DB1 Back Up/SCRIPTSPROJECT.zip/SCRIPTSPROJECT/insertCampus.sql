Insert into campus
(id_campus,name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_campus.nextval,'Campus Tecnol�gico Local San Jos�',0,0, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');


Insert into campus
(id_campus,name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_campus.nextval,'Campus Central Tecnol�gico Cartago',0,130, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

Insert into campus
(id_campus,name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_campus.nextval,'Campus Tecnol�gico Local San Carlos',0,70, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

Insert into campus
(id_campus,name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_campus.nextval,'Centro Acad�mico de Alajuela',0,244, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

Insert into campus
(id_campus,name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_campus.nextval,'Centro Acad�mico de Lim�n',0,470, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

Insert into campus
(id_campus,name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_campus.nextval,'Ciudad Universitaria Rodrigo Facio',1,66, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

Insert into campus
(id_campus,name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_campus.nextval,'Sede de Occidente',1,257, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

Insert into campus
(id_campus,name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_campus.nextval,'Recinto de Para�so',1,133, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

Insert into campus
(id_campus,name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_campus.nextval,'Campus Benjam�n N��ez Presb�tero',2,359, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

Insert into campus
(id_campus,name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_campus.nextval,'Campus Omar Dengo',2,361, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

Insert into campus
(id_campus,name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_campus.nextval,'Campus Sarapiqu�',2,395, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');






