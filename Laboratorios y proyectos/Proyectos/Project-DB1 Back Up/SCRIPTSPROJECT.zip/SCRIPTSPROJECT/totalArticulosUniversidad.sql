CREATE OR REPLACE PROCEDURE articles_per_university(pCursorArticles out SYS_REFCURSOR)
AS
  BEGIN
        OPEN pCursorArticles for
        SELECT COUNT(1) as countArticles,college.name_college
        from article
        inner join digitalnewspaper
        on article.id_dig_news = digitalnewspaper.id_digital_newspaper
        inner join campus
        ON digitalnewspaper.id_quad  = campus.id_campus
        inner join college 
        On college.id_college = campus.id_university
        where id_status_article = 0
        group by college.name_college;
 END;
 
              