insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_article.nextval,'Marcha por FEES: Universidades logran evitar recorte de presupuesto para 2023 tras manifestaci�n multitudinaria',
'Estudiantes y personal de U p�blicas se manifestaron contra propuesta de Gobierno para el FEES del pr�ximo a�o. Las partes alcanzaron un primer acuerdo este martes pero seguir�n conversaciones ma�ana mi�rcoles

Fuera de Casa Presidencial, los manifestantes celebraron el resultado de la negociaci�n del FEES 2023 de este martes, donde el Gobierno acept�, finalmente, la propuesta que llevaron los rectores desde el primer encuentro, hace una semana. En aquel momento, los universitarios plantearon partir del presupuesto otorgado para 2022 y a�adir inflaci�n o costo de vida.

El Ejecutivo present� una contrapropuesta con el recorte, la cual no fue aceptada. Finalmente, se acogi� el primer plan, por lo que este mi�rcoles se reunir�n de nuevo para decidir ese componente por costo de vida que se sumar� a los �522.000 millones. El punto fundamental ser� definir si se usar� la inflaci�n interanual de 8,7% o la alcanzada en julio, de 11,4 %.

�Hemos avanzado, repito lo que se ha acordado: se mantiene el presupuesto base 2022, no hemos podido negociar el tema de la inflaci�n tal y como lo establece la Constituci�n. Dimos un primer paso en esta reuni�n, ma�ana hemos acordado reunirnos a las 2:30 p. m. en nuestras instalaciones de Conare, con la esperanza de que el Gobierno nos pueda aceptar el costo de vida que estamos planteando�, declar� Gustavo Guti�rrez, rector de la UCR, instituci�n que recibe la mayor parte del Fondo.

�Muy contentos, muy positivos con esta reuni�n y seguimos adelante con la importancia de darle a la universidad p�blica y a la educaci�n p�blica la inversi�n que merece�, expres� Francisco Gonz�lez, jerarca de la Universidad Nacional.

Los estudiantes, por su parte, consideraban manifestarse de nuevo este mi�rcoles, en Conare, para asegurar el acuerdo definitivo a su favor.
La Nacion logo

Educaci�n
Marcha por FEES: Universidades logran evitar recorte de presupuesto para 2023 tras manifestaci�n multitudinaria
Estudiantes y personal de U p�blicas se manifestaron contra propuesta de Gobierno para el FEES del pr�ximo a�o. Las partes alcanzaron un primer acuerdo este martes pero seguir�n conversaciones ma�ana mi�rcoles
Por Jos� Andr�s C�spedes , Daniela Cerdas E. y Irene Vizca�no
16 de agosto 2022, 1:02 PM
"S� se pudo, s� se pudo"

Fuera de Casa Presidencial, los manifestantes celebraron el resultado de la negociaci�n del FEES 2023 de este martes, donde el Gobierno acept�, finalmente, la propuesta que llevaron los rectores desde el primer encuentro, hace una semana. En aquel momento, los universitarios plantearon partir del presupuesto otorgado para 2022 y a�adir inflaci�n o costo de vida.

El Ejecutivo present� una contrapropuesta con el recorte, la cual no fue aceptada. Finalmente, se acogi� el primer plan, por lo que este mi�rcoles se reunir�n de nuevo para decidir ese componente por costo de vida que se sumar� a los �522.000 millones. El punto fundamental ser� definir si se usar� la inflaci�n interanual de 8,7% o la alcanzada en julio, de 11,4 %.

�Hemos avanzado, repito lo que se ha acordado: se mantiene el presupuesto base 2022, no hemos podido negociar el tema de la inflaci�n tal y como lo establece la Constituci�n. Dimos un primer paso en esta reuni�n, ma�ana hemos acordado reunirnos a las 2:30 p. m. en nuestras instalaciones de Conare, con la esperanza de que el Gobierno nos pueda aceptar el costo de vida que estamos planteando�, declar� Gustavo Guti�rrez, rector de la UCR, instituci�n que recibe la mayor parte del Fondo.

�Muy contentos, muy positivos con esta reuni�n y seguimos adelante con la importancia de darle a la universidad p�blica y a la educaci�n p�blica la inversi�n que merece�, expres� Francisco Gonz�lez, jerarca de la Universidad Nacional.
',DATE '2022-08-16',0,0,2,0, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');


insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_article.nextval,'Casa Verde ser� anfitriona y protagonista del pr�ximo Art City Tour virtual','El pr�ximo Art City Tour virtual de San Jos� se transmitir� desde la Casa Verde de Barrio Am�n, un inmueble declarado patrimonio hist�rico-arquitect�nico del pa�s y que es propiedad del Tecnol�gico de Costa Rica.

Adem�s de ser la anfitriona de la actividad, Casa Verde tambi�n participar� con una c�psula que mostrar� sus principales caracter�sticas arquitect�nicas y contar� parte de su historia.

De acuerdo con Henry Bastos Ulate, director de GAM Cultural + Art City Tour, Casa Verde es un referente arquitect�nico de Barrio Am�n. Su construcci�n en madera de principios del siglo XX y su buena conservaci�n hasta la fecha, la convierten en una pieza fundamental del paisaje urbano.

�El momentum generado por el debate p�blico como consecuencia de la demolici�n de la edificaci�n de Cuesta Nu�ez es una gran oportunidad para reforzar ante diferentes audiencias la importancia del patrimonio, proyectar sus beneficios y la apuesta por su conservaci�n�, subray� Bastos.

El Art City Tour adapt� sus recorridos culturales a la virtualidad v�a streaming desde junio del 2020 bajo el nombre Por Chepe desde casa, con la finalidad de seguir difundiendo la amplia producci�n cultural del pa�s en medio de la pandemia por COVID-19.

Cada transmisi�n se ha realizado desde espacios ic�nicos de la capital y de gran valor hist�rico para la poblaci�n, como el Museo Nacional, el Museo de Jade, el Teatro Nacional, el Museo de Arte y Dise�o Contempor�neo y el Castillo Azul de la Asamblea Legislativa.

Adem�s de la Casa Verde del TEC, en este �ltimo Art City Tour virtual del a�o, participar�n el Teatro Nacional de Costa Rica, el Museo Nacional, el Museo Penitenciario, el Museo Filat�lico, la Galer�a Nacional, el Centro Cultural de Espa�a, el Centro Cultural Hist�rico Jos� Figueres Ferrer, la Compa��a Nacional de Danza, la Compa��a Nacional de Teatro y DidiFood.',DATE '2021-10-7',0,0,7,0, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');


insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_article.nextval,'Estudiantes elaboraron 14 propuestas para mejorar el espacio urbano en la capital 
','Los barrios Am�n y Otoya, al norte de la capital, fueron el foco de atenci�n de toda la comunidad estudiantil y docente de la Escuela de Arquitectura y Urbanismo por toda una semana durante la XVIII edici�n del Taller Vertical, una experiencia acad�mica que promueve la b�squeda de soluciones a problem�ticas del espacio urbano mediante el trabajo colaborativo entre estudiantes de todos los niveles de la carrera.

El lema de la actividad fue �Hacer lugares�, un concepto que busca convertir espacios p�blicos olvidados e inseguros en puntos atractivos y de confianza para la comunidad. Para ello, se utiliz� el principio de �urbanismo t�ctico�, el cual promueve la recuperaci�n de las �reas p�blicas y su puesta en valor por medio de intervenciones ligeras, de bajo costo y de r�pida implementaci�n para explorar opciones de mejora peri�dicamente.

En esta ocasi�n, el Taller integr� a representantes de ambos barrios para que aportaran sus ideas y sugerencias. Esto se hizo tanto en las reuniones preparatorias durante los meses de abril, mayo y agosto, como en la semana de realizaci�n del Taller, cuando abrieron las puertas de sus casas a los equipos estudiantiles y asistieron al acto de inauguraci�n. Adem�s, se cont� con el aporte de la Municipalidad de San Jos� y del Colegio de Arquitectos de Costa Rica.

Para lograr los objetivos, estudiantes y docentes se dividieron en catorce equipos de trabajo, los cuales elaboraron propuestas de mejora para siete zonas claves de este sector de San Jos�. A cada uno de estos puntos se le especific� un enfoque en relaci�n con el uso actual de la tierra (cultural, institucional o comercial) y, adem�s, se le definieron posibles estrategias de intervenci�n que cada equipo de trabajo deb�a considerar para su propuesta.

Todos los equipos tuvieron como eje central la puesta en valor del paisaje urbano hist�rico de los barrios Am�n y Otoya y debieron considerar dentro de las propuestas elementos de temporalidad en el uso del espacio, iluminaci�n y mobiliario urbano, dise�o con enfoque en derechos humanos, paisajismo urbano y perdurabilidad de los materiales propuestos.

Durante la inauguraci�n de la actividad, Alejandro V�ctor Benavides, presidente de la Asociaci�n de Estudiantes de Arquitectura y Urbanismo, invit� a los equipos de trabajo a convertir el Taller Vertical en un �laboratorio de sue�os�, a reimaginar la ciudad y a visionar los barrios Am�n y Otoya del ma�ana como espacios m�s activos, participativos y seguros.

�Hemos detectado junto a la comunidad una serie de problem�ticas que afecta a nuestro barrio, problem�ticas sociales, pol�ticas, econ�micas y de infraestructura que han debilitado la ciudad y la forma en la que participamos en ella. Por ejemplo, la percepci�n de inseguridad, el comercio sexual il�cito, basura, falta de iluminaci�n, demarcaci�n incorrecta de calles, prioridad vehicular, aceras en mal estado e inaccesibles son algunas de las problem�ticas que aquejan nuestro entorno urbano�, especific� V�ctor.

Por su parte, Pablo Bulgarelli Bola�os, coordinador general del XVIII Taller Vertical, resalt� la importancia de esta actividad porque es cuando �se hace escuela� y toda la poblaci�n estudiantil une sus esfuerzos para construir propuestas que van mucho m�s all� de ganar puntos para los cursos. De acuerdo con Bulgarelli, adem�s de ser una experiencia acad�mica, el Taller Vertical facilita que los estudiantes de todos los niveles de la carrera se conozcan entre s�, ejerciten sus habilidades blandas y comprendan la importancia de que el conocimiento traspase las paredes de las aulas.',DATE '2022-09-7',0,0,7,0, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_article.nextval,'Teatro Agosto estren� "Uvieta" en la virtualidad','En el marco del centenario de la publicaci�n de los Cuentos de mi t�a Panchita de Carmen Lyra, Teatro Agosto, del Campus Tecnol�gico Local San Jos�, estren� su adaptaci�n para teatro virtual del cuento Uvieta, el pasado 28 de noviembre por su canal de YouTube.

La obra tambi�n se proyect� en vivo, ese mismo d�a, durante el Festival Internacional de Teatro Puntarenense de la Universidad de Costa Rica y estuvo disponible hasta el 30 de noviembre. Posteriormente, quienes visitaron la Feria Internacional del Libro, en su versi�n virtual, pudieron observarla en el stand de la Editorial Tecnol�gica de Costa Rica, del 4 al 6 de diciembre.

Luego de 6 d�as de exposici�n al p�blico, la obra dirigida por Alexandra De Simone logr� acumular m�s de 1050 visualizaciones y centenares de comentarios.

De acuerdo con Daniel Morales Sibaja, estudiante de Ingenier�a en Dise�o Industrial e integrante del Teatro Agosto, a lo largo del segundo semestre el grupo se dedic� de lleno a la adaptaci�n del cuento, a la exploraci�n de herramientas virtuales y a la creaci�n colectiva para el desarrollo del montaje.
Como punto de partida se defini� una est�tica de �un mundo dentro de otro�. De esta manera, los integrantes de este grupo art�stico jugaron a distorsionar tama�os, pesos y dimensiones y a imaginar formas en las que viajan las historias.

�A partir de la concepci�n de que el mundo de Uvieta iba a suceder dentro del armario de t�a Panchita, fue fundamental la selecci�n de los objetos que van a estar ah�. Realizamos una gran colecci�n de unos 200 objetos que cada miembro del grupo encontr� en su casa�, detall� Morales.

El grupo utiliz� para el montaje una t�cnica audiovisual denominada �croma� o �clave de color� que consiste en extraer un color de una imagen o v�deo y reemplazar el �rea que ocupaba ese color por otra imagen o v�deo, con la ayuda de un equipo especializado o una computadora. Esta t�cnica es ampliamente usada en cine, televisi�n y fotograf�a para recrear escenas en ambientes imaginarios o de ciencia ficci�n, similares a los fondos virtuales que ofrece la plataforma Zoom.

Gracias al uso del croma, Teatro Agosto pudo crear escenas grupales y generar una mejor interacci�n entre los personajes. Para ello, cada actor tuvo que acondicionar su espacio de grabaci�n de acuerdo con sus posibilidades y limitaciones y convertirse en su propio camar�grafo.

�Utilizamos una gran variedad de recursos tecnol�gicos para darle vida al montaje, desde filtros de aplicaciones m�viles para cambiar el aspecto facial de algunos personajes hasta programas de dise�o y modelado en 3D para realizar la casa de t�a Panchita y el armario. Tambi�n usamos programas de edici�n fotogr�fica para crear los escenarios junto a la colecci�n de objetos, adem�s de programas de edici�n de v�deo y animaci�n para crear el producto final�, especific� Morales.

Otro rasgo particular del montaje es su m�sica original. Para ello se ech� mano de software y recursos gratuitos para la composici�n musical y se obtuvieron 4 canciones originales que se utilizan a lo largo de la obra.

�Tambi�n, en enero estrenamos Uvieta: la miniserie en el canal de YouTube del grupo. Una miniserie de 3 episodios cortos que exploran historias producto de las consecuencias de dejar a La Muerte atrapada tanto tiempo en el palo de uvas de Uvieta�, adelant� Morales.

El primer episodio de Uvieta: la miniserie se llama Inmortales y se transmitir� el viernes 15 de enero a las 7 p.m. El segundo episodio se titula Crisis infernal y se emitir� el viernes 22 de enero a las 7 p.m. Mientras que el �ltimo cap�tulo se denomina El regreso y se podr� ver el viernes 29 de enero a las 7 p.m.',DATE '2020-12-9',0,0,3,0, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');


insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_article.nextval,'Centro Hist�rico de San Jos� contar� con se�al�tica dise�ada por egresado del TEC','A partir de hoy, los transe�ntes de la capital contar�n con un sistema de informaci�n cultural y tur�stica que contribuir� a visibilizar edificios patrimoniales y atractivos del Centro Hist�rico de San Jos� y sus ensanches.

Se trata de 4 mojones de delimitaci�n, 13 se�ales grupales o t�tems y 8 se�ales individuales ubicadas en los postes de alumbrado p�blico, que se ubicar�n en puntos estrat�gicos del centro de San Jos�.

El proyecto fue inaugurado el mi�rcoles 16 de diciembre en el parque Espa�a, en una actividad donde estuvieron presentes autoridades de la Municipalidad de San Jos� y del Tecnol�gico de Costa Rica.

Esta iniciativa forma parte del proyecto �Se�al�tica para el Centro Hist�rico de San Jos� y sus Ensanches�, impulsado por la Comisi�n Centro Hist�rico, conformada por la Municipalidad de San Jos� (MSJ), el Tecnol�gico de Costa Rica (TEC) y el Ministerio de Cultura y Juventud (MCJ), entre otras organizaciones p�blicas y privadas.

Jorge Mora Jara, arquitecto reci�n egresado del TEC, tuvo a su cargo el dise�o del sistema informativo como asistente del proyecto Centro Hist�rico de San Jos� y, posteriormente, de forma voluntaria y ad honorem. Para �l, es de suma importancia desarrollar estrategias de informaci�n, difusi�n y visibilizaci�n de los atractivos e historia de la ciudad de San Jos� para que la ciudadan�a los valore y aprecie.
�Lo m�s satisfactorio para m� es poder generar, con este proyecto, un peque�o aporte que comenzar� a visibilizar las acciones que se han generado durante algunos a�os, desde la academia y el municipio, para consolidar la imagen y la importancia de un proyecto tan interesante como lo es el Centro Hist�rico de la ciudad de San Jos�. Jorge Mora Jara, arquitecto egresado del TEC y quien tuvo a su cargo el dise�o de la se�al�tica.
�Aparte de visibilizar nuestro patrimonio, la se�al�tica permitir� tener mapeados diferentes hitos de la ciudad, fortaleciendo el sentido de pertenencia y ubicaci�n en la misma, ya sea identificando un edificio o un espacio p�blico. Adem�s, ayudar� a que m�s poblaci�n pueda tener m�s informaci�n sobre sitios que pasan desapercibidos en la actualidad y, por ende, un mayor acceso a los mismos�, destac�.

Adem�s, explic� que el proyecto es un complemento a las rutas tur�sticas que ya han desarrollado el Departamento de Servicios Culturales y la Oficina de Turismo, de la Municipalidad de San Jos�, con el acompa�amiento del TEC. En este sentido, se espera que la nueva se�al�tica ayude a proyectar el Centro Hist�rico de San Jos� y sus atractivos tur�sticos, patrimoniales y culturales, al turismo local e internacional, de la misma forma como sucede en otras ciudades latinoamericanas.
La se�alizaci�n utiliza componentes de alta resistencia a golpes y a las inclemencias del tiempo, como policarbonatos, acr�licos, impresiones de alto gramaje, tintas resistentes a la luz solar y emplasticados mate. A la vez, todos estos materiales son de escaso o nulo valor en las plantas recicladoras, por lo que se espera que no sean objeto de robo.

Jeannette Alvarado, directora de la Escuela de Arquitectura y Urbanismo del TEC, explica que la se�al�tica es una t�cnica de comunicaci�n visual que utiliza se�ales ic�nicas y s�mbolos, crom�ticos y ling��sticos, para brindar informaci�n y orientar a las personas un espacio determinado.

De acuerdo con Alvarado, una se�al�tica debe ser de f�cil lectura y comprensi�n. Adem�s, es imprescindible que la informaci�n sea concreta, clara y precisa. Para ello, se presentan datos esenciales, de forma esquem�tica y en un sistema arquitect�nico que quede en el imaginario de la poblaci�n.

�El TEC, en coordinaci�n con la Municipalidad de San Jos�, ha promovido que la ciudadan�a valore su ciudad mediante intervenciones urbanas y proyectos. Desde la academia se ha realizado dise�o en ciudad y de marca desde el a�o 2013.
',DATE '2020-12-17',0,0,3,0, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');


insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_article.nextval,'El poder transformador del arte','La vida y obra de Juan Luis Rodr�guez Sibaja, Premio Mag�n 2020, fue el tema de la lecci�n inaugural del Campus Tecnol�gico Local San Jos�, realizada de forma virtual y con la participaci�n del historiador del arte y exprofesor del Tecnol�gico de Costa Rica, Luis Fernando Quir�s.

Tradicionalmente, esta lecci�n es dictada por la persona galardonada con el m�ximo reconocimiento que otorga el Ministerio de Cultura y Juventud. En esta ocasi�n, Rodr�guez no pudo estar presente por razones de salud, pero su esposa, Diana Patricia Mosheim Castro, comparti� una serie de ideas y principios que el artista ha pregonado a lo largo de su vida.

Posteriormente, Quir�s hizo una rese�a de la vida de Rodr�guez y destac� algunos momentos de su carrera art�stica y su capacidad creativa para transformar materiales de desecho en verdaderas obras de arte, muchas de ellas ef�meras y creadas a partir de elementos naturales.

En la voz de su esposa, Diana Patricia Mosheim Castro:
�Hay algunas palabras y algunas ideas que Juan Luis repite, no solamente de manera hablada, sino tambi�n en sus trabajos, y voy a tratar de transmitirlas. Claro, no es igual. Pero, �l siempre dice que hay un vac�o del que se debe estar consciente, algo que uno desea llenar con lo que hace, pero tiene que ser a partir de qui�n es uno y definir el terreno donde uno est�, porque uno siempre tiene un sustento. Entonces, conocer el terreno es importante. El terreno externo como el terreno interno.

�En el trabajo creativo, mientras uno hace las cosas, porque una cosa es imaginarlas y otra cosa es hacerlas, uno tiene que estar un poco suelto, tiene que seguir las intuiciones, dejar que se manifieste esa parte de uno que no necesariamente es tan consciente. Cada idea que uno tiene, la manifestaci�n no necesariamente es a trav�s del mismo material. Entonces, por ejemplo, a veces hay una gran inquietud, algo que uno quiere transmitir y no va a ser por medio del dibujo o de un grabado como �l lo hace, sino puede ser a trav�s de la poes�a, puede ser a trav�s de la escultura o puede ser a trav�s de una receta de cocina o puede ser, simplemente, de una forma de vivir, un giro en la forma de vivir. Entonces, la creatividad, en este aspecto del artista, tiene que cubrir muchas partes de su vida y, en general, �l dice de cualquier persona, as� debe ser.

�La copia, inicialmente, tal vez es un ejercicio que los artistas o los intelectuales o cualquier persona hace, pero, poco a poco, la copia o ese ejemplo que uno sigue tiene que ir cogiendo caracter�sticas personales. Eso hay que irlo reconociendo. La l�nea nunca es igual, el peso de una l�nea sobre un papel o el trabajo que uno hace nunca es igual al de otra persona, porque uno tiene vivencias diferentes. Entonces, siempre hay que recuperar eso, esa parte que se va manifestado, que es lo que uno llama su sombra, su terreno interno. Ese es un gran respeto que �l siempre promueve.

�Juan Luis dice que lo que uno hace tiene que ser algo que no podr�a dejar de hacer. Es decir, que lo llena tanto de pasi�n y de alegr�a o hasta de sufrimiento o tensi�n, que no puede dejar de hacerlo. Entonces, no es una cosa que se elige por comercio, dig�mosle as�. Si, finalmente, dan buenos resultados en cuesti�n de dinero pues es muy bueno, pero la creatividad no puede estar solamente manejada por un aspecto de bienestar material. Dentro de estas manifestaciones, a veces, surgen lo que la gente califica como errores. Dice Juan Luis que estos errores son la punta del iceberg de lo que uno es de su originalidad, de su particularidad. Estos errores hay que estudiarlos, limarlos, ver c�mo fue que salieron de esa parte no racional que uno tiene y pueden ser la fuente de un trabajo o un hallazgo que sea parte de lo que uno va a dejar de original.',DATE '2021-02-16',1,0,3,0, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');


insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_article.nextval,' El 54,8% de los estudiantes del TEC tienen trabajo antes de graduarse','Cuando se trata de insertarse en el mercado laboral, los estudiantes del Tecnol�gico de Costa Rica (TEC) tienen un panorama prometedor. 

As� lo confirma el primer censo realizado por la Oficina de Planificaci�n Institucional del TEC, el cual revel� que el 54,84% de los estudiantes de grado (bachillerato y licenciatura) tienen trabajo antes de graduarse. Se trata espec�ficamente de j�venes que se encuentran en el �ltimo ciclo y, por ende, est�n realizando sus tesis o pasant�as.

El informe se�ala, adem�s, que  de los estudiantes que se encuentran trabajando durante sus estudios (independientemente del ciclo lectivo) el 88,39% laboran para el sector privado, mientras que el 10,05% lo hace para el sector p�blico.

Caso de �xito

Uno de ellos es Jos� Pablo Delgado, quien recibi� su t�tulo hace 15 d�as como ingeniero en Biotecnolog�a. 

Sin embargo, desde antes de comenzar su proyecto de graduaci�n ya hab�a sido seleccionado para trabajar en la empresa Ginkgo Bioworks en Boston, Estados Unidos. 

Ginkgo Bioworks es una empresa dedicada a facilitar la modificaci�n de organismos por medio de la biolog�a sint�tica y la automatizaci�n. 

�Definitivamente, la preparaci�n acad�mica del TEC nos permite integrarnos en el �mbito laboral m�s r�pido. Creo que el secreto es que desde el primer a�o nos ense�an a no conformarnos y buscar siempre nuevas soluciones a problemas tanto en la investigaci�n como para la vida�, afirm� el joven de 23 a�os. 

El censo fue realizado entre abril y octubre del 2019 y cont� con la participaci�n de 9 574 estudiantes; es decir, un 90,1% de porcentaje de respuesta de la poblaci�n estudiantil de grado. 

En el caso de los graduados con al menos 3 a�os en el mercado, seg�n datos del Estudio de Seguimiento de Graduados 2016, del Consejo Nacional de Rectores (Conare), el porcentaje de graduados del TEC con empleo es del 98%, siendo la universidad con el mayor porcentaje de empleabilidad.',DATE '2020-10-20',0,0,0,0, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_article.nextval,'Gemelas reciben su t�tulo junto a 409 nuevos profesionales','El Tecnol�gico de Costa Rica (TEC) llev� a cabo la graduaci�n No.307 correspondiente al segundo Acto Ordinario del 2022 en su campus Central localizado en Cartago.

En total, el TEC entreg� al pa�s 409 nuevos profesionales, correspondiente a 128 bachilleratos universitarios, 195 licenciados, en maestr�a 86 y un doctorado. Representando a un total de 157 mujeres y 253 son hombres. 

�Con esto seguimos cumpliendo con el objetivo para el cual  fue creada esta Instituci�n hace 51 a�os: �aportar al pa�s  profesionales capaces de liderar el cambio en nuestro modelo  de desarrollo. Para nosotros es un orgullo seguir aportando con profesionales, cuya calidad es reconocida a nivel nacional e internacional en disciplinas de alto impacto�, indic� el rector, Luis Paulino M�ndez.
Entre los graduados, las j�venes gemelas, oriundas de Coronado tambi�n recibieron su t�tulo. 

Se trat� de Mar�a Graciela y Ana Gabriela Rosales Largaespada. Ambas recibieron su t�tulo como licenciadas en el mismo acto de graduaci�n. La primera en Ingenier�a en Biotecnolog�a y la segunda en Ingenier�a en Mecatr�nica. 

�Cualquiera podr�a pensar que nos pusimos de acuerdo. Pero no fue as�. Yo por ejemplo, me atras� en mi carrera, porque mi sue�o era entrar a Biotecnolog�a, y la primera vez que hice el examen de admisi�n no alcanc� el puntaje. Pero lo intent� hasta que logr� ingresar�, recuerda muy orgullosa, Ana Gabriela Rosales, quien recibi� su t�tulo con menci�n de honor tras obtener un promedio ponderado de 97,83. 

Por su parte Mar�a Gabriela, relat� que se atras� en su carrera tras vivir dos etapas de depresi�n. �Pero hoy, gracias a la ayuda de profesionales, familia y amigos logr� sacar la carrera�, indic�.

�Deseo aprovechar este espacio para recordarle a los profesores, administrativos y estudiantes que debemos cuidar nuestra salud. Que el TEC brinda herramientas para poder cuidarla, no est�n solos. Yo acud� a ellas y les agradezco mucho�, puntualiz� la Joven. 

Las j�venes de 25 a�os recibieron su certifcado acompa�adas de sus padres, hermana y amigos. 

El evento se desarroll� en tres actos. Uno en la ma�ana, la tarde y la noche. Todos en el auditorio del Centro de las Artes. 

Tras 51 a�os de existencia, el TEC ha graduado m�s  de  28 mil profesionales, con el esfuerzo por impulsar el desarrollo econ�mico y social.',DATE '2022-09-6',2,0,7,0, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_article.nextval,'El 75,9% de los estudiantes matriculados en el TEC provienen de colegios p�blicos o semi-p�blicos','La Oficina de Planificaci�n Institucional (OPI) del Tecnol�gico de Costa Rica (TEC) present� los resultados del Censo Estudiantil del primer semestre 2019, donde se dan a conocer los datos sociodemogr�ficos, vida universitaria y laboral. 

La presentaci�n oficial se llev� a cabo durante una de las sesiones del Consejo de Rector�a.

Dentro de los resultados se dio a conocer que del total de estudiantes matriculados en la Instituci�n, el 57,89% provienen de colegios p�blicos y el 18,07% de colegios semip�blicos; es decir, el 75,9% de los estudiantes proceden de estas modalidades. 

�En la categor�a de colegios semip�blicos se incluyen aquellos que cuentan con un aporte del presupuesto nacional, entre ellos colegios cient�ficos, biling�es y otras modalidades que ofrecen opciones de formaci�n adicional a la oferta tradicional de los colegios p�blicos para poblaciones que no tienen acceso a la educaci�n privada�, afirm� Evelyn Hern�ndez, funcionaria de la OPI. 

De igual manera, se indica que el 23,29% de los estudiantes matriculados provienen de colegios privados. 

�Con este tipo de estudios, lo que se busca es tener un mayor acercamiento a la poblaci�n estudiantil desde varias aristas, que sirva como insumo para la toma de decisiones�, puntualiz� Hern�ndez. 

El censo fue realizado entre abril y octubre de 2019, y en �l participaron 9 574 estudiantes de grado; es decir, el 90,1% de la poblaci�n en estudio.
',DATE '2020-10-21',0,0,0,0, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_article.nextval,'�Por qu� cantamos el Himno Nacional cada 14 de septiembre a las 6:00 p.m?','Cada 14 de septiembre, a las 6:00 p. m., el pa�s revive la tradici�n de entonar el Himno Nacional en Costa Rica. Este a�o no ser� la excepci�n, en v�speras de cumplir 201 a�os de vida independiente, luego de llegar al Bicentenario en el 2021.

La tradici�n de cantar el Himno Nacional cada 14 de septiembre a las 6:00 p. m., se estableci� a partir del gobierno de Luis Alberto Monge, en 1982; en el marco de la Guerra Civil en Centroam�rica.

Esta guerrilla estableci� tensi�n en el istmo centroamericano y con la llegada al poder de Ronald Reagan en Estados Unidos, se pretend�a el establecimiento de un �Frente Sur� en Costa Rica, como medida de presi�n a la dictadura Sandinista en Nicaragua.

Para el Dr. David D�az Arias, director del Centro de Investigaciones Hist�ricas de Am�rica Central (CIHAC) de la Universidad de Costa Rica, esta celebraci�n constituy� un marco nuevo de la fiesta a la independencia en un momento de crisis muy fuerte en Centroam�rica, as� como a lo interno del pa�s.

Fue en este contexto, posterior a una crisis econ�mica y siendo frontera sur de la Revoluci�n Sandinista, que el ex presidente Monge implement� la denominada �Declaraci�n Perpetua de Neutralidad Costarricense� como medida de oposici�n a la intenci�n del presidente Reagan, de establecer un ej�rcito en el pa�s.

La Declaraci�n Perpetua de Neutralidad Costarricense fue proclamada en 1983, en la cual el exmandatario Luis Alberto Monge, estableci� la neutralidad perpetua, activa y no armada de Costa Rica ante cualquier conflicto b�lico. Esta acci�n represent� la culminaci�n del proceso de desarme unilateral y voluntario, que se origin� en 1949.
Monge reorden� las fiestas patrias, incluyendo al 14 de septiembre como parte de las celebraciones; contrario a las disposiciones del mandatario anterior, Rodrigo Carazo Odio, quien estableci� que las festividades se realizar�an �nicamente el 15 de septiembre y con concentraci�n en el Estadio Nacional de Costa Rica.

El ex mandatario Monge, estableci� como parte de las festividades que ni�os, ni�as y j�venes de escuelas y colegios marcharan en las calles y que se estableciera una cadena nacional, en radio y televisi�n, con el prop�sito de cantar el Himno Nacional el 14 de septiembre a las 6:00 p.m., en un acto que unificara a la ciudadan�a.

La tradici�n del �Desfile de los Faroles� y la llegada de la Antorcha de la Independencia se establecieron varios a�os antes, en 1949, como medidas para enriquecer las celebraciones del 14 de septiembre en el pa�s.

La tradici�n del desfile de los faroles inici� en 1949, ante el rescate de los valores patrios. Por este motivo, el profesor V�ctor Manuel Ure�a Arguedas, director provincial de las Escuelas de San Jos�, organiz� oficialmente el desfile de los faroles y encomend� a los docentes de escuelas y colegios, realizar esta actividad cada a�o el 14 de septiembre, a las 6:00 p.m., con el objetivo de inculcar el esp�ritu c�vico en la ciudadan�a.

�El canto del himno nacional y el desfile de los faroles, constituyen una recuperaci�n de la fiesta patria que hab�a perdido mucho brillo, en la d�cada de 1970. Principalmente por la p�rdida del eje que se centraba en los ni�os y ni�as y s�lo contemplaba a los j�venes en las celebraciones en el Estadio Nacional�, expres� el historiador David D�az.

�Ambas tradiciones constituyeron un esfuerzo importante de la recuperaci�n y popularizaci�n de esa fiesta en sitios p�blicos y las calles. As� como para impulsar el nacionalismo costarricense en el marco de la crisis centroamericana que atraves� el pa�s�, concluy� el acad�mico.',DATE '2022-09-14',0,1,3,1, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_article.nextval,'La UCR cre� una gu�a sobre pruebas estandarizadas de alto impacto','El Instituto de Investigaciones Psicol�gicas (IIP) de la Universidad de Costa Rica (UCR) public� una gu�a sobre los est�ndares de calidad para las Pruebas Estandarizadas de Alto Impacto en diversos contextos acad�micos y profesionales del pa�s.

Las Pruebas Estandarizadas son dispositivos o procedimientos evaluativos que brindan muestras de la conducta, caracter�sticas, aptitudes y destrezas de las personas evaluadas, las cuales se aplican en poblaciones muy grandes; tal como se realiza en los procesos de admisi�n a universidades o la incorporaci�n a colegios profesionales.

�Las pruebas estandarizadas de alto impacto y sus resultados afectan directamente las vidas de las personas; desde entrar a la universidad, obtener el bachillerato o ejercer una profesi�n�, expres� la Dra. Vanessa Smith Castro, psic�loga y creadora del proyecto.

Este esfuerzo es producto de la Comisi�n Interinstitucional Est�ndares de Calidad del IIP, conformada desde el 2016, ante la necesidad de una instancia que estableciera est�ndares de calidad para las Pruebas de Alto Impacto que se aplican en el pa�s desde diversos contextos. 

A lo interno de la Comisi�n Interinstitucional, coordinada por el IIP, participan diversas unidades de la Universidad de Costa Rica, tales como la Maestr�a en Evaluaci�n Educativa, el Posgrado en Especialidades M�dicas, y la Oficina de Recursos Humanos, entre otras; as� como entidades externas a la UCR, incluidas el Instituto Tecnol�gico, el Colegio de Abogados y Abogadas, el Colegio de Profesionales en Psicolog�a, la Direcci�n General del Servicio Civil y, el Ministerio de Educaci�n P�blica.

El IIP busca con esta nueva publicaci�n ofrecer insumos para la conformaci�n de pruebas estandarizadas que sean justas, v�lidas, �ticas y cient�ficas. La gu�a ser� compartida con entidades tales como universidades p�blicas, colegios profesionales, centros de investigaci�n, ministerios y otras entidades que elaboren y apliquen Pruebas Estandarizadas,  o bien, aquellas que se encarguen del estudio de las mismas.

Seg�n la Dra. Eiliana Montero Rojas, evaluadora educativa y estad�stica, el uso de Pruebas Estandarizadas de Alto Impacto implica un proceso de construcci�n y validaci�n guiado cient�ficamente, utilizando los m�s altos est�ndares de calidad para garantizar la confiabilidad y validez de las inferencias que se realizan en dichas evaluaciones.

La acad�mica afirm� que con la publicaci�n de esta gu�a se busca erradicar los mitos alrededor de estas pruebas y sus usos, con el objetivo de promover la pr�ctica de una cultura rigurosa, transparente, �tica y justa alrededor de este tipo de procedimientos evaluativos.

Para Montero, la gu�a para las Pruebas Estandarizadas constituye un primer esfuerzo, en la generaci�n de productos y est�ndares de calidad, los cuales sin embargo, requieren de una continua actualizaci�n de los t�picos y lineamientos.

�El avance en metodolog�as y construcci�n de pruebas estandarizadas hace necesarias la continua actualizaci�n de los temas y la inclusi�n de temas emergentes. Por lo que es un trabajo en proceso�, aclar� la investigadora que lidera la iniciativa. 

Debido a que se trata de ex�menes de grandes consecuencias para la vida y el desarrollo de las personas, las pruebas deben ser construidas, validadas y aplicadas respetando la tradici�n cient�fica en psicometr�a y medici�n educativa.

El documento generado tiene como prop�sito orientar la labor y los planes de mejoramiento de las instituciones involucradas con la validez, equidad y �tica en la aplicaci�n de las Pruebas Estandarizadas en contextos acad�micos y profesionales.

Las investigadoras involucradas en este proceso enfatizan en que las recomendaciones constituyen un primer paso y aspiran a una futura acreditaci�n, con el fin de que estas gu�as y el trabajo de la Comisi�n Interinstitucional se conviertan en referentes en materia de elaboraci�n de pruebas estandarizadas en el pa�s.',DATE '2022-09-09',2,1,0,1, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
values(s_article.nextval,'Voz experta: Negociar el FEES','Hace pocos d�as inici� un proceso de negociaci�n del Fondo Especial para la Educaci�n Superior (FEES), que se da en el seno de la Comisi�n de Enlace, constituida por representantes de las universidades p�blicas y del gobierno. Este proceso, seg�n una lectura estricta del art�culo 85 de la Constituci�n Pol�tica de nuestro pa�s deber�a darse cada 5 a�os, pero en los �ltimos a�os ha ocurrido anualmente.

Negociar, seg�n la segunda acepci�n del Diccionario de la Real Academia Espa�ola, significa �Tratar asuntos p�blicos o privados procurando su mejor logro.� Deber�a ser un proceso de di�logo honesto, claro, basado en datos y hechos que lleve a un acuerdo entre las partes. Puede ser corto, en el que las partes llegan a un acuerdo r�pido o lento con muchas discusiones, propuestas y contrapropuestas. No es, ni deber�a ser uno en el que una de las partes imponga sus condiciones. Debe prevalecer un inter�s com�n, en el caso de la negociaci�n del FEES, m�s a�n, un inter�s superior.

Este a�o, la negociaci�n del FFES inici� tard�amente, y luego de dos sesiones de negociaci�n, el conflicto estall�. Las universidades iniciaron la negociaci�n con su propuesta en la primera sesi�n y el Gobierno hizo la suya en la segunda. Hasta all� todo parec�a ir bien. Sin embargo, el Gobierno acompa�� su propuesta con una declaraci�n p�blica de exigencias a las universidades, en tono confrontativo e insultante.

En la primera parte de esta declaraci�n, el Gobierno enfrenta la educaci�n b�sica y media a la universitaria. Dice que �Estamos ante un gran dilema, porque todos los niveles de educaci�n son importantes.� Hasta aqu� estamos de acuerdo, pero luego, hace un salto il�gico al decir: ��A qui�n damos m�s quit�ndole al otro?� No, se�ora Ministra de Educaci�n, a todos debemos darles m�s y satisfacer sus necesidades. Nuestra Constituci�n Pol�tica, en su Art�culo 78 dice que �En la educaci�n estatal, incluida la superior, el gasto p�blico no ser� inferior al ocho por ciento (8%) anual del producto interno bruto, de acuerdo con la ley, sin perjuicio de lo establecido en los art�culos 84 y 85 de esta Constituci�n.� Actualmente ese gasto apenas llega al 6 %. Si �El estado de las escuelas y colegios es deplorable, la infraestructura est� en un nivel de deterioro sin precedentes, maestros trabajan con las u�as��, si esto es as� no es porque �El presupuesto de las Universidades viene creciendo de manera sostenida desde el a�o 2010, mientras que el presupuesto del MEP decrece, con los resultados no satisfactorios en calidad educativa que estamos teniendo.� No, se�ora Ministra, este estado de cosas no se debe al �crecimiento del FEES� sino a la baja inversi�n del Estado en educaci�n. Por otra parte, la proporci�n del FEES en el presupuesto de la educaci�n se ha mantenido casi constante alrededor del 19 al 20%.

La declaraci�n del Gobierno, luego de enfrentar los estudiantes universitarios a los estudiantes del MEP en la primera p�gina, con un nuevo salto argumentativo dice, c�nicamente en la segunda p�gina, �No estamos propiciando una lucha entre estudiantes del MEP y estudiantes de las universidades porque ambos son igualmente importantes. Debemos velar por los derechos de ambas poblaciones.�

Luego viene la lista de 10 �vehementes solicitudes�. No me referir� a ellas una a una, ya que todas estas solicitudes ya se est�n cumpliendo de muchas formas. Me detengo en la n�mero 9, que es la que califico de insultante: �Que (las Universidades) sean transparentes, no enga�en a la opini�n ni a la comunidad estudiantil, que muestren datos incluyendo el costo por estudiante y la asignaci�n real en becas.�

No se�ora Ministra, las Universidades p�blicas no enga�an �ni a la opini�n (�p�blica?) ni a la comunidad estudiantil�� La Universidad de Costa Rica est� entre las primeras instituciones en el ��ndice de Transparencia del Sector P�blico, ITSP� que publica la Defensor�a de los Habitantes.',DATE '2022-08-23',1,1,2,1, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');


insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
values(s_article.nextval,'Aumento en intereses no da tregua al bolsillo nacional','Tasa de pol�tica monetaria subi� a 8,5% y condiciona intereses de pr�stamos
En agosto pasado, la variaci�n del IPC alcanz� el 12,13%, siendo la inflaci�n m�s alta en el pa�s en los �ltimos 13 a�os.
Con la m�s alta Inflaci�n Interanual y Tasa de Pol�tica Monetaria de la �ltima d�cada, as� cerr� la noche del 14 de setiembre, cuando la Junta Directiva del Banco Central de Costa Rica (BCCR) anunci� mediante comunicado de prensa el s�timo aumento consecutivo de la Tasa de Pol�tica Monetaria (TPM). El incremento de 7,50% a 8,50%, representa un aumento de 7,75 puntos porcentuales desde diciembre del 2021. 

Bajo esta premisa, los aumentos de la tasa tienen implicaciones muy serias en todo el sistema financiero y la econom�a nacional. La TPM parte como referencia de las entidades financieras, intermediarios y otros, para calcular el costo econ�mico en caso de requerir recursos del Banco Central; adem�s parte como base de cobro para el c�lculo de las tasas de cr�ditos al p�blico, es decir, los aumentos de la TPM terminan traspas�ndose a las tasas activas, que son las que paga el p�blico y las empresas por sus cr�ditos.

�Los efectos para las familias y el sector productivo que requieren dinero o que tienen pr�stamos es de estrujamiento en sus finanzas y de desaceleraci�n de la actividad econ�mica.  Si las personas tienen deudas con tasas variables, las mismas van a aumentar reduciendo el ingreso disponible y necesariamente el consumo de otros bienes y servicios�, indic� Olman Segura Bonilla, Director del Centro Internacional de Pol�tica Econ�mica para el Desarrollo Sostenible (CINPE), de la Universidad Nacional. 

As� mismo, las empresas igualmente deber�n acomodar sus finanzas y de hecho tender�n a reducir sus gastos para ajustar su presupuesto a la nueva realidad. Tambi�n, ante el aumento de las tasas de inter�s se reduce la propensi�n al riesgo y a las inversiones en nuevos emprendimientos.

Costa Rica, de acuerdo a el �ndice Mensual de Actividad Econ�mica (IMAE) ha registrado 12 meses seguidos de desaceleraci�n, pasando de 10,3% en enero del 2022, a 3,5% en agosto de este a�o. Por otra parte, el pa�s registr� el mayor aumento del �ndice de precios al consumidor (IPC), siendo un 12,13% de inflaci�n interanual de setiembre del 2021 a agosto 2022.

Los aumentos de la TPM, a pesar de la ralentizaci�n de la econom�a, se realizan con la intenci�n de controlar la inflaci�n. �sta, a diferencia del 2021 en que termin� dentro del rango meta que hab�a establecido el BCCR de entre 2% y 4%, siendo 3,30%; en el 2022 definitivamente terminar� fuera de ese rango, pues de enero a agosto de este a�o ya alcanz� 9,45%.

Seg�n el Instituto Nacional de Estad�stica y Censos (INEC), el transporte, los alimentos y bebidas no alcoh�licas, y comidas fuera del hogar son los que m�s contribuyen al aumento de la inflaci�n. Este tipo de gastos representan una mayor porci�n de los ingresos de las personas de ingresos m�s bajos, lo que convierte lamentablemente a la inflaci�n como el �impuesto enemigo� que puede enfrentar la poblaci�n. 

�El Banco Central y el gobierno deben considerar esta situaci�n de un doble estrujamiento a los bolsillos de las familias m�s pobres y endeudadas, que en el corto plazo tendr�n que enfrentar aumentos en el pago de intereses y aumento de precios en su canasta b�sica, y quiz�s hasta un tercer efecto que puede ser la p�rdida de empleo ante la desaceleraci�n de la econom�a�, manifest� el Director Segura.

A su vez Segura calific� como preciso y urgente un plan de reactivaci�n econ�mica y el anuncio de una pol�tica econ�mica clara que reduzca la incertidumbre, y genere estabilidad y confianza en el sector productivo nacional.',DATE '2022-09-06',0,2,4,1, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');


insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_article.nextval,'A 12 a�os del terremoto de Cinchona','�Costa Rica, 8 de enero del 2009, 13:21 pm, hora local, un terremoto con magnitud de momento s�smico, MW= 6,2, ubicado 4 km hacia el Suroeste de Cinchona de Sarapiqu� de Alajuela, a una profundidad de 7 km, gener� una basta cantidad de deslizamientos que provocaron la muerte a 22 personas, 100 desaparecidos y gran cantidad de heridos, tambi�n da�os estructurales en casas y edificios cercanos�, as� consta en el reporte oficial emitido por el Observatorio Vulcanol�gico y Sismol�gico de Costa Rica de la Universidad Nacional (Ovsicori-UNA).

Datos del instituto se�alan que el evento principal estuvo asociado al sistema de fallas Vara Blanca-�ngel; un sistema de fallas ubicado en el flanco este del volc�n Po�s con movimiento lateral derecho y orientaci�n Noroeste-Suroeste.

Marino Protti, sism�logo y actual director del Ovsicori, indic� que el evento fue precedido por un sismo (evento premonitor) de magnitud 4,5, ubicado 4 km al Noroeste de Fraijanes de Sabanilla de Alajuela, (a menos de 3 km del Terremoto de Cinchona), ocurrido el 7 de enero a las 10:00 hora local, el cual gener� alrededor de 25 r�plicas con magnitudes locales menores a 3,0.

En esa oportunidad, la red s�smica del OVSICORI-UNA localiz� un total de 1032 r�plicas todo el mes de enero de 2009. Asimismo, el deslizamiento ocurrido en esa falla durante el terremoto de Cinchona tuvo una duraci�n de ~5 s, generando una ca�da de esfuerzos de 6.71 MPa y aceleraciones m�ximas en superficie de 223 gal (2.156 m/s2) en el valle central.

Durante 12 a�os, la misma naturaleza se ha encargado de ocultar los deslizamientos en los cerros cercanos al lugar del epicentro, la carretera se habilit�, la actividad agr�cola de la zona se activ� tiempo despu�s y el poblado de Cinchona fue reubicado en Cariblanco de Sarapiqu� de Alajuela, donde habitan las casi 80 familias que perdieron sus casas en el terremoto de Cinchona, la tarde del 8 de enero del 2009.',DATE '2021-01-08',0,2,3,2, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');

insert into article
(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_article.nextval,'Situaci�n del empleo en Costa Rica sigue delicada','El Observatorio Econ�mico y Social (OES) de la Escuela de Econom�a de la Universidad Nacional (UNA), present� un an�lisis sobre la situaci�n del empleo en Costa Rica, con base en los datos obtenidos de la Encuesta Continua de Empleo del primer trimestre del 2021, a cargo de los economistas Fernando Rodr�guez y Greivin Salazar, quienes consideran que volver a la situaci�n pre covid-19 en materia de empleo implicar� un esfuerzo muy grande en cuanto a crecimiento de ciertos sectores. A la vez, que j�venes, mujeres y habitantes de zonas rurales son quienes sufren mayor afectaci�n por problemas de desempleo e informalidad.

Una de las principales observaciones del estudio es que el dato de desempleo podr�a ser mayor, pues muchas personas se quedaron sin trabajo y decidieron no buscar empleo, por lo que formalmente no se les considera desempleados. Este grupo de personas que est�n fuera del mercado laboral incluye un porcentaje creciente de j�venes, quienes no s�lo no est�n trabajando, sino que tampoco est�n estudiando en el sistema formal.

Aquellas actividades que perdieron empleos producto de la pandemia covid-19 requerir�n crecer a tasas importantes en los pr�ximos a�os para que se puedan recuperar esos puestos de trabajo perdidos. En actividades vinculadas con el turismo, la actividad econ�mica deber� crecer un 31% en dos a�os, para reponer los trabajos perdidos durante el 2020, mientras que en el caso de construcci�n se deber� crecer un 3,9% y en el sector comercial a un 5,1%, a fin de lograr el mismo objetivo.

La informalidad se alivi� parcialmente durante la etapa m�s fuerte del confinamiento no por una mejora en las condiciones de trabajo del pa�s, sino porque muchas personas en actividades informales perdieron su empleo y no salieron a buscar trabajo. La informalidad se sigue centrando en el pac�fico costarricense, donde alcanza casi un 47% de la poblaci�n ocupada a nivel nacional.
En cuanto al ingreso de las personas ocupadas, este no sufri� mayor variaci�n en el �ltimo a�o, cuando se ve al total de la poblaci�n, pero s� aument� ligeramente para los hombres y disminuy� en una proporci�n similar para las mujeres. Cuando se desglosa el ingreso seg�n posici�n en el trabajo, los asalariados y los trabajadores por cuenta propia no sufrieron mayor variaci�n, mientras que los empleadores mejoraron su ingreso al punto de ubicarse por encima de los niveles de la pre pandemia.

Sobre los datos de desempleo, la mayor�a de las personas desempleadas no tienen formaci�n profesional: el 81% tiene secundaria completa o una formaci�n menor y es, mayoritariamente, un grupo joven; el 62% de los desempleados tiene 34 a�os o menos. La regi�n con m�s problemas de desempleo es la regi�n Central, seguida de la Brunca y de la Chorotega. El desempleo contin�a siendo un problema que afecta m�s a las mujeres, pues casi se duplica el porcentaje con respecto a los hombres. El dato es todav�a m�s dram�tico en el caso de las mujeres j�venes, pues aqu� el desempleo entre mujeres de 15 a 24 a�os es de 58,8%, mientras que en el grupo de 25 a 34 a�os es de 26,4%.

A fin de retomar la recuperaci�n del empleo, los investigadores del Observatorio Econ�mico y Social de la Escuela de Econom�a llaman a aplicar medidas de est�mulo productivo, que cambien la senda actual de crecimiento y rompan con las medidas contractivas aplicadas desde la pol�tica fiscal (centrada en recortes de gasto). Es fundamental�agregan�una pol�tica de recuperaci�n de empleo con visi�n de g�nero, que promueva un mayor acceso al mercado de trabajo y no se convierta en un obst�culo para ese fin. Por lo tanto, los investigadores reiteran su rechazo al Proyecto de Ley de Jornadas Extraordinarias y m�s bien hacen un llamado a fortalecer las iniciativas que promuevan una mayor incorporaci�n de las mujeres al mercado laboral.',DATE '2021-07-09',2,2,5,2, SYSDATE, 'BDPROJECT', SYSDATE, 'BDPROJECT');
