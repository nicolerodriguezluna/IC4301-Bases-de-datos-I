INSERT INTO street
(id_street,name_street,id_location)
VALUES (00,'Avenida 5', 01);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (01,'Avenida 18', 02);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (02,'Avenida 30', 03);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (03,'Calle Meza', 04);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (04,'Calle La Cartonera', 05);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (05,'Avenida 3', 06);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (06,'Calle 4 Maravilla', 07);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (07,'Calle Lim�n', 08);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (08,'Avenida Tulipanes', 09);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (09,'Calle Beto', 10);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (10,'Calle Bol�var', 11);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (11,'Calle 10', 12);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (12,'Avenida 5 Juan Santamar�a', 13);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (13,'Calle Valverde', 14);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (14,'Loria', 15);


INSERT INTO street
(id_street,name_street,id_location)
VALUES (15,'Calle Boza', 16);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (16,'Calle Naranjo', 17);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (17,'Calle Central', 18);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (18,'Calle Cuchilla', 19);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (19,'Calle 30', 20);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (20,'Calle F', 21);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (21,'Nel Ruiz', 22);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (22,'Calle Los Caballeros', 23);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (23,'Calle 7 Damasco Villalobos', 24);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (24,'Calle Central Rafael Iglesias', 25);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (25,'Calle Argentina', 26);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (26,'Avenida Parroquial', 27);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (27,'Calle Los Papas', 28);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (28,'Calle Corobic� 2', 29);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (29,'Calle Palma', 30);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (30,'Calle Acapulco', 31);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (31,'Calle Los Bomberos', 32);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (32,'Calle Artieda', 33);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (33,'Calle Alto Barrantes', 34);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (34,'Alameda 4', 35);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (35,'Calle Volc�n-Cacao', 36);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (36,'Calle Mo�n', 37);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (37,'Carretera Braulio Carrillo', 38);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (38,'Calle El Bosque', 39);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (39,'Calle Ceibo', 40);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (40,'Calle Los Paisas', 41);

INSERT INTO street
(id_street,name_street,id_location)
VALUES (41,'Calle Cairo', 42);












