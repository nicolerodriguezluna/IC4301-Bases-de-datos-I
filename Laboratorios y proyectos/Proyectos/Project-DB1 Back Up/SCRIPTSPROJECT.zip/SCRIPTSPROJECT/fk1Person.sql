ALTER TABLE person 
ADD CONSTRAINT fk_person_idcampus FOREIGN KEY (id_quad) REFERENCES campus (id_campus)
ADD CONSTRAINT fk_person_idCouncil FOREIGN KEY (id_council) REFERENCES committe (id_committe)
ADD CONSTRAINT fk_person_iddirection FOREIGN KEY (id_direction) REFERENCES street (id_street)
ADD CONSTRAINT fk_person_gender FOREIGN KEY (type_gender) REFERENCES gender (type_gender)

