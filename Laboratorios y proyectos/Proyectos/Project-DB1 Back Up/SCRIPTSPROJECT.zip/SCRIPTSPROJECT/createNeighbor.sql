create table neighbour
(
    id_person number(15) CONSTRAINT neighbour_idperson_nn NOT NULL
);