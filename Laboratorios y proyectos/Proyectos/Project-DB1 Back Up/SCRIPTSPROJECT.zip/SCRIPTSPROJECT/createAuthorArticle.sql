CREATE TABLE authorxarticle
(
 id_author_autart NUMBER(15) CONSTRAINT authartcl_idauthor_nn NOT NULL,
 id_article_autart NUMBER(15) CONSTRAINT authartcl_idarticle_nn NOT NULL
);