create table status(
    id_status NUMBER(3) CONSTRAINT status_idstatus_nn NOT NULL,
    name_status VARCHAR2(15) CONSTRAINT status_namestat_nn NOT NULL
);
