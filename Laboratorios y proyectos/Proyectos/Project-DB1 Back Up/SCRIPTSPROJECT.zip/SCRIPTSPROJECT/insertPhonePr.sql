INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,22509878,0, 00,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,64854789,1, 01,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,22707713,2, 2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,71602741,3, 0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,88906576,4, 1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,22145391,5, 2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,22144536,6, 0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,88375692,7, 1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,22142111,8, 2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,89098162,9,0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,28716278,10, 1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,84854780,11, 0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,22707711,12, 2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,88192817,13,0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,22817627,14, 1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,22145123,15, 2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,22144231,16, 0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,88375618,17, 1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_phone.nextval,22142019,18, 2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT into phone
(id_phone,number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_phone.nextval,89098117,19,0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

