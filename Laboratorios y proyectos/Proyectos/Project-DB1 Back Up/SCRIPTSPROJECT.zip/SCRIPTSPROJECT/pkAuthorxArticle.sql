ALTER TABLE authorxarticle
ADD CONSTRAINT pk_authorxarticle PRIMARY KEY (id_author_autart, id_article_autart)
USING INDEX
TABLESPACE bdproject_ind PCTFREE 20
STORAGE (INITIAL 10K NEXT 10K PCTINCREASE 0)
