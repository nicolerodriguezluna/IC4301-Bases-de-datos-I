CREATE table parameterDb
(
    id_parameter NUMBER(15) CONSTRAINT parameterDB_idparameter_nn NOT NULL,
    name_parameter VARCHAR2(30) CONSTRAINT parameterDB_name_nn NOT NULL,
    description_parameter VARCHAR2(100) CONSTRAINT parameterDB_descrp_nn NOT NULL,
    value_parameter NUMBER(4) CONSTRAINT parameterDB_value_nn NOT NULL
);