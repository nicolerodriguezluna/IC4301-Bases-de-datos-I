CREATE TABLE productXauthor
(
 id_product_pa NUMBER(15) CONSTRAINT productauthor_idproduct_nn NOT NULL,
 id_author_pa NUMBER(15) CONSTRAINT productauthor_author_nn NOT NULL
);