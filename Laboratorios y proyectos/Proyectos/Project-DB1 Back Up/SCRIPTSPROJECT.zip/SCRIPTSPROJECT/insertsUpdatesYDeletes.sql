CREATE OR REPLACE PROCEDURE insert_administrative(pidPerson in NUMBER, pIdDedication in number)
as
BEGIN 
    insert into administrative(id_person,id_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
    values (pidPerson,pIdDedication,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_administrative;

CREATE OR REPLACE PROCEDURE insert_administrator(pidPerson in NUMBER,pvPassword in VARCHAR2)
as
BEGIN 
    insert into administrator(id_person,password_admin,creationdate,userid,lastmodifydate,lastmodifyby)
    values (pidPerson,pvPassword,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_administrator;

CREATE OR REPLACE PROCEDURE insert_article(pvTitle Varchar2,pvText VARCHAR2,pvPublication IN VARCHAR2,pidStatus in NUMBER,
pidNewspaper in NUMBER,pidArticlecategory in NUMBER, pidcommitte in NUMBER)
AS
BEGIN
    insert into article(id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art,
    creationdate,userid,lastmodifydate,lastmodifyby)
    VALUES (s_article.nextval,pvTitle,pvText,TO_DATE(pvPublication),pidStatus,pidNewspaper,pidArticlecategory,pidcommitte,
    NULL, NULL, NULL, NULL);
    COMMIT;
END insert_article;

CREATE OR REPLACE PROCEDURE insert_article_category(pvNameCategory IN VARCHAR2,pvDescription IN VARCHAR2)
AS
BEGIN
    insert into articlecategory(id_article_category,name_category,description_category,creationdate,userid,lastmodifydate,lastmodifyby)
    VALUES(s_articlecategory.nextval,pvNameCategory,pvDescription,NULL,NULL,NULL,NULL);
    COMMIT;
END insert_article_category;

CREATE OR REPLACE PROCEDURE insert_author(pidPerson in NUMBER, pidAuthorCategory in Number) AS
BEGIN
    insert into author(id_person,id_author_cathegory,creationdate,userid,lastmodifydate,lastmodifyby)
    VALUES (pidPerson,pidAuthorCategory,NULL,NULL,NULL,NULL);
    COMMIT;
END insert_author;

CREATE OR REPLACE PROCEDURE insert_author_category(pvTypeCategory in VARCHAR2) AS
BEGIN
INSERT INTO AUTHORCATEGORY(id_author_category,type_category,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(s_authorcategory.nextval,pvTypeCategory,NULL,NULL,NULL,NULL);
COMMIT;
END insert_author_category;

CREATE OR REPLACE PROCEDURE insert_authorxarticle(pnidAuthor in NUMBER,pnidArticle in Number)
AS
BEGIN
INSERT INTO authorxarticle(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (pnidAuthor,pnidArticle,NULL,NULL,NULL,NULL);
COMMIT;
END insert_authorxarticle;

CREATE OR REPLACE PROCEDURE insert_availability (pvdescription in VARCHAR2)
AS
BEGIN
INSERT INTO availabilitypr (id_availability,description_availability,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(s_availabilitypr.nextval,pvdescription,NULL,NULL,NULL,NULL);
COMMIT;
END insert_availability;

CREATE OR REPLACE PROCEDURE insert_campus(pvName IN VARCHAR2, pidCollege IN NUMBER,pidDistrict IN NUMBER)
AS
BEGIN
INSERT INTO campus(id_campus,name_campus,id_university,id_district,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(s_campus.nextval,pvName,pidCollege,pidDistrict,NULL,NULL,NULL,NULL);
COMMIT;
END insert_campus;

CREATE OR REPLACE PROCEDURE insert_canton(pvName IN VARCHAR2,pidArea in NUMBER)
AS
BEGIN
INSERT INTO canton(id_canton,name_canton,id_area,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(s_canton.nextval,pvName,pidArea,NULL,NULL,NULL,NULL);
COMMIT;
END  insert_canton;

CREATE OR REPLACE PROCEDURE insert_catalog (pidNewspaper IN NUMBER,pvDescription in VARCHAR2)
AS
BEGIN
INSERT INTO catalog(id_catalog,id_newspaper,description_catalog,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(s_catalog.nextval,pidNewspaper,pvDescription,NULL,NULL,NULL,NULL);
COMMIT;
END  insert_catalog;

CREATE OR REPLACE PROCEDURE insert_college(pvName IN VARCHAR2)
AS
BEGIN
INSERT INTO college(id_college,name_college,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES (s_college.nextval,pvName,NULL,NULL,NULL,NULL);
COMMIT;
END insert_college;

CREATE OR REPLACE PROCEDURE update_administrative(pidDedication in NUMBER,pidPerson IN number)
AS
BEGIN
    update administrative
    set id_dedication = pidDedication
    where pidPerson = administrative.id_person;
    COMMIT;
END update_administrative;

CREATE OR REPLACE PROCEDURE update_administrator(pidPerson in NUMBER,pvnewPass in NUMBER)
AS
BEGIN
    update administrator
    set password_admin = pvnewPass
    where administrator.id_person = pidPerson;
    COMMIT;
END update_administrator;

CREATE OR REPLACE PROCEDURE update_article_title(pvTitle in Varchar2, pidArticle in NUMBER)
AS
BEGIN
    update article
    set title_article = pvTitle
    where article.id_article = pidArticle;
    COMMIT;
END update_article_title;

CREATE OR REPLACE PROCEDURE update_article_note(pvText in VARCHAR2,pidarticle in NUMBER)
AS
BEGIN
    update article
    set text_note = pvText
    where article.id_article = pidarticle;
    COMMIT;
END update_article_note;

CREATE OR REPLACE PROCEDURE update_article_date(pvDate in VARCHAR2,pidarticle in NUMBER)
as
BEGIN
    update article
    set publication_date = TO_DATE(pvDate)
    where article.id_article = pidarticle;
    COMMIT;
END  update_article_date;

CREATE OR REPLACE PROCEDURE update_article_status(pnewStatus in NUMBER,pidarticle in NUMBER)
as
BEGIN
    update article
    set article.id_status_article = pnewStatus
    where article.id_article = pidarticle;
    COMMIT;
END  update_article_status;

CREATE OR REPLACE PROCEDURE update_article_newspaper(pNewNewspaper in NUMBER, pidarticle in NUMBER)
AS
BEGIN
    update article
    set article.id_dig_news = pNewNewspaper
    where article.id_article = pidarticle;
    COMMIT;
END update_article_newspaper;

CREATE OR REPLACE PROCEDURE update_article_category(pnewCategory in number,pidarticle in number)
as
BEGIN
    update article
    set article.id_art_cat = pnewCategory
    where article.id_article = pidarticle;
    COMMIT;
END update_article_category;

CREATE OR REPLACE PROCEDURE update_article_committe(pnewCommitte in number,pidarticle in number)
as
begin
    update article
    set article.id_committe_art = pnewCommitte
    where article.id_article = pidarticle;
    COMMIT;
END update_article_committe;

CREATE OR REPLACE PROCEDURE update_article_category_name(pcName in varchar2, pidcategory in Number)
AS
BEGIN
    update articlecategory
    set name_category = pcName
    where articlecategory.id_article_category = pidcategory;
    COMMIT;
END update_article_category_name;

CREATE OR REPLACE PROCEDURE update_article_cat_descrp(pcDescription in varchar2, pidcategory in number)
as
begin
    update articlecategory
    set articlecategory.description_category = pcDescription
    where articlecategory.id_article_category = pidcategory;
    COMMIT;
END update_article_cat_descrp;

CREATE OR REPLACE PROCEDURE update_author_category(pnewCategory in number, pidperson in number)
AS
begin
    update author
    set author.id_author_cathegory = pnewCategory
    where author.id_person = pidperson;
    COMMIT;
END update_author_category;

CREATE OR REPLACE PROCEDURE update_authorcategory_type(pnewType in VARCHAR2, pidauthorcategory in number)
AS
begin
    update authorcategory
    set authorcategory.type_category = pnewType
    where authorcategory.id_author_category = pidauthorcategory;
    COMMIT;
END update_authorcategory_type;

CREATE OR REPLACE PROCEDURE update_availabilitypr_descrp(pnewDescription in VARCHAR2, pidAvailability in number)
AS
BEGIN
    update availabilitypr
    set availabilitypr.description_availability = pnewDescription
    where availabilitypr.id_availability = pidAvailability;
    COMMIT;
END update_availabilitypr_descrp;

CREATE OR REPLACE PROCEDURE update_campus_name(pName in varchar2,pidcampus in number)
AS
BEGIN
    update campus
    set campus.name_campus = pName
    where campus.id_campus = pidcampus;
    COMMIT;
END  update_campus_name;

CREATE OR REPLACE PROCEDURE update_campus_university(pnewUniversity in NUMBER,pidcampus in NUMBER)
AS
BEGIN
    update campus
    set campus.id_university = pnewUniversity
    where campus.id_campus = pidcampus;
    COMMIT;
END update_campus_university;

CREATE OR REPLACE PROCEDURE update_campus_district(pnewDistrict in number, pidcampus in number)
AS
BEGIN
    update campus
    set campus.id_district = pnewDistrict
    where campus.id_campus = pidcampus;
    COMMIT;
END update_campus_district;

CREATE OR REPLACE PROCEDURE update_canton_name(pnewName in varchar2, pidcanton in NUMBER)
AS
begin
    update canton
    set name_canton = pnewName
    where canton.id_canton = pidcanton;
    COMMIT;
END update_canton_name;

CREATE OR REPLACE PROCEDURE update_canton_area(pnewarea in number, pidcanton in number)
as
begin
    update canton
    set canton.id_area = pnewarea
    where canton.id_canton = pidcanton;
    COMMIT;
END update_canton_area;

CREATE OR REPLACE PROCEDURE update_catalog_newspaper(pnewPaper in number, pidcatalog in number)
as
begin
    update catalog
    set catalog.id_newspaper = pnewPaper
    where catalog.id_catalog = pidcatalog;
    COMMIT;
END update_catalog_newspaper;

CREATE OR REPLACE PROCEDURE update_catalog_description(pnewDescription in VARCHAR2, pidcatalog in number)
as
begin
    update catalog
    set catalog.description_catalog = pnewDescription
    where catalog.id_catalog = pidcatalog;
    COMMIT;
END update_catalog_description;

CREATE OR REPLACE PROCEDURE update_college_name(pnewName in varchar2, pidcollege in number)
AS
BEGIN
    update college 
    set college.name_college = pnewName
    where college.id_college = pidcollege;
    COMMIT;
END update_college_name;



--DELETES
CREATE OR REPLACE PROCEDURE delete_administrative(pidadministrative in number)
as
begin
    delete from administrative
    where administrative.id_person = pidadministrative;
    COMMIT;
END delete_administrative;

CREATE OR REPLACE PROCEDURE delete_administrator(pidadministrator in number)
as
begin
    delete from administrator
    where administrator.id_person = pidadministrator;
    COMMIT;
END delete_administrator;

CREATE OR REPLACE PROCEDURE delete_article(pidarticle in NUMBER)
AS
BEGIN
    delete from article
    where article.id_article = pidarticle;
    COMMIT;
END  delete_article;

CREATE OR REPLACE PROCEDURE delete_articlecategory(pidarticlecategory in number)
as
begin
    delete from articlecategory
    where articlecategory.id_article_category = pidarticlecategory;
    COMMIT;
END delete_articlecategory;

CREATE OR REPLACE PROCEDURE delete_author(pidauthor in number)
as
begin
    delete from author
    where author.id_person = pidauthor;
    commit;
END delete_author;

CREATE OR REPLACE PROCEDURE delete_author_category(pidAuthorcategory in number)
as
begin
    delete from authorcategory
    where authorcategory.id_author_category = pidAuthorcategory;
    commit;
end  delete_author_category;

CREATE OR REPLACE PROCEDURE delete_authorxarticle_author(pidauthor in number)
AS
begin
    delete from authorxarticle
    where authorxarticle.id_author_autart = pidauthor;
    commit;
end delete_authorxarticle_author;

CREATE OR REPLACE PROCEDURE delete_authorxarticle_article(pidarticle in number)
as
begin
    delete from authorxarticle
    where authorxarticle.id_article_autart = pidarticle;
    commit;
end delete_authorxarticle_article;

CREATE OR REPLACE PROCEDURE delete_availability(pidavailability in number)
as
begin
    delete from availabilitypr
    where availabilitypr.id_availability = pidavailability;
    commit;
end delete_availability;

CREATE OR REPLACE PROCEDURE delete_campus(idcampus in number)
as
begin
 delete from campus
 where campus.id_campus = idcampus;
 commit;
end delete_campus;

CREATE OR REPLACE PROCEDURE delete_canton(pidcanton in number)
as
begin
    delete from canton
    where canton.id_canton = pidcanton;
    commit;
end delete_canton;

CREATE OR REPLACE PROCEDURE delete_catalog(pidcatalog in number)
as
begin
    delete from catalog
    where catalog.id_catalog = pidcatalog;
    commit;
end delete_catalog;

CREATE OR REPLACE PROCEDURE delete_college(pidcollege in number)
as
begin
    delete from college
    where college.id_college = pidcollege;
    commit;
end delete_college;

CREATE OR REPLACE PROCEDURE delete_committee(pidCommittee IN NUMBER) AS
BEGIN
    DELETE FROM committe
    WHERE committe.id_committe = pidCommittee;
    COMMIT;
END delete_committee;

CREATE OR REPLACE PROCEDURE delete_country(pidCountry IN NUMBER) AS
BEGIN
    DELETE FROM country
    WHERE country.id_country = pidCountry;
    COMMIT;
END delete_country;

CREATE OR REPLACE PROCEDURE delete_dedication(pidDedication IN NUMBER) AS
BEGIN
    DELETE FROM dedication
    WHERE dedication.id_dedication = pidDedication;
    COMMIT;
END delete_dedication;

CREATE OR REPLACE PROCEDURE delete_digital_newspaper(pidDigitalNewspaper IN NUMBER) AS
BEGIN
    DELETE FROM digitalnewspaper
    WHERE digitalnewspaper.id_digital_newspaper = pidDigitalNewspaper;
    COMMIT;
END delete_digital_newspaper;

CREATE OR REPLACE PROCEDURE delete_district(pidDistrict IN NUMBER) AS
BEGIN
    DELETE FROM district
    WHERE district.id_district = pidDistrict;
    COMMIT;
END delete_district;

CREATE OR REPLACE PROCEDURE delete_email(pidEmail IN NUMBER) AS
BEGIN
    DELETE FROM email
    WHERE email.id_email = pidEmail;
    COMMIT;
END delete_email;


CREATE OR REPLACE PROCEDURE delete_favourite(pidArtRev IN NUMBER, pidUserRev IN NUMBER) AS
BEGIN
    DELETE FROM favourite
    WHERE favourite.id_user_fav = pidUserRev OR favourite.id_article_fav = pidArtRev;
    COMMIT;
END delete_favourite;

CREATE OR REPLACE PROCEDURE delete_gender(pidGender IN NUMBER) AS
BEGIN
    DELETE FROM gender
    WHERE gender.id_gender = pidGender;
    COMMIT;
END delete_gender;

CREATE OR REPLACE PROCEDURE delete_logDB(pidLogDB IN NUMBER) AS
BEGIN
    DELETE FROM logDB
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END delete_logDB;

CREATE OR REPLACE PROCEDURE delete_neighbour(pidNeighbour IN NUMBER) AS
BEGIN
    DELETE FROM neighbour
    WHERE neighbour.id_person = pidNeighbour;
    COMMIT;
END delete_neighbour;

CREATE OR REPLACE PROCEDURE delete_parameterDb(pidParameterDb IN NUMBER) AS
BEGIN
    DELETE FROM parameterDB
    WHERE parameterDb.id_parameter = pidParameterDb;
    COMMIT;
END delete_parameterDb;

CREATE OR REPLACE PROCEDURE delete_person(pidPerson IN NUMBER) AS
BEGIN
    DELETE FROM person
    WHERE person.id_person = pidPerson;
    COMMIT;
END delete_person;


--1
create or replace PROCEDURE insert_committe(pnIdCampus IN NUMBER,  pcNameCommittee IN VARCHAR2) AS
BEGIN
    INSERT INTO committe(id_committe, description_committe, creationDate, userid, lastModifyDate, lastModifyBy,id_campus)
    VALUES(s_committe.nextval, pcNameCommittee, NULL, NULL, NULL, NULL,pnIdCampus);
    COMMIT;
END insert_committe; 
--2
create or replace PROCEDURE insert_country(pnameCountry IN VARCHAR2) AS
BEGIN
    INSERT INTO country(id_country, name_country, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_country.nextval, pnameCountry, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_country;
--3
CREATE OR REPLACE PROCEDURE insert_dedication(pdescriptionDedication IN VARCHAR2) AS
BEGIN
    INSERT INTO dedication(id_dedication, description_dedication, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_dedication.nextval, pdescriptionDedication, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_dedication;
--4
CREATE OR REPLACE PROCEDURE insert_digital_newspaper(pname_digital_newspaper IN VARCHAR2, pidQuad IN NUMBER) AS
BEGIN
    INSERT INTO digitalNewspaper(id_digital_newspaper, name_digital_newspaper, id_quad,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_digitalNewspaper.nextval, pname_digital_newspaper, pidQuad, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_digital_newspaper;
--5
CREATE OR REPLACE PROCEDURE insert_district(pnameDistrict IN VARCHAR2, pidSector IN NUMBER) AS
BEGIN
    INSERT INTO district(id_district, name_district, id_sector, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_district.nextval, pnameDistrict, pidSector ,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_district; 
--6
CREATE OR REPLACE PROCEDURE insert_email(pAdressEmail IN VARCHAR2, pidPerson in NUMBER) AS
BEGIN
    INSERT INTO email(id_email, address_email, id_person_mail, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_email.nextval, pAdressEmail, pidPerson, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_email; 
--7
CREATE OR REPLACE PROCEDURE insert_favourite(pidArticleFav IN NUMBER, pidUserFav IN NUMBER, pDateFavourite IN VARCHAR2) AS
BEGIN
    INSERT INTO favourite(id_article_fav,id_user_fav,date_favourite, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidArticleFav, pidUserFav, pDateFavourite, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_favourite; 
--8
CREATE OR REPLACE PROCEDURE insert_gender(pTypeGender IN VARCHAR2) AS
BEGIN
    INSERT INTO gender(id_gender, type_gender,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_gender.nextval, pTypeGender,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_gender; 
--9
CREATE OR REPLACE PROCEDURE insert_logDB(pChangeDescription in VARCHAR2, pPreviousText in VARCHAR2, pCurrentText in VARCHAR2) AS
BEGIN
    INSERT INTO logdb(id_log,systemdate, time_log, change_descrp, previous_text,current_text,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, pChangeDescription, pPreviousText, pCurrentText,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_logDB; 
--10
CREATE OR REPLACE PROCEDURE insert_neighbour(pidPerson IN NUMBER) AS
BEGIN
    INSERT INTO neighbour(id_person,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidPerson,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_neighbour; 
--11
CREATE OR REPLACE PROCEDURE insert_ParameterDb(pnameParameter IN VARCHAR2,pdescriptionParameter IN VARCHAR2,pvalueParameter IN NUMBER, proute IN VARCHAR2) AS
BEGIN
    INSERT INTO ParameterDb(id_Parameter,name_parameter, description_parameter, value_parameter, route,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_parameter.nextval, pnameParameter, pdescriptionParameter, pvalueParameter, proute, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_ParameterDb; 
--12
CREATE OR REPLACE PROCEDURE insert_person(pidentifyCard IN NUMBER, pfirstName IN VARCHAR2,psecondName IN VARCHAR2, pfirstSurname IN VARCHAR2, psecondSurname IN VARCHAR2, pdatebirth IN VARCHAR2, pidQuad IN NUMBER, pidGender IN NUMBER, pexactLocalitation in VARCHAR2, pidDistrict in NUMBER) AS
BEGIN
    INSERT INTO person(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
    VALUES(s_person.nextval, pidentifyCard, pfirstName,psecondName, pfirstSurname, psecondSurname, pdatebirth, pidQuad, pidGender, pexactLocalitation, pidDistrict, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_person; 

CREATE OR REPLACE PROCEDURE update_committee_description(pidCommittee IN NUMBER, pNewDescriptionCommittee IN VARCHAR2) AS
BEGIN
    UPDATE committe
    SET committe.description_committe = pNewDescriptionCommittee
    WHERE committe.id_committe= pidCommittee;
    COMMIT;
END update_committee_description;

create or replace PROCEDURE update_country_name(pidCountry IN NUMBER, pNewNameCountry IN VARCHAR2) AS
BEGIN
    UPDATE country
    SET country.name_country = pNewNameCountry
    WHERE country.id_country = pidCountry;
    COMMIT;
END update_country_name;

CREATE OR REPLACE PROCEDURE update_dedication_description(pidDedication  IN NUMBER, pNewDescriptionDadication IN VARCHAR2) AS
BEGIN
    UPDATE dedication
    SET dedication.description_dedication = pNewDescriptionDadication
    WHERE dedication.id_dedication = pidDedication;
    COMMIT;
END update_dedication_description;

CREATE OR REPLACE PROCEDURE update_digitalNewspaper_name(pidDigitalNewspaper IN NUMBER, pNewNameDigital IN VARCHAR2) AS
BEGIN
    UPDATE digitalnewspaper
    SET digitalnewspaper.name_digital_newspaper = pNewNameDigital
    WHERE digitalnewspaper.id_digital_newspaper = pidDigitalNewspaper;
    COMMIT;
END update_digitalNewspaper_name;

CREATE OR REPLACE PROCEDURE update_digitalNewspaper_quad(pidDigitalNewspaper IN NUMBER, pNewIdQuad IN NUMBER) AS
BEGIN
    UPDATE digitalnewspaper
    SET digitalnewspaper.id_quad = pNewIdQuad
    WHERE digitalnewspaper.id_digital_newspaper = pidDigitalNewspaper;
    COMMIT;
END update_digitalNewspaper_quad;


CREATE OR REPLACE PROCEDURE update_district_name(pidDistrict IN NUMBER, pNewNameDistrict IN VARCHAR2) AS
BEGIN
    UPDATE district
    SET district.name_district = pNewNameDistrict
    WHERE district.id_district = pidDistrict;
    COMMIT;
END update_district_name;

CREATE OR REPLACE PROCEDURE update_district_sector(pidDistrict IN NUMBER, pNewIdSector IN NUMBER) AS
BEGIN
    UPDATE district
    SET district.id_sector = pNewIdSector
    WHERE district.id_sector = pidDistrict;
    COMMIT;
END update_district_name;


CREATE OR REPLACE PROCEDURE update_email_address(pidEmail IN NUMBER, pNewAddress IN VARCHAR2) AS
BEGIN
    UPDATE email
    SET email.address_email = pNewAddress
    WHERE email.id_email = pidEmail;
    COMMIT;
END update_email_address;

CREATE OR REPLACE PROCEDURE update_favourite_date_favourite(pidArtRev IN NUMBER, pidUserRev IN NUMBER, pNewDateFavourite IN VARCHAR2) AS
BEGIN
    UPDATE favourite
    SET favourite.date_favourite = To_date(pNewDateFavourite,'YY-MM-DD')
    WHERE favourite.id_user_fav = pidUserRev AND favourite.id_article_fav = pidArtRev;
    COMMIT;
END update_favourite_date_favourite;

CREATE OR REPLACE PROCEDURE update_gender_type_gender(pidGender IN NUMBER, pNewTypeGender IN VARCHAR2) AS
BEGIN
    UPDATE gender
    SET gender.type_gender = pNewTypeGender
    WHERE gender.id_gender = pidGender;
    COMMIT;
END update_gender_type_gender;

CREATE OR REPLACE PROCEDURE update_logDB_change_descp(pidLogDB IN NUMBER, pNewChangeDescription IN VARCHAR2) AS
BEGIN
    UPDATE logDB
    SET logDB.change_descrp = pNewChangeDescription
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END update_logDB_change_descp;

CREATE OR REPLACE PROCEDURE update_logDB_previous_text(pidLogDB IN NUMBER, pNewPreviousText IN VARCHAR2) AS
BEGIN
    UPDATE logDB
    SET logDB.previous_text = pNewPreviousText
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END update_logDB_previous_text;

CREATE OR REPLACE PROCEDURE update_logDB_current_text(pidLogDB IN NUMBER, pNewCurrentText IN VARCHAR2) AS
BEGIN
    UPDATE logDB
    SET logDB.current_text = pNewCurrentText
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END update_logDB_current_text;

CREATE OR REPLACE PROCEDURE update_parameter_name(pidParameter IN NUMBER, pNewNameParameter IN VARCHAR2) AS
BEGIN
    UPDATE parameterDB
    SET parameterDB.name_parameter = pNewNameParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_name;

CREATE OR REPLACE PROCEDURE update_parameter_description(pidParameter IN NUMBER, pNewDescriptionParameter IN VARCHAR2) AS
BEGIN
    UPDATE parameterDB
    SET parameterDB.description_parameter = pNewDescriptionParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_description;

CREATE OR REPLACE PROCEDURE update_parameter_value(pidParameter IN NUMBER, pNewValueParameter IN NUMBER) AS
BEGIN
    UPDATE parameterDB
    SET parameterDB.value_parameter = pNewValueParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_value;

CREATE OR REPLACE PROCEDURE update_parameter_route(pidParameter IN NUMBER, pNewRoute IN VARCHAR2) AS
BEGIN
    UPDATE parameterDB
    SET parameterDB.route = pNewRoute
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_route;


CREATE OR REPLACE PROCEDURE update_person_identitycard(pidPerson IN NUMBER, pNewIdentificationCard IN NUMBER) AS
BEGIN
    UPDATE person
    SET person.identification_card = pNewIdentificationCard
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_identitycard;


CREATE OR REPLACE PROCEDURE update_person_first_name(pidPerson IN NUMBER, pNewFirstName IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.first_name = pNewFirstName
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_first_name;

CREATE OR REPLACE PROCEDURE update_person_second_name(pidPerson IN NUMBER, pNewSecondName IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.second_name  = pNewSecondName
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_second_name;

CREATE OR REPLACE PROCEDURE update_person_first_surname(pidPerson IN NUMBER, pNewFirstSurname IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.first_surname = pNewFirstSurname
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_first_surname;


CREATE OR REPLACE PROCEDURE update_person_second_surname(pidPerson IN NUMBER, pNewSecondSurname IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.second_surname = pNewSecondSurname
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_second_surname;

CREATE OR REPLACE PROCEDURE update_person_datebirth(pidPerson IN NUMBER, pNewDatebirth IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.datebirth = to_date(pNewDatebirth,'YY-MM-DD')
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_datebirth;


CREATE OR REPLACE PROCEDURE update_person_quad(pidPerson IN NUMBER, pNewIdQuad IN NUMBER) AS
BEGIN
    UPDATE person
    SET person.id_quad = pNewIdQuad
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_quad;

CREATE OR REPLACE PROCEDURE update_person_gender(pidPerson IN NUMBER, pNewIdGender IN NUMBER) AS
BEGIN
    UPDATE person
    SET person.id_gender = pNewIdGender
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_gender;

CREATE OR REPLACE PROCEDURE update_person_localitation(pidPerson IN NUMBER, pNewExactLocalitation IN VARCHAR2) AS
BEGIN
    UPDATE person
    SET person.exact_location = pNewExactLocalitation
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_localitation;

CREATE OR REPLACE PROCEDURE update_person_district(pidPerson IN NUMBER, pNewIdDistrict IN NUMBER) AS
BEGIN
    UPDATE person
    SET person.id_district = pNewIdDistrict
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_district;

create or replace PROCEDURE insert_user(pUserName in VARCHAR2,pPassUser IN VARCHAR2, pidPerson IN NUMBER) AS
BEGIN
    INSERT INTO userdb(id_User, password_user, id_person, creationDate, userid, lastModifyDate, lastModifyBy,user_name)
    VALUES(s_user.nextval, pPassUser, pidPerson, NULL, NULL, NULL, NULL,pUserName);
    COMMIT;
END insert_user;

create or replace PROCEDURE insert_student(pidPerson IN NUMBER, pstudentCard IN NUMBER) AS
BEGIN
    INSERT INTO student(id_person, student_card, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidPerson, pstudentCard, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_student;

CREATE OR REPLACE PROCEDURE insert_status(pnameStatus VARCHAR2) AS
BEGIN
    INSERT INTO status(id_status, name_status, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_status.nextval, pnameStatus, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_status;

CREATE OR REPLACE PROCEDURE insert_review(pdescription IN VARCHAR2, pid_article_rev IN NUMBER, pid_user_rev IN NUMBER) AS
BEGIN
    INSERT INTO review(description_review, id_article_rev, id_user_rev,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pdescription, pid_article_rev, pid_user_rev, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_review;

CREATE OR REPLACE PROCEDURE insert_province(pname IN VARCHAR2, pidNation IN NUMBER) AS
BEGIN
    INSERT INTO province(id_province, name_province, id_nation, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_province.nextval, pname, pidNation ,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_province; 

CREATE OR REPLACE PROCEDURE insert_professor(pidDedication IN NUMBER, pidPerson IN NUMBER) AS
BEGIN
    INSERT INTO professor(id_dedication, id_person, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidDedication, pidPerson,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_professor; 

CREATE OR REPLACE PROCEDURE insert_productxauthor(pidProPa IN NUMBER, pidAutPa IN NUMBER) AS
BEGIN
    INSERT INTO productxauthor(id_product_pa, id_author_pa, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidProPa, pidAutPa, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_productxauthor; 

CREATE OR REPLACE PROCEDURE insert_product(pCost IN NUMBER, pdescription IN VARCHAR2, 
pidCatalog IN NUMBER, pidAvailability IN NUMBER) AS
BEGIN
    INSERT INTO product(id_product, cost_product, description_product, id_catalog_pr, id_availability,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_product.nextval, pcost, pdescription, pidcatalog, pidavailability, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_product; 

CREATE OR REPLACE PROCEDURE insert_photo_article(proute IN VARCHAR2,pidArticle IN NUMBER) AS
BEGIN
    INSERT INTO photo(id_photo,route, id_article, id_user, id_product,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_photo.nextval, proute, pidArticle, NULL, NULL, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_photo_article; 

CREATE OR REPLACE PROCEDURE insert_photo_user(proute IN VARCHAR2,pidUser IN NUMBER) AS
BEGIN
    INSERT INTO photo(id_photo,route, id_article, id_user, id_product,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_photo.nextval, proute, NULL, pidUser, NULL, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_photo_user; 

CREATE OR REPLACE PROCEDURE insert_photo_product(proute IN VARCHAR2,pidProduct IN NUMBER) AS
BEGIN
    INSERT INTO photo(id_photo,route, id_article, id_user, id_product,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_photo.nextval, proute, NULL, NULL, pidProduct, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_photo_product; 

CREATE OR REPLACE PROCEDURE insert_phoneCategory(pdescription IN VARCHAR2) AS
BEGIN
    INSERT INTO phoneCategory(id_category, description_category,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_phcategory.nextval, pdescription, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_phoneCategory; 

CREATE OR REPLACE PROCEDURE insert_phone(pnumber IN NUMBER, pidPerson IN NUMBER, pidPhoneCategory IN NUMBER) AS
BEGIN
    INSERT INTO phone(id_phone, number_phone, id_person, id_phone_category, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(s_phone.nextval, pnumber, pidPerson, pidPhoneCategory, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_phone; 

create or replace PROCEDURE insert_personxcommitte(pidPerson IN NUMBER, pidCommitte IN NUMBER) AS
BEGIN
    INSERT INTO personxcommitte(id_committe, id_person, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidCommitte, pidPerson, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_personxcommitte;

CREATE OR REPLACE PROCEDURE update_user_password(pidUser IN NUMBER, pNewPass IN VARCHAR2) AS
BEGIN
    UPDATE userdb
    SET password_user = pNewPass
    WHERE pidUser = id_user;
    COMMIT;
END update_user_password;

CREATE OR REPLACE PROCEDURE update_user_username(pidUser IN NUMBER, pNewName IN VARCHAR2) AS
BEGIN
    UPDATE userdb
    SET user_name = pNewName
    WHERE pidUser = id_user;
    COMMIT;
END update_user_username;

CREATE OR REPLACE PROCEDURE update_student(pidPerson IN NUMBER, pNewStudCard IN NUMBER) AS
BEGIN
    UPDATE student
    SET student_card = pNewStudCard
    WHERE pidPerson = id_person;
    COMMIT;
END update_student;

CREATE OR REPLACE PROCEDURE update_status(pidStatus  IN NUMBER, pNewStatus IN VARCHAR2) AS
BEGIN
    UPDATE status
    SET name_status = pNewStatus
    WHERE pidStatus = id_status;
    COMMIT;
END update_status;

CREATE OR REPLACE PROCEDURE update_review(pidArtRev IN NUMBER, pidUserRev IN NUMBER, pNewDescription IN VARCHAR2) AS
BEGIN
    UPDATE review
    SET description_review = pNewDescription
    WHERE pidUserRev = id_user_rev AND pidArtRev = id_article_rev;
    COMMIT;
END update_review;

CREATE OR REPLACE PROCEDURE update_province(pidProvince IN NUMBER, pNewName IN VARCHAR2) AS
BEGIN
    UPDATE province
    SET name_province = pNewName
    WHERE pidProvince = id_province;
    COMMIT;
END update_province;

CREATE OR REPLACE PROCEDURE update_professor(pidPerson IN NUMBER, pNewDedication IN NUMBER) AS
BEGIN
    UPDATE professor
    SET id_dedication = pNewDedication
    WHERE pidPerson = id_person;
    COMMIT;
END update_professor;

CREATE OR REPLACE PROCEDURE update_product(pidProduct IN NUMBER, pNewCost IN NUMBER, pNewDescription IN VARCHAR2) AS
BEGIN
    UPDATE product
    SET cost_product = pNewCost, 
        description_product = pNewDescription
    WHERE pidProduct = id_product;
    COMMIT;
END update_product;

CREATE OR REPLACE PROCEDURE update_product_description(pidProduct IN NUMBER, pNewDescription IN VARCHAR2) AS
BEGIN
    UPDATE product
    SET  description_product = pNewDescription
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_description;

CREATE OR REPLACE PROCEDURE update_product_cost(pidProduct IN NUMBER, costProduct in number) AS
BEGIN
    UPDATE product
    SET  cost_product = costProduct
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_cost;

CREATE OR REPLACE PROCEDURE update_product_catalog(pidProduct IN NUMBER, idCatalog in number) AS
BEGIN
    UPDATE product
    SET  id_catalog_pr = idCatalog
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_catalog;

create or replace PROCEDURE update_product_availability(pidProduct IN NUMBER, pnIdNewAv IN NUMBER) AS
BEGIN
    UPDATE product
    SET id_availability = pnidnewav
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_availability;


CREATE OR REPLACE PROCEDURE update_photo(pidPhoto IN NUMBER, pNewRoute IN NUMBER) AS
BEGIN
    UPDATE photo
    SET route = pnewRoute
    WHERE pidPhoto = id_photo;
    COMMIT;
END update_photo;

CREATE OR REPLACE PROCEDURE update_phoneCategory(pidCategory IN NUMBER, pNewDescription IN VARCHAR2) AS
BEGIN
    UPDATE phonecategory
    SET description_category = pNewDescription
    WHERE pidCategory = id_category;
    COMMIT;
END update_phoneCategory;

CREATE OR REPLACE PROCEDURE update_phone(pidPhone IN NUMBER, pNewNumber IN NUMBER) AS
BEGIN
    UPDATE phone
    SET number_phone = pNewNumber
    WHERE pidPhone = id_phone;
    COMMIT;
END update_phone;

CREATE OR REPLACE PROCEDURE delete_user(pidUser IN NUMBER) AS
BEGIN
    DELETE FROM userdb
    WHERE id_user = pidUser;
    COMMIT;
END delete_user;

CREATE OR REPLACE PROCEDURE delete_student(pidPerson IN NUMBER) AS
BEGIN
    DELETE FROM student
    WHERE id_person = pidPerson;
    COMMIT;
END delete_student;

CREATE OR REPLACE PROCEDURE delete_status(pidStatus  IN NUMBER) AS
BEGIN
    DELETE FROM status
    WHERE id_status = pidStatus;
    COMMIT;
END delete_status;

CREATE OR REPLACE PROCEDURE delete_review(pidArtRev IN NUMBER, pidUserRev IN NUMBER) AS
BEGIN
    DELETE FROM review
    WHERE id_user_rev = pidUserRev AND id_article_rev = pidArtRev;
    COMMIT;
END delete_review;

CREATE OR REPLACE PROCEDURE delete_province(pidProvince IN NUMBER) AS
BEGIN
    DELETE FROM province
    WHERE id_province = pidProvince;
    COMMIT;
END delete_province;

CREATE OR REPLACE PROCEDURE delete_professor(pidPerson IN NUMBER) AS
BEGIN
    DELETE FROM professor
    WHERE id_person = pidPerson;
    COMMIT;
END delete_professor;

CREATE OR REPLACE PROCEDURE delete_product(pidProduct IN NUMBER) AS
BEGIN
    DELETE FROM product
    WHERE id_product = pidProduct;
    COMMIT;
END delete_product;

CREATE OR REPLACE PROCEDURE delete_photo(pidPhoto IN NUMBER) AS
BEGIN
    DELETE FROM photo
    WHERE id_photo = pidPhoto;
    COMMIT;
END delete_photo;

create or replace PROCEDURE delete_photo_article(pidArticle IN NUMBER) AS
BEGIN
    DELETE FROM photo
    WHERE id_article = pidArticle;
    COMMIT;
END delete_photo_article;

create or replace PROCEDURE delete_photo_product(pidProduct IN NUMBER) AS
BEGIN
    DELETE FROM photo
    WHERE id_product = pidProduct;
    COMMIT;
END delete_photo_product;

CREATE OR REPLACE PROCEDURE delete_phoneCategory(pidCategory IN NUMBER) AS
BEGIN
    DELETE FROM phonecategory
    WHERE id_category = pidCategory;
    COMMIT;
END delete_phoneCategory;

CREATE OR REPLACE PROCEDURE delete_phone(pidPhone IN NUMBER) AS
BEGIN
    DELETE FROM phone
    WHERE id_phone = pidPhone;
    COMMIT;
END delete_phone;

CREATE OR REPLACE PROCEDURE delete_personxcommitte(pidPerson IN NUMBER, pidCommitte IN NUMBER) AS
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_person = pidPerson AND id_committe = pidCommitte;
    COMMIT;
END delete_personxcommitte;

CREATE OR REPLACE PROCEDURE delete_personxcommitte_person(pidPerson IN number) AS
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_person = pidPerson;
    COMMIT;
END delete_personxcommitte_person;

CREATE OR REPLACE PROCEDURE delete_personxcommitte_comm(pidCommittee IN number) AS
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_committe = pidCommittee;
    COMMIT;
END delete_personxcommitte_comm;

create or replace PROCEDURE delete_photo_user(pidUser IN NUMBER) AS
BEGIN
    DELETE FROM photo
    WHERE id_user = pidUser;
    COMMIT;
END delete_photo_user;

create or replace PROCEDURE delete_favourite_user(pidUserRev IN NUMBER) AS
BEGIN
    DELETE FROM favourite
    WHERE favourite.id_user_fav = pidUserRev;
    COMMIT;
END delete_favourite_user;
create or replace PROCEDURE delete_review_user(pidUserRev IN NUMBER) AS
BEGIN
    DELETE FROM review
    WHERE id_user_rev = pidUserRev;
    COMMIT;
END delete_review_user;

create or replace PROCEDURE delete_email_person(pidPerson IN NUMBER) AS
BEGIN
    DELETE FROM email
    WHERE email.id_person_mail = pidPerson;
    COMMIT;
END delete_email_person;

create or replace PROCEDURE delete_phone_person(pidPerson IN NUMBER) AS
BEGIN
    DELETE FROM phone
    WHERE id_person = pidPerson;
    COMMIT;
END delete_phone_person;

create or replace PROCEDURE update_photo_user(pidUser IN NUMBER, pNewRoute IN VARCHAR2) AS
BEGIN
    UPDATE photo
    SET route = pnewRoute
    WHERE pidUser = id_user;
    COMMIT;
END update_photo_user;

create or replace PROCEDURE get_usersByPerson(pnIdPerson in number, pCursorUsers out sys_refcursor)
AS
BEGIN
    OPEN pCursorUsers for
    select id_person, id_user, user_name, password_user
    from userdb
    where id_person = pnIdPerson;
END;

create or replace PROCEDURE delete_user_person(pidPerson IN NUMBER) AS
BEGIN
    DELETE FROM userdb
    WHERE id_person = pidPerson;
    COMMIT;
END delete_user_person;

create or replace PROCEDURE update_personXCommittee(pidPerson IN NUMBER, pidCommittee IN NUMBER) AS
BEGIN
    UPDATE personxcommitte
    SET id_committe = pidCommittee
    WHERE id_person = pidPerson;
    COMMIT;
END update_personXCommittee;

