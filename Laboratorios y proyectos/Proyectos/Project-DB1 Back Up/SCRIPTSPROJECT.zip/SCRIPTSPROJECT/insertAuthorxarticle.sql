insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(0,0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(0,1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(0,2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(0,3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(0,4,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(0,5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(0,6,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(0,7,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(0,8,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(19,9,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');


insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(19,10,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(19,11,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(19,13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(19,14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(19,12,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');
