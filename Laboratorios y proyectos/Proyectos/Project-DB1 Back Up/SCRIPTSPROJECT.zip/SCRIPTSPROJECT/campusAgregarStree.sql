ALTER TABLE campus
add id_ubication NUMBER(15) CONSTRAINT campus_idubication_nn NOT NULL