insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'zmelissa@estudiantec.cr',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'scatalina@estudiantec.cr',1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'falejandro@estudiantec.cr',2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'ppaula@estudiantec.cr',3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'gariana@estudiantec.cr',4,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'pisabel@ucr.ac.cr',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'rkenneth@ucr.ac.cr',6,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'mjezabel@ucr.ac.cr',7,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'rluis@est.una.ac.cr',8,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'ljeffrey@est.una.ac.cr',9,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'pesteban@est.una.ac.cr',10,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'vandres@estudiantec.cr',11,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'sfrancisco@estudiantec.cr',12,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'rhilda@estudiantec.cr',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into email
(id_email,address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (s_email.nextval,'fcarlos@estudiantec.cr',14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO email(id_email, address_email, id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_email.nextval, 'vjames@estudiantec.cr', 15,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO email(id_email, address_email, id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_email.nextval, 'mpedro@ucr.ac.cr', 16,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO email(id_email, address_email, id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_email.nextval, 'brachel@ucr.ac.cr', 17,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO email(id_email, address_email, id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_email.nextval, 'omariana@ucr.ac.cr', 18,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO email(id_email, address_email, id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(s_email.nextval, 'ajeffry@est.una.ac.cr', 19,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');
