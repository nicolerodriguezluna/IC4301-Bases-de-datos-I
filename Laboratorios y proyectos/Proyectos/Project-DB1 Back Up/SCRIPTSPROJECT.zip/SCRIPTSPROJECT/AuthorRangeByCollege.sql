CREATE OR REPLACE PROCEDURE get_authors_byage_college(pidCollege in number,pCursorAuthors out sys_refcursor)
AS
    BEGIN
    OPEN pCursorAuthors for
    SELECT '0-18' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 0 AND 18 and college.id_college = pidCollege
    UNION
    SELECT '19-30' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 19 AND 30 and college.id_college = pidCollege
    UNION
    SELECT '31-45' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 31 AND 45 and college.id_college = pidCollege
    UNION
     SELECT '45-60' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 45 AND 60 and college.id_college = pidCollege
    UNION
     SELECT '61-75' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (trunc(sysdate - person.datebirth)/365) BETWEEN 61 AND 75 and college.id_college = pidCollege
    UNION
    SELECT '75-' as range,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (trunc(sysdate - person.datebirth)/365)>75 and college.id_college = pidCollege;
END;
    