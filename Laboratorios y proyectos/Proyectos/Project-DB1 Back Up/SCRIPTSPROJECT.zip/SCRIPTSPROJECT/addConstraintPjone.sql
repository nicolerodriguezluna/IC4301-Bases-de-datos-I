alter TABLE phone
add constraint phone_pk primary key (id_phone);