CREATE OR REPLACE PROCEDURE get_topn_authors_category(pTopn in number,pidCategory in Number, pCursorAuthors OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN pCursorAuthors for
    Select count_articles,full_name
    from (select count(id_article_autart) as count_articles,first_name||' '||second_name||' '||first_surname||' '||second_surname as full_name
          from authorxarticle
          inner join person
          on person.id_person = authorxarticle.id_author_autart
          inner join article
          on article.id_article = authorxarticle.id_article_autart
          where article.id_art_cat = pidCategory
          group by(id_author_autart,first_name||' '||second_name||' '||first_surname||' '||second_surname)
          order by count_articles desc)
    where rownum<=pTopn;
END;