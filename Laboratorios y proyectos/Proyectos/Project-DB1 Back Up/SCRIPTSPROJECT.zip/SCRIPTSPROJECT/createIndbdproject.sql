CREATE TABLESPACE bdproject_Ind
DATAFILE 'C:\app\JeffreyLeiva\oradata\demo\bdprojectind.dbf'
SIZE 10M
REUSE
AUTOEXTEND ON
NEXT 512k
MAXSIZE 200M;