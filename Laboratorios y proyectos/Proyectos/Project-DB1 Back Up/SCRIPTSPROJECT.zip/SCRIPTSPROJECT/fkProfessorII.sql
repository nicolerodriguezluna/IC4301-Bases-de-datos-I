ALTER TABLE professor
ADD CONSTRAINT fk_professor_iddedication FOREIGN KEY (id_dedication) references dedication(id_dedication)
