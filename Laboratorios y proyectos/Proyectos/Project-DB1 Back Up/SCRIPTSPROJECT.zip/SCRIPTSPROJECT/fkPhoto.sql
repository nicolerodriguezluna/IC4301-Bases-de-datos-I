ALTER TABLE photo 
ADD Constraint fk_photo_idarticle FOREIGN KEY (id_article) REFERENCES article(id_article)
