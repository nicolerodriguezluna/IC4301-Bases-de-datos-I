update photo
set id_article = 12
where id_photo = 15;

update photo
set id_article = 1
where id_photo = 22;

update photo
set id_article = 4
where id_photo = 23;

update photo
set id_article = 8
where id_photo = 24;

update photo
set id_article = 9
where id_photo = 25;

update photo
set id_article = 11
where id_photo = 26;

update photo
set id_article = 7
where id_photo = 27;

update photo
set id_article = 10
where id_photo = 28;

update photo
set id_article = 0
where id_photo = 29;

update photo
set id_article = 14
where id_photo = 30;

update photo
set id_article = 2
where id_photo = 31;

update photo
set id_article = 3
where id_photo = 32;

update photo
set id_article = 13
where id_photo = 33;

update photo
set id_article = 6
where id_photo = 34;

