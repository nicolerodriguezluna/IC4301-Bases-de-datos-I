ALTER TABLE catalog
ADD CONSTRAINT fk_catalog_idnews FOREIGN KEY (id_newspaper) REFERENCES digitalnewspaper (id_digital_newspaper)
