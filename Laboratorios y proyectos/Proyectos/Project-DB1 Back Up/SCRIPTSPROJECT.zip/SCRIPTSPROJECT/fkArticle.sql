ALTER TABLE article
ADD CONSTRAINT fk_article_idstatus FOREIGN KEY (id_status_article) REFERENCES status(id_status)
ADD CONSTRAINT fk_article_idnewspaper FOREIGN KEY (id_dig_news) REFERENCES digitalnewspaper(id_digital_newspaper)
ADD CONSTRAINT fk_article_category FOREIGN KEY (id_art_cat) REFERENCES articleCategory(id_article_Category)
ADD CONSTRAINT fk_article_idcommitte FOREIGN KEY (id_committe_art) REFERENCES committe(id_committe)
