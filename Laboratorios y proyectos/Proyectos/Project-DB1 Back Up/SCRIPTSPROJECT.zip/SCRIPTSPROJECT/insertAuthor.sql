insert into author
(id_person,id_author_cathegory, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (19,2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

insert into author
(id_person,id_author_cathegory, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (0,3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');