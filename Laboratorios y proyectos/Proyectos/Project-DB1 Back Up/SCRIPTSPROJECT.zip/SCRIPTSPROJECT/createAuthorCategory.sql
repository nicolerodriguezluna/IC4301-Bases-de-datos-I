CREATE TABLE authorcategory
(
 id_author_category NUMBER(15) CONSTRAINT autcat_idauthcat_nn NOT NULL,
 type_category VARCHAR2(30) CONSTRAINT autcat_typecategory_nn NOT NULL
);