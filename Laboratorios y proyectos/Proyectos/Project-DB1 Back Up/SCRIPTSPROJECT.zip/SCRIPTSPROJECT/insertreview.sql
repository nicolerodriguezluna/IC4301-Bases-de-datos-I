INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Estoy en total acuerdo con que se manifiesten los estudiantes, la U p�blica es por y para el pueblo.',5,0,0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Espero poder ir, sin embargo creo que esa casa est� un poco peligrosa por sus a�os en nuestro querido barrio Am�n.',4,1,1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('La verdad no me gustaron las maquetas, tantos d�as de trabajo para tres palos y cartones puestos',2,2,2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Qu� bonito ver como las obras de anta�o se modernizan y en plena crisis sanitaria hacen que sonr�amos a la distancia.',5,3,3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Lo hizo alguien del TEC, ni la ha puesto y ya s� que no sirve.#SiempreUCR #AlmaMater',2,4,4,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('La creatividad es una maravillosa herramienta que nos abre muchas puertas, un aplauso para este artista.',5,5,0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Muy bien por estos j�venes que aprovechan el tiempo, no andan perdiendo el tiempo y atribuyen a la sociedad.',5,6,12,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Fueron mis compa�eras en varios cursos, son muy inteligentes  pero algo juega de vivas.',3,7,18,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Qu� va! No rinden los de privada',3,8,13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Noble patria, tu hermosa bandera, expresi�n de tu vida nos da; bajo el l�mpido azul de tu cielo blanca y pura descansa la paz.',5,9,1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');
INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev,creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Me parece muy bien que saquen pruebas que ayuden a mejorar la educaci�n superior del pa�s',5,10,5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('No s� que tanto discuten, no entiendo como es que le quitan dinero a la educaci�n...',4,11,10,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Nombres... y uno sin plata, viviendo a como humildemente se puede, y el presidente sigue y sigue aumentando los impuestos e intereses. Piensan que uno es un banco',1,12,8,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Ishhh que loco, yo me acuerdo esa tarde cuando estaba chamaco. Que ras susto legal. Mi casa todav�a tiene un hueco de ese temblor.',4,13,6,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Que triste, por eso todo el mundo se quiere ir del pa�s. Apenas me gradu� voy jalando de aqu�. Para alg�n pa�s con oportunidades como Estados Unidos o Canad�.',1,14,15,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT');
