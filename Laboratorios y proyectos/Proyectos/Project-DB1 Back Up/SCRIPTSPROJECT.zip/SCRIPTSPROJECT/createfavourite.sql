CREATE TABLE favourite 
(
    id_favourite NUMBER(38) CONSTRAINT favourite_idfav_nn NOT NULL,
    id_article_fav NUMBER(15) CONSTRAINT favourite_idartfav_nn NOT NULL,
    id_user_fav NUMBER(15) CONSTRAINT favourite_iduser_nn NOT NULL
)