INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'ocean1998',0,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','Carrillo29');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'camaron2022',1,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','camaronSupremo');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'sebas77',2,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','sebaselmasguapo74');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'universo23',3,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','cosmosInfinito');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'password',4,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','guijarro81');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'harvard83',5,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','inteligente123');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'perrito14',6,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','perrofachero90');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'chicle04',7,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','bubblegum89');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'mariofanboy66',8,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','marioysonic01');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'supermarioparty23',9,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','meGustaMario');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'riotisbad90',10,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','arcaneIsgood76');

INSERT INTO userdb
(id_user,password_user,id_person,creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'minecra2011',11,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','minecraftForLife');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'willyrexvegetta777',12,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','willyrexfanboy');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'cyberbug2077',13,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','videogameGeek');

INSERT INTO userdb
(id_user,password_user,id_person ,creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'ibaiFanBoy72',14,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','ibaiHasStream');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'jamesRodriguez2000',15,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','colombiaCampeon2022');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'pedropabloxd1996',16,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','picapiedra28');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'ractchetclank02',17,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','ratchetElGenio');

INSERT INTO userdb
(id_user,password_user,id_person,creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'fieldsSteff00',18,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','steffPop65');

INSERT INTO userdb
(id_user,password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES (s_user.nextval,'dechil777',19,SYSDATE,'BDPROJECT',SYSDATE,'BDPROJECT','chillingIntheHouse');
