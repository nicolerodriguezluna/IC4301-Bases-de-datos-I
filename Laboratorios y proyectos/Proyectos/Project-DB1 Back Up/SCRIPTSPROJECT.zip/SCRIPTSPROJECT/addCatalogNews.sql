ALTER TABLE catalog
add id_newspaper NUMBER(15) CONSTRAINT catalog_idnewspaper_nn NOT NULL