UPDATE ARTICLE
set id_art_cat = 5
where id_article = 12;