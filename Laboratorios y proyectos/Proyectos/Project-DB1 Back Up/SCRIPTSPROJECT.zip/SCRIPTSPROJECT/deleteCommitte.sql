DELETE from committe
where id_committe = 0;

DELETE from committe
where id_committe = 1;

DELETE from committe
where id_committe = 2;