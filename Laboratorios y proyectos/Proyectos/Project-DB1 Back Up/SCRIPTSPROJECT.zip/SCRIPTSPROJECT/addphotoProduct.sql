ALTER TABLE product
add id_photo NUMBER(38) CONSTRAINT product_idphoto_nn NOT NULL