SELECT count(*)
from person;
