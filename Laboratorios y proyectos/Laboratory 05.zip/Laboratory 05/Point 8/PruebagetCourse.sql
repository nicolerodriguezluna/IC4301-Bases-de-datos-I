BEGIN
    getCourse(0,'APROBADO');
END;

--OTHER TEST CASES
--BEGIN
--    getCourse(0,'PENDIENTE');
--END;
--
--BEGIN
--    getCourse(1,'REPROBADO');
--END;
--
--BEGIN
--    getCourse(0,NULL);
--END;
--
--BEGIN
--    getCourse(1,NULL);
--END;
--
--
