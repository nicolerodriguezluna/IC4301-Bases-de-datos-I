BEGIN
    getPhonesForLoop(0,'CELULAR');
END;

-- OTHER TEST CASES.
--BEGIN
--    getPhonesForLoop(1,'CELULAR');
--END;
--
--BEGIN
--    getPhonesForLoop(0,'CASA');
--END;
--
--BEGIN
--    getPhonesForLoop(1,'CASA');
--END;
--
--BEGIN
--    getPhonesForLoop(0,NULL);
--END;
--
--BEGIN
--    getPhonesForLoop(1,NULL);
--END;
