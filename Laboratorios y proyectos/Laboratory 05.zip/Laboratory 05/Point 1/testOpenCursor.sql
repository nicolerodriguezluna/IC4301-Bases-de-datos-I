BEGIN
    getPhones(0,'CELULAR');
END;

-- OTHER TEST CASES.
--BEGIN
--    getPhones(1,'CELULAR');
--END;
--
--BEGIN
--    getPhones(0,'CASA');
--END;
--
--BEGIN
--    getPhones(1,'CASA');
--END;
--
--BEGIN
--    getPhones(0,NULL);
--END;
--
--BEGIN
--    getPhones(1,NULL);
--END;
--
--
--
--
