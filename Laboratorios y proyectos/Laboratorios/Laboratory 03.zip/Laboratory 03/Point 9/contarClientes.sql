SELECT count(1)
from customer