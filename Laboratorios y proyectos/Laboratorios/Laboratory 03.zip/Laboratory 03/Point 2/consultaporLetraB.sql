SELECT first_name from person 
where first_name LIKE 'B%'
