ALTER TABLE person
add constraint pk_person primary key (id_person)
Using index 
tablespace ge_ind PCTFREE 20
STORAGE (Initial 10k next 10k PCTINCREASE 0);

