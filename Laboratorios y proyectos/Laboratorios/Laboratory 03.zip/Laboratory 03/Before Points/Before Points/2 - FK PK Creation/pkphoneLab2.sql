ALTER TABLE phone
add constraint pk_phone primary key (id_phone)
Using index 
tablespace ge_ind PCTFREE 20
STORAGE (Initial 10k next 10k PCTINCREASE 0);
