ALTER TABLE employeege
add constraint fk_employeead foreign key (id_person) references person(id_person)
