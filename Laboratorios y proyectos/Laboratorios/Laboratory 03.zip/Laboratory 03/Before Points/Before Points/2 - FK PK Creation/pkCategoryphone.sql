ALTER TABLE phoneCategory
add constraint pk_phoneCategory primary key (type_phone)
Using index 
tablespace ge_ind PCTFREE 20
STORAGE (Initial 10k next 10k PCTINCREASE 0);
