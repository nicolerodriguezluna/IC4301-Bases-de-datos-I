ALTER TABLE purchasexproduct
add constraint pk_purchasexproduct primary key (idpurchase,idproduct)
USING index
tablespace ge_ind PCTFREE 20
STORAGE (INITIAL 10K NEXT 10K PCTINCREASE 0);