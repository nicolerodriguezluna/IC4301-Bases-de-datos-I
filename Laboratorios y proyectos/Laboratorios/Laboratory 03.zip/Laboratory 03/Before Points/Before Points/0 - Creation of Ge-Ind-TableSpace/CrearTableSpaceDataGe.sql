CREATE TABLESPACE ge_DATA
DATAFILE 'C:\app\JeffreyLeiva\oradata\demo\gedata.dbf'
   SIZE 10M
   REUSE
   AUTOEXTEND ON
   NEXT 512k
   MAXSIZE 200M;
   
   