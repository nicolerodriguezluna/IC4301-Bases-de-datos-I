INSERT INTO Phone
(id_phone,number_phone,phoneCategory,idperson)
VALUES (00,88596321,'celular',00)
VALUES (09,25506941,'oficina',02)
VALUES (10,87509706,'celular',05)