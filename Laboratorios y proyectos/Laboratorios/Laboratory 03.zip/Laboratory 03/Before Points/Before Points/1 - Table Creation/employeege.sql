CREATE TABLE employeege(
       id_employee NUMBER(15),
       salary_employee NUMBER(8),
       id_person NUMBER(15),
       birthday_employee DATE
);
