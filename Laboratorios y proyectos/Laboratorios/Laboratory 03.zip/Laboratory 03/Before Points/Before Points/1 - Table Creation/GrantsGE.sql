GRANT connect TO ge;
GRANT create session TO ge;
GRANT create table TO ge;
grant create view TO ge;
grant insert any table to ge;
