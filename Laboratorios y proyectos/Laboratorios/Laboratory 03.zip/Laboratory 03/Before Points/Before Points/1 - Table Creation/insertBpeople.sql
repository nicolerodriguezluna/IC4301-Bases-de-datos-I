Insert into person
(id_person,first_name,identitycard,second_name,first_surname,second_surname,birthdate)
VALUES (49,'Adrian',204568496,'Jose','Herrera','Mata',DATE '1985-11-16');
  
