Select first_name from person
where first_name LIKE 'b%'