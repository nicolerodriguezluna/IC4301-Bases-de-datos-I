SELECT count(1)
from person
