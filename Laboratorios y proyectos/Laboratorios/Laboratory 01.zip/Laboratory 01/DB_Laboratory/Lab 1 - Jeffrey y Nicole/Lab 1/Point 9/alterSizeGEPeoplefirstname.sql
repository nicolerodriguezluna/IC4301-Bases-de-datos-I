ALTER TABLE peoplege
MODIFY (first_name_ge varchar2(50));