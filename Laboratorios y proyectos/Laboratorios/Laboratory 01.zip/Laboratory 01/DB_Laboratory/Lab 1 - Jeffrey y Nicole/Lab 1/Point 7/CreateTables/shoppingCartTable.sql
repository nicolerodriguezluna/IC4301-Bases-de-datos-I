CREATE TABLE shoppingCart
(
    id_shoppingCart NUMBER(10)
);