DELETE from customer where id_customer = 15;
DELETE from person where id_person = 45;
