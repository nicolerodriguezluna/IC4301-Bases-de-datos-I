Insert into Customer
(id_customer,id_person)
VALUE(00,30)
VALUE(01,31)
VALUE(02,32)
VALUE(03,33)
VALUE(04,34)
VALUE(05,35)
VALUE(06,36)
VALUE(07,37)
VALUE(08,38)
VALUE(09,39)
VALUE(10,40)
VALUE(11,41)
VALUE(12,42)
VALUE(13,43)
VALUE(14,44)
VALUE(15,45)
-- We inserted, the id_customer for the primary key of the table customer, and the idperson is 
-- the foreign key referencing the idperson on table person. Persons from 30 to 45 are clients as well,
-- with idClient from 0 to 15.