CREATE TABLE customer(
       id_customer NUMBER(15)
       id_person NUMBER(15)
);
