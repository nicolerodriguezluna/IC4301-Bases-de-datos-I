CREATE TABLE purchase(
    idPurchase Number(15) Constraint purchase_idpurchase_nn NOT NULL,
    idCustomer Number(15)
)