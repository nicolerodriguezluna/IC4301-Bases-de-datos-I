UPDATE person
SET first_name = 'Marcela'
WHERE id_person = 2;