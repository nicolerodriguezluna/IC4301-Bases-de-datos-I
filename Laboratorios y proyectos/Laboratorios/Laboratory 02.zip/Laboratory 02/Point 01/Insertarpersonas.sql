INSERT INTO Person (id_person,first_name,identitycard,second_name,first_surname,second_surname,birthdate)
VALUES (01,'Melissa',119560234, 'Laura', 'Zarate', 'L�pez',DATE '1998-04-15')
VALUES (02,'Catalina',202678512, 'Mar�a', 'Santana', 'Hern�ndez',DATE '1986-05-86')
VALUES (03,'Alejandro',705689412, 'Sebastian', 'Fern�ndez', 'Ortiz',DATE '2007-09-13')
VALUES (04,'Paula',306872354, 'Liliana', 'Perez', 'L�pez',DATE '1998-02-13')
VALUES (05,'Ariana',603154786, 'Vanessa', 'Gonzalez', 'Molina',DATE '2005-11-11')
VALUES (06,'Isabel',452618723, 'Rosaura', 'Torres', 'Benavides',DATE '1970-02-19')
VALUES (07,'Kenneth',514896458, 'Ricardo', 'Ibarra', 'Vargas',DATE '1999-08-17')
VALUES (08,'Jezabel',789630412, 'Hillary', 'Morales', 'Barrera',DATE '2007-10-27')
VALUES (09,'Luis',402569871, 'Roberto', 'Rivera', 'Moaraga',DATE '2002-12-16')
VALUES (11,'Jeffrey',118670120,'Daniel','Leiva','Cascante',DATE '2003-03-21'),
VALUES (12,'Esteban',119872619,'Alfredo','Perez','Caceres',DATE '2000-04-22'),
VALUES (13,'Andres',290871627,'Eduardo','Villalobos','Sandi',DATE '1987-12-31'),
VALUES (14,'Francisco',390812345,'Franco','Sanchez','Ruben',DATE '1999-01-12'),
VALUES (15,'Hilda',568909876,'Heriberta','Robles','Torres',DATE '1989-09-09'),
VALUES (16,'Carlos',435678901,'Humberto','Flores','Valerio',DATE '1998-07-07'),
VALUES (17,'James',189098762,'Kevin','Valverde','Alpizar',DATE '2000-09-01'),
VALUES (18,'Pedro',198098765,'Pablo','Matarrita','Smith', DATE '1996-12-03',
VALUES (19,'Rachell',345987654,'Maria','Bermudez','Salazar',DATE '1998-03-10'),
VALUES (20,'Mariana',478985748,'Steffany','Orozco','Campos',DATE '2003-05-27');
VALUES (30,'Johanny',112345678, 'David', 'Morales', 'Vega',DATE '1982-07-11')
VALUES (31,'Jeffry',119845679, 'Alexander', 'Avil�s', 'Figueroa',DATE '1989-06-14')
VALUES (32,'Luciana',112345671, 'Yancy', 'Alfaro', 'Bonilla',DATE '2001-01-09')
VALUES (33,'Anabel',112398672, 'Elizabeth', 'Dar�o', 'Cisneros',DATE '2004-07-23')
VALUES (34,'Daniel',112345673, 'Armando', 'Castro', 'Jarquin',DATE '1996-12-24')
VALUES (35,'Jeannette',112345984, 'Sandra', 'Mora', 'Zamora',DATE '1972-08-23')
VALUES (36,'Kevin',112398675, 'Richard', 'Iglesias', 'Cerratti',DATE '1985-09-12')
VALUES (37,'Josette',112345676, 'Laurenth', 'Oreamuno', 'Jara',DATE '2001-03-29')
VALUES (38,'Fernando',198345677, 'Andres', 'Rojas', 'Loria',DATE '2002-07-18')
VALUES (39,'Katherine',119845681, 'Patricia', 'Carcamo', 'Helo',DATE '1962-04-15')
VALUES (40,'Paula',112345682, 'Digna', 'Jarqu�n', 'Altamirano',DATE '1963-02-14')
VALUES (41,'Iris',112398683, 'Tatiana', 'Chavarr�a', 'Montero',DATE '2001-12-04')
VALUES (42,'Loana',112345684, 'Emilia', 'Chavez', 'Alvarado',DATE '1996-05-09')
VALUES (43,'Fabricio',112345685, 'Mauro', 'Alvarado', 'Flores',DATE '1958-04-04')
VALUES (44,'Luisa',112345686, 'Raquel', 'Romero', 'Cascante',DATE '2002-04-12')
VALUES (45,'Hermeneguildo',198345687, 'Carlos', 'Herrera', 'Mora',DATE '1962-02-03')
--a. �A cu�l lenguaje corresponde la creaci�n de la tabla?
-- DDL, The data definition language.
--b. �A cu�l lenguaje corresponde la inserci�n?
--DML, The data manipulation language.
--c. Salga de la BD y vuelva a entrar. �Est�n los datos que registr�? Justifique su
--respuesta.
-- Yes, the data is still there, we already knew the steps to mantain it with no issues.