CREATE TABLE product
(
  id_product NUMBER(10)
);