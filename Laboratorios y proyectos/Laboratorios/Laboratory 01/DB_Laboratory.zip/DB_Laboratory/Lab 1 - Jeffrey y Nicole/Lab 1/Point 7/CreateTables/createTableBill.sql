CREATE TABLE bill
(
    code_bill NUMBER(20) CONSTRAINT bill_code_nn NOT NULL
);