ALTER TABLE peoplege
rename column last_name TO last_name_ge;