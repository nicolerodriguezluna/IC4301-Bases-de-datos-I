/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;
/**
 *
 * @author Alexander
 */
public class Person {
    int id;
    int idCard;
    String firstName;
    String secondName;
    String firstSurname;
    String secondSurname;
    Date datebirth;
    int idCampus;
    int idGender;
    int idDistrict;
    String exactLocation;

    public Person() {
    }

    public Person(int id, int idCard, String firstName, String secondName, String firstSurname, String secondSurname, Date datebirth, int idCampus, int idDistrict, int idGender, String exactLocation) {
        this.id = id;
        this.idCard = idCard;
        this.firstName = firstName;
        this.secondName = secondName;
        this.firstSurname = firstSurname;
        this.secondSurname = secondSurname;
        this.datebirth = datebirth;
        this.idCampus = idCampus;
        this.idGender = idGender;
        this.exactLocation = exactLocation;
        this.idDistrict = idDistrict;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setIdCard(int idCard) {
        this.idCard = idCard;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public void setFirstSurname(String firstSurname) {
        this.firstSurname = firstSurname;
    }

    public void setSecondSurname(String secondSurname) {
        this.secondSurname = secondSurname;
    }

    public void setDatebirth(Date datebirth) {
        this.datebirth = datebirth;
    }

    public void setIdCampus(int idCampus) {
        this.idCampus = idCampus;
    }

    public void setIdGender(int idGender) {
        this.idGender = idGender;
    }

    public void setExactLocation(String exactLocation) {
        this.exactLocation = exactLocation;
    }

    public void setIdDistrict(int idDistrict) {
        this.idDistrict = idDistrict;
    }

    public int getId() {
        return id;
    }

    public int getIdCard() {
        return idCard;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public String getFirstSurname() {
        return firstSurname;
    }

    public String getSecondSurname() {
        return secondSurname;
    }

    public Date getDatebirth() {
        return datebirth;
    }

    public int getIdCampus() {
        return idCampus;
    }

    public int getIdGender() {
        return idGender;
    }

    public String getExactLocation() {
        return exactLocation;
    }

    public int getIdDistrict() {
        return idDistrict;
    }

    @Override
    public String toString() {
        return "Person{" + "id=" + id + ", idCard=" + idCard + ", firstName=" + firstName + ", secondName=" + secondName + ", firstSurname=" + firstSurname + ", secondSurname=" + secondSurname + ", datebirth=" + datebirth + ", idCampus=" + idCampus + ", idGender=" + idGender + ", idDistrict=" + idDistrict + ", exactLocation=" + exactLocation + '}';
    }
    
}

    
    
