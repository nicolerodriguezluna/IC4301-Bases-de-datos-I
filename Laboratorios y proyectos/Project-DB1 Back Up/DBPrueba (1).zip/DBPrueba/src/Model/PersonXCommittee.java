/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class PersonXCommittee {
    int idPerson;
    int idCommitte;

    public PersonXCommittee() {
    }

    public PersonXCommittee(int idPerson, int idCommitte) {
        this.idPerson = idPerson;
        this.idCommitte = idCommitte;
    }

    public void setIdPerson(int idPerson) {
        this.idPerson = idPerson;
    }

    public void setIdCommitte(int idCommitte) {
        this.idCommitte = idCommitte;
    }

    public int getIdPerson() {
        return idPerson;
    }

    public int getIdCommitte() {
        return idCommitte;
    }

    @Override
    public String toString() {
        return "PersonXCommitte{" + "idPerson=" + idPerson + ", idCommitte=" + idCommitte + '}';
    }
    
    
}
