/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class AuthorRangeAge {
    String range;
    int count;
    
    public AuthorRangeAge(){}
    
    public AuthorRangeAge(String range, int count){
        this.range =range;
        this.count = count;
    }

    public String getRange() {
        return range;
    }

    public void setRange(String range) {
        this.range = range;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "AuthorRangeAge{" + "range=" + range + ", count=" + count + '}';
    }
    
    
    
}
