/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class Author {
    int idPerson;
    int idAuthorCategory;
    
    public Author(){}
    
    public Author(int id,int category){
        this.idPerson = id;
        this.idAuthorCategory = category;
    }

    public int getIdPerson() {
        return idPerson;
    }

    public void setIdPerson(int idPerson) {
        this.idPerson = idPerson;
    }

    public int getIdAuthorCategory() {
        return idAuthorCategory;
    }

    public void setIdAuthorCategory(int idAuthorCategory) {
        this.idAuthorCategory = idAuthorCategory;
    }
    
}
