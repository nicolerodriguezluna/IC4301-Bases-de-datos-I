/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class Product {
    int id;
    int cost;
    String description;
    int idCatalog;
    int idAvailability;

    public Product() {
    }

    public Product(int id, int cost, String description, int idCatalog, int idAvailability) {
        this.id = id;
        this.cost = cost;
        this.description = description;
        this.idCatalog = idCatalog;
        this.idAvailability = idAvailability;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setIdCatalog(int idCatalog) {
        this.idCatalog = idCatalog;
    }

    public void setIdAvailability(int idAvailability) {
        this.idAvailability = idAvailability;
    }

    public int getId() {
        return id;
    }

    public int getCost() {
        return cost;
    }

    public String getDescription() {
        return description;
    }

    public int getIdCatalog() {
        return idCatalog;
    }

    public int getIdAvailability() {
        return idAvailability;
    }

    @Override
    public String toString() {
        return "Product{" + "id=" + id + ", cost=" + cost + ", description=" + description + ", idCatalog=" + idCatalog + ", idAvailability=" + idAvailability + '}';
    }
    
    
}
