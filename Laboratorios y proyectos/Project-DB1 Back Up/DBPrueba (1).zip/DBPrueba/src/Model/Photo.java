/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class Photo {
    int id;
    String route;
    int idProduct;
    int idArticle;
    int idUser;

    public Photo() {
    }

    public Photo(int id, String route, int idProduct, int idArticle, int idUser) {
        this.id = id;
        this.route = route;
        this.idProduct = idProduct;
        this.idArticle = idArticle;
        this.idUser = idUser;
    }

    public int getId() {
        return id;
    }

    public String getRoute() {
        return route;
    }

    public int getIdProduct() {
        return idProduct;
    }

    public int getIdArticle() {
        return idArticle;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setRoute(String route) {
        this.route = route;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    public void setIdArticle(int idArticle) {
        this.idArticle = idArticle;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    @Override
    public String toString() {
        return "Photo{" + "id=" + id + ", route=" + route + ", idProduct=" + idProduct + ", idArticle=" + idArticle + ", idUser=" + idUser + '}';
    }
    
}
