/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class AuthorPerCollege {
    String nameCollege;
    int count;
    
    public AuthorPerCollege(){}
    
    public AuthorPerCollege(String name,int count){
        this.nameCollege = name;
        this.count = count;
    }

    public String getNameCollege() {
        return nameCollege;
    }

    public void setNameCollege(String nameCollege) {
        this.nameCollege = nameCollege;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
    
}
