/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class Professor {
    int idPerson;
    int idDedication;

    public Professor() {
    }

    public Professor(int idPerson, int idDedication) {
        this.idPerson = idPerson;
        this.idDedication = idDedication;
    }

    public void setIdPerson(int idPerson) {
        this.idPerson = idPerson;
    }

    public void setIdDedication(int idDedication) {
        this.idDedication = idDedication;
    }

    public int getIdPerson() {
        return idPerson;
    }

    public int getIdDedication() {
        return idDedication;
    }

    @Override
    public String toString() {
        return "Professor{" + "idPerson=" + idPerson + ", idDedication=" + idDedication + '}';
    }
    
    
}
