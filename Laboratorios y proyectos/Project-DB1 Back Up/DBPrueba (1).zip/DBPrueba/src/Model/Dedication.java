/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class Dedication {
    int idDedication;
    String description;
    
    public Dedication(){}
    
    public Dedication(int id,String description){
        this.idDedication = id;
        this.description =description;
    }
    public int getIdDedication() {
        return idDedication;
    }

    public void setIdDedication(int idDedication) {
        this.idDedication = idDedication;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
}
