/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class Review {
    String description;
    int stars;
    int idArticle;
    int idUser;

    public Review() {
    }

    public Review(String description, int stars, int idArticle, int idRev,int idUser) {
        this.description = description;
        this.stars = stars;
        this.idArticle = idArticle;
        this.idUser = idRev;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setStars(int stars) {
        this.stars = stars;
    }

    public void setIdArticle(int idArticle) {
        this.idArticle = idArticle;
    }

    public void setIdUser(int idRev) {
        this.idUser = idRev;
    }

    public String getDescription() {
        return description;
    }

    public int getStars() {
        return stars;
    }

    public int getIdArticle() {
        return idArticle;
    }

    public int getIdUser() {
        return idUser;
    }

    @Override
    public String toString() {
        return "Review{" + "description=" + description + ", stars=" + stars + ", idArticle=" + idArticle + ", idRev=" + idUser + '}';
    }
}
