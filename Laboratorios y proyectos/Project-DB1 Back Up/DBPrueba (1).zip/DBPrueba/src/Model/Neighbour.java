/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class Neighbour {
    int idNeighbour;
    
    public Neighbour(){}
    
    public Neighbour(int id){
        this.idNeighbour = id;
    }

    public int getIdNeighbour() {
        return idNeighbour;
    }

    public void setIdNeighbour(int idNeighbour) {
        this.idNeighbour = idNeighbour;
    }
    
    
}
