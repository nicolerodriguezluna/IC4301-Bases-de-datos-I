/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import oracle.jdbc.OracleTypes;
import java.sql.*;

/**
 
 * @author Jeffrey Leiva
 */
public class ConnectDB {
    public static String host = "jdbc:oracle:thin:@//localhost:1521/BASEUNO";
    public static String Uname = "bdproject";
    public static String Upass = "bdproject";
    
    public static Connection getConnection(){
        try{
            DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
            java.sql.Connection connection = DriverManager.getConnection(host, Uname, Upass);
            return connection;
        }catch(SQLException e){
            System.out.println("The exception raised is:" + e);
            return null;
        }
    }
    
     public static void closeConnection(CallableStatement stmt, Connection con) throws SQLException{
        if (stmt != null) {
            stmt.close();
        }
        if (con != null) {
              con.close();
        }
    }
    public static void closeConnectionCursors(CallableStatement stmt, Connection con, ResultSet rs) throws SQLException{
        if(rs != null){
            rs.close();
        }
        if(stmt != null) {
            stmt.close();
        }
        if(con != null) {
              con.close();
        }
    }
   /*---------------------------------------------------------------------------------------------------------------
    Inserts
   ----------------------------------------------------------------------------------------------------------------*/
    public static void insertAdministrative(int idAdministrative,int idDedication) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_administrative(?,?)}");
        
        stmt.setInt(1, idAdministrative);
        stmt.setInt(2, idDedication);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertAdministrator(int idAdministrator,String password) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_administrator(?,?)}");
        
        stmt.setInt(1, idAdministrator);
        stmt.setString(2,password);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertArticleCategory(String name,String description) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_article_category(?,?)}");
        
        stmt.setString(1,name);
        stmt.setString(2,description);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertAuthor(int idAuthor,int idAuthorCategory) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_author(?,?)}");
        
        stmt.setInt(1,idAuthor);
        stmt.setInt(2,idAuthorCategory);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertAuthorCategory(String typeCategory) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_author_category(?)}");
        
        stmt.setString(1,typeCategory);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertAuthorxarticle(int idAuthor,int idArticle) throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_authorxarticle(?,?)}");
        
        stmt.setInt(1,idAuthor);
        stmt.setInt(2,idArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertAvailability(String description) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_availability(?)}");
        
        stmt.setString(1,description);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
     public static void insertCampus(String vcName,int idCollege,int idDistrict) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_campus(?,?,?)}");
        
        stmt.setString(1, vcName);
        stmt.setInt(2, idCollege);
        stmt.setInt(3,idDistrict);
        stmt.execute();
        closeConnection(stmt, con);
    }
    public static void insertCanton(String name,int idArea) throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_canton(?,?)}");
        
        stmt.setString(1, name);
        stmt.setInt(2, idArea);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void  insertCatalog(int idNewspaper,String description) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_catalog(?,?)}");
        
        stmt.setInt(1,idNewspaper);
        stmt.setString(2,description);
        stmt.execute();
        closeConnection(stmt, con);
    }

    public static void insertCollege(String name) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_college(?)}");
        
        stmt.setString(1,name);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertArticle(String pvTitle,String pvText,java.sql.Date pvDate,int pIdStatus, int pidNewspaper,int pidcategory,int idcommittee)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_article(?,?,?,?,?,?,?)}");
        
        stmt.setString(1, pvTitle);
        stmt.setString(2, pvText);
        stmt.setDate(3,pvDate);
        stmt.setInt(4,pIdStatus);
        stmt.setInt(5,pidNewspaper);
        stmt.setInt(6,pidcategory);
        stmt.setInt(7,idcommittee);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertCommittee(int idCampus,String nameCommittee)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{call insert_committe(?,?)}");
        stmt.setInt(1, idCampus);
        stmt.setString(2, nameCommittee);
        stmt.execute();
        closeConnection(stmt,con);
    }
    
    public static void insertCountry(String nameCountry) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_country(?)}");
        
        stmt.setString(1, nameCountry);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertDedication(String description) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_dedication(?)}");
        
        stmt.setString(1, description);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertDigitalNewspaper(String name,int idquad)throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_digital_newspaper(?,?)}");
        
        stmt.setString(1, name);
        stmt.setInt(2,idquad);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertDistrict(String name,int idSector)throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_district(?,?)}");
        
        stmt.setString(1, name);
        stmt.setInt(2, idSector);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertEmail(String address,int idPerson)throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_email(?,?)}");
        
        stmt.setString(1, address);
        stmt.setInt(2, idPerson);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertFavourite(int idArticle,int idAuthor,java.sql.Date date)throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_favourite(?,?,?)}");
        
        stmt.setInt(1, idArticle);
        stmt.setInt(2, idAuthor);
        stmt.setDate(3, date);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertGender(String typeGender)throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_gender(?)}");
        
        stmt.setString(1, typeGender);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertLogdb(String changeDescription,String previousText,String currentText) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_logDB(?,?,?)}");
        
        stmt.setString(1, changeDescription);
        stmt.setString(2,previousText);
        stmt.setString(3,currentText);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertNeighbour(int idPerson) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_neighbour(?)}");
        
        stmt.setInt(1, idPerson);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertParamaterDB(String name,String description,int value,String route)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_ParameterDb(?,?,?,?)}");
        
        stmt.setString(1, name);
        stmt.setString(2, description);
        stmt.setInt(3, value);
        stmt.setString(4, route);
        stmt.execute();
        closeConnection(stmt, con);
    }
    public static void insertPerson(int idCard, String firstName, String secondName, String firstSurname, String secondSurname,
            java.sql.Date dateBirth, int idQuad, int idGender, String exactLocation, int idDistrict)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_person(?,?,?,?,?,?,?,?,?,?)}");
        stmt.setInt(1, idCard);
        stmt.setString(2, firstName);
        stmt.setString(3, secondName);
        stmt.setString(4, firstSurname);
        stmt.setString(5, secondSurname);
        stmt.setDate(6, dateBirth);
        stmt.setInt(7, idQuad);
        stmt.setInt(8, idGender);
        stmt.setString(9, exactLocation);
        stmt.setInt(10, idDistrict);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertPersonxCommitte(int pnIdPerson, int pnIdCommitte)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_personxcommitte(?,?)}");
        
        stmt.setInt(1, pnIdPerson);
        stmt.setInt(2, pnIdCommitte);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertPhone(int pnIdPerson, int pnNumber, int pnIdCategory )throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_phone(?,?,?)}");
        
        stmt.setInt(1, pnNumber);
        stmt.setInt(2, pnIdPerson);
        stmt.setInt(3, pnIdCategory);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertPhoneCategory(String pcDescription)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_phoneCategory(?)}");
        
        stmt.setString(1, pcDescription);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertPhotoArticle(String pcRoute, int pnIdArticle)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_photo_article(?,?)}");
        
        stmt.setString(1, pcRoute);
        stmt.setInt(2, pnIdArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertPhotoProduct(String pcRoute, int pnIdProduct)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_photo_product(?,?)}");
        
        stmt.setString(1, pcRoute);
        stmt.setInt(2, pnIdProduct);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertPhotoUser(String pnRoute, int pnIdUser)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_photo_user(?,?)}"); 
        
        stmt.setString(1, pnRoute);
        stmt.setInt(2, pnIdUser);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertProduct(int pnCost, String pcDescription, int pnIdCatalog, int pnIdAvailability)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_product(?,?,?,?)}");
        
        stmt.setInt(1, pnCost);
        stmt.setString(2, pcDescription);
        stmt.setInt(3, pnIdCatalog);
        stmt.setInt(4, pnIdAvailability);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertProductxAuthor(int pnIdProduct, int pnIdAuthor)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_productxauthor(?,?)}");
        
        stmt.setInt(1, pnIdProduct);
        stmt.setInt(2, pnIdAuthor);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertProfessor(int pnIdPerson, int pnIdDedication)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_professor(?,?)");
        
        stmt.setInt(1, pnIdPerson);
        stmt.setInt(2, pnIdDedication);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertProvince(String pcName, int pnIdNation)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_province(?,?)}");
        
        stmt.setString(1, pcName);
        stmt.setInt(2, pnIdNation);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertReview(String pcDescription,int stars, int pnIdArticle, int pnIdUser)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_review(?,?,?,?)}");
        
        stmt.setString(1, pcDescription);
        stmt.setInt(2, stars);
        stmt.setInt(3, pnIdArticle);
        stmt.setInt(4, pnIdUser);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertStatus(String pcNameStatus)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_status(?)}");
        
        stmt.setString(1, pcNameStatus);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertStudent(int pnIdPerson, int pnStudentCard)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_student(?,?)}");
        
        stmt.setInt(1, pnIdPerson);
        stmt.setInt(2, pnStudentCard);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void insertUser(int pnIdPerson, String pcPassUser,String username)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call insert_user(?,?,?)}");
        
        stmt.setString(1, username);
        stmt.setString(2, pcPassUser);
        stmt.setInt(3, pnIdPerson);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    /*---------------------------------------------------------------------------------------------------------------
    Deletes
   ----------------------------------------------------------------------------------------------------------------*/
    public static void deleteAdministrative(int idAdministrative) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_administrative(?)}");
        
        stmt.setInt(1,idAdministrative);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteAdministrator(int idAdministrator) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_administrator(?)}");
        
        stmt.setInt(1,idAdministrator);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteArticle(int idArticle) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_article(?)}");
        
        stmt.setInt(1,idArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteArticleCategory(int idCategory) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_articlecategory(?)}");
        
        stmt.setInt(1,idCategory);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteAuthor(int idAuthor) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_author(?)}");
        
        stmt.setInt(1,idAuthor);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
     public static void deleteAuthorCategory(int idCategory) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_author_category(?)}");
        
        stmt.setInt(1,idCategory);
        stmt.execute();
        closeConnection(stmt, con);
    }
     
    public static void deleteAuthorxarticleArticle(int idArticle) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_authorxarticle_article(?)}");
        
        stmt.setInt(1,idArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteAuthorxarticleAuthor(int idAuthor) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_authorxarticle_author(?)}");
        
        stmt.setInt(1,idAuthor);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteAvailability(int idAvailability) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_availability(?)}");
        
        stmt.setInt(1,idAvailability);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteCampus(int idCampus) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_campus(?)}");
        
        stmt.setInt(1,idCampus);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteCanton(int idCanton) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_canton(?)}");
        
        stmt.setInt(1,idCanton);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteCatalog(int idCatalog) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_catalog(?)}");
        
        stmt.setInt(1,idCatalog);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteCollege(int idCollege) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_college(?)}");
        
        stmt.setInt(1,idCollege);
        stmt.execute();
        closeConnection(stmt, con);
    }    
    
    public static void deleteCountry(int idCountry) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_country(?)}");

        stmt.setInt(1,idCountry);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteCommittee(int idCommittee) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_committee(?)}");
        
        stmt.setInt(1,idCommittee);
        stmt.execute();
        closeConnection(stmt, con);
    } 
    
    public static void deleteDedication(int idDedication) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_dedication(?)}");

        stmt.setInt(1,idDedication);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteDigitalNewspaper(int idPaper) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_digital_newspaper(?)}");
        
        stmt.setInt(1,idPaper);
        stmt.execute();
        closeConnection(stmt, con);
    } 
    
    public static void deleteDistrict(int idDistrict) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_district(?)}");
        
        stmt.setInt(1,idDistrict);
        stmt.execute();
        closeConnection(stmt, con);
    } 
    
    public static void deleteEmail(int idEmail) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_email(?)}");
        
        stmt.setInt(1,idEmail);
        stmt.execute();
        closeConnection(stmt, con);
    } 
    
    public static void deleteFavourite(int iduser,int idArticle) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_favourite(?,?)}");
        
        stmt.setInt(1,idArticle);
        stmt.setInt(2, iduser);
        stmt.execute();
        closeConnection(stmt, con);
    } 
    
    public static void deleteGender(int idgender) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_gender(?)}");
        
        stmt.setInt(1,idgender);
        stmt.execute();
        closeConnection(stmt, con);
    } 
    
    public static void deleteLogdb(int idLog) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_logDB(?)}");
        
        stmt.setInt(1,idLog);
        stmt.execute();
        closeConnection(stmt, con);
    } 
    
    public static void deleteNeighbour(int idNeighbour) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_neighbour(?)}");
        
        stmt.setInt(1,idNeighbour);
        stmt.execute();
        closeConnection(stmt, con);
    } 
    
    public static void deleteParameter(int idParameter) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_parameterDb(?)}");
        
        stmt.setInt(1,idParameter);
        stmt.execute();
        closeConnection(stmt, con);
    } 
    
    
    public static void deletePhotoProduct(int pnIdProduct) throws SQLException {
        Connection con = DriverManager.getConnection(host, Uname, Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_photo_product(?)}");

        stmt.setInt(1, pnIdProduct);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deletePhotoArticle(int pnIdArticle) throws SQLException {
        Connection con = DriverManager.getConnection(host, Uname, Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_photo_article(?)}");

        stmt.setInt(1, pnIdArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    
    
    public static void deletePerson(int pnIdPerson)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_person(?)}");
        
        stmt.setInt(1, pnIdPerson);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deletePersonXCommitte(int pnIdPerson, int pnIdCommittee)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_personxcommitte(?,?)}");
        
        stmt.setInt(1, pnIdPerson);
        stmt.setInt(2, pnIdCommittee);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deletePersonXCommittePerson(int pnIdPerson)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_personxcommitte_person(?)}");
        
        stmt.setInt(1, pnIdPerson);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deletePersonXCommitteCommittee(int idCommittee)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_personxcommitte_comm(?)}");
        
        stmt.setInt(1,idCommittee);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deletePhone(int pnIdPhone)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_phone(?)}");
        
        stmt.setInt(1, pnIdPhone);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    //Delete photo user
    public static void deletePhotoUser(int deleteId) throws SQLException {
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_photo_user(?)}");
        
        stmt.setInt(1, deleteId);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    //Delete review user
    public static void deleteReviewUser(int pnIdUserRev)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_review_user(?)}");
        
        stmt.setInt(1, pnIdUserRev);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    //Delete email person
    public static void deleteEmailPerson(int idPerson) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_email_person(?)}");
       
        stmt.setInt(1,idPerson);
        stmt.execute();
        closeConnection(stmt, con);
    }    
    
    //Delete favourite per user
    public static void deleteFavouriteUser(int pnIdUser) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_favourite_user(?)}");
        stmt.setInt(1,pnIdUser);
        stmt.execute();
        closeConnection(stmt, con);
    }    
    
    //Delete phone per person
    public static void deletePhonePerson(int pnIdPerson)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_phone_person(?)}");
        stmt.setInt(1, pnIdPerson);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deletePhoneCategory(int pnIdCategory)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_phonecategory(?)}");
        
        stmt.setInt(1, pnIdCategory);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deletePhoto(int pnIdPhoto)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_photo(?)}");
        
        stmt.setInt(1, pnIdPhoto);
        stmt.execute();
        closeConnection(stmt, con);
    }
 
    public static void deleteProduct(int pnIdProduct)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_product(?)}");

        stmt.setInt(1, pnIdProduct);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    
    public static void deleteProfessor(int pnIdPerson)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_professor(?)}");
        
        stmt.setInt(1, pnIdPerson);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteProvince(int pnIdProvince)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_province(?)}");
        
        stmt.setInt(1, pnIdProvince);
        stmt.execute();
        closeConnection(stmt, con);
    }
    public static void deleteReview(int pnIdArtRev, int pnIdUserRev)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_review(?,?)}");
        
        stmt.setInt(1, pnIdArtRev);
        stmt.setInt(2, pnIdUserRev);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteStatus(int pnIdStatus)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_status(?)}");
        
        stmt.setInt(1, pnIdStatus);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteStudent(int pnIdPerson)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_student(?)}");
        
        stmt.setInt(1, pnIdPerson);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void deleteUser(int pnIdUser)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_user(?)}");

        stmt.setInt(1, pnIdUser);
        stmt.execute();
        closeConnection(stmt, con);
    }
    public static void deleteUsersPerson(int pnIdPerson)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call delete_user_person(?)}");

        stmt.setInt(1, pnIdPerson);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    /*---------------------------------------------------------------------------------------------------------------
    Updates
   ----------------------------------------------------------------------------------------------------------------*/
    //Updates administrative dedication
    public static void updateAdministrative(int idAdministrative,int idDedication) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_administrative(?,?)}");
        
        stmt.setInt(1,idDedication);
        stmt.setInt(2, idAdministrative);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates password of administrator
    public static void updateAdministrator(int idAdministrator,String newPass) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_administrator(?,?)}");
        
        stmt.setInt(1,idAdministrator);
        stmt.setString(2, newPass);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates a category description
    public static void updateArticleCategoryDescription(String description,int idCategory) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_article_cat_descrp(?,?)}");
        
        stmt.setString(1,description);
        stmt.setInt(2, idCategory);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void updatePhotoArticle(int pnIdArticle, String pcNewRoute) throws SQLException {
        Connection con = DriverManager.getConnection(host, Uname, Upass);
        CallableStatement stmt = con.prepareCall("{ call update_photo_article(?,?)}");

        stmt.setInt(1, pnIdArticle);
        stmt.setString(2, pcNewRoute);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates category of an article.
    public static void updateArticleCategory(int idNewCategory,int idArticle) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_article_category(?,?)}");
        
        stmt.setInt(1,idNewCategory);
        stmt.setInt(2, idArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    //Updates name of category
    public static void updateArticleCategoryName(String newName,int idCategory) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_article_category_name(?,?)}");
        
        stmt.setString(1,newName);
        stmt.setInt(2, idCategory);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    //Updates committee of an article
    public static void updateArticleCommitte(int idnewCommitte,int idArticle) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_article_committe(?,?)}");
        
        stmt.setInt(1,idnewCommitte);
        stmt.setInt(2, idArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates article date ofpublication
    public static void updateArticleDate(java.sql.Date date,int idArticle) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_article_date(?,?)}");
        
        stmt.setDate(1,date);
        stmt.setInt(2, idArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates the newspaper that an article is part of
    public static void updateArticleNewspaper(int idnewNewspaper,int idArticle) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_article_newspaper(?,?)}");
        
        stmt.setInt(1,idnewNewspaper);
        stmt.setInt(2, idArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates note of an article.
    public static void updateArticleNote(String newText,int idArticle) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_article_note(?,?)}");
        
        stmt.setString(1,newText);
        stmt.setInt(2, idArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates status of an article.
    public static void updateArticleStatus(int newStatus,int idArticle) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_article_status(?,?)}");
        
        stmt.setInt(1,newStatus);
        stmt.setInt(2, idArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates an article title.
    public static void updateArticleTitle(String newTitle,int idArticle) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_article_title(?,?)}");
        
        stmt.setString(1,newTitle);
        stmt.setInt(2, idArticle);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates category of an author
    public static void updateAuthorCategory(int idNewCategory,int idAuthor) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_author_category(?,?)}");
        
        stmt.setInt(1,idNewCategory);
        stmt.setInt(2, idAuthor);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates name of an author category
    public static void updateAuthorcategoryType(String newType,int idAuthorCategory) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_authorcategory_type(?,?)}");
        
        stmt.setString(1,newType);
        stmt.setInt(2, idAuthorCategory);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates an availability description.
    public static void updateAvailabilityDescription(String description,int idAvailability) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_availabilitypr_descrp(?,?)}");
        
        stmt.setString(1,description);
        stmt.setInt(2, idAvailability);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates district of a campus
    public static void updateCampusDistrict(int newDistrict,int idCampus) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_campus_district(?,?)}");
        
        stmt.setInt(1,newDistrict);
        stmt.setInt(2, idCampus);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates name of campus
    public static void updateCampusName(String newName,int idCampus) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_campus_name(?,?)}");
        
        stmt.setString(1,newName);
        stmt.setInt(2, idCampus);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates campus university
    public static void updateCampusUniversity(int newUniversity,int idCampus) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_campus_university(?,?)}");
        
        stmt.setInt(1,newUniversity);
        stmt.setInt(2, idCampus);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates canton province
    public static void updateCantonArea(int newArea,int idCanton) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_canton_area(?,?)}");
        
        stmt.setInt(1,newArea);
        stmt.setInt(2, idCanton);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates canton name
    public static void updateCantonName(String newName,int idCanton) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_canton_name(?,?)}");
        
        stmt.setString(1,newName);
        stmt.setInt(2, idCanton);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates a catalog description
    public static void updateCatalogDescription(String newDescription,int idCatalog) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_catalog_description(?,?)}");
        
        stmt.setString(1,newDescription);
        stmt.setInt(2, idCatalog);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates a catalog newspaper
    public static void updateCatalogNewspaper(int newPaper,int idCatalog) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_catalog_newspaper(?,?)}");
        
        stmt.setInt(1,newPaper);
        stmt.setInt(2, idCatalog);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates college name
    public static void updateCollegeName(String newName,int idCollege) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_college_name(?,?)}");
        
        stmt.setString(1,newName);
        stmt.setInt(2, idCollege);
        stmt.execute();
        closeConnection(stmt, con);
    }    
    //Updates description of a committee
    public static void updateCommitteeDescription(String description,int idCommittee)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_committee_description(?,?)}");

        stmt.setInt(1, idCommittee);
        stmt.setString(2,description);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates name of a country
    public static void updateCountryName(int idCountry,String newName) throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_country_name(?,?)}");
        
       
        stmt.setInt(1, idCountry);
        stmt.setString(2,newName);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates description of a dedication
    public static void updateDedicationDescription(int idDedication,String newDescription)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_dedication_description(?,?)}");
        
       
        stmt.setInt(1, idDedication);
        stmt.setString(2,newDescription);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates the name of a newspaper
    public static void updateDigitalNewspaperName(int idPaper,String newName)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_digitalNewspaper_name(?,?)}");
        
       
        stmt.setInt(1, idPaper);
        stmt.setString(2,newName);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates the quad of a digital newspaper
    public static void updateDigitalNewspaperQuad(int idPaper,int idQuad)throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_digitalNewspaper_quad(?,?)}");
        
       
        stmt.setInt(1, idPaper);
        stmt.setInt(2,idQuad);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates a district name
    public static void updateDistrictName(int idDistrict,String newName)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_district_name(?,?)}");
        
       
        stmt.setInt(1, idDistrict);
        stmt.setString(2,newName);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Update an email address
    public static void updateEmailAddress(int idEmail,String newAddress)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_email_address(?,?)}");
        
       
        stmt.setInt(1, idEmail);
        stmt.setString(2,newAddress);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Update a gender type
    public static void updateGenderTypeGender(int idGender,String newType)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_gender_type_gender(?,?)}");
        
       
        stmt.setInt(1, idGender);
        stmt.setString(2,newType);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Update description of a change in logdb
    public static void updateLogdbChangeDescription(int idLog,String changeDescription)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_logDB_change_descrp(?,?)}");
        
       
        stmt.setInt(1, idLog);
        stmt.setString(2,changeDescription);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates current text in logDB
     public static void updateLogdbCurrentText(int idLog,String text)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_logDB_current_text(?,?)}");
        
       
        stmt.setInt(1, idLog);
        stmt.setString(2,text);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates previous text on logDB
     public static void updateLogdbPreviousText(int idLog,String text)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_logDB_previous_text(?,?)}");
        
       
        stmt.setInt(1, idLog);
        stmt.setString(2,text);
        stmt.execute();
        closeConnection(stmt, con);
    }
     //Updates parameter description
     public static void updateParameterDescription(int idParameter,String description) throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_parameter_description(?,?)}");
        
       
        stmt.setInt(1, idParameter);
        stmt.setString(2,description);
        stmt.execute();
        closeConnection(stmt, con);
     }
     //Updates parameter name
     public static void updateParameterName(int idParameter,String name) throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_parameter_name(?,?)}");
        
       
        stmt.setInt(1, idParameter);
        stmt.setString(2,name);
        stmt.execute();
        closeConnection(stmt, con);
     }
     //Updates parameter route.
     public static void updateParameterRoute(int idParameter,String route) throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_parameter_route(?,?)}");
        
       
        stmt.setInt(1, idParameter);
        stmt.setString(2,route);
        stmt.execute();
        closeConnection(stmt, con);
     }
     
     public static void updateParameterValue(int idParameter,int value) throws SQLException{
         Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_parameter_value(?,?)}");
        
       
        stmt.setInt(1, idParameter);
        stmt.setInt(2,value);
        stmt.execute();
        closeConnection(stmt, con);
     }
     //Updates date of birth of a person.
     public static void updatePersonDateBirth(int pnIdPerson, java.sql.Date date)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_person_datebirth(?,?)}");
        stmt.setInt(1, pnIdPerson);
        stmt.setDate(2, date);
        stmt.execute();
        closeConnection(stmt, con);
    }
     
     public static void updatePersonXCommittee(int pnIdPeson, int pnIdCommittee)throws SQLException{
        Connection con = DriverManager.getConnection(host, Uname, Upass);
        CallableStatement  stmt = con.prepareCall("{ call update_personXCommittee(?,?)}");
        stmt.setInt(1, pnIdPeson);
        stmt.setInt(2, pnIdCommittee);
        stmt.execute();
        closeConnection(stmt, con);
    }
     public static void updatePersonDistrict(int pnIdPerson, int newDistrict)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_person_district(?,?)}");
        stmt.setInt(1, pnIdPerson);
        stmt.setInt(2, newDistrict);
        stmt.execute();
        closeConnection(stmt, con);
       }
     
     public static void updatePhotoProduct(int pnIdProduct, String pcNewRoute) throws SQLException {
        Connection con = DriverManager.getConnection(host, Uname, Upass);
        CallableStatement stmt = con.prepareCall("{ call update_photo_product(?,?)}");

        stmt.setInt(1, pnIdProduct);
        stmt.setString(2, pcNewRoute);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Update person first name.
     public static void updatePersonFrstName(int pnIdPerson, String pcNew)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_person_first_name(?,?)}");
        stmt.setInt(1, pnIdPerson);
        stmt.setString(2, pcNew);
        stmt.execute();
        closeConnection(stmt, con);
    }
     //Update person second name.
    public static void updatePersonScndName(int pnIdPerson, String pcNew)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_person_second_name(?,?)}");
        stmt.setInt(1, pnIdPerson);
        stmt.setString(2, pcNew);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Update person first surname.
    public static void updatePersonFirstSurname(int pnIdPerson, String pcNew)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_person_first_surname(?,?)}");
        stmt.setInt(1, pnIdPerson);
        stmt.setString(2, pcNew);
        stmt.execute();
        closeConnection(stmt, con);
       }
    //Update person second surname.
    public static void updatePersonSecondSurname(int pnIdPerson, String pcNew)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_person_second_surname(?,?)}");
        stmt.setInt(1, pnIdPerson);
        stmt.setString(2, pcNew);
        stmt.execute();
        closeConnection(stmt, con);
       }
    //Update person identity card.
    public static void updatePersonIdentityCard(int pnIdPerson, int pcNew)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_person_identitycard(?,?)}");
        stmt.setInt(1, pnIdPerson);
        stmt.setInt(2, pcNew);
        stmt.execute();
        closeConnection(stmt, con);
       }
    //Updates gender of a person
    public static void updatePersonGender(int pnIdPerson, int pcNew)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_person_gender(?,?)}");
        stmt.setInt(1, pnIdPerson);
        stmt.setInt(2, pcNew);
        stmt.execute();
        closeConnection(stmt, con);
       }
    //Updates person quad
    public static void updatePersonQuad(int pnIdPerson, int pcNew)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_person_quad(?,?)}");
        stmt.setInt(1, pnIdPerson);
        stmt.setInt(2, pcNew);
        stmt.execute();
        closeConnection(stmt, con);
       }
    //Updates person exact location.
    public static void updatePersonExactLocation(int pnIdPerson, String pcNew)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_person_localitation(?,?)}");
        stmt.setInt(1, pnIdPerson);
        stmt.setString(2, pcNew);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates a phone number
    public static void updatePhone(int pnIdPhone, int pnNewNumber)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_phone(?,?)}");

        stmt.setInt(1, pnIdPhone);
        stmt.setInt(2, pnNewNumber);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates phone category description
    public static void updatePhoneCategory(int pnIdCategory, String pcNewDescription)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_phonecategory(?,?)}");

        stmt.setInt(1, pnIdCategory);
        stmt.setString(2, pcNewDescription);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates product
    public static void updateProduct(int pnIdProduct, int pnNewCost, String pcNewDescription)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_product(?,?,?)}");
        
        stmt.setInt(1, pnIdProduct);
        stmt.setInt(2, pnNewCost);
        stmt.setString(3, pcNewDescription);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Update product description
    public static void updateProductDescription(int pnIdProduct, String pcNewDescription)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_product_description(?,?)}");
        
        stmt.setInt(1, pnIdProduct);
        stmt.setString(2, pcNewDescription);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    //Update product description
    public static void updateProductCost(int pnIdProduct, int newCost)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_product_cost(?,?)}");
        
        stmt.setInt(1, pnIdProduct);
        stmt.setInt(2, newCost);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Update catalog of product
    public static void updateProductCatalog(int pnIdProduct, int newCatalog)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_product_catalog(?,?)}");
        
        stmt.setInt(1, pnIdProduct);
        stmt.setInt(2, newCatalog);
        stmt.execute();
        closeConnection(stmt, con);
    }
    
    public static void updateProductAvailability(int pnIdProduct, int newAvailability)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_product_availability(?,?)}");
        
        stmt.setInt(1, pnIdProduct);
        stmt.setInt(2, newAvailability);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates route of photo
    public static void updatePhoto(int pnIdPhoto, String pcNewRoute)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_photo(?,?)}");
        
       stmt.setInt(1, pnIdPhoto);
       stmt.setString(2, pcNewRoute);
       stmt.execute();
       closeConnection(stmt, con);
    }
    //Updates professor dedication
    public static void updateProfessor(int pnIdPerson, int pnNewDedication)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_professor(?,?)}");

        stmt.setInt(1, pnIdPerson);
        stmt.setInt(2, pnNewDedication);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates province name
    public static void updateProvince(int pnIdProvince, String pcNewName)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_province(?,?)}");

        stmt.setInt(1, pnIdProvince);
        stmt.setString(2, pcNewName);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates description of review
    public static void updateReview(int pnIdArticle, int pnIdUser, String pcNewDescription)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_review(?,?,?)}");

        stmt.setInt(1, pnIdArticle);
        stmt.setInt(2, pnIdUser);
        stmt.setString(3, pcNewDescription);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates status description
    public static void updateStatus(int pnIdStatus, String pcNewStatus)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_status(?,?)}");

        stmt.setInt(1, pnIdStatus);
        stmt.setString(2, pcNewStatus);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates student card
    public static void updateStudent(int pnIdPerson, int pnNewCard )throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_student(?,?)}");
        
        stmt.setInt(1, pnIdPerson);
        stmt.setInt(2, pnNewCard);
        stmt.execute();
        closeConnection(stmt, con);
    }
    //Updates user password
    public static void updateUserPassword(int pnIdUser, String pcNewPass)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_user_password(?,?)}");
        
        stmt.setInt(1, pnIdUser);
        stmt.setString(2, pcNewPass);
        stmt.execute();
        closeConnection(stmt, con);
    } 
    //Updates user username
     public static void updateUserUserName(int pnIdUser, String pcNewName)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_user_username(?,?)}");
        
        stmt.setInt(1, pnIdUser);
        stmt.setString(2, pcNewName);
        stmt.execute();
        closeConnection(stmt, con);
    } 
     
     public static void updatePhotoUser(int pnIdUser, String pcNewRoute)throws SQLException{
        Connection con = DriverManager.getConnection(host,Uname,Upass);
        CallableStatement stmt = con.prepareCall("{ call update_photo_user(?,?)}");

       stmt.setInt(1, pnIdUser);
       stmt.setString(2, pcNewRoute);
       stmt.execute();
       closeConnection(stmt, con);
    }
}
