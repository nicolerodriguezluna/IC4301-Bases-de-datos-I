/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Model.Administrative;
import Model.Administrator;
import Model.Article;
import Model.ArticleCategory;
import Model.Author;
import Model.AuthorCategory;
import Model.AuthorxArticle;
import Model.Availability;
import Model.Campus;
import Model.Canton;
import Model.Catalog;
import Model.College;
import Model.Committee;
import Model.Country;
import Model.Dedication;
import Model.DigitalNewspaper;
import Model.District;
import Model.Email;
import Model.Gender;
import Model.LogDB;
import Model.Parameter;
import Model.Person;
import Model.PersonXCommittee;
import Model.Phone;
import Model.PhoneCategory;
import Model.Photo;
import Model.Product;
import Model.ProductXAuthor;
import Model.Professor;
import Model.Province;
import Model.Review;
import Model.Status;
import Model.Student;
import Model.User;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.ConnectionBuilder;
import oracle.jdbc.internal.OracleTypes;
import java.sql.*;

/**
 *
 * @author Alexander
 */
public class Cursors {
    
    public static ArrayList<Campus> getCampus() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_campus(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Campus> allCampus = new ArrayList<>();
        while(rs.next()){
            Campus campus = new Campus();
            campus.setIdCampus(rs.getInt("id_campus"));
            campus.setIdUniversity(rs.getInt("id_university"));
            campus.setIdDistrict(rs.getInt("id_district"));
            campus.setNameCampus(rs.getString("name_campus"));
            allCampus.add(campus);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return allCampus;
    }
    
    public static ArrayList<Catalog> getCatalogs() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_catalogs(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();

        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Catalog> catalogs = new ArrayList<>();
        while(rs.next()){
            Catalog catalog = new Catalog();
            catalog.setIdCatalog(rs.getInt("id_catalog"));
            catalog.setIdNewspaper(rs.getInt("id_newspaper"));
            catalog.setDescription(rs.getString("description_catalog"));
            catalogs.add(catalog);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return catalogs;
    }
    
    public static ArrayList<College> getColleges() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_colleges(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<College> colleges = new ArrayList<>();
        while(rs.next()){
            College college = new College();
            college.setIdCollege(rs.getInt("id_college"));
            college.setName(rs.getString("name_college"));
            colleges.add(college);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return colleges;   
    }
    
    public static College getCollegeByAuthor(int idAuthor) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_college_byauthor(?,?)}");
        sql.setInt(1, idAuthor);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        College college = new College();
        while(rs.next()){
            college.setIdCollege(rs.getInt("id_college"));
            college.setName(rs.getString("name_college"));
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return college;   
    }
    
    public static ArrayList<ArticleCategory> getArticleCategories() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_articlecategories(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<ArticleCategory> categories = new ArrayList<>();
        while(rs.next()){
           ArticleCategory category = new ArticleCategory();
           category.setIdCategory(rs.getInt("id_article_category"));
           category.setNameCategory(rs.getString("name_category"));
           category.setDescription(rs.getString("description_category"));
           categories.add(category);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return categories;   
    }
    
    public static ArrayList<AuthorCategory> getAuthorCategories() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_author_categories(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<AuthorCategory> categories = new ArrayList<>();
        while(rs.next()){
           AuthorCategory category = new AuthorCategory();
           category.setIdCategory(rs.getInt("id_author_category"));
           category.setTypeCategory(rs.getString("type_category"));
           categories.add(category);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return categories; 
    }
    
    
    
    
    public static ArrayList<Availability> getAvailabilities() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_availability(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Availability> availabilities = new ArrayList<>();
        while(rs.next()){
           Availability availability = new Availability();
           availability.setIdAvailability(rs.getInt("id_availability"));
           availability.setDescription(rs.getString("description_availability"));
           availabilities.add(availability);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return availabilities; 
        
    }
    
    //getCantons
    public static ArrayList<Canton> getCantons() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_cantons(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Canton> cantons = new ArrayList<>();
        while(rs.next()){
           Canton canton = new Canton();
           canton.setIdCanton(rs.getInt("id_canton"));
           canton.setName(rs.getString("name_canton"));
           canton.setIdArea(rs.getInt("id_area"));
           cantons.add(canton);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return cantons; 
    
    }
    
    public static Canton getCanton(int idCanton) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_canton(?,?)}");
        sql.setInt(1, idCanton);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();

        ResultSet rs = (ResultSet) sql.getObject(2);
        Canton canton = new Canton();
        while(rs.next()){
           canton.setIdCanton(rs.getInt("id_canton"));
           canton.setName(rs.getString("name_canton"));
           canton.setIdArea(rs.getInt("id_area"));
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return canton;
    }
    
    public static ArrayList<Administrative> getAdministratives()throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_administratives(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Administrative> administratives = new ArrayList<>();
        while(rs.next()){
           Administrative administrative = new Administrative();
           administrative.setIdAdministrative(rs.getInt("id_person"));
           administrative.setIdDedication(rs.getInt("id_dedication"));
           administratives.add(administrative);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return administratives;
    }
    
    public static ArrayList<Administrative> getAdministrative(int Administrative)throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_administrative(?,?)}");
        sql.setInt(1, Administrative);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Administrative> administratives = new ArrayList<>();
        while(rs.next()){
           Administrative administrative = new Administrative();
           administrative.setIdAdministrative(rs.getInt("id_person"));
           administrative.setIdDedication(rs.getInt("id_dedication"));
           administratives.add(administrative);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return administratives;
    }
    
    public static ArrayList<Administrator> getAdministrators() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_administrators(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Administrator> administrators = new ArrayList<>();
        while(rs.next()){
           Administrator administrator = new Administrator();
           administrator.setIdAdministrator(rs.getInt("id_person"));
           administrator.setPasswordAdmin(rs.getString("password_admin"));
           administrators.add(administrator);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return administrators;
    }
    
    public static ArrayList<Administrator> getAdministrator(int Administrator) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_Administrator(?,?)}");
        sql.setInt(1, Administrator);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Administrator> administrators = new ArrayList<>();
        while(rs.next()){
           Administrator administrator = new Administrator();
           administrator.setIdAdministrator(rs.getInt("id_person"));
           administrator.setPasswordAdmin(rs.getString("password_admin"));
           administrators.add(administrator);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return administrators;
    }
    
    public static ArrayList<Author> getAuthors() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_authors(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Author> authors = new ArrayList<>();
        while(rs.next()){
           Author author = new Author();
           author.setIdPerson(rs.getInt("id_person"));
           author.setIdAuthorCategory(rs.getInt("id_author_cathegory"));
           authors.add(author);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return authors;
    }
    
    
    public static ArrayList<Article> getArticles() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_articles(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Article> articles = new ArrayList<>();
        while(rs.next()){
           Article article = new Article();
           article.setIdArticle(rs.getInt("id_article"));
           article.setTitleArticle(rs.getString("title_article"));
           article.setTextNote(rs.getString("text_note"));
           article.setPublicationDate(rs.getDate("publication_date"));
           article.setIdStatus(rs.getInt("id_status_article"));
           article.setIdNewspaper(rs.getInt("id_dig_news"));
           article.setIdCategory(rs.getInt("id_art_cat"));
           article.setIdCommittee(rs.getInt("id_committe_art"));
           articles.add(article);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return articles;
    }
    
    public static ArrayList<Article> getArticlesByCommittee(int idCommittee) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_articles_byCommittee(?,?)}");
        sql.setInt(1, idCommittee);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Article> articles = new ArrayList<>();
        while(rs.next()){
           Article article = new Article();
           article.setIdArticle(rs.getInt("id_article"));
           article.setTitleArticle(rs.getString("title_article"));
           article.setTextNote(rs.getString("text_note"));
           article.setPublicationDate(rs.getDate("publication_date"));
           article.setIdStatus(rs.getInt("id_status_article"));
           article.setIdNewspaper(rs.getInt("id_dig_news"));
           article.setIdCategory(rs.getInt("id_art_cat"));
           article.setIdCommittee(rs.getInt("id_committe_art"));
           articles.add(article);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return articles;
    }
    
    public static ArrayList<Article> getArticlesLastNews() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_last_news(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Article> articles = new ArrayList<>();
        while(rs.next()){
           Article article = new Article();
           article.setIdArticle(rs.getInt("id_article"));
           article.setTitleArticle(rs.getString("title_article"));
           article.setTextNote(rs.getString("text_note"));
           article.setPublicationDate(rs.getDate("publication_date"));
           article.setIdStatus(rs.getInt("id_status_article"));
           article.setIdNewspaper(rs.getInt("id_dig_news"));
           article.setIdCategory(rs.getInt("id_art_cat"));
           article.setIdCommittee(rs.getInt("id_committe_art"));
           articles.add(article);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return articles;
    }
    //ArticlexAuthor
    public static ArrayList<Article> getArticleByAuthor(int idAuthor) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_articles_byauthor(?,?)}");
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.setInt(1,idAuthor);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Article> articles = new ArrayList<>();
        while(rs.next()){
           Article article = new Article();
           article.setIdArticle(rs.getInt("id_article"));
           article.setTitleArticle(rs.getString("title_article"));
           article.setTextNote(rs.getString("text_note"));
           article.setPublicationDate(rs.getDate("publication_date"));
           article.setIdStatus(rs.getInt("id_status_article"));
           article.setIdNewspaper(rs.getInt("id_dig_news"));
           article.setIdCategory(rs.getInt("id_art_cat"));
           article.setIdCommittee(rs.getInt("id_committe_art"));
           articles.add(article);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return articles;
    }
    
    public static ArrayList<AuthorxArticle> getAuthorxArticle() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_authorxarticle(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<AuthorxArticle> authorsxarticles  = new ArrayList<>();
        while(rs.next()){
           AuthorxArticle authorxarticle = new AuthorxArticle();
           authorxarticle.setIdAuthor(rs.getInt("id_author_autart"));
           authorxarticle.setIdArticle(rs.getInt("id_article_autart"));
           authorsxarticles.add(authorxarticle);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return authorsxarticles;
    }
    
    public static Author getAuthorByArticle(int idArticle) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_author_byarticle(?,?)}");
        sql.setInt(1, idArticle);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        Author author = new Author();
        while(rs.next()){
          author.setIdAuthorCategory(rs.getInt("id_author_cathegory"));
          author.setIdPerson(rs.getInt("id_person"));
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return author;
    }
    
    public static ArrayList<Article> getArticleByCategory(int category) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_article_bycategory(?,?)}");
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.setInt(1,category);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Article> articles = new ArrayList<>();
        while(rs.next()){
           Article article = new Article();
           article.setIdArticle(rs.getInt("id_article"));
           article.setTitleArticle(rs.getString("title_article"));
           article.setTextNote(rs.getString("text_note"));
           article.setPublicationDate(rs.getDate("publication_date"));
           article.setIdStatus(rs.getInt("id_status_article"));
           article.setIdNewspaper(rs.getInt("id_dig_news"));
           article.setIdCategory(rs.getInt("id_art_cat"));
           article.setIdCommittee(rs.getInt("id_committe_art"));
           articles.add(article);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return articles;
    }
    
    public static ArrayList<Article> getArticleByCategoryAdmin(int category) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_article_bycategory_admin(?,?)}");
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.setInt(1,category);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Article> articles = new ArrayList<>();
        while(rs.next()){
           Article article = new Article();
           article.setIdArticle(rs.getInt("id_article"));
           article.setTitleArticle(rs.getString("title_article"));
           article.setTextNote(rs.getString("text_note"));
           article.setPublicationDate(rs.getDate("publication_date"));
           article.setIdStatus(rs.getInt("id_status_article"));
           article.setIdNewspaper(rs.getInt("id_dig_news"));
           article.setIdCategory(rs.getInt("id_art_cat"));
           article.setIdCommittee(rs.getInt("id_committe_art"));
           articles.add(article);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return articles;
    }
    
    public static ArrayList<Article> getArticleByDate(Date date) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_article_bydate(?,?)}");
        sql.setDate(1, date);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Article> articles = new ArrayList<>();
        while(rs.next()){
           Article article = new Article();
           article.setIdArticle(rs.getInt("id_article"));
           article.setTitleArticle(rs.getString("title_article"));
           article.setTextNote(rs.getString("text_note"));
           article.setPublicationDate(rs.getDate("publication_date"));
           article.setIdStatus(rs.getInt("id_status_article"));
           article.setIdNewspaper(rs.getInt("id_dig_news"));
           article.setIdCategory(rs.getInt("id_art_cat"));
           article.setIdCommittee(rs.getInt("id_committe_art"));
           articles.add(article);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return articles;
    }
    
    public static ArrayList<Article> getArticleFullSearch(int idAuthor,int category,Date date) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_article_fullsearch(?,?,?,?)}");
        sql.setInt(1,idAuthor);
        sql.setInt(2, category);
        sql.setDate(3, date);
        sql.registerOutParameter(4, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(4);
        ArrayList<Article> articles = new ArrayList<>();
        while(rs.next()){
           Article article = new Article();
           article.setIdArticle(rs.getInt("id_article"));
           article.setTitleArticle(rs.getString("title_article"));
           article.setTextNote(rs.getString("text_note"));
           article.setPublicationDate(rs.getDate("publication_date"));
           article.setIdStatus(rs.getInt("id_status_article"));
           article.setIdNewspaper(rs.getInt("id_dig_news"));
           article.setIdCategory(rs.getInt("id_art_cat"));
           article.setIdCommittee(rs.getInt("id_committe_art"));
           articles.add(article);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return articles;
    }
    
    public static ArrayList<Author> getAuthorsByCategory(int category) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_author_bycategory(?,?)}");
        sql.setInt(1, category);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Author> authors = new ArrayList<>();
        while(rs.next()){
           Author author = new Author();
           author.setIdPerson(rs.getInt("id_person"));
           author.setIdAuthorCategory(rs.getInt("id_author_cathegory"));
           authors.add(author);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return authors;
    }
    
    public static ArrayList<Campus> getCampusByCollege(int college) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_campusbycollege(?,?)}");
        sql.setInt(1, college);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Campus> allCampus = new ArrayList<>();
        while(rs.next()){
            Campus campus = new Campus();
            campus.setIdCampus(rs.getInt("id_campus"));
            campus.setIdUniversity(rs.getInt("id_university"));
            campus.setIdDistrict(rs.getInt("id_district"));
            campus.setNameCampus(rs.getString("name_campus"));
            allCampus.add(campus);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return allCampus;
    }
    
    public static ArrayList<Canton> getCantonsByArea(int area) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_canton_byarea(?,?)}");
        sql.setInt(1, area);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Canton> cantons = new ArrayList<>();
        while(rs.next()){
           Canton canton = new Canton();
           canton.setIdCanton(rs.getInt("id_canton"));
           canton.setName(rs.getString("name_canton"));
           canton.setIdArea(rs.getInt("id_area"));
           cantons.add(canton);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return cantons; 
    }
    
    public static ArrayList<Catalog> getCatalogsByPaper(int paper) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_catalogs_bypaper(?,?)}");
        sql.setInt(1, paper);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Catalog> catalogs = new ArrayList<>();
        while(rs.next()){
            Catalog catalog = new Catalog();
            catalog.setIdCatalog(rs.getInt("id_catalog"));
            catalog.setIdNewspaper(rs.getInt("id_newspaper"));
            catalog.setDescription(rs.getString("description_catalog"));
            catalogs.add(catalog);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return catalogs;
    }
    
    public static Catalog getCatalog(int Catalog) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_catalog(?,?)}");
        sql.setInt(1, Catalog);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        Catalog catalog = new Catalog();
        while(rs.next()){
            catalog.setIdCatalog(rs.getInt("id_catalog"));
            catalog.setIdNewspaper(rs.getInt("id_newspaper"));
            catalog.setDescription(rs.getString("description_catalog"));
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return catalog;
    }
    
    //Equivalente a getPersonxCommittee
    public ArrayList<Person> getCommitteePeople(int idCommittee) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_people_bycommittee(?,?)}");
        sql.setInt(1, idCommittee);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Person> people = new ArrayList<>();
        while(rs.next()){
            Person person = new Person();
            person.setId(rs.getInt("id_person"));
            person.setFirstName(rs.getString("first_name"));
            person.setSecondName(rs.getString("second_name"));
            person.setFirstSurname(rs.getString("first_surname"));
            person.setSecondSurname(rs.getString("second_surname"));
            person.setIdCard(rs.getInt("identification_card"));
            person.setDatebirth(rs.getDate("datebirth"));
            person.setIdCampus(rs.getInt("id_quad"));
            person.setIdGender(rs.getInt("id_gender"));
            person.setExactLocation(rs.getString("exact_location"));
            person.setIdDistrict(rs.getInt("id_district"));
            people.add(person);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return people;
    }
    
    public static ArrayList<PersonXCommittee> getPersonxCommittee() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_personxcommitte(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<PersonXCommittee> peoplexCommittee  = new ArrayList<>();
        while(rs.next()){
           PersonXCommittee personxcommittee = new PersonXCommittee();
           personxcommittee.setIdPerson(rs.getInt("id_person"));
           personxcommittee.setIdCommitte(rs.getInt("id_committe"));
           peoplexCommittee.add(personxcommittee);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return peoplexCommittee;
    }
    
    public static ArrayList<Phone> getAllPhones() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_all_phones(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Phone> phones = new ArrayList<>();
        while(rs.next()){
            Phone phone = new Phone();
            phone.setId(rs.getInt("id_phone"));
            phone.setNumber(rs.getInt("number_phone"));
            phone.setIdPerson(rs.getInt("id_person"));
            phone.setIdPhoneCategory(rs.getInt("id_phone_category"));
            phones.add(phone);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return phones; 
    }
    
    public static ArrayList<Phone> getPersonPhones(int idPerson) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_person_phones(?,?)}");
        sql.setInt(1, idPerson);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Phone> phones = new ArrayList<>();
        while(rs.next()){
            Phone phone = new Phone();
            phone.setId(rs.getInt("id_phone"));
            phone.setNumber(rs.getInt("number_phone"));
            phone.setIdPerson(rs.getInt("id_person"));
            phone.setIdPhoneCategory(rs.getInt("id_phone_category"));
            phones.add(phone);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return phones; 
    }
    
    public static ArrayList<Phone> getPhone(int idPhone) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_phone(?,?)}");
        sql.setInt(1, idPhone);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Phone> phones = new ArrayList<>();
        while(rs.next()){
            Phone phone = new Phone();
            phone.setId(rs.getInt("id_phone"));
            phone.setNumber(rs.getInt("number_phone"));
            phone.setIdPerson(rs.getInt("id_person"));
            phone.setIdPhoneCategory(rs.getInt("id_phone_category"));
            phones.add(phone);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return phones; 
    }
    
    public static ArrayList<PhoneCategory> getPhoneCategory(int idCategory) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_phonecategory(?,?)}");
        sql.setInt(1, idCategory);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<PhoneCategory> categories = new ArrayList<>();
        while(rs.next()){
            PhoneCategory category = new PhoneCategory();
            category.setIdCategory(rs.getInt("id_phone_category"));
            category.setDescription(rs.getString("description_category"));
            categories.add(category);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return categories; 
    }
    
    public static ArrayList<PhoneCategory> getPhoneCategories() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_phonecategories(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<PhoneCategory> categories = new ArrayList<>();
        while(rs.next()){
            PhoneCategory category = new PhoneCategory();
            category.setIdCategory(rs.getInt("id_category"));
            category.setDescription(rs.getString("description_category"));
            categories.add(category);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return categories; 
    }
    
    public static Photo getArticlePhoto(int idArticle) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_photo_article(?,?)}");
        sql.setInt(1, idArticle);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
       ResultSet rs = (ResultSet) sql.getObject(2);
       Photo photo = new Photo();
        while(rs.next()){      
            photo.setId(rs.getInt("id_photo"));
            photo.setIdArticle(rs.getInt("id_article"));
            photo.setRoute(rs.getString("route"));
            photo.setIdUser(rs.getInt("id_user"));
            photo.setIdProduct(rs.getInt("id_product"));
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return photo; 
    }
    
    public static ArrayList<Photo> getPhotos() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_photos(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Photo> photos = new ArrayList<>();
        while(rs.next()){
            Photo photo = new Photo();
            photo.setId(rs.getInt("id_photo"));
            photo.setIdArticle(rs.getInt("id_article"));
            photo.setRoute(rs.getString("route"));
            photo.setIdUser(rs.getInt("id_user"));
            photo.setIdProduct(rs.getInt("id_product"));
            photos.add(photo);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return photos; 
    }
    
    public static Photo getProductPhoto(int idProduct) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_photo_product(?,?)}");
        sql.setInt(1, idProduct);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();      
        ResultSet rs = (ResultSet) sql.getObject(2);
         Photo photo = new Photo();
        while(rs.next()){
           
            photo.setId(rs.getInt("id_photo"));
            photo.setIdArticle(rs.getInt("id_article"));
            photo.setRoute(rs.getString("route"));
            photo.setIdUser(rs.getInt("id_user"));
            photo.setIdProduct(rs.getInt("id_product"));
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return photo;
    }
    
    public static Photo getUserPhoto(int idUser) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_photo_user(?,?)}");
        sql.setInt(1, idUser);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        Photo photo = new Photo();
        while(rs.next()){
            photo.setId(rs.getInt("id_photo"));
            photo.setIdArticle(rs.getInt("id_article"));
            photo.setRoute(rs.getString("route"));
            photo.setIdUser(rs.getInt("id_user"));
            photo.setIdProduct(rs.getInt("id_product"));
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return photo; 
    }
    
    public static ArrayList<Product> getProduct(int idProduct) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_product(?,?)}");
        sql.setInt(1, idProduct);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Product> products = new ArrayList<>();
        while(rs.next()){
            Product product = new Product();
            product.setId(rs.getInt("id_product"));
            product.setCost(rs.getInt("cost_product"));
            product.setDescription(rs.getString("description_product"));
            product.setIdCatalog(rs.getInt("id_catalog_pr"));
            product.setIdAvailability(rs.getInt("id_availability"));
            products.add(product);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return products; 
    }
    
    public static ArrayList<Product> getProducts() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_products(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Product> products = new ArrayList<>();
        while(rs.next()){
            Product product = new Product();
            product.setId(rs.getInt("id_product"));
            product.setCost(rs.getInt("cost_product"));
            product.setDescription(rs.getString("description_product"));
            product.setIdCatalog(rs.getInt("id_catalog_pr"));
            product.setIdAvailability(rs.getInt("id_availability"));
            products.add(product);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return products; 
    }
    
    public static ArrayList<Product> getProductsByCollege(int idCollege) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_products_byCollege(?,?)}");
        sql.setInt(1, idCollege);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Product> products = new ArrayList<>();
        while(rs.next()){
            Product product = new Product();
            product.setId(rs.getInt("id_product"));
            product.setCost(rs.getInt("cost_product"));
            product.setDescription(rs.getString("description_product"));
            product.setIdCatalog(rs.getInt("id_catalog_pr"));
            product.setIdAvailability(rs.getInt("id_availability"));
            products.add(product);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return products; 
    }
    
    public static ArrayList<Product> getProductsByCampus(int idCampus) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_products_byCampus(?,?)}");
        sql.setInt(1, idCampus);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Product> products = new ArrayList<>();
        while(rs.next()){
            Product product = new Product();
            product.setId(rs.getInt("id_product"));
            product.setCost(rs.getInt("cost_product"));
            product.setDescription(rs.getString("description_product"));
            product.setIdCatalog(rs.getInt("id_catalog_pr"));
            product.setIdAvailability(rs.getInt("id_availability"));
            products.add(product);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return products; 
    }
    
    public static ArrayList<Product> getProductxAuthorByProduct(int idProduct) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_productxauthor_byproduct(?,?)}");
        sql.setInt(1, idProduct);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Product> products = new ArrayList<>();
        while(rs.next()){
            Product pr = new Product();
            pr.setId(rs.getInt("id_product"));
            pr.setCost(rs.getInt("cost_product"));
            pr.setDescription(rs.getString("description_product"));
            pr.setIdCatalog(rs.getInt("id_catalog_pr"));
            pr.setIdAvailability(rs.getInt("id_availability"));           
            products.add(pr);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return products; 
    }
    
    public static ArrayList<Product> getProductxAuthorByAuthor(int idAuthor) throws SQLException{
       Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_productxauthor_byauthor(?,?)}");
        sql.setInt(1, idAuthor);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Product> products = new ArrayList<>();
        while(rs.next()){
            Product pr = new Product();
            pr.setId(rs.getInt("id_product"));
            pr.setCost(rs.getInt("cost_product"));
            pr.setDescription(rs.getString("description_product"));
            pr.setIdCatalog(rs.getInt("id_catalog_pr"));
            pr.setIdAvailability(rs.getInt("id_availability"));           
            products.add(pr);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return products;
    }
    
    public static ArrayList<Professor> getProfessor(int idProfessor) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_professor(?,?)}");
        sql.setInt(1, idProfessor);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Professor> professors =  new ArrayList<>();
        while(rs.next()){
            Professor professor = new Professor();
            professor.setIdPerson(rs.getInt("id_person"));
            professor.setIdDedication(rs.getInt("id_dedication"));
            professors.add(professor);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return professors; 
    }
    
    public static ArrayList<Professor> getProfessors() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_professors(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Professor> professors =  new ArrayList<>();
        while(rs.next()){
            Professor professor = new Professor();
            professor.setIdPerson(rs.getInt("id_person"));
            professor.setIdDedication(rs.getInt("id_dedication"));
            professors.add(professor);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return professors; 
    }
    
    public static Province getProvince(int idProvince)throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_province(?,?)}");
        sql.setInt(1, idProvince);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        Province province = new Province();
        while(rs.next()){
            
            province.setId(rs.getInt("id_province"));
            province.setIdCountry(rs.getInt("id_nation"));
            province.setName(rs.getString("name_province"));
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return province;
    }
    
    public static ArrayList<Province> getProvinceByCountry(int idCountry)throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_province_bycountry(?,?)}");
        sql.setInt(1, idCountry);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();

        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Province> allProvinces = new ArrayList<>();
        while(rs.next()){
           Province province = new Province();
           province.setId(rs.getInt("id_province"));
           province.setName(rs.getString("name_province"));
           province.setIdCountry(rs.getInt("id_nation"));
           allProvinces.add(province);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return allProvinces;
    }
    
    public static ArrayList<Province> getProvinces()throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_provinces(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Province> provinces =  new ArrayList<>();
        while(rs.next()){
            Province province = new Province();
            province.setId(rs.getInt("id_province"));
            province.setIdCountry(rs.getInt("id_nation"));
            province.setName(rs.getString("name_province"));
            provinces.add(province);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return provinces; 
    }
    
    public static ArrayList<Review> getReviews() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_reviews(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Review> reviews  =  new ArrayList<>();
        while(rs.next()){
            Review review = new Review();
            review.setIdArticle(rs.getInt("id_article_rev"));
            review.setIdUser(rs.getInt("id_user_rev"));
            review.setDescription(rs.getString("description_review"));
            review.setStars(rs.getInt("stars"));
            reviews.add(review);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return reviews; 
    }
    
    
    public static ArrayList<Review> getReviewsByArticle(int idArticle) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_reviews_article(?,?)}");
        sql.setInt(1, idArticle);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Review> reviews  =  new ArrayList<>();
        while(rs.next()){
            Review review = new Review();
            review.setIdArticle(rs.getInt("id_article_rev"));
            review.setIdUser(rs.getInt("id_user_rev"));
            review.setDescription(rs.getString("description_review"));
            review.setStars(rs.getInt("stars"));
            reviews.add(review);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return reviews; 
    }
    
    public static ArrayList<Status> getStatuses() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_statuses(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Status> statuses  =  new ArrayList<>();
        while(rs.next()){
            Status status = new Status();
            status.setIdStatus(rs.getInt("id_status"));
            status.setName(rs.getString("name_status"));
            statuses.add(status);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return statuses; 
    }
    
    public static ArrayList<Status> getStatus(int idStatus) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_status(?,?)}");
        sql.setInt(1, idStatus);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Status> statuses  =  new ArrayList<>();
        while(rs.next()){
            Status status = new Status();
            status.setIdStatus(rs.getInt("id_status"));
            status.setName(rs.getString("name_status"));
            statuses.add(status);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return statuses; 
    }
    
    public static ArrayList<Student> getStudents() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_students(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Student> students  =  new ArrayList<>();
        while(rs.next()){
            Student student = new Student();
            student.setIdPerson(rs.getInt("id_person"));
            student.setStudentCard(rs.getInt("student_card"));
            students.add(student);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return students; 
    }
    
    public static ArrayList<Student> getStudent(int idPerson) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_student(?,?)}");
        sql.setInt(1, idPerson);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Student> students  =  new ArrayList<>();
        while(rs.next()){
            Student student = new Student();
            student.setIdPerson(rs.getInt("id_person"));
            student.setStudentCard(rs.getInt("student_card"));
            students.add(student);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return students; 
    }
    
    public static ArrayList<User> getUsers() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_users(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<User> users  =  new ArrayList<>();
        while(rs.next()){
            User user = new User();
            user.setIdPerson(rs.getInt("id_person"));
            user.setPassword(rs.getString("password_user"));
            user.setUserName(rs.getString("user_name"));
            user.setIdUser(rs.getInt("id_user"));
            users.add(user);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return users; 
    }
    
    public static User getUser(int idUser) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_user(?,?)}");
        sql.setInt(1, idUser);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        User user = new User();
        while(rs.next()){           
            user.setIdPerson(rs.getInt("id_person"));
            user.setPassword(rs.getString("password_user"));
            user.setUserName(rs.getString("user_name"));
            
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return user; 
    }
    
    public static ArrayList<Committee> getCommittees() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_committees(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Committee> committees  =  new ArrayList<>();
        while(rs.next()){
            Committee committee = new Committee();
            committee.setIdCommittee(rs.getInt("id_committe"));
            committee.setDescription(rs.getString("description_committe"));
            committee.setIdCampus(rs.getInt("id_campus"));
            committees.add(committee);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return committees; 
    }
    
    public static ArrayList<Committee> getCommittee(int idCommittee) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_committee(?,?)}");
        sql.setInt(1, idCommittee);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Committee> committees  =  new ArrayList<>();
        while(rs.next()){
            Committee committee = new Committee();
            committee.setIdCommittee(rs.getInt("id_committe"));
            committee.setDescription(rs.getString("description_committe"));
            committee.setIdCampus(rs.getInt("id_campus"));
            committees.add(committee);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return committees; 
    }
    
    public static ArrayList<Country> getCountries()throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_countries(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Country> countries  =  new ArrayList<>();
        while(rs.next()){
            Country country = new Country();
            country.setIdCountry(rs.getInt("id_country"));
            country.setName(rs.getString("name_country"));
            countries.add(country);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return countries; 
    }
    
    public static ArrayList<Country> getCountry(int idCountry)throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_country(?,?)}");
        sql.setInt(1, idCountry);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Country> countries  =  new ArrayList<>();
        while(rs.next()){
            Country country = new Country();
            country.setIdCountry(rs.getInt("id_country"));
            country.setName(rs.getString("name_country"));
            countries.add(country);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return countries; 
    }
    
    public static ArrayList<Dedication> getDedications() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_dedications(?)}");     
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Dedication> dedications  =  new ArrayList<>();
        while(rs.next()){
            Dedication dedication = new Dedication();
            dedication.setIdDedication(rs.getInt("id_dedication"));
            dedication.setDescription(rs.getString("description_dedication"));
            dedications.add(dedication);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return dedications; 
    }
    
    public static ArrayList<Dedication> getDedication(int idDedication) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_dedication(?,?)}");     
        sql.setInt(1, idDedication);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Dedication> dedications  =  new ArrayList<>();
        while(rs.next()){
            Dedication dedication = new Dedication();
            dedication.setIdDedication(rs.getInt("id_dedication"));
            dedication.setDescription(rs.getString("description_dedication"));
            dedications.add(dedication);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return dedications; 
    }
    
    public static ArrayList<DigitalNewspaper> getDigitalNewspapers() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_digital_newspapers(?)}");     
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<DigitalNewspaper> papers  =  new ArrayList<>();
        while(rs.next()){
            DigitalNewspaper paper = new DigitalNewspaper();
            paper.setIdDigitalNewspaper(rs.getInt("id_digital_newspaper"));
            paper.setName(rs.getString("name_digital_newspaper"));
            paper.setIdQuad(rs.getInt("id_quad"));
            papers.add(paper);
           
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return papers; 
    }
     public static ArrayList<DigitalNewspaper> getDigitalNewspapersByCollege(int idCollege) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_newspapers_byCollege(?,?)}");
        sql.setInt(1, idCollege);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<DigitalNewspaper> papers  =  new ArrayList<>();
        while(rs.next()){
            DigitalNewspaper paper = new DigitalNewspaper();
            paper.setIdDigitalNewspaper(rs.getInt("id_digital_newspaper"));
            paper.setName(rs.getString("name_digital_newspaper"));
            paper.setIdQuad(rs.getInt("id_quad"));
            papers.add(paper);
           
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return papers; 
    }
     
     public static ArrayList<DigitalNewspaper> getDigitalNewspapersByQuad(int idQuad) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_newspapers_byCollege(?,?)}");
        sql.setInt(1, idQuad);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<DigitalNewspaper> papers  =  new ArrayList<>();
        while(rs.next()){
            DigitalNewspaper paper = new DigitalNewspaper();
            paper.setIdDigitalNewspaper(rs.getInt("id_digital_newspaper"));
            paper.setName(rs.getString("name_digital_newspaper"));
            paper.setIdQuad(rs.getInt("id_quad"));
            papers.add(paper);
           
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return papers; 
    }
    
    public static DigitalNewspaper getDigitalNewspaper(int idPaper) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_digital_newspaper(?,?)}");    
        sql.setInt(1, idPaper);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        DigitalNewspaper paper = new DigitalNewspaper();
        while(rs.next()){
            
            paper.setIdDigitalNewspaper(rs.getInt("id_digital_newspaper"));
            paper.setName(rs.getString("name_digital_newspaper"));
            paper.setIdQuad(rs.getInt("id_quad"));
           
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return paper; 
    }
    
    public static ArrayList<District> getDistricts() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_districts(?)}");    
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<District> districts  =  new ArrayList<>();
        while(rs.next()){
           District district = new District();
           district.setIdDistrict(rs.getInt("id_district"));
           district.setName(rs.getString("name_district"));
           district.setIdSector(rs.getInt("id_sector"));
           districts.add(district);  
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return districts; 
    }
    
    public static ArrayList<District> getDistrictByArea(int idDistrict)throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_district_byarea(?,?)}");
        sql.setInt(1, idDistrict);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();

        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<District> allDistricts = new ArrayList<>();
        while(rs.next()){
           District district = new District();
           district.setIdDistrict(rs.getInt("id_district"));
           district.setIdSector(rs.getInt("id_sector"));
           district.setName(rs.getString("name_district"));
           allDistricts.add(district);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return allDistricts;
    }
    
     public static ArrayList<District> getDistrict(int idDistrict) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_district(?,?)}");    
        sql.setInt(1, idDistrict);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<District> districts  =  new ArrayList<>();
        while(rs.next()){
           District district = new District();
           district.setIdDistrict(rs.getInt("id_district"));
           district.setName(rs.getString("name_district"));
           district.setIdSector(rs.getInt("id_sector"));
           districts.add(district);  
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return districts; 
    }
     
     public static ArrayList<Email> getEmails() throws SQLException{
         Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_emails(?)}");    
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Email> emails  =  new ArrayList<>();
        while(rs.next()){
           Email email = new Email();
           email.setIdEmail(rs.getInt("id_email"));
           email.setAddressEmail(rs.getString("address_email"));
           email.setIdPerson(rs.getInt("id_person_mail"));
           emails.add(email);
          
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return emails; 
     }
     
     public static ArrayList<Email> getEmailsPerson(int idPerson) throws SQLException{
         Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_emails_person(?,?)}");   
        sql.setInt(1, idPerson);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Email> emails  =  new ArrayList<>();
        while(rs.next()){
           Email email = new Email();
           email.setIdEmail(rs.getInt("id_email"));
           email.setAddressEmail(rs.getString("address_email"));
           email.setIdPerson(rs.getInt("id_person_mail"));
           emails.add(email);
          
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return emails; 
     }
     
     public static ArrayList<Gender> getGenders()throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_genders(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();

        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Gender> allGenders = new ArrayList<>();
        while(rs.next()){
           Gender gender = new Gender();
           gender.setIdGender(rs.getInt("id_gender"));
           gender.setType(rs.getString("type_gender"));
           allGenders.add(gender);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return allGenders;
    }
     
     public static ArrayList<Gender> getGender(int idGender)throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_gender(?,?)}");
        sql.setInt(1, idGender);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();

        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Gender> allGenders = new ArrayList<>();
        while(rs.next()){
           Gender gender = new Gender();
           gender.setIdGender(rs.getInt("id_gender"));
           gender.setType(rs.getString("type_gender"));
           allGenders.add(gender);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return allGenders;
    }
     
     public static ArrayList<LogDB> getLogDBs() throws SQLException{
         Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_logdbs(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();

        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<LogDB> logs = new ArrayList<>();
        while(rs.next()){
          LogDB log = new LogDB();
          log.setIdLog(rs.getInt("id_log"));
          log.setSystemDate(rs.getDate("systemdate"));
          log.setTime(rs.getTimestamp("time_log"));
          log.setDescription(rs.getString("change_description"));
          log.setPrevious(rs.getString("previous_text"));
          log.setCurrent(rs.getString("current_text"));
          logs.add(log);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return logs;
     }
     
     public static ArrayList<LogDB> getLogDB(int idLog) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_logdb(?,?)}");
        sql.setInt(1, idLog);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();

        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<LogDB> logs = new ArrayList<>();
        while(rs.next()){
          LogDB log = new LogDB();
          log.setIdLog(rs.getInt("id_log"));
          log.setSystemDate(rs.getDate("systemdate"));
          log.setTime(rs.getTimestamp("time_log"));
          log.setDescription(rs.getString("change_description"));
          log.setPrevious(rs.getString("previous_text"));
          log.setCurrent(rs.getString("current_text"));
          logs.add(log);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return logs;
     }
     
     public static ArrayList<Parameter> getParameters() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_parameters(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();

        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Parameter> parameters = new ArrayList<>();
        while(rs.next()){
          Parameter parameter = new Parameter();
          parameter.setIdParameter(rs.getInt("id_parameter"));
          parameter.setName(rs.getString("name_parameter"));
          parameter.setDescription(rs.getString("description_parameter"));
          parameter.setValue(rs.getInt("value_parameter"));
          parameter.setRoute(rs.getString("route"));
          parameters.add(parameter);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return parameters;
     }
     
     public static ArrayList<Parameter> getParameter(int idParameter) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_parameter(?,?)}");
        sql.setInt(1, idParameter);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();

        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Parameter> parameters = new ArrayList<>();
        while(rs.next()){
          Parameter parameter = new Parameter();
          parameter.setIdParameter(rs.getInt("id_parameter"));
          parameter.setName(rs.getString("name_parameter"));
          parameter.setDescription(rs.getString("description_parameter"));
          parameter.setValue(rs.getInt("value_parameter"));
          parameter.setRoute(rs.getString("route"));
          parameters.add(parameter);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return parameters;
     }
     
     public static ArrayList<Person> getPersons() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_people(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Person> people = new ArrayList<>();
        while(rs.next()){
            Person person = new Person();
            person.setId(rs.getInt("id_person"));
            person.setIdCard(rs.getInt("identification_card"));
            person.setDatebirth(rs.getDate("datebirth"));
            person.setFirstName(rs.getString("first_name"));
            person.setSecondName(rs.getString("second_name"));
            person.setFirstSurname(rs.getString("first_surname"));
            person.setSecondSurname(rs.getString("second_surname"));
            person.setExactLocation(rs.getString("exact_location"));
            person.setIdCampus(rs.getInt("id_quad"));
            person.setIdGender(rs.getInt("id_gender"));   
            person.setIdDistrict(rs.getInt("id_district")); 
            people.add(person);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return people;
    }
     
     public static Person getPerson(int idPerson) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_person(?,?)}");
        sql.setInt(1, idPerson);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        Person person = new Person();
        while(rs.next()){
            person.setId(rs.getInt("id_person"));
            person.setIdCard(rs.getInt("identification_card"));
            person.setDatebirth(rs.getDate("datebirth"));
            person.setFirstName(rs.getString("first_name"));
            person.setSecondName(rs.getString("second_name"));
            person.setFirstSurname(rs.getString("first_surname"));
            person.setSecondSurname(rs.getString("second_surname"));
            person.setExactLocation(rs.getString("exact_location"));
            person.setIdCampus(rs.getInt("id_quad"));
            person.setIdGender(rs.getInt("id_gender"));   
            person.setIdDistrict(rs.getInt("id_district")); 
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return person;
    }
     
    public static ArrayList<Article> getMostViewed() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_most_viewed(?)}");
        sql.registerOutParameter(1, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(1);
        ArrayList<Article> articles = new ArrayList<>();
        while(rs.next()){
           Article article = new Article();
           article.setIdArticle(rs.getInt("id_article"));
           article.setTitleArticle(rs.getString("title_article"));
           article.setTextNote(rs.getString("text_note"));
           article.setPublicationDate(rs.getDate("publication_date"));
           article.setIdStatus(rs.getInt("id_status_article"));
           article.setIdNewspaper(rs.getInt("id_dig_news"));
           article.setIdCategory(rs.getInt("id_art_cat"));
           article.setIdCommittee(rs.getInt("id_committe_art"));
           articles.add(article);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return articles;
    }
    
    public static int getAuthorTotalPoints(int idAuthor) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{? = call get_author_total_points(?)}");
        sql.registerOutParameter(1, OracleTypes.INTEGER);
        sql.setInt(2, idAuthor);
        sql.execute();
        return (int)sql.getObject(1);
    }
    
    public static int getAuthorCurrentPoints(int idAuthor) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{? = call get_author_current_points(?)}");
        sql.registerOutParameter(1, OracleTypes.INTEGER);
        sql.setInt(2, idAuthor);
        sql.execute();
        return (int)sql.getObject(1);
    }
    
    public static int getAuthorSpentPoints(int idAuthor) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{? = call get_author_spent_points(?)}");
        sql.registerOutParameter(1,OracleTypes.INTEGER);
        sql.setInt(2, idAuthor);
        sql.execute();
        return (int)sql.getObject(1);
    }
    
    public static Person getUserPerson(int idUser)throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_user_person(?,?)}");
        sql.setInt(1, idUser);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        Person person = new Person();
        while(rs.next()){
            person.setId(rs.getInt("id_person"));
            person.setIdCard(rs.getInt("identification_card"));
            person.setDatebirth(rs.getDate("datebirth"));
            person.setFirstName(rs.getString("first_name"));
            person.setSecondName(rs.getString("second_name"));
            person.setFirstSurname(rs.getString("first_surname"));
            person.setSecondSurname(rs.getString("second_surname"));
            person.setExactLocation(rs.getString("exact_location"));
            person.setIdCampus(rs.getInt("id_quad"));
            person.setIdGender(rs.getInt("id_gender"));   
            person.setIdDistrict(rs.getInt("id_district")); 
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return person;
    }
    
    public static ArrayList<Article> getUserFavourites(int idUser) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_user_favourites(?,?)}");
        sql.setInt(1, idUser);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();
        
        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<Article> articles = new ArrayList<>();
        while(rs.next()){
           Article article = new Article();
           article.setIdArticle(rs.getInt("id_article"));
           article.setTitleArticle(rs.getString("title_article"));
           article.setTextNote(rs.getString("text_note"));
           article.setPublicationDate(rs.getDate("publication_date"));
           article.setIdStatus(rs.getInt("id_status_article"));
           article.setIdNewspaper(rs.getInt("id_dig_news"));
           article.setIdCategory(rs.getInt("id_art_cat"));
           article.setIdCommittee(rs.getInt("id_committe_art"));
           articles.add(article);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return articles;
    }
    
    public static ArrayList<User> getUserByPerson(int idPerson) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_usersByPerson(?,?)}");
        sql.setInt(1, idPerson);
        sql.registerOutParameter(2, OracleTypes.REF_CURSOR);
        sql.execute();

        ResultSet rs = (ResultSet) sql.getObject(2);
        ArrayList<User> users  =  new ArrayList<>();
        while(rs.next()){
            User user = new User();
            user.setIdPerson(rs.getInt("id_person"));
            user.setPassword(rs.getString("password_user"));
            user.setUserName(rs.getString("user_name"));
            user.setIdUser(rs.getInt("id_user"));
            users.add(user);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return users; 
    }
    
    
}
