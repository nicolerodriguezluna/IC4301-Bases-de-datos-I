/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dbprueba;

/**
 *
 * @author Jeffrey Leiva
 */

import Control.ConnectDB;
import Control.Statistics;
import Model.ArticlesPerCollege;
import Model.AuthorAverageReview;
import Model.AuthorRangeAge;
import Model.TopNAuthors;
import Model.TotalArticlesxAuthor;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import oracle.jdbc.OracleTypes;
public class DBPrueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        System.out.println("Average Review of Authors");
        ArrayList<AuthorAverageReview> statistics = Statistics.averageAuthorReview();
        for(AuthorAverageReview article: statistics){
            System.out.println(article.toString());
        }
        System.out.println("Articles Per College");
         ArrayList<ArticlesPerCollege> statisticsCollege = Statistics.getArticlesPerCollege();
         for(ArticlesPerCollege article: statisticsCollege){
            System.out.println(article.toString());
        }
        System.out.println("Top N Authors By Category");
         ArrayList<TopNAuthors> authorsByCategory = Statistics.getTopAuthorsByCategory(4,2);
        for(TopNAuthors article: authorsByCategory){
            System.out.println(article.toString());
        }
        System.out.println("Top N Authors by College");
         ArrayList<TopNAuthors> authorsByCollege = Statistics.getTopAuthorsByCollege(4,2);
        for(TopNAuthors article: authorsByCollege){
            System.out.println(article.toString());
        }
        System.out.println("Top N Authors by gender");
         ArrayList<TopNAuthors> authorsByGender = Statistics.getTopAuthorsByGender(4,0);
        for(TopNAuthors article: authorsByGender){
            System.out.println(article.toString());
        }
        System.out.println("Total ArticlesxAuthor");
        ArrayList<TotalArticlesxAuthor> totalArticles = Statistics.getTotalArticlesxAuthor();
        for(TotalArticlesxAuthor article: totalArticles){
            System.out.println(article.toString());
        }
        
        System.out.println("Author by age gender");
        ArrayList<AuthorRangeAge> byage = Statistics.getAuthorsByAgeGender(0);
        for( AuthorRangeAge article: byage){
            System.out.println(article.toString());
        }
        
        System.out.println("Articles by age college");
        ArrayList<AuthorRangeAge> bycollege = Statistics.getAuthorsByAgeCollege(1);
        for( AuthorRangeAge article: bycollege){
            System.out.println(article.toString());
        }
        
        System.out.println("Articles by age type");
        ArrayList<AuthorRangeAge> bytype = Statistics.getAuthorsByAgeType(3);
        for( AuthorRangeAge article: bytype){
            System.out.println(article.toString());
        }
        
        
    }
    
}
