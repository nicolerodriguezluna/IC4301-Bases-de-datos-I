/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class Top10Products {
    String description;
    int cost;
    int totalCount;
    
    public Top10Products(){}
    
    public Top10Products(String description,int cost,int total){
        this.description = description;
        this.cost = cost;
        this.totalCount = total;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    @Override
    public String toString() {
        return "Top10Products{" + "description=" + description + ", cost=" + cost + ", totalCount=" + totalCount + '}';
    }
    
    
}
