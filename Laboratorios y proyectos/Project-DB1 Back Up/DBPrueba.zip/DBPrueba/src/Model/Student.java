/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class Student {
    int idPerson;
    int studentCard;

    public Student() {
    }

    public Student(int idPerson, int studentCard) {
        this.idPerson = idPerson;
        this.studentCard = studentCard;
    }

    public void setIdPerson(int idPerson) {
        this.idPerson = idPerson;
    }

    public void setStudentCard(int studentCard) {
        this.studentCard = studentCard;
    }

    public int getIdPerson() {
        return idPerson;
    }

    public int getStudentCard() {
        return studentCard;
    }

    @Override
    public String toString() {
        return "Student{" + "idPerson=" + idPerson + ", studentCard=" + studentCard + '}';
    }
}
