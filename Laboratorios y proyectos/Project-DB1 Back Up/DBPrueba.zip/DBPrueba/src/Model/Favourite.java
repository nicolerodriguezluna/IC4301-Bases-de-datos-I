/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.Date;

/**
 *
 * @author Jeffrey Leiva
 */
public class Favourite {
    int idArticle;
    int idUser;
    Date dateFavourite;
    
    public Favourite(){}
    
    public Favourite(int idArticle,int idUser,Date date){
        this.idArticle = idArticle;
        this.idUser = idUser;
        this.dateFavourite = date;
    }

    public int getIdArticle() {
        return idArticle;
    }

    public void setIdArticle(int idArticle) {
        this.idArticle = idArticle;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public Date getDateFavourite() {
        return dateFavourite;
    }

    public void setDateFavourite(Date dateFavourite) {
        this.dateFavourite = dateFavourite;
    }
    
    
}
