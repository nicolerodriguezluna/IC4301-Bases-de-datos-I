/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class AuthorxArticle {
    
    public AuthorxArticle(){}
    
    public AuthorxArticle(int idAuthor,int idArticle){
        this.idAuthor = idAuthor;
        this.idArticle = idArticle;
    }
    public int getIdAuthor() {
        return idAuthor;
    }

    public void setIdAuthor(int idAuthor) {
        this.idAuthor = idAuthor;
    }

    public int getIdArticle() {
        return idArticle;
    }

    public void setIdArticle(int idArticle) {
        this.idArticle = idArticle;
    }
    int idAuthor;
    int idArticle;
    
    
}
