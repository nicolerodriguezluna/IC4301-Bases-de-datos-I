/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class Campus {
    int idCampus;
    String nameCampus;
    int idUniversity;
    int idDistrict;
    
    public Campus(){}
    
    public Campus(int id,String name,int college,int district){
        this.idCampus = id;
        this.nameCampus =name;
        this.idUniversity = college;
        this.idDistrict = district;
    }

    public int getIdCampus() {
        return idCampus;
    }

    public void setIdCampus(int idCampus) {
        this.idCampus = idCampus;
    }

    public String getNameCampus() {
        return nameCampus;
    }

    public void setNameCampus(String nameCampus) {
        this.nameCampus = nameCampus;
    }

    public int getIdUniversity() {
        return idUniversity;
    }

    public void setIdUniversity(int idUniversity) {
        this.idUniversity = idUniversity;
    }

    public int getIdDistrict() {
        return idDistrict;
    }

    public void setIdDistrict(int idDistrict) {
        this.idDistrict = idDistrict;
    }
    
    
}
