/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class Province {
    int id;
    int idCountry;
    String name;

    public Province() {
    }

    public Province(int id, int idCountry, String name) {
        this.id = id;
        this.idCountry = idCountry;
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setIdCountry(int idCountry) {
        this.idCountry = idCountry;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public int getIdCountry() {
        return idCountry;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Province{" + "id=" + id + ", idCountry=" + idCountry + ", name=" + name + '}';
    }
    
    
}
