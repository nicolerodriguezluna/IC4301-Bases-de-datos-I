/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class Phone {
    int id;
    int number;
    int idPerson;
    int idPhoneCategory;

    public Phone() {
    }

    
    public Phone(int id, int number, int idPerson, int idPhoneCategory) {
        this.id = id;
        this.number = number;
        this.idPerson = idPerson;
        this.idPhoneCategory = idPhoneCategory;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setIdPerson(int idPerson) {
        this.idPerson = idPerson;
    }

    public void setIdPhoneCategory(int idPhoneCategory) {
        this.idPhoneCategory = idPhoneCategory;
    }

    public int getId() {
        return id;
    }

    public int getNumber() {
        return number;
    }

    public int getIdPerson() {
        return idPerson;
    }

    public int getIdPhoneCategory() {
        return idPhoneCategory;
    }

    @Override
    public String toString() {
        return "Phone{" + "id=" + id + ", number=" + number + ", idPerson=" + idPerson + ", idPhoneCategory=" + idPhoneCategory + '}';
    }
    
    
}
