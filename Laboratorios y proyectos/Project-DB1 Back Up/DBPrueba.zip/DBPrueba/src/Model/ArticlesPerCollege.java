/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class ArticlesPerCollege {
    int total;
    String nameCollege;
    
    public ArticlesPerCollege(){}
    
    public ArticlesPerCollege(int total,String nameCollege){
        this.total = total;
        this.nameCollege = nameCollege;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getNameCollege() {
        return nameCollege;
    }

    public void setNameCollege(String nameCollege) {
        this.nameCollege = nameCollege;
    }

    @Override
    public String toString() {
        return "ArticlesPerCollege{" + "total=" + total + ", nameCollege=" + nameCollege + '}';
    }
    
}
