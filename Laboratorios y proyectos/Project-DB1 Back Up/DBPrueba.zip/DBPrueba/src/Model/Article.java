/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.Date;

/**
 *
 * @author Jeffrey Leiva
 */
public class Article {
    int idArticle;
    String titleArticle;
    String textNote;
    Date publicationDate;
    int idStatus;
    int idNewspaper;
    int idCategory;
    int idCommittee;
    
    public Article(){}
    
    public Article(int articleNumber,String title,String note,Date date,int status,int newspaper,int category,int committee){
        this.idArticle = articleNumber;
        this.titleArticle = title;
        this.textNote = note;
        this.publicationDate = date;
        this.idStatus = status;
        this.idNewspaper = newspaper;
        this.idCategory = category;
        this.idCommittee = committee;
    }

    public int getIdArticle() {
        return idArticle;
    }

    public void setIdArticle(int idArticle) {
        this.idArticle = idArticle;
    }

    public String getTitleArticle() {
        return titleArticle;
    }

    public void setTitleArticle(String titleArticle) {
        this.titleArticle = titleArticle;
    }

    public String getTextNote() {
        return textNote;
    }

    public void setTextNote(String textNote) {
        this.textNote = textNote;
    }

    public Date getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }

    public int getIdStatus() {
        return idStatus;
    }

    public void setIdStatus(int idStatus) {
        this.idStatus = idStatus;
    }

    public int getIdNewspaper() {
        return idNewspaper;
    }

    public void setIdNewspaper(int idNewspaper) {
        this.idNewspaper = idNewspaper;
    }

    public int getIdCategory() {
        return idCategory;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    public int getIdCommittee() {
        return idCommittee;
    }

    public void setIdCommittee(int idCommittee) {
        this.idCommittee = idCommittee;
    }
    
    
    
}
