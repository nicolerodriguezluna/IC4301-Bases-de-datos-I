/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class DigitalNewspaper {
    int idDigitalNewspaper;
    String name;
    int idQuad;
    
    public DigitalNewspaper(){}
    
    public DigitalNewspaper(int id,String name,int idCampus){
        this.idDigitalNewspaper = id;
        this.name = name;
        this.idQuad = idCampus;
    }

    public int getIdDigitalNewspaper() {
        return idDigitalNewspaper;
    }

    public void setIdDigitalNewspaper(int idDigitalNewspaper) {
        this.idDigitalNewspaper = idDigitalNewspaper;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIdQuad() {
        return idQuad;
    }

    public void setIdQuad(int idQuad) {
        this.idQuad = idQuad;
    }
    
    
}
