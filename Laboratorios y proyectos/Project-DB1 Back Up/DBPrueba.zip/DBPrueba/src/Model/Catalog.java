/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class Catalog {
    int idCatalog;
    int idNewspaper;
    String description;
    
    public Catalog(){}
    
    public Catalog(int id, int newspaper,String description){
        this.idCatalog = id;
        this.idNewspaper = newspaper;
        this.description = description;
    }

    public int getIdCatalog() {
        return idCatalog;
    }

    public void setIdCatalog(int idCatalog) {
        this.idCatalog = idCatalog;
    }

    public int getIdNewspaper() {
        return idNewspaper;
    }

    public void setIdNewspaper(int idNewspaper) {
        this.idNewspaper = idNewspaper;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
}
