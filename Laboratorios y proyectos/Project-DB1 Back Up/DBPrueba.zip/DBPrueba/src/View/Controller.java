/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package View;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Jeffrey Leiva
 */
public class Controller {
    
    menuPrincipal principal;
    lastNews lastNews;
    Controller () throws SQLException, IOException{
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, IOException, NoSuchAlgorithmException {
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Enter password\n");

        String password = "hola24";  // Read user input 01Imagine1998
        System.out.println();  // Output user input
       
        String encrypted = MD5(password);
        System.out.println(encrypted+"\n");
        String newPass = myObj.nextLine();
        String encryptedNewPass = MD5(newPass);
        System.out.println(encryptedNewPass);
        System.out.println(encryptedNewPass.equals(encrypted));
        
    }
    
    private static String MD5(String password) throws NoSuchAlgorithmException{
        try{
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte []array = md.digest(password.getBytes());
            StringBuffer sb = new StringBuffer();
            for(int i = 0;i<array.length;i++){
                sb.append(Integer.toHexString((array[i] & 0xFF)| 0X100).substring(1,3));
                
            }
            return sb.toString();
        } catch(java.security.NoSuchAlgorithmException e){
            
        }
        return null;
    }
    
}
