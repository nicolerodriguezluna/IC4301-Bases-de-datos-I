CREATE TABLESPACE dbproject_IND
DATAFILE 'C:\BD1\oradata\DNProject\dbprojectind.dbf'
   SIZE 10M
   REUSE
   AUTOEXTEND ON
   NEXT 512k
   MAXSIZE 200M;
