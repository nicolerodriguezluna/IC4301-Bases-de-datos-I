CREATE TABLESPACE dbproject_DATA
DATAFILE 'C:\BD1\oradata\DNProject\dbprojectdata.dbf'
   SIZE 10M
   REUSE
   AUTOEXTEND ON
   NEXT 512k
   MAXSIZE 200M;
   