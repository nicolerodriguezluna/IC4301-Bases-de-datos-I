USE BDPROJECT;

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (119560234,'Melissa', 'Laura', 'Zarate', 'López',DATE '1998-04-15',1,1,'Torre A - Centro Corporativo Internacional, en Barrio don Bosco, avenida 8, calles 26 y 28', 1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (202678512,'Catalina', 'María', 'Santana', 'Hernández',DATE '1986-05-16',2,1, 'cerca del pueblo de Ujarrás a lo largo de la carretera nacional 225 en el curso medio del río Reventazón, en el valle de Ujarrás', 244,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (705689412,'Alejandro', 'Sebastian', 'Fernández', 'Ortiz',DATE '2007-09-13',3,2,'4.8km noroeste de la Iglesia Católica de La Fortuna', 314,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (306872354,'Paula', 'Liliana', 'Perez', 'López',DATE '1998-02-13',4,1,'150 metros sureste de la municipalidad de la Fortuna de San Carlos', 314,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (603154786,'Ariana', 'Vanessa', 'Gonzalez', 'Molina',DATE '2005-11-11',5,1, '50 metros norte del restaurante  El Bambú, Pocora Limón', 471,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (452618723,'Isabel', 'Rosaura', 'Torres', 'Benavides',DATE '1970-02-19',6,1,'1 kilómetro al oeste de la agencia del Banco Nacional, Provincia de Alajuela, San Ramón', 146,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (514896458,'Kenneth', 'Ricardo', 'Ibarra', 'Vargas',DATE '1999-08-17',7,2,'100 metros de la farmacia Value, Provincia de Cartago, Paraíso',131,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (789630412,'Jezabel', 'Hillary', 'Morales', 'Barrera',DATE '2007-10-27',8,1, '200 metros de la bomba La Tica, Barreal Heredia',371,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (402569871,'Luis', 'Roberto', 'Rivera', 'Moaraga',DATE '2002-12-16',9,2,'200 metros este de la municipalidad de Heredia',352,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (118670120,'Jeffrey','Daniel','Leiva','Cascante',DATE '2003-03-21',10,2,'De la universidad nacional campus sarapiquí 100 metros este 100 metros sur de la universidad nacional campus sarapiquí Heredia Horquetas',396,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (119872619,'Esteban','Alfredo','Perez','Caceres',DATE '2000-04-22',11,2,'Calle Rosales, Provincia de Alajuela, Alajuela',236,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (290871627,'Andres','Eduardo','Villalobos','Sandi',DATE '1987-12-31',1,2,'Calles 8, diagonal a la soda Las Delicias, Av 9, Amón, San José', 1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (390812345,'Francisco','Franco','Sanchez','Ruben',DATE '1999-01-12',2,2,'Calle 16, Avenida 13., 1 km Suroeste de la Basílica de los Ángeles., Provincia de Cartago, Cartago',123,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (568909876,'Hilda','Heriberta','Robles','Torres',DATE '1989-09-09',3,1,'500 metros del polideportivo de San Carlos,Provincia de Alajuela, San Carlos',314,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (435678901,'Carlos','Humberto','Flores','Valerio',DATE '1998-07-07',4,2,'250 metros del Multicentro,Av. 4, Limón',79,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (189098762,'James','Kevin','Valverde','Alpizar',DATE '2000-09-01',3,2,'800 metros de la entrada sur de la Ciudad Universitaria Rodrigo Facio Brenes, San José, San Pedro',67,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (198098765,'Pedro','Pablo','Matarrita','Smith', DATE '1996-12-03',6,2,'600 metros de la  Iglesia de Alajuela, Provincia de Alajuela, San Ramón', 250,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (345987654,'Rachell','Maria','Bermudez','Salazar',DATE '1998-03-10',7,1,'100 metros diagonal del Mall Paraíso de Cartago, Paraíso Cartago', 134,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (478985748,'Mariana','Steffany','Orozco','Campos',DATE '2003-05-27',8,1,'1 km al este del Mall Oxigeno', 361,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO person
(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (119845679,'Jeffry', 'Alexander', 'Avilés', 'Figueroa',DATE '1989-06-14',9,2,'1 km al sur de los Tribunales de Justicia de Heredia',352,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');
