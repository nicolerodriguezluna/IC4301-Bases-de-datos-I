INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'San José', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Acosta', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Alajuelita', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Aserrí', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Curridabat', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Desamparados', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Dota', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Escazú', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Goicoechea', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'León Cortés', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Montes de Oca', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Mora', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Moravia', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Pérez Zeledón', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Puriscal', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Santa Ana', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Tarrazú', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Tibás', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Turrubares', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Vázques de Coronado', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2 , 'Alajuela', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2,  'San Ramón', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, 'Grecia', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, 'San Mateo', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2,  'Atenas', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, 'Naranjo', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, 'Palmares', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, 'Poás', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2,  'Orotina', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, 'San Carlos', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2,  'Zarcero', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, 'Sarchí', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, 'Upala', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, 'Los Chiles', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, 'Guatuso', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2, 'Río Cuarto', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3,'Heredia', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3,'Barva', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3,'Belén', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3,'Flores', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3,'San Isidro', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3,'San Pablo', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3,'San Rafael', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3,'Santa Bárbara', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3,'Santo Domingo', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3,'Sarapiquí', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,'Cartago', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,'Paraíso', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,'La Unión', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,'Jimenéz', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,'Turrialba', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,'Alvarado', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,'Oreamuno', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,'El Guarco', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,'Liberia', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,'Nicoya', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,'Santa Cruz', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,'Bagaces', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,'Carrillo', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,'Cañas', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,'Albangares', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,'Tilarán', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,'Nandayure', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,'La Cruz', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,'Hojancha', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Puntarenas', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');
INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Esparza', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Buenos Aires', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Montes de Oro', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Osa', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Quepos', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Golfito', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Coto Brus', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Parrita', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Corredores', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Garabito', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Monteverde', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,'Puerto Jiménez', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area, name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(7, 'Limón', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(7,'Pococí', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(7,'Siquirres', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(7,'Talamanca', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(7,'Matina', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO canton(id_area,  name_canton, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(7,'Guácimo', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');
