DELIMITER //
create  PROCEDURE get_authors()
BEGIN
    SELECT author.id_person,author.id_author_cathegory
    from author;
END; //
DELIMITER ;

DELIMITER //
create PROCEDURE get_articles()
BEGIN
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article;
END; //
DELIMITER ;

DELIMITER //
create procedure get_last_news()
BEGIN
    select b.id_article,b.title_article,b.text_note,b.publication_date,b.id_status_article,b.id_dig_news,b.id_art_cat,b.id_committe_art
    from(select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
         from article
         order by publication_date desc limit 10) as b
    where id_status_article = 1;
END;//
DELIMITER ;

delimiter //
create procedure get_author_byarticle(in pIdArticle int)
BEGIN
    SELECT author.id_person,author.id_author_cathegory
    from author
    inner join person
    on author.id_person = person.id_person
    inner join authorxarticle
    on author.id_person = authorxarticle.id_author_autart
    where authorxarticle.id_article_autart = pIdArticle;
END;//
DELIMITER ;

DELIMITER //
create PROCEDURE get_article_bycategory(IN pIdCategory iNT)
BEGIN
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    where article.id_art_cat = pIdCategory and id_status_article=1;
END; //
DELIMITER ;

delimiter //
create PROCEDURE get_article_bycategory_admin(in pIdCategory int)
BEGIN
    select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    where article.id_art_cat = pIdCategory;
END;//
delimiter ;


DELIMITER //
create PROCEDURE get_author_bycategory(IN pIdCategory int)
BEGIN
    SELECT author.id_person,id_author_cathegory
    from author
    inner join person
    on person.id_person = author.id_person
    where id_author_cathegory = pIdCategory;
END;//
delimiter ;

delimiter //
create  PROCEDURE get_newspapers_byCollege(in pidCollege int)
BEGIN
    SELECT digitalnewspaper.id_digital_newspaper,digitalnewspaper.name_digital_newspaper,digitalnewspaper.id_quad
    from digitalnewspaper
    inner join campus
    on campus.id_campus = digitalnewspaper.id_quad
    inner join college
    on campus.id_university = college.id_college
    where college.id_college = pidCollege;
END; //
DELIMITER ;

DELIMITER //
create PROCEDURE get_newspapers_byQuad(in pidQuad int)
BEGIN
    SELECT digitalnewspaper.id_digital_newspaper,digitalnewspaper.name_digital_newspaper,digitalnewspaper.id_quad
    from digitalnewspaper
    inner join campus
    on campus.id_campus = digitalnewspaper.id_quad
    where digitalnewspaper.id_quad = pidQuad;
END; //
delimiter ;

DELIMITER //
create  PROCEDURE get_district_byarea(in pidCanton int)
BEGIN
    SELECT id_district,name_district,id_sector
    from district
    where id_sector = pidCanton;
END;//
DELIMITER ;

DELIMITER //
create PROCEDURE get_most_viewed()
BEGIN 
    SELECT b.id_article,b.title_article,b.text_note,b.publication_date,b.id_status_article,b.id_dig_news,b.id_art_cat,b.id_committe_art
    from (SELECT count(id_article_rev) as total,id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
          from article 
          inner join review
          on article.id_article = review.id_article_rev 
          group by id_article, title_article, text_note, publication_date, id_status_article,id_dig_news, id_art_cat, id_committe_art
          Order by total desc limit 10) as b
    where id_status_article = 1;
END;//
delimiter ;

DELIMITER //
create FUNCTION get_author_current_points(idAuthor INT) returns integer
BEGIN
	DECLARE currentPoints INT;
    Select a.total-b.exchanged
    into currentPoints
    from (Select sum(stars) as total
          from review
          inner join article
          on review.id_article_rev = article.id_article
          inner join authorxarticle
          on authorxarticle.id_article_autart = article.id_article
          where authorxarticle.id_author_autart = idAuthor)as a,
          (SELECT COALESCE(sum(cost_product),0) as exchanged
           from product
           inner join productxauthor
           on productxauthor.id_product_pa = product.id_product
           where productxauthor.id_author_pa = idAuthor) as b;
   return (currentPoints);
END;//
DELIMITER ;



DELIMITER //
create FUNCTION get_author_spent_points(idAuthor INT) returns integer
BEGIN
declare spentPoints INT;
SELECT COALESCE(sum(cost_product),0)
into spentPoints
from product
inner join productxauthor
on productxauthor.id_product_pa = product.id_product
where productxauthor.id_author_pa = idAuthor;
return (spentPoints);
END;//
delimiter ;

DELIMITER //
create PROCEDURE get_user_person(IN pidUser INT)
begin
select b.id_person,b.first_name,b.second_name,b.first_surname,b.second_surname,b.identification_card,b.datebirth,b.id_quad,b.id_gender,b.exact_location,b.id_district
from(select person.id_person,first_name,second_name,first_surname,second_surname,identification_card,datebirth,id_quad,id_gender,exact_location,id_district
    from person
    inner join userdb
    on person.id_person = userdb.id_person
    where userdb.id_user = pidUser) AS b
LIMIT 1;
END;//
DELIMITER ;

delimiter //
create PROCEDURE get_avg_review()
  BEGIN
    SELECT CAST(AVG(stars) AS DECIMAL(10,2)) as average_stars,CONCAT(first_name,' ',second_name,' ',first_surname,' ',second_surname) as complete_name 
    from review
    inner join authorxarticle
    On authorxarticle.id_article_autart = review.id_article_rev
    inner join person
    ON authorxarticle.id_author_autart = person.id_person
    group by CONCAT(first_name,' ',second_name,' ',first_surname,' ',second_surname)
    ORDER BY average_stars;
 END;//
 DELIMITER ;
 
 delimiter //
 create PROCEDURE get_topn_authors_category(in pTopn int,in pidCategory int)
BEGIN
    Select b.count_articles,b.full_name
    from (select count(id_article_autart) as count_articles,CONCAT(first_name,' ',second_name,' ',first_surname,' ',second_surname) as full_name
          from authorxarticle
          inner join person
          on person.id_person = authorxarticle.id_author_autart
          inner join article
          on article.id_article = authorxarticle.id_article_autart
          where article.id_art_cat = pidCategory
          group by(CONCAT(first_name,' ',second_name,' ',first_surname,' ',second_surname))
          order by count_articles desc) as b
    Limit pTopn;
END;//
DELIMITER ;

DELIMITER //
create PROCEDURE get_topn_authors_college(in pTopn int,in pidCollege int)
BEGIN
    Select b.count_articles,b.full_name
    from (select count(id_article_autart) as count_articles,CONCAT(first_name,' ',second_name,' ',first_surname,' ',second_surname) as full_name
          from authorxarticle
          inner join person
          on person.id_person = authorxarticle.id_author_autart
          inner join campus
          on person.id_quad = campus.id_campus
          inner join college
          on campus.id_university = college.id_college
          where college.id_college = pidCollege) as b
	ORDER BY b.count_articles DESC
    LIMIT pTopn;
END;//
DELIMITER ;

CALL get_topn_authors_college(4,3);

DELIMITER //
create PROCEDURE get_topn_authors_gender(in pTopn int ,in pidGender int)
BEGIN
    Select b.count_articles,b.full_name
    from (select count(id_article_autart) as count_articles,CONCAT(first_name,' ',second_name,' ',first_surname,' ',second_surname) as full_name
          from authorxarticle
          inner join person
          on person.id_person = authorxarticle.id_author_autart
          inner join gender
          on person.id_gender = gender.id_gender
          where person.id_gender = pidGender) as b
	order by b.count_articles desc
    limit pTopn;
END;//
DELIMITER ;

DELIMITER //
create PROCEDURE get_author_articles()
  BEGIN
     SELECT COUNT(id_article_autart) as totalArticle,CONCAT(first_name,' ',second_name,' ',first_surname,' ',second_surname) as complete_name
     from authorxarticle
     inner join author
     On author.id_person = authorxarticle.id_author_autart
     inner join person
     on author.id_person = person.id_person 
     where author.id_person = authorxarticle.id_author_autart
     group by CONCAT(first_name,' ',second_name,' ',first_surname,' ',second_surname)
     ORDER BY (totalArticle) DESC;
  END;//
  DELIMITER ;

DELIMITER //
create PROCEDURE get_authors_byage_gender(in pidGender int)
    BEGIN
    SELECT '0-18' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth)) BETWEEN 0 AND 18 and person.id_gender = pidGender
    UNION ALL
    SELECT '19-30' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth)) BETWEEN 19 AND 30 and person.id_gender = pidGender
    UNION ALL
     SELECT '31-45' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth)) BETWEEN 31 AND 45 and person.id_gender = pidGender
    UNION ALL
     SELECT '45-60' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth)) BETWEEN 45 AND 60 and person.id_gender = pidGender
    UNION ALL
     SELECT '61-75' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth)) BETWEEN 61 AND 75 and person.id_gender = pidGender
    UNION ALL
    SELECT '75-' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth))>75 and person.id_gender = pidGender;
END;//
DELIMITER ;

DELIMITER //
create PROCEDURE get_authors_byage_college(IN pidCollege INT)
    BEGIN
    SELECT '0-18' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (YEAR(sysdate()) - YEAR(person.datebirth)) BETWEEN 0 AND 18 and college.id_college = pidCollege
    UNION
    SELECT '19-30' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (YEAR(sysdate()) - YEAR(person.datebirth)) BETWEEN 19 AND 30 and college.id_college = pidCollege
    UNION
    SELECT '31-45' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (YEAR(sysdate()) - YEAR(person.datebirth)) BETWEEN 31 AND 45 and college.id_college = pidCollege
    UNION
     SELECT '45-60' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (YEAR(sysdate()) - YEAR(person.datebirth)) BETWEEN 45 AND 60 and college.id_college = pidCollege
    UNION
     SELECT '61-75' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (YEAR(sysdate()) - YEAR(person.datebirth)) BETWEEN 61 AND 75 and college.id_college = pidCollege
    UNION
    SELECT '75-' as rangeAgeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    inner join campus
    on person.id_quad = campus.id_campus
    inner join college
    on campus.id_university = college.id_college
    where (YEAR(sysdate()) - YEAR(person.datebirth))>75 and college.id_college = pidCollege;
END;//
DELIMITER ;

DELIMITER //
create PROCEDURE get_authors_byage_type(IN pidType inT)
    BEGIN
    SELECT '0-18' as rangeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth))BETWEEN 0 AND 18 and author.id_author_cathegory = pidType
    UNION
    SELECT '19-30' as rangeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth))BETWEEN 19 AND 30 and author.id_author_cathegory = pidType
    UNION
    SELECT '31-45' as rangeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth))BETWEEN 31 AND 45 and author.id_author_cathegory = pidType
    UNION
    SELECT '45-60' as rangeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth))BETWEEN 45 AND 60 and author.id_author_cathegory = pidType
    UNION
    SELECT '61-75' as rangeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth))BETWEEN 61 AND 75 and author.id_author_cathegory = pidType
    UNION
    SELECT '75-' as rangeAge,count(1) as count
    from author
    inner join person
    on author.id_person = person.id_person
    where (YEAR(sysdate()) - YEAR(person.datebirth))>75 and author.id_author_cathegory = pidType;
END;//
DELIMITER ;


DELIMITER //
create PROCEDURE top_purchased_products()
BEGIN
    SELECT b.description_product,b.cost_product,b.total_count
    from (SELECT description_product,cost_product,count(id_product_pa) as total_count from product
          inner join productxauthor
          on productxauthor.id_product_pa = product.id_product 
          group by description_product, cost_product
          order by total_count desc) AS b
    LIMIT 10;
END; //
DELIMITER ;

CALL top_purchased_products();
CALL get_authors_byage_type(4);

select * from photo;

select * from administrator