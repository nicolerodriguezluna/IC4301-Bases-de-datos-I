DELIMITER //
CREATE PROCEDURE insert_administrative(IN pidPerson INT, IN pIdDedication INT)
BEGIN 
    insert into administrative(id_person,id_dedication,creationdate,userid,ltmodifydate,ltmodifyby)
    values (pidPerson,pIdDedication,NULL, NULL, NULL, NULL);
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE insert_administrator(in pidPerson INT,in pvPsword VARCHAR(100))
BEGIN 
    insert into administrator(id_person,psword_admin,creationdate,userid,ltmodifydate,ltmodifyby)
    values (pidPerson,pvPsword,NULL, NULL, NULL, NULL);
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE insert_article(in pvTitle VARCHAR(1000),in pvText VARCHAR(4000),in pvPublication DATE,in pidStatus INT,
in pidNewspaper INT,in pidArticlecategory INT,in pidcommitte INT)
BEGIN
    insert into article(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art,
    creationdate,userid,ltmodifydate,ltmodifyby)
    VALUES (pvTitle,pvText,pvPublication,pidStatus,pidNewspaper,pidArticlecategory,pidcommitte,
    NULL, NULL, NULL, NULL);
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE insert_article_category(in pvNameCategory VARCHAR(30),in pvDescription VARCHAR(1000))
BEGIN
    insert into articlecategory(name_category,description_category,creationdate,userid,ltmodifydate,ltmodifyby)
    VALUES(pvNameCategory,pvDescription,NULL,NULL,NULL,NULL);
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE insert_author(in pidPerson INT, in pidAuthorCategory INT) 
BEGIN
    insert into author(id_person,id_author_cathegory,creationdate,userid,ltmodifydate,ltmodifyby)
    VALUES (pidPerson,pidAuthorCategory,NULL,NULL,NULL,NULL);
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE insert_author_category(in pvTypeCategory VARCHAR(30)) 
BEGIN
INSERT INTO AUTHORCATEGORY(type_category,creationdate,userid,ltmodifydate,ltmodifyby)
VALUES(pvTypeCategory,NULL,NULL,NULL,NULL);
COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE insert_authorxarticle(in pnidAuthor INT,in pnidArticle INT)
BEGIN
INSERT INTO authorxarticle(id_author_autart,id_article_autart,creationdate,userid,ltmodifydate,ltmodifyby)
VALUES (pnidAuthor,pnidArticle,NULL,NULL,NULL,NULL);
COMMIT;
END;//
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE insert_availability (in pvdescription VARCHAR(100))
BEGIN
INSERT INTO availabilitypr (description_availability,creationdate,userid,ltmodifydate,ltmodifyby)
VALUES(pvdescription,NULL,NULL,NULL,NULL);
COMMIT;
END;//
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE insert_campus(IN pvName VARCHAR(100),IN pidCollege INT,IN pidDistrict INT)
BEGIN
INSERT INTO campus(name_campus,id_university,id_district,creationdate,userid,ltmodifydate,ltmodifyby)
VALUES(pvName,pidCollege,pidDistrict,NULL,NULL,NULL,NULL);
COMMIT;
END ; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE insert_canton(IN pvName VARCHAR(100),IN pidArea INT)
BEGIN
INSERT INTO canton(name_canton,id_area,creationdate,userid,ltmodifydate,ltmodifyby)
VALUES(pvName,pidArea,NULL,NULL,NULL,NULL);
COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE insert_catalog (IN pidNewspaper INT,IN pvDescription VARCHAR(1000))
BEGIN
INSERT INTO catalog(id_newspaper,description_catalog,creationdate,userid,ltmodifydate,ltmodifyby)
VALUES(pidNewspaper,pvDescription,NULL,NULL,NULL,NULL);
COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE insert_college(IN pvName VARCHAR(100))
BEGIN
INSERT INTO college(name_college,creationdate,userid,ltmodifydate,ltmodifyby)
VALUES (pvName,NULL,NULL,NULL,NULL);
COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_administrative(IN pidDedication INT,IN pidPerson INT)
BEGIN
    update administrative
    set id_dedication = pidDedication
    where pidPerson = administrative.id_person;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_administrator(IN pidPerson INT,IN pvnewPs INT)
BEGIN
    update administrator
    set psword_admin = pvnewPs
    where administrator.id_person = pidPerson;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_article_title(IN pvTitle VARCHAR(1000),IN pidArticle INT)
BEGIN
    update article
    set title_article = pvTitle
    where article.id_article = pidArticle;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_article_note(in pvText VARCHAR(4000),in pidarticle INT)
BEGIN
    update article
    set text_note = pvText
    where article.id_article = pidarticle;
    COMMIT;
END; //
delimiter ;

DELIMITER //
CREATE  PROCEDURE update_article_date(in pvDate DATE,IN pidarticle  INT)
BEGIN
    update article
    set publication_date = pvDate
    where article.id_article = pidarticle;
    COMMIT;
END; //
DELIMITER ;

delimiter //
CREATE  PROCEDURE update_article_status(in pnewStatus INT,in pidarticle INT)
BEGIN
    update article
    set article.id_status_article = pnewStatus
    where article.id_article = pidarticle;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_article_newspaper(IN pNewNewspaper INT,IN pidarticle INT)
BEGIN
    update article
    set article.id_dig_news = pNewNewspaper
    where article.id_article = pidarticle;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_article_category(IN pnewCategory INT,IN pidarticle INT)
BEGIN
    update article
    set article.id_art_cat = pnewCategory
    where article.id_article = pidarticle;
    COMMIT;
END;//
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_article_committe(IN pnewCommitte INT,IN pidarticle INT)
begin
    update article
    set article.id_committe_art = pnewCommitte
    where article.id_article = pidarticle;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_article_category_name(IN pcName VARCHAR(30),IN pidcategory INT)
BEGIN
    update articlecategory
    set name_category = pcName
    where articlecategory.id_article_category = pidcategory;
    COMMIT;
END;//
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_article_cat_descrp(IN pcDescription VARCHAR(1000),IN pidcategory INT)
begin
    update articlecategory
    set articlecategory.description_category = pcDescription
    where articlecategory.id_article_category = pidcategory;
    COMMIT;
END;//
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_author_category(IN pnewCategory INT, IN pidperson INT)
begin
    update author
    set author.id_author_cathegory = pnewCategory
    where author.id_person = pidperson;
    COMMIT;
END;//
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_authorcategory_type(in pnewType VARCHAR(30),in pidauthorcategory INT)
begin
    update authorcategory
    set authorcategory.type_category = pnewType
    where authorcategory.id_author_category = pidauthorcategory;
    COMMIT;
END;//
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_availabilitypr_descrp(in pnewDescription VARCHAR(100),in pidAvailability INT)

BEGIN
    update availabilitypr
    set availabilitypr.description_availability = pnewDescription
    where availabilitypr.id_availability = pidAvailability;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_campus_name(IN pName VARCHAR(100),in pidcampus INT)
BEGIN
    update campus
    set campus.name_campus = pName
    where campus.id_campus = pidcampus;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_campus_university(IN pnewUniversity  INT,IN pidcampus  INT)
BEGIN
    update campus
    set campus.id_university = pnewUniversity
    where campus.id_campus = pidcampus;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_campus_district(IN pnewDistrict INT,IN pidcampus INT)
BEGIN
    update campus
    set campus.id_district = pnewDistrict
    where campus.id_campus = pidcampus;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_canton_name(IN pnewName VARCHAR(100),IN pidcanton INT)

begin
    update canton
    set name_canton = pnewName
    where canton.id_canton = pidcanton;
    COMMIT;
END;//
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_canton_area(IN pnewarea INT,IN pidcanton INT)
begin
    update canton
    set canton.id_area = pnewarea
    where canton.id_canton = pidcanton;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_catalog_newspaper(IN pnewPaper INT,IN pidcatalog INT)
begin
    update catalog
    set catalog.id_newspaper = pnewPaper
    where catalog.id_catalog = pidcatalog;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_catalog_description(IN pnewDescription VARCHAR(1000),in pidcatalog INT)
begin
    update catalog
    set catalog.description_catalog = pnewDescription
    where catalog.id_catalog = pidcatalog;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE update_college_name(IN pnewName VARCHAR(100),IN pidcollege INT)
BEGIN
    update college 
    set college.name_college = pnewName
    where college.id_college = pidcollege;
    COMMIT;
END; //
DELIMITER ;



-- DELETES
DELIMITER //
CREATE  PROCEDURE delete_administrative(IN pidadministrative INT)
begin
    delete from administrative
    where administrative.id_person = pidadministrative;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_administrator(IN pidadministrator INT)
begin
    delete from administrator
    where administrator.id_person = pidadministrator;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_article(IN pidarticle INT)
BEGIN
    delete from article
    where article.id_article = pidarticle;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_articlecategory(IN pidarticlecategory INT)
begin
    delete from articlecategory
    where articlecategory.id_article_category = pidarticlecategory;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_author(IN pidauthor INT)
begin
    delete from author
    where author.id_person = pidauthor;
    commit;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_author_category(IN pidAuthorcategory INT)
begin
    delete from authorcategory
    where authorcategory.id_author_category = pidAuthorcategory;
    commit;
end; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_authorxarticle_author(IN pidauthor INT)
begin
    delete from authorxarticle
    where authorxarticle.id_author_autart = pidauthor;
    commit;
end; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_authorxarticle_article(IN pidarticle INT)
begin
    delete from authorxarticle
    where authorxarticle.id_article_autart = pidarticle;
    commit;
end; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_availability(IN pidavailability INT)
begin
    delete from availabilitypr
    where availabilitypr.id_availability = pidavailability;
    commit;
end; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_campus(IN idcampus INT)
begin
 delete from campus
 where campus.id_campus = idcampus;
 commit;
enD; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_canton(IN pidcanton INT)
begin
    delete from canton
    where canton.id_canton = pidcanton;
    commit;
end; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_catalog(IN pidcatalog INT)
begin
    delete from catalog
    where catalog.id_catalog = pidcatalog;
    commit;
enD;//
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_college(IN pidcollege INT)
begin
    delete from college
    where college.id_college = pidcollege;
    commit;
end; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_committee(IN pidCommittee INT) 
BEGIN
    DELETE FROM committe
    WHERE committe.id_committe = pidCommittee;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_country(IN pidCountry INT) 
BEGIN
    DELETE FROM country
    WHERE country.id_country = pidCountry;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_dedication(IN pidDedication INT) 
BEGIN
    DELETE FROM dedication
    WHERE dedication.id_dedication = pidDedication;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_digital_newspaper(IN pidDigitalNewspaper INT) 
BEGIN
    DELETE FROM digitalnewspaper
    WHERE digitalnewspaper.id_digital_newspaper = pidDigitalNewspaper;
    COMMIT;
END; // 
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_district(IN pidDistrict INT) 
BEGIN
    DELETE FROM district
    WHERE district.id_district = pidDistrict;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_email(IN pidEmail INT) 
BEGIN
    DELETE FROM email
    WHERE email.id_email = pidEmail;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_favourite(IN pidArtRev  INT, IN pidUserRev INT) 
BEGIN
    DELETE FROM favourite
    WHERE favourite.id_user_fav = pidUserRev OR favourite.id_article_fav = pidArtRev;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_gender(IN pidGender  INT) 
BEGIN
    DELETE FROM gender
    WHERE gender.id_gender = pidGender;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_logDB(IN pidLogDB INT) 
BEGIN
    DELETE FROM logDB
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_neighbour(IN pidNeighbour INT) 
BEGIN
    DELETE FROM neighbour
    WHERE neighbour.id_person = pidNeighbour;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_parameterDb(IN pidParameterDb INT) 
BEGIN
    DELETE FROM parameterDB
    WHERE parameterDb.id_parameter = pidParameterDb;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_person(IN pidPerson INT) 
BEGIN
    DELETE FROM person
    WHERE person.id_person = pidPerson;
    COMMIT;
END; //
DELIMITER ;


-- 1
delimiter //
create  PROCEDURE insert_committe(IN pnIdCampus  INT,IN  pcNameCommittee VARCHAR(100)) 
BEGIN
    INSERT INTO committe(id_committe, description_committe, creationDate, userid, ltModifyDate, ltModifyBy,id_campus)
    VALUES(s_committe.nextval, pcNameCommittee, NULL, NULL, NULL, NULL,pnIdCampus);
    COMMIT;
END; //
DELIMITER ;

-- 2
DELIMITER //
create  PROCEDURE insert_country(IN pnameCountry VARCHAR(60)) 
BEGIN
    INSERT INTO country(id_country, name_country, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_country.nextval, pnameCountry, NULL, NULL, NULL, NULL);
    COMMIT;
END; //
DELIMITER ;

-- 3
DELIMITER //
CREATE  PROCEDURE insert_dedication(IN pdescriptionDedication VARCHAR(30)) 
BEGIN
    INSERT INTO dedication(id_dedication, description_dedication, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_dedication.nextval, pdescriptionDedication, NULL, NULL, NULL, NULL);
    COMMIT;
END; //
DELIMITER ;

-- 4
DELIMITER //
CREATE  PROCEDURE insert_digital_newspaper(IN pname_digital_newspaper VARCHAR(30),IN pidQuad INT) 
BEGIN
    INSERT INTO digitalNewspaper(id_digital_newspaper, name_digital_newspaper, id_quad,creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_digitalNewspaper.nextval, pname_digital_newspaper, pidQuad, NULL, NULL, NULL, NULL);
    COMMIT;
END; //
DELIMITER ;

-- 5
DELIMITER //
CREATE  PROCEDURE insert_district(IN pnameDistrict VARCHAR(100), IN pidSector INT) 
BEGIN
    INSERT INTO district(id_district, name_district, id_sector, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_district.nextval, pnameDistrict, pidSector ,NULL, NULL, NULL, NULL);
    COMMIT;
END; //
DELIMITER ;

-- 6
DELIMITER //
CREATE  PROCEDURE insert_email(IN pAdressEmail VARCHAR(100), IN pidPerson  INT) 
BEGIN
    INSERT INTO email(id_email, address_email, id_person_mail, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_email.nextval, pAdressEmail, pidPerson, NULL, NULL, NULL, NULL);
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
create PROCEDURE delete_authorxproduct_author(in pidAuthor INT)
BEGIN
    DELETE from productxauthor
    where id_author_pa = pidAuthor;
    commit;
END; //
DELIMITER ;
 
-- 7
CREATE  PROCEDURE insert_favourite(pidArticleFav IN INT, pidUserFav IN INT, pDateFavourite IN VARCHAR) 
BEGIN
    INSERT INTO favourite(id_article_fav,id_user_fav,date_favourite, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(pidArticleFav, pidUserFav, pDateFavourite, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_favourite; 
--8
CREATE  PROCEDURE insert_gender(pTypeGender IN VARCHAR) 
BEGIN
    INSERT INTO gender(id_gender, type_gender,creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_gender.nextval, pTypeGender,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_gender; 
--9
CREATE  PROCEDURE insert_logDB(pChangeDescription in VARCHAR, pPreviousText in VARCHAR, pCurrentText in VARCHAR) 
BEGIN
    INSERT INTO logdb(id_log,systemdate, time_log, change_descrp, previous_text,current_text,creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_log.nextval, SYSDATE, CURRENT_TIMESTAMP, pChangeDescription, pPreviousText, pCurrentText,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_logDB; 
--10
CREATE  PROCEDURE insert_neighbour(pidPerson IN INT) 
BEGIN
    INSERT INTO neighbour(id_person,creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(pidPerson,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_neighbour; 
--11
CREATE  PROCEDURE insert_ParameterDb(pnameParameter IN VARCHAR,pdescriptionParameter IN VARCHAR,pvalueParameter IN INT, proute IN VARCHAR) 
BEGIN
    INSERT INTO ParameterDb(id_Parameter,name_parameter, description_parameter, value_parameter, route,creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_parameter.nextval, pnameParameter, pdescriptionParameter, pvalueParameter, proute, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_ParameterDb; 
--12
CREATE  PROCEDURE insert_person(pidentifyCard IN INT, pfirstName IN VARCHAR,psecondName IN VARCHAR, pfirstSurname IN VARCHAR, psecondSurname IN VARCHAR, pdatebirth IN VARCHAR, pidQuad IN INT, pidGender IN INT, pexactLocalitation in VARCHAR, pidDistrict in INT) 
BEGIN
    INSERT INTO person(id_person,identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, ltModifyDate, ltModifyBy)
    VALUES(s_person.nextval, pidentifyCard, pfirstName,psecondName, pfirstSurname, psecondSurname, pdatebirth, pidQuad, pidGender, pexactLocalitation, pidDistrict, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_person; 

CREATE  PROCEDURE update_committee_description(pidCommittee IN INT, pNewDescriptionCommittee IN VARCHAR) 
BEGIN
    UPDATE committe
    SET committe.description_committe = pNewDescriptionCommittee
    WHERE committe.id_committe= pidCommittee;
    COMMIT;
END update_committee_description;

create  PROCEDURE update_country_name(pidCountry IN INT, pNewNameCountry IN VARCHAR) 
BEGIN
    UPDATE country
    SET country.name_country = pNewNameCountry
    WHERE country.id_country = pidCountry;
    COMMIT;
END update_country_name;

CREATE  PROCEDURE update_dedication_description(pidDedication  IN INT, pNewDescriptionDadication IN VARCHAR) 
BEGIN
    UPDATE dedication
    SET dedication.description_dedication = pNewDescriptionDadication
    WHERE dedication.id_dedication = pidDedication;
    COMMIT;
END update_dedication_description;

CREATE  PROCEDURE update_digitalNewspaper_name(pidDigitalNewspaper IN INT, pNewNameDigital IN VARCHAR) 
BEGIN
    UPDATE digitalnewspaper
    SET digitalnewspaper.name_digital_newspaper = pNewNameDigital
    WHERE digitalnewspaper.id_digital_newspaper = pidDigitalNewspaper;
    COMMIT;
END update_digitalNewspaper_name;

CREATE  PROCEDURE update_digitalNewspaper_quad(pidDigitalNewspaper IN INT, pNewIdQuad IN INT) 
BEGIN
    UPDATE digitalnewspaper
    SET digitalnewspaper.id_quad = pNewIdQuad
    WHERE digitalnewspaper.id_digital_newspaper = pidDigitalNewspaper;
    COMMIT;
END update_digitalNewspaper_quad;


CREATE  PROCEDURE update_district_name(pidDistrict IN INT, pNewNameDistrict IN VARCHAR) 
BEGIN
    UPDATE district
    SET district.name_district = pNewNameDistrict
    WHERE district.id_district = pidDistrict;
    COMMIT;
END update_district_name;

CREATE  PROCEDURE update_district_sector(pidDistrict IN INT, pNewIdSector IN INT) 
BEGIN
    UPDATE district
    SET district.id_sector = pNewIdSector
    WHERE district.id_sector = pidDistrict;
    COMMIT;
END update_district_name;


CREATE  PROCEDURE update_email_address(pidEmail IN INT, pNewAddress IN VARCHAR) 
BEGIN
    UPDATE email
    SET email.address_email = pNewAddress
    WHERE email.id_email = pidEmail;
    COMMIT;
END update_email_address;

CREATE  PROCEDURE update_favourite_date_favourite(pidArtRev IN INT, pidUserRev IN INT, pNewDateFavourite IN VARCHAR) 
BEGIN
    UPDATE favourite
    SET favourite.date_favourite = STR_TO_DATE(pNewDateFavourite,'YY-MM-DD')
    WHERE favourite.id_user_fav = pidUserRev AND favourite.id_article_fav = pidArtRev;
    COMMIT;
END update_favourite_date_favourite;

CREATE  PROCEDURE update_gender_type_gender(pidGender IN INT, pNewTypeGender IN VARCHAR) 
BEGIN
    UPDATE gender
    SET gender.type_gender = pNewTypeGender
    WHERE gender.id_gender = pidGender;
    COMMIT;
END update_gender_type_gender;

CREATE  PROCEDURE update_logDB_change_descp(pidLogDB IN INT, pNewChangeDescription IN VARCHAR) 
BEGIN
    UPDATE logDB
    SET logDB.change_descrp = pNewChangeDescription
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END update_logDB_change_descp;

CREATE  PROCEDURE update_logDB_previous_text(pidLogDB IN INT, pNewPreviousText IN VARCHAR) 
BEGIN
    UPDATE logDB
    SET logDB.previous_text = pNewPreviousText
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END update_logDB_previous_text;

CREATE  PROCEDURE update_logDB_current_text(pidLogDB IN INT, pNewCurrentText IN VARCHAR) 
BEGIN
    UPDATE logDB
    SET logDB.current_text = pNewCurrentText
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END update_logDB_current_text;

CREATE  PROCEDURE update_parameter_name(pidParameter IN INT, pNewNameParameter IN VARCHAR) 
BEGIN
    UPDATE parameterDB
    SET parameterDB.name_parameter = pNewNameParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_name;

CREATE  PROCEDURE update_parameter_description(pidParameter IN INT, pNewDescriptionParameter IN VARCHAR) 
BEGIN
    UPDATE parameterDB
    SET parameterDB.description_parameter = pNewDescriptionParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_description;

CREATE  PROCEDURE update_parameter_value(pidParameter IN INT, pNewValueParameter IN INT) 
BEGIN
    UPDATE parameterDB
    SET parameterDB.value_parameter = pNewValueParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_value;

CREATE  PROCEDURE update_parameter_route(pidParameter IN INT, pNewRoute IN VARCHAR) 
BEGIN
    UPDATE parameterDB
    SET parameterDB.route = pNewRoute
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END update_parameter_route;


CREATE  PROCEDURE update_person_identitycard(pidPerson IN INT, pNewIdentificationCard IN INT) 
BEGIN
    UPDATE person
    SET person.identification_card = pNewIdentificationCard
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_identitycard;


CREATE  PROCEDURE update_person_first_name(pidPerson IN INT, pNewFirstName IN VARCHAR) 
BEGIN
    UPDATE person
    SET person.first_name = pNewFirstName
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_first_name;

CREATE  PROCEDURE update_person_second_name(pidPerson IN INT, pNewSecondName IN VARCHAR) 
BEGIN
    UPDATE person
    SET person.second_name  = pNewSecondName
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_second_name;

CREATE  PROCEDURE update_person_first_surname(pidPerson IN INT, pNewFirstSurname IN VARCHAR) 
BEGIN
    UPDATE person
    SET person.first_surname = pNewFirstSurname
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_first_surname;


CREATE  PROCEDURE update_person_second_surname(pidPerson IN INT, pNewSecondSurname IN VARCHAR) 
BEGIN
    UPDATE person
    SET person.second_surname = pNewSecondSurname
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_second_surname;

CREATE  PROCEDURE update_person_datebirth(pidPerson IN INT, pNewDatebirth IN VARCHAR) 
BEGIN
    UPDATE person
    SET person.datebirth = STR_TO_DATE(pNewDatebirth,'YY-MM-DD')
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_datebirth;


CREATE  PROCEDURE update_person_quad(pidPerson IN INT, pNewIdQuad IN INT) 
BEGIN
    UPDATE person
    SET person.id_quad = pNewIdQuad
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_quad;

CREATE  PROCEDURE update_person_gender(pidPerson IN INT, pNewIdGender IN INT) 
BEGIN
    UPDATE person
    SET person.id_gender = pNewIdGender
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_gender;

CREATE  PROCEDURE update_person_localitation(pidPerson IN INT, pNewExactLocalitation IN VARCHAR) 
BEGIN
    UPDATE person
    SET person.exact_location = pNewExactLocalitation
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_localitation;

CREATE  PROCEDURE update_person_district(pidPerson IN INT, pNewIdDistrict IN INT) 
BEGIN
    UPDATE person
    SET person.id_district = pNewIdDistrict
    WHERE person.id_person = pidPerson;
    COMMIT;
END update_person_district;

create  PROCEDURE insert_user(pUserName in VARCHAR,pPsUser IN VARCHAR, pidPerson IN INT) 
BEGIN
    INSERT INTO userdb(id_User, psword_user, id_person, creationDate, userid, ltModifyDate, ltModifyBy,user_name)
    VALUES(s_user.nextval, pPsUser, pidPerson, NULL, NULL, NULL, NULL,pUserName);
    COMMIT;
END insert_user;

create  PROCEDURE insert_student(pidPerson IN INT, pstudentCard IN INT) 
BEGIN
    INSERT INTO student(id_person, student_card, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(pidPerson, pstudentCard, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_student;

CREATE  PROCEDURE insert_status(pnameStatus VARCHAR) 
BEGIN
    INSERT INTO status(id_status, name_status, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_status.nextval, pnameStatus, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_status;

CREATE  PROCEDURE insert_review(pdescription IN VARCHAR, pid_article_rev IN INT, pid_user_rev IN INT) 
BEGIN
    INSERT INTO review(description_review, id_article_rev, id_user_rev,creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(pdescription, pid_article_rev, pid_user_rev, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_review;

CREATE  PROCEDURE insert_province(pname IN VARCHAR, pidNation IN INT) 
BEGIN
    INSERT INTO province(id_province, name_province, id_nation, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_province.nextval, pname, pidNation ,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_province; 

CREATE  PROCEDURE insert_professor(pidDedication IN INT, pidPerson IN INT) 
BEGIN
    INSERT INTO professor(id_dedication, id_person, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(pidDedication, pidPerson,NULL, NULL, NULL, NULL);
    COMMIT;
END insert_professor; 

CREATE  PROCEDURE insert_productxauthor(pidProPa IN INT, pidAutPa IN INT) 
BEGIN
    INSERT INTO productxauthor(id_product_pa, id_author_pa, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(pidProPa, pidAutPa, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_productxauthor; 

CREATE  PROCEDURE insert_product(pCost IN INT, pdescription IN VARCHAR, 
pidCatalog IN INT, pidAvailability IN INT) 
BEGIN
    INSERT INTO product(id_product, cost_product, description_product, id_catalog_pr, id_availability,creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_product.nextval, pcost, pdescription, pidcatalog, pidavailability, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_product; 

CREATE  PROCEDURE insert_photo_article(proute IN VARCHAR,pidArticle IN INT) 
BEGIN
    INSERT INTO photo(id_photo,route, id_article, id_user, id_product,creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_photo.nextval, proute, pidArticle, NULL, NULL, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_photo_article; 

CREATE  PROCEDURE insert_photo_user(proute IN VARCHAR,pidUser IN INT) 
BEGIN
    INSERT INTO photo(id_photo,route, id_article, id_user, id_product,creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_photo.nextval, proute, NULL, pidUser, NULL, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_photo_user; 

CREATE  PROCEDURE insert_photo_product(proute IN VARCHAR,pidProduct IN INT) 
BEGIN
    INSERT INTO photo(id_photo,route, id_article, id_user, id_product,creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_photo.nextval, proute, NULL, NULL, pidProduct, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_photo_product; 

CREATE  PROCEDURE insert_phoneCategory(pdescription IN VARCHAR) 
BEGIN
    INSERT INTO phoneCategory(id_category, description_category,creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_phcategory.nextval, pdescription, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_phoneCategory; 

CREATE  PROCEDURE insert_phone(pINT IN INT, pidPerson IN INT, pidPhoneCategory IN INT) 
BEGIN
    INSERT INTO phone(id_phone, INT_phone, id_person, id_phone_category, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(s_phone.nextval, pINT, pidPerson, pidPhoneCategory, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_phone; 

create  PROCEDURE insert_personxcommitte(pidPerson IN INT, pidCommitte IN INT) 
BEGIN
    INSERT INTO personxcommitte(id_committe, id_person, creationDate, userid, ltModifyDate, ltModifyBy)
    VALUES(pidCommitte, pidPerson, NULL, NULL, NULL, NULL);
    COMMIT;
END insert_personxcommitte;

CREATE  PROCEDURE update_user_psword(pidUser IN INT, pNewPs IN VARCHAR) 
BEGIN
    UPDATE userdb
    SET psword_user = pNewPs
    WHERE pidUser = id_user;
    COMMIT;
END update_user_psword;

CREATE  PROCEDURE update_user_username(pidUser IN INT, pNewName IN VARCHAR) 
BEGIN
    UPDATE userdb
    SET user_name = pNewName
    WHERE pidUser = id_user;
    COMMIT;
END update_user_username;

CREATE  PROCEDURE update_student(pidPerson IN INT, pNewStudCard IN INT) 
BEGIN
    UPDATE student
    SET student_card = pNewStudCard
    WHERE pidPerson = id_person;
    COMMIT;
END update_student;

CREATE  PROCEDURE update_status(pidStatus  IN INT, pNewStatus IN VARCHAR) 
BEGIN
    UPDATE status
    SET name_status = pNewStatus
    WHERE pidStatus = id_status;
    COMMIT;
END update_status;

CREATE  PROCEDURE update_review(pidArtRev IN INT, pidUserRev IN INT, pNewDescription IN VARCHAR) 
BEGIN
    UPDATE review
    SET description_review = pNewDescription
    WHERE pidUserRev = id_user_rev AND pidArtRev = id_article_rev;
    COMMIT;
END update_review;

CREATE  PROCEDURE update_province(pidProvince IN INT, pNewName IN VARCHAR) 
BEGIN
    UPDATE province
    SET name_province = pNewName
    WHERE pidProvince = id_province;
    COMMIT;
END update_province;

CREATE  PROCEDURE update_professor(pidPerson IN INT, pNewDedication IN INT) 
BEGIN
    UPDATE professor
    SET id_dedication = pNewDedication
    WHERE pidPerson = id_person;
    COMMIT;
END update_professor;

CREATE  PROCEDURE update_product(pidProduct IN INT, pNewCost IN INT, pNewDescription IN VARCHAR) 
BEGIN
    UPDATE product
    SET cost_product = pNewCost, 
        description_product = pNewDescription
    WHERE pidProduct = id_product;
    COMMIT;
END update_product;

CREATE  PROCEDURE update_product_description(pidProduct IN INT, pNewDescription IN VARCHAR) 
BEGIN
    UPDATE product
    SET  description_product = pNewDescription
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_description;

CREATE  PROCEDURE update_product_cost(pidProduct IN INT, costProduct in INT) 
BEGIN
    UPDATE product
    SET  cost_product = costProduct
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_cost;

CREATE  PROCEDURE update_product_catalog(pidProduct IN INT, idCatalog in INT) 
BEGIN
    UPDATE product
    SET  id_catalog_pr = idCatalog
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_catalog;

create  PROCEDURE update_product_availability(pidProduct IN INT, pnIdNewAv IN INT) 
BEGIN
    UPDATE product
    SET id_availability = pnidnewav
    WHERE pidProduct = id_product;
    COMMIT;
END update_product_availability;


CREATE  PROCEDURE update_photo(pidPhoto IN INT, pNewRoute IN INT) 
BEGIN
    UPDATE photo
    SET route = pnewRoute
    WHERE pidPhoto = id_photo;
    COMMIT;
END update_photo;

CREATE  PROCEDURE update_phoneCategory(pidCategory IN INT, pNewDescription IN VARCHAR) 
BEGIN
    UPDATE phonecategory
    SET description_category = pNewDescription
    WHERE pidCategory = id_category;
    COMMIT;
END update_phoneCategory;

CREATE  PROCEDURE update_phone(pidPhone IN INT, pNewINT IN INT) 
BEGIN
    UPDATE phone
    SET INT_phone = pNewINT
    WHERE pidPhone = id_phone;
    COMMIT;
END update_phone;

CREATE  PROCEDURE delete_user(pidUser IN INT) 
BEGIN
    DELETE FROM userdb
    WHERE id_user = pidUser;
    COMMIT;
END delete_user;

CREATE  PROCEDURE delete_student(pidPerson IN INT) 
BEGIN
    DELETE FROM student
    WHERE id_person = pidPerson;
    COMMIT;
END delete_student;

CREATE  PROCEDURE delete_status(pidStatus  IN INT) 
BEGIN
    DELETE FROM status
    WHERE id_status = pidStatus;
    COMMIT;
END delete_status;

CREATE  PROCEDURE delete_review(pidArtRev IN INT, pidUserRev IN INT) 
BEGIN
    DELETE FROM review
    WHERE id_user_rev = pidUserRev AND id_article_rev = pidArtRev;
    COMMIT;
END delete_review;

CREATE  PROCEDURE delete_province(pidProvince IN INT) 
BEGIN
    DELETE FROM province
    WHERE id_province = pidProvince;
    COMMIT;
END delete_province;

CREATE  PROCEDURE delete_professor(pidPerson IN INT) 
BEGIN
    DELETE FROM professor
    WHERE id_person = pidPerson;
    COMMIT;
END delete_professor;

CREATE  PROCEDURE delete_product(pidProduct IN INT) 
BEGIN
    DELETE FROM product
    WHERE id_product = pidProduct;
    COMMIT;
END delete_product;

CREATE  PROCEDURE delete_photo(pidPhoto IN INT) 
BEGIN
    DELETE FROM photo
    WHERE id_photo = pidPhoto;
    COMMIT;
END delete_photo;

create  PROCEDURE delete_photo_article(pidArticle IN INT) 
BEGIN
    DELETE FROM photo
    WHERE id_article = pidArticle;
    COMMIT;
END delete_photo_article;

create  PROCEDURE delete_photo_product(pidProduct IN INT) 
BEGIN
    DELETE FROM photo
    WHERE id_product = pidProduct;
    COMMIT;
END delete_photo_product;

CREATE  PROCEDURE delete_phoneCategory(pidCategory IN INT) 
BEGIN
    DELETE FROM phonecategory
    WHERE id_category = pidCategory;
    COMMIT;
END delete_phoneCategory;

CREATE  PROCEDURE delete_phone(pidPhone IN INT) 
BEGIN
    DELETE FROM phone
    WHERE id_phone = pidPhone;
    COMMIT;
END delete_phone;

CREATE  PROCEDURE delete_personxcommitte(pidPerson IN INT, pidCommitte IN INT) 
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_person = pidPerson AND id_committe = pidCommitte;
    COMMIT;
END delete_personxcommitte;

CREATE  PROCEDURE delete_personxcommitte_person(pidPerson IN INT) 
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_person = pidPerson;
    COMMIT;
END delete_personxcommitte_person;

CREATE  PROCEDURE delete_personxcommitte_comm(pidCommittee IN INT) 
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_committe = pidCommittee;
    COMMIT;
END delete_personxcommitte_comm;

create  PROCEDURE delete_photo_user(pidUser IN INT) 
BEGIN
    DELETE FROM photo
    WHERE id_user = pidUser;
    COMMIT;
END delete_photo_user;

create  PROCEDURE delete_favourite_user(pidUserRev IN INT) 
BEGIN
    DELETE FROM favourite
    WHERE favourite.id_user_fav = pidUserRev;
    COMMIT;
END delete_favourite_user;
create  PROCEDURE delete_review_user(pidUserRev IN INT) 
BEGIN
    DELETE FROM review
    WHERE id_user_rev = pidUserRev;
    COMMIT;
END delete_review_user;

create  PROCEDURE delete_email_person(pidPerson IN INT) 
BEGIN
    DELETE FROM email
    WHERE email.id_person_mail = pidPerson;
    COMMIT;
END delete_email_person;

create  PROCEDURE delete_phone_person(pidPerson IN INT) 
BEGIN
    DELETE FROM phone
    WHERE id_person = pidPerson;
    COMMIT;
END delete_phone_person;

create  PROCEDURE update_photo_user(pidUser IN INT, pNewRoute IN VARCHAR) 
BEGIN
    UPDATE photo
    SET route = pnewRoute
    WHERE pidUser = id_user;
    COMMIT;
END update_photo_user;

create  PROCEDURE get_usersByPerson(pnIdPerson in INT, pCursorUsers out sys_refcursor)

BEGIN
    OPEN pCursorUsers for
    select id_person, id_user, user_name, psword_user
    from userdb
    where id_person = pnIdPerson;
END;

create  PROCEDURE delete_user_person(pidPerson IN INT) 
BEGIN
    DELETE FROM userdb
    WHERE id_person = pidPerson;
    COMMIT;
END delete_user_person;

create  PROCEDURE update_personXCommittee(pidPerson IN INT, pidCommittee IN INT) 
BEGIN
    UPDATE personxcommitte
    SET id_committe = pidCommittee
    WHERE id_person = pidPerson;
    COMMIT;
END update_personXCommittee;

CREATE  PROCEDURE delete_authorxproduct_author(pidAuthor in INT)

BEGINf
    DELETE from productxauthor
    where id_author_pa = pidAuthor;
    commit;
END delete_authorxproduct_author;