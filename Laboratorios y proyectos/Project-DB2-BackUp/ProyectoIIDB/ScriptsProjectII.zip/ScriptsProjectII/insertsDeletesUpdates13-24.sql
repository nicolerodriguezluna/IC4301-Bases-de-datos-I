-- ------------------------------ UPDATES --------------------------------------
DELIMITER //
CREATE PROCEDURE update_committee_description(IN pidCommittee INT, IN pNewDescriptionCommittee VARCHAR(100)) 
BEGIN
    UPDATE committe
    SET committe.description_committe = pNewDescriptionCommittee
    WHERE committe.id_committe= pidCommittee;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_country_name(IN pidCountry INT, IN pNewNameCountry VARCHAR(100)) 
BEGIN
    UPDATE country
    SET country.name_country = pNewNameCountry
    WHERE country.id_country = pidCountry;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_dedication_description(IN pidDedication INT, IN pNewDescriptionDadication VARCHAR(100)) 
BEGIN
    UPDATE dedication
    SET dedication.description_dedication = pNewDescriptionDadication
    WHERE dedication.id_dedication = pidDedication;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_digitalNewspaper_name(IN pidDigitalNewspaper INT, IN pNewNameDigital VARCHAR(100)) 
BEGIN
    UPDATE digitalnewspaper
    SET digitalnewspaper.name_digital_newspaper = pNewNameDigital
    WHERE digitalnewspaper.id_digital_newspaper = pidDigitalNewspaper;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_digitalNewspaper_quad(IN pidDigitalNewspaper INT, IN pNewIdQuad INT)
BEGIN
    UPDATE digitalnewspaper
    SET digitalnewspaper.id_quad = pNewIdQuad
    WHERE digitalnewspaper.id_digital_newspaper = pidDigitalNewspaper;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_district_name(IN pidDistrict INT, IN pNewNameDistrict VARCHAR(100)) 
BEGIN
    UPDATE district
    SET district.name_district = pNewNameDistrict
    WHERE district.id_district = pidDistrict;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_district_sector(IN pidDistrict INT, IN pNewIdSector INT) 
BEGIN
    UPDATE district
    SET district.id_sector = pNewIdSector
    WHERE district.id_sector = pidDistrict;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_email_address(IN pidEmail INT, IN pNewAddress VARCHAR(100)) 
BEGIN
    UPDATE email
    SET email.address_email = pNewAddress
    WHERE email.id_email = pidEmail;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_favourite_date_favourite(IN pidArtRev INT, IN pidUserRev INT, IN pNewDateFavourite VARCHAR(100)) 
BEGIN
    UPDATE favourite
    SET favourite.date_favourite = str_to_date(pNewDateFavourite,'%y, %m, %d')
    WHERE favourite.id_user_fav = pidUserRev AND favourite.id_article_fav = pidArtRev;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_gender_type_gender(IN pidGender INT, IN pNewTypeGender VARCHAR(100)) 
BEGIN
    UPDATE gender
    SET gender.type_gender = pNewTypeGender
    WHERE gender.id_gender = pidGender;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_logDB_change_descp(IN pidLogDB INT, IN pNewChangeDescription VARCHAR(100)) 
BEGIN
    UPDATE logDB
    SET logDB.change_descrp = pNewChangeDescription
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_logDB_previous_text(IN pidLogDB INT, IN pNewPreviousText VARCHAR(4000))
BEGIN
    UPDATE logDB
    SET logDB.previous_text = pNewPreviousText
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_logDB_current_text(IN pidLogDB INT,  IN pNewCurrentText VARCHAR(4000)) 
BEGIN
    UPDATE logDB
    SET logDB.current_text = pNewCurrentText
    WHERE logDB.id_log = pidLogDB;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_parameter_name(IN pidParameter INT, IN pNewNameParameter VARCHAR(100))
BEGIN
    UPDATE parameterDB
    SET parameterDB.name_parameter = pNewNameParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_parameter_description(IN pidParameter INT, IN pNewDescriptionParameter VARCHAR(100)) 
BEGIN
    UPDATE parameterDB
    SET parameterDB.description_parameter = pNewDescriptionParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_parameter_value(IN pidParameter INT, IN pNewValueParameter INT) 
BEGIN
    UPDATE parameterDB
    SET parameterDB.value_parameter = pNewValueParameter
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_parameter_route(IN pidParameter INT, IN pNewRoute VARCHAR(200)) 
BEGIN
    UPDATE parameterDB
    SET parameterDB.route = pNewRoute
    WHERE parameterDB.id_parameter = pidParameter;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_person_identitycard(IN pidPerson INT,  IN pNewIdentificationCard INT)
BEGIN
    UPDATE person
    SET person.identification_card = pNewIdentificationCard
    WHERE person.id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_person_first_name(IN pidPerson INT, IN pNewFirstName VARCHAR(100)) 
BEGIN
    UPDATE person
    SET person.first_name = pNewFirstName
    WHERE person.id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_person_second_name(IN pidPerson INT, IN pNewSecondName VARCHAR(100)) 
BEGIN
    UPDATE person
    SET person.second_name  = pNewSecondName
    WHERE person.id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_person_first_surname(IN pidPerson INT,  IN pNewFirstSurname VARCHAR(100))
BEGIN
    UPDATE person
    SET person.first_surname = pNewFirstSurname
    WHERE person.id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_person_second_surname(IN pidPerson INT, IN pNewSecondSurname VARCHAR(100)) 
BEGIN
    UPDATE person
    SET person.second_surname = pNewSecondSurname
    WHERE person.id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_person_datebirth(IN pidPerson INT, IN pNewDatebirth VARCHAR(100)) 
BEGIN
    UPDATE person
    SET person.datebirth = to_date(pNewDatebirth,'YY-MM-DD')
    WHERE person.id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_person_quad(IN pidPerson INT, IN pNewIdQuad INT)
BEGIN
    UPDATE person
    SET person.id_quad = pNewIdQuad
    WHERE person.id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_person_gender(IN pidPerson INT, IN pNewIdGender INT) 
BEGIN
    UPDATE person
    SET person.id_gender = pNewIdGender
    WHERE person.id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_person_localitation(IN pidPerson INT,  IN pNewExactLocalitation VARCHAR(2000)) 
BEGIN
    UPDATE person
    SET person.exact_location = pNewExactLocalitation
    WHERE person.id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_person_district(IN pidPerson INT, IN pNewIdDistrict INT) 
BEGIN
    UPDATE person
    SET person.id_district = pNewIdDistrict
    WHERE person.id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

-- ------------------------------ DELETES --------------------------------------
DELIMITER //
CREATE PROCEDURE delete_user(IN pidUser INT) 
BEGIN
    DELETE FROM userdb
    WHERE id_user = pidUser;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_student(IN pidPerson INT)
BEGIN
    DELETE FROM student
    WHERE id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_status(IN pidStatus INT) 
BEGIN
    DELETE FROM status
    WHERE id_status = pidStatus;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_review(IN pidArtRev INT, IN pidUserRev INT)
BEGIN
    DELETE FROM review
    WHERE id_user_rev = pidUserRev AND id_article_rev = pidArtRev;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_province(IN pidProvince INT)
BEGIN
    DELETE FROM province
    WHERE id_province = pidProvince;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_professor(IN pidPerson INT) 
BEGIN
    DELETE FROM professor
    WHERE id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_product(IN pidProduct INT)
BEGIN
    DELETE FROM product
    WHERE id_product = pidProduct;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_photo(IN pidPhoto INT) 
BEGIN
    DELETE FROM photo
    WHERE id_photo = pidPhoto;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_photo_article(IN pidArticle INT)
BEGIN
    DELETE FROM photo
    WHERE id_article = pidArticle;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_photo_product(IN pidProduct INT) 
BEGIN
    DELETE FROM photo
    WHERE id_product = pidProduct;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_phoneCategory(IN pidCategory INT) 
BEGIN
    DELETE FROM phonecategory
    WHERE id_category = pidCategory;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_phone(IN pidPhone INT) 
BEGIN
    DELETE FROM phone
    WHERE id_phone = pidPhone;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_personxcommitte(IN pidPerson INT, IN pidCommitte INT) 
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_person = pidPerson AND id_committe = pidCommitte;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_personxcommitte_person(IN pidPerson INT)
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_personxcommitte_comm(IN pidCommittee INT)
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_committe = pidCommittee;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_photo_user(IN pidUser INT) 
BEGIN
    DELETE FROM photo
    WHERE id_user = pidUser;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_favourite_user(IN pidUserRev INT) 
BEGIN
    DELETE FROM favourite
    WHERE favourite.id_user_fav = pidUserRev;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_review_user(IN pidUserRev INT)
BEGIN
    DELETE FROM review
    WHERE id_user_rev = pidUserRev;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_email_person(IN pidPerson INT)
BEGIN
    DELETE FROM email
    WHERE email.id_person_mail = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_phone_person(IN pidPerson INT) 
BEGIN
    DELETE FROM phone
    WHERE id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;
















-- ------------------------------ INSERTS --------------------------------------
DELIMITER //
CREATE PROCEDURE insert_committe(IN pnIdCampus INT, IN pcNameCommittee VARCHAR(100)) 
BEGIN
    INSERT INTO committe(description_committe, creationDate, userid, lastModifyDate, lastModifyBy,id_campus)
    VALUES(pcNameCommittee, NULL, NULL, NULL, NULL,pnIdCampus);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_country(IN pnameCountry VARCHAR(100)) 
BEGIN
    INSERT INTO country(name_country, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pnameCountry, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_dedication(IN pdescriptionDedication VARCHAR(100)) 
BEGIN
    INSERT INTO dedication(description_dedication, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pdescriptionDedication, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_digital_newspaper(IN pname_digital_newspaper VARCHAR(100), IN pidQuad INT) 
BEGIN
    INSERT INTO digitalNewspaper(name_digital_newspaper, id_quad,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pname_digital_newspaper, pidQuad, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_district(IN pnameDistrict VARCHAR(100), IN pidSector INT) 
BEGIN
    INSERT INTO district(name_district, id_sector, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pnameDistrict, pidSector ,NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_email(IN pAdressEmail VARCHAR(100), IN pidPerson INT) 
BEGIN
    INSERT INTO email(address_email, id_person_mail, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pAdressEmail, pidPerson, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_favourite(IN pidArticleFav INT, IN pidUserFav INT, IN pDateFavourite VARCHAR(100)) 
BEGIN
    INSERT INTO favourite(id_article_fav,id_user_fav,date_favourite, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidArticleFav, pidUserFav, pDateFavourite, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_gender(IN pTypeGender VARCHAR(100)) 
BEGIN
    INSERT INTO gender(type_gender,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pTypeGender,NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_logDB(IN pChangeDescription VARCHAR(100), IN pPreviousText VARCHAR(4000), IN pCurrentText VARCHAR(4000)) 
BEGIN
    INSERT INTO logdb(systemdate, time_log, change_descrp, previous_text,current_text,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(SYSDATE, CURRENT_TIMESTAMP, pChangeDescription, pPreviousText, pCurrentText,NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_neighbour(IN pidPerson INT) 
BEGIN
    INSERT INTO neighbour(id_person,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidPerson,NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_ParameterDb(IN pnameParameter VARCHAR(100), IN pdescriptionParameter VARCHAR(100) ,IN pvalueParameter INT, IN proute VARCHAR(100)) 
BEGIN
    INSERT INTO ParameterDb(name_parameter, description_parameter, value_parameter, route,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pnameParameter, pdescriptionParameter, pvalueParameter, proute, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_person(IN pidentifyCard INT, IN pfirstName VARCHAR(100), IN psecondName VARCHAR(100), IN pfirstSurname VARCHAR(100), 
IN psecondSurname VARCHAR(100), IN pdatebirth VARCHAR(100), IN pidQuad INT, IN pidGender INT, IN pexactLocalitation VARCHAR(200), IN pidDistrict INT) 
BEGIN
    INSERT INTO person(identification_card,first_name,second_name,first_surname,second_surname,datebirth,id_quad,id_gender,exact_location, id_district, creationDate, userId, lastModifyDate, lastModifyBy)
    VALUES(pidentifyCard, pfirstName,psecondName, pfirstSurname, psecondSurname, pdatebirth, pidQuad, pidGender, pexactLocalitation, pidDistrict, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

