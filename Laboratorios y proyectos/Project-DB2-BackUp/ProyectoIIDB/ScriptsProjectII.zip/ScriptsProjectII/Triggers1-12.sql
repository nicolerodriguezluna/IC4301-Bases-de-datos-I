USE bdproject;
-- Administrative
CREATE TRIGGER bdproject.before_insert_administrative
before insert on bdproject.administrative
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

CREATE TRIGGER bdproject.before_update_administrative
before update on bdproject.administrative
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

-- Administrator
CREATE TRIGGER bdproject.before_insert_administrator
before insert on bdproject.administrator
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

CREATE TRIGGER bdproject.before_update_administrator
before update on bdproject.administrator
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

-- ARTICLE
CREATE TRIGGER bdproject.before_insert_article
before insert on bdproject.article
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

CREATE TRIGGER bdproject.before_update_article
before update on bdproject.article
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

-- ARTICLE CATEGORY
CREATE TRIGGER bdproject.before_insert_articlecategory
before insert on bdproject.articlecategory
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();


CREATE TRIGGER bdproject.before_update_articlecategory
before update on bdproject.articlecategory
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

-- AUTHOR
CREATE TRIGGER bdproject.before_insert_author
before insert on bdproject.author
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

CREATE TRIGGER bdproject.before_update_author
before update on bdproject.author
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

-- AUTHOR CATEGORY
CREATE TRIGGER bdproject.before_insert_authorcategory
before insert on bdproject.authorcategory
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

CREATE TRIGGER bdproject.before_update_authorcategory
before update on bdproject.authorcategory
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();


-- AUTHORXARTICLE
CREATE TRIGGER bdproject.before_insert_authorxarticle
BEFORE insert on bdproject.authorxarticle
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

CREATE TRIGGER bdproject.before_update_authorxarticle
BEFORE UPDATE ON bdproject.authorxarticle
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

-- Availabilitypr
CREATE TRIGGER bdproject.before_insert_availabilitypr
BEFORE INSERT ON bdproject.availabilitypr
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

CREATE TRIGGER bdproject.before_update_availabilitypr
BEFORE UPDATE ON bdproject.availabilitypr
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

-- Campus
CREATE TRIGGER bdproject.before_insert_campus
BEFORE INSERT ON bdproject.campus
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

CREATE TRIGGER bdproject.before_update_campus
BEFORE UPDATE ON bdproject.campus
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

-- Canton
CREATE TRIGGER bdproject.before_insert_canton
before insert on bdproject.canton
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

CREATE TRIGGER bdproject.before_update_canton
before update on bdproject.canton
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

-- Catalog
CREATE TRIGGER bdproject.before_insert_catalog
before insert on bdproject.catalog
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

CREATE TRIGGER bdproject.before_update_catalog
before update on bdproject.catalog
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

-- College
CREATE TRIGGER bdproject.before_insert_college
before insert on bdproject.college
for each row set
new.userid:= USER(),
new.creationdate:=SYSDATE(),
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

CREATE TRIGGER bdproject.before_update_college
before update on bdproject.college
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();


create TRIGGER bdproject.before_update_district
before update on district
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

create TRIGGER bdproject.before_update_email
before update on bdproject.email
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

create TRIGGER bdproject.before_update_student
before update on bdproject.student
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

DELIMITER //
create trigger beforeUpdateStudent
    before update 
    on student
    for each row
    BEGIN
		if not(old.student_card <=> new.student_card) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Student Card',old.student_card,new.student_card);
		END IF;
END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertStudentCard
    before insert
    on student
    for each row
    BEGIN
		INSERT INTO logdb
		(systemdate, time_log, change_descrp, previous_text, current_text)
		VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Student Card',NULL,new.student_card);
END; //
DELIMITER ;


create  TRIGGER bdproject.before_update_status
before update on bdproject.status
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

DELIMITER //
create trigger beforeUpdateStatus
    before  update on status
    for each row
    BEGIN
		if not(old.name_status <=> new.name_status) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Status Name',old.name_status, new.name_status);
		END IF;
END; //
DELIMITER ;


DELIMITER //
create trigger beforeeInsertStatusName
    before insert on status
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Status Name',NULL, new.name_status);
END; //
DELIMITER ;

create TRIGGER bdproject.before_update_review
before update on bdproject.review
for each row SET
new.lastmodifydate:= SYSDATE,
new.lastmodifyby:=USER;

DELIMITER //
create trigger beforeUpdateReview
    before UPDATE on review
    for each row
    BEGIN
		if not(old.description_review <=> new.description_review) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Review Description',old.description_review, new.description_review);
		END IF;
    END; //
    DELIMITER ;


DELIMITER //
create trigger beforeInsertReviewDecrp
    before UPDATE on review
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Review Description',NULL, new.description_review);
    END; //
    DELIMITER ;
    
create TRIGGER bdproject.before_update_province
before update on bdproject.province
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

delimiter //
create  trigger beforeUpdateProvince
    before update
    on province
    for each row
    BEGIN
		if not(old.name_province <=> new.name_province) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Name Province',old.name_province, new.name_province);
		END IF;
    END; //
    DELIMITER ;
    
delimiter //
create  trigger beforeInsertProvinceName
before insert
on province
for each row
BEGIN
	INSERT INTO logdb
	(systemdate, time_log, change_descrp, previous_text, current_text)
	VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Name Province',NULL, new.name_province);
END; //
DELIMITER ;

DELIMITER //
create trigger beforeUpdateProfessor
    before update 
    on professor
    for each row
    BEGIN
		IF not(old.id_dedication <=> new.id_dedication) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Dedication Professor',(Select description_dedication
			from dedication where id_dedication=old.id_dedication), (Select description_dedication
			from dedication where id_dedication=new.id_dedication));
		END IF;
    END; //
delimiter ;


DELIMITER //
create trigger beforeUpdateProfessorDed
    before insert
    on professor
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(),'New Dedication Professor',NULL,(Select description_dedication
			from dedication where id_dedication= new.id_dedication));
    END; //
delimiter ;

show triggers;
            
create TRIGGER bdproject.before_update_product
before update on bdproject.product
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

DELIMITER //
create trigger beforeUpdateProductDescription
    before update
    on product
    for each row
    BEGIN
		if not(old.description_product <=> new.description_product) then
			INSERT INTO logdb
			( systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Description Product',old.description_product, new.description_product);
		END IF;
    END; //
    DELIMITER ;
    
    
DELIMITER //
create trigger beforeInsertProductDescription
before insert
on product
for each row
BEGIN
	INSERT INTO logdb
	( systemdate, time_log, change_descrp, previous_text, current_text)
	VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Description Product',NULL, new.description_product);
END; //
DELIMITER ;


DELIMITER //
create trigger beforeUpdateProductCost
before update
on product
for each row
BEGIN
	if not(old.cost_product <=> new.cost_product)then
		INSERT INTO logdb
		(systemdate, time_log, change_descrp, previous_text, current_text)
		VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Cost Product',old.cost_product, new.cost_product);
	END IF;
END; //
DELIMITER ;



DELIMITER //
create trigger beforeInsertProductCost
before insert
on product
for each row
BEGIN
		INSERT INTO logdb
		(systemdate, time_log, change_descrp, previous_text, current_text)
		VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Cost Product',NULL, new.cost_product);
END; //
DELIMITER ;

DELIMITER //
create trigger beforeUpdatePhoto
    before update
    on photo
    for each row
    BEGIN
		if not(old.route <=> new.route) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Route Photo',old.route, new.route);
		END IF;
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertPhotoRoute
    before update
    on photo
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Route Photo',NULL, new.route);
    END; //
DELIMITER ;

show triggers;

create TRIGGER bdproject.before_update_photo
before update on bdproject.photo
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();


create TRIGGER bdproject.before_update_professor
before update on bdproject.professor
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

create TRIGGER bdproject.before_update_phonecategory
before update on bdproject.phonecategory
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

DELIMITER //
create trigger beforeUpdatePhoneCategory
    before update
    on phoneCategory
    for each row
    BEGIN
		if not(old.description_category <=> new.description_category) then
			INSERT INTO logdb
			( systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Phone Category',old.description_category, new.description_category);
		end if;
    END; //
DELIMITER ;
show triggers;
DELIMITER //
create trigger beforeInsertPhoneCategoryDescrp
    before insert
    on phoneCategory
    for each row
    BEGIN
			INSERT INTO logdb
			( systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Phone Category',NULL, new.description_category);
    END; //
DELIMITER ;


create TRIGGER bdproject.before_update_phone
before update on bdproject.phone
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

DELIMITER //
create trigger beforeUpdatePhone
    before update
    on phone
    for each row
    BEGIN
		if not(old.number_phone <=> new.number_phone) then
        INSERT INTO logdb
        (systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Phone Number',old.number_phone, new.number_phone);
        END IF;
    END; //
DELIMITER ;

show triggers;

DELIMITER //
create trigger beforeinsertPhoneNumber
    before insert
    on phone
    for each row
    BEGIN
        INSERT INTO logdb
        (systemdate, time_log, change_descrp, previous_text, current_text)
        VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New Phone Number',NULL, new.number_phone);
    END; //
DELIMITER ;



create TRIGGER bdproject.before_update_person
before update on bdproject.person
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

DELIMITER //
create trigger beforeUpdatePersonSecondSur
    before update
    on person
    for each row
    BEGIN
		if not(old.second_surname <=> new.second_surname) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New second surname',old.second_surname, new.second_surname);
		END IF;
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertPersonSecondSur
    before insert
    on person
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New second surname',NULL, new.second_surname);
    END; //
DELIMITER ;

delimiter //
create trigger beforeUpdatePersonSecondName
    before Update
    on person
    for each row
    BEGIN
		if not(old.second_name <=> new.second_name) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New second name',old.second_name, new.second_name);
		END IF;
    END; //
delimiter ;


delimiter //
create trigger beforeInsertPersonSecondName
    before insert
    on person
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New second name',NULL, new.second_name);
    END; //
delimiter ;

DELIMITER //
create trigger beforeUpdatePersonQuad
    before update
    on person
    for each row
    BEGIN
		if not(old.id_quad <=> new.id_quad) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New quad',old.id_quad, new.id_quad);
		END IF;
    END; //
    DELIMITER ;
    
DELIMITER //
create trigger beforeInsertPersonQuad
    before insert
    on person
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New quad',NULL, new.id_quad);
    END; //
    DELIMITER ;

DELIMITER //
create trigger beforeUpdatePersonLocation
    before update
    on person
    for each row
    BEGIN
		if not(old.exact_location <=> new.exact_location) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New exact Localitation',old.exact_location, new.exact_location);
		END IF;
    END; //
    DELIMITER ;
    

DELIMITER //
create trigger beforeInsertPersonLocation
    before insert
    on person
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New exact Localitation',NULL, new.exact_location);
    END; //
    DELIMITER ;
    
    
    delimiter //
    create trigger beforeUpdatePersonGender
    before update
    on person
    for each row
    BEGIN
		if not(old.id_gender <=> new.id_gender) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New gender',old.id_gender, new.id_gender);
		END IF;
    END; //
    delimiter ;
    
delimiter //
    create trigger beforeInsertPersonGender
    before insert
    on person
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New gender',NULL, new.id_gender);
    END; //
    delimiter ;

show triggers;
DELIMITER //
create trigger beforeUpdatePersonFirstSurname
    before update 
    on person
    for each row
    BEGIN
		if NOT (old.first_surname <=> new.first_name) then	
			INSERT INTO logdb
			(systemdate,time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New first surname',old.first_surname, new.first_surname);
		END IF;
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertPersonFirstSurname
    before insert
    on person
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate,time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New first surname',NULL, new.first_surname);
    END; //
DELIMITER ;


DELIMITER //
create trigger beforeUpdatePersonFirstName
    before update 
    on person
    for each row
    BEGIN
		if not(old.first_name <=> new.first_name) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New first name',old.first_name, new.first_name);
		END IF;
    END; //
    DELIMITER ;

DELIMITER //
create trigger beforeInsertPersonFirstName
    before insert
    on person
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New first name',NULL, new.first_name);
    END; //
    DELIMITER ;
    
DELIMITER //
create trigger beforeUpdatePersonDistrict
    before update
    on person
    for each row
    BEGIN
		if not(old.id_district <=> new.id_district) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New district',old.id_district,new.id_district);
		END IF;
    END; //
    DELIMITER ;

show triggers;

DELIMITER //
create trigger beforeInsertPersonDistrict
    before INSERT
    on person
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New district',NULL,new.id_district);
    END; //
    DELIMITER ;

DELIMITER //
create trigger beforeUpdatePersonDatebirth
    before update
    on person
    for each row
    BEGIN
		if not (old.datebirth <=> new.datebirth) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New datebirth',old.datebirth, new.datebirth);
		END IF;
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertPersonDatebirth
    before insert
    on person
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New datebirth',NULL, new.datebirth);
    END; //
DELIMITER ;

delimiter //
create trigger beforeUpdateParameterDBValue
    before update
    on parameterDB
    for each row
    BEGIN
		if NOT(old.value_parameter <=> new.value_parameter) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New value of parameter',old.value_parameter,new.value_parameter);
		END IF;
    END; //
DELIMITER ;

delimiter //
create trigger beforeInsertParameterDBValue
    before insert
    on parameterDB
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New value of parameter',NULL,new.value_parameter);
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeUpdateParameterDBRoute
    before update
    on parameterDB
    for each row
    BEGIN
		if NOT(old.route <=> new.route) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New route of parameter',old.route, new.route);
		end if;
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertParameterDBRoute
    before insert
    on parameterDB
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New route of parameter',NULL, new.route);
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeUpdateParameterDBName
    before update
    on parameterDB
    for each row
    BEGIN
		if NOT(old.name_parameter <=> new.name_parameter) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New name of parameter',old.name_parameter,new.name_parameter);
		END IF;
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertParameterDBName
    before insert
    on parameterDB
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New name of parameter',NULL,new.name_parameter);
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeUpdateParameterDBDescrp
    before update 
    on parameterDB
    for each row
    BEGIN
		if not(old.description_parameter <=> new.description_parameter) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New description of parameter',old.description_parameter,new.description_parameter);
		END IF;
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertParameterDBDescrp
    before insert
    on parameterDB
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New description of parameter',NULL,new.description_parameter);
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeUpdateNewspaperQuad
    before update
    on digitalnewspaper
    for each row
    BEGIN
		if NOT(old.id_quad <=> new.id_quad) THEN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New quad for Digital Newspaper',old.id_quad, new.id_quad);
		END IF;
    END;//
delimiter ;


DELIMITER //
create trigger beforeInsertNewspaperQuad
    before insert
    on digitalnewspaper
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New quad for Digital Newspaper',NULL, new.id_quad);
    END;//
delimiter ;

DELIMITER //
create trigger beforeUpdateNewspaperName
    before update
    on digitalnewspaper
    for each row
    BEGIN
		if NOT(old.name_digital_newspaper <=> new.name_digital_newspaper) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New name for Digital Newspaper',old.name_digital_newspaper,new.name_digital_newspaper);
		END IF;
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertNewspaperName
    before insert
    on digitalnewspaper
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New name for Digital Newspaper',NULL,new.name_digital_newspaper);
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeUpdateGenderType
    before update
    on gender
    for each row
    BEGIN
		if NOT(old.type_gender <=> new.type_gender) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New gender type',old.type_gender,new.type_gender);
		END IF;
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertGenderType
    before insert
    on gender
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New gender type',NULL,new.type_gender);
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeUpdateFavouriteDate
    before update
    on favourite
    for each row
    BEGIN
		if NOT(old.date_favourite <=> new.date_favourite) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New date of favourite',old.date_favourite,new.date_favourite);
		END IF;
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertFavouriteDate
    before insert
    on favourite
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New date of favourite',NULL,new.date_favourite);
    END; //
DELIMITER ;

DELIMITER //
create  trigger beforeUpdateEmailAdress
    before update
    on email
    for each row
    BEGIN
		if not(old.address_email <=> new.address_email) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New address email',old.address_email,new.address_email);
		END IF;
    END; //
DELIMiTER ;

DELIMITER //
create  trigger beforeInsertEmailAdress
    before insert
    on email
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New address email',null,new.address_email);
    END; //
DELIMiTER ;

DELIMITER //
create trigger beforeUpdateDistrictSector
    before update
    on district
    for each row
    BEGIN
		if not(old.id_sector <=> new.id_sector) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New sector for district',old.id_sector,new.id_sector);
	    END IF;
    END;//
DELIMITER ;

DELIMITER //
create trigger beforeInsertDistrictSector
    before insert
    on district
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New sector for district',NULL,new.id_sector);
    END;//
DELIMITER ;

DELIMITER //
create trigger beforeUpdateDistrictName
    before update 
    on district
    for each row
    BEGIN
		if not(old.name_district <=> new.name_district) then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New name of district',old.name_district,new.name_district);
		END IF;
    END; //
DELIMITER ;

DELIMITER //
create trigger beforeInsertDistrictName
    before insert
    on district
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New name of district',NULL,new.name_district);
    END; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_available_descrp
before update
on availabilitypr
for each row
begin
	if not(old.description_availability <=> new.description_availability) then
		insert into logdb
		(id_log,systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'AVAILABILITY DESCR CHANGED',old.description_availability,
		new.description_availability);
	END IF;
end; //
DELIMITER ;

delimiter //
create trigger beforeUpdatePersonIdCard
    before update 
    on person
    for each row
    BEGIN
		if not(old.identification_card <=> new.identification_card)then
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New identification card',old.identification_card, new.identification_card);
		END IF;
    END; //
    DELIMITER ;
    
delimiter //
create trigger beforeInsertPersonIdCard
    before insert 
    on person
    for each row
    BEGIN
			INSERT INTO logdb
			(systemdate, time_log, change_descrp, previous_text, current_text)
			VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New identification card',NULL, new.identification_card);
    END; //
    DELIMITER ;

create TRIGGER bdproject.before_update_country
before update on bdproject.country
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

create TRIGGER bdproject.before_update_committe
before update on bdproject.committe
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

create TRIGGER bdproject.before_update_dedication
before update on bdproject.dedication
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

create TRIGGER bdproject.before_update_digitalNewspaper
before update on bdproject.digitalNewspaper
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

create TRIGGER bdproject.before_update_favourite
before update on bdproject.favourite
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

create TRIGGER bdproject.before_update_gender
before update on bdproject.gender
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

create  TRIGGER bdproject.before_update_personxcommitte
before update on bdproject.personxcommitte
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();


create TRIGGER bdproject.before_update_productxauthor
before update on bdproject.productxauthor
for each row set
new.lastmodifydate:= SYSDATE(),
new.lastmodifyby:=USER();

DELIMITER //
create  TRIGGER before_update_perxcom
before update on personxcommitte
for each row
begin
    insert into logdb
    (systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'CHANGED PERSON IN COMMITTE',(SELECT first_name from person 
    where old.id_person = person.id_person),(SELECT first_name from person 
    where new.id_person = person.id_person));
end; //
DELIMITER ;

DELIMITER //
create  TRIGGER before_insert_perxcom
before insert on personxcommitte
for each row
begin
    insert into logdb
    (systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW PERSON IN COMMITTE',NULL,(SELECT first_name from person 
    where new.id_person = person.id_person));
end; //
DELIMITER ;

DELIMITER //
Create TRIGGER before_update_campus_dignews
before update on digitalnewspaper
for each row
begin
    if not(old.id_quad<=>new.id_quad) then
        insert into logdb
        (systemdate,time_log,change_descrp,previous_text,current_text)
        VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEWSPAPER CAMPUS CHANGED',(select name_campus from campus where old.id_quad = campus.id_campus),
        (select name_campus from campus where new.id_quad = campus.id_campus));
    END if;
end; //
DELIMITER ;


SELECT * from personxcommitte;

SELECT Concat('DROP TRIGGER ', Trigger_Name, ';') FROM  information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = 'bdproject';

DROP TRIGGER before_insert_administrative;
DROP TRIGGER before_update_administrative;
DROP TRIGGER before_insert_administrator;
DROP TRIGGER before_update_administrator;
DROP TRIGGER before_insert_article;
DROP TRIGGER before_update_article;
DROP TRIGGER before_insert_articlecategory;
DROP TRIGGER before_update_articlecategory;
DROP TRIGGER before_insert_author;
DROP TRIGGER before_update_author;
DROP TRIGGER before_insert_authorcategory;
DROP TRIGGER before_update_authorcategory;
DROP TRIGGER before_insert_authorxarticle;
DROP TRIGGER before_update_authorxarticle;
DROP TRIGGER before_insert_availabilitypr;
DROP TRIGGER before_update_availabilitypr;
DROP TRIGGER before_insert_campus;
DROP TRIGGER before_update_campus;
DROP TRIGGER before_insert_canton;
DROP TRIGGER before_update_canton;
DROP TRIGGER before_insert_catalog;
DROP TRIGGER before_update_catalog;
DROP TRIGGER before_insert_college;
DROP TRIGGER before_update_college;
DROP TRIGGER before_update_username;
select * from article;

SELECT * from photo;

select * from person;

select * from campus;

select * from author;

select * from committe;

select * from digitalnewspaper;

call get_newspapers_byQuad(2);

show triggers;

select * from logdb;