use bdproject;
insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(1,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(1,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(1,3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(1,4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(1,5,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(1,6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(1,7,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(1,8,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(1,9,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(20,10,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(20,11,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(20,12,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(20,13,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(20,14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into authorxarticle
(id_author_autart,id_article_autart,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES(20,15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');
