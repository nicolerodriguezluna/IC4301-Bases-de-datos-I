use bdproject;

INSERT INTO Authorcategory
(type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Ciencias de la Computación', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO Authorcategory
(type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Matemáticas', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO Authorcategory
(type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Ciencia', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO Authorcategory
(type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Arte', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO Authorcategory
(type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Biología', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO Authorcategory
(type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Deportes', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO Authorcategory
(type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Medicina', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO Authorcategory
(type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Química', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO Authorcategory
(type_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Física', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

