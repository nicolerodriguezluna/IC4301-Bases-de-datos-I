use bdproject;

insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Marcha por FEES: Universidades logran evitar recorte de presupuesto para 2023 tras manifestación multitudinaria',
'Estudiantes y personal de U públicas se manifestaron contra propuesta de Gobierno para el FEES del próximo año. Las partes alcanzaron un primer acuerdo este martes pero seguirán conversaciones mañana miércoles

Fuera de Casa Presidencial, los manifestantes celebraron el resultado de la negociación del FEES 2023 de este martes, donde el Gobierno aceptó, finalmente, la propuesta que llevaron los rectores desde el primer encuentro, hace una semana. En aquel momento, los universitarios plantearon partir del presupuesto otorgado para 2022 y añadir inflación o costo de vida.

El Ejecutivo presentó una contrapropuesta con el recorte, la cual no fue aceptada. Finalmente, se acogió el primer plan, por lo que este miércoles se reunirán de nuevo para decidir ese componente por costo de vida que se sumará a los ¢522.000 millones. El punto fundamental será definir si se usará la inflación interanual de 8,7% o la alcanzada en julio, de 11,4 %.

“Hemos avanzado, repito lo que se ha acordado: se mantiene el presupuesto base 2022, no hemos podido negociar el tema de la inflación tal y como lo establece la Constitución. Dimos un primer paso en esta reunión, mañana hemos acordado reunirnos a las 2:30 p. m. en nuestras instalaciones de Conare, con la esperanza de que el Gobierno nos pueda aceptar el costo de vida que estamos planteando”, declaró Gustavo Gutiérrez, rector de la UCR, institución que recibe la mayor parte del Fondo.

“Muy contentos, muy positivos con esta reunión y seguimos adelante con la importancia de darle a la universidad pública y a la educación pública la inversión que merece”, expresó Francisco González, jerarca de la Universidad Nacional.

Los estudiantes, por su parte, consideraban manifestarse de nuevo este miércoles, en Conare, para asegurar el acuerdo definitivo a su favor.
La Nacion logo

Educación
Marcha por FEES: Universidades logran evitar recorte de presupuesto para 2023 tras manifestación multitudinaria
Estudiantes y personal de U públicas se manifestaron contra propuesta de Gobierno para el FEES del próximo año. Las partes alcanzaron un primer acuerdo este martes pero seguirán conversaciones mañana miércoles
Por José Andrés Céspedes , Daniela Cerdas E. y Irene Vizcaíno
16 de agosto 2022, 1:02 PM
"Sí se pudo, sí se pudo"

Fuera de Casa Presidencial, los manifestantes celebraron el resultado de la negociación del FEES 2023 de este martes, donde el Gobierno aceptó, finalmente, la propuesta que llevaron los rectores desde el primer encuentro, hace una semana. En aquel momento, los universitarios plantearon partir del presupuesto otorgado para 2022 y añadir inflación o costo de vida.

El Ejecutivo presentó una contrapropuesta con el recorte, la cual no fue aceptada. Finalmente, se acogió el primer plan, por lo que este miércoles se reunirán de nuevo para decidir ese componente por costo de vida que se sumará a los ¢522.000 millones. El punto fundamental será definir si se usará la inflación interanual de 8,7% o la alcanzada en julio, de 11,4 %.

“Hemos avanzado, repito lo que se ha acordado: se mantiene el presupuesto base 2022, no hemos podido negociar el tema de la inflación tal y como lo establece la Constitución. Dimos un primer paso en esta reunión, mañana hemos acordado reunirnos a las 2:30 p. m. en nuestras instalaciones de Conare, con la esperanza de que el Gobierno nos pueda aceptar el costo de vida que estamos planteando”, declaró Gustavo Gutiérrez, rector de la UCR, institución que recibe la mayor parte del Fondo.

“Muy contentos, muy positivos con esta reunión y seguimos adelante con la importancia de darle a la universidad pública y a la educación pública la inversión que merece”, expresó Francisco González, jerarca de la Universidad Nacional.
',DATE '2022-08-16',1,1,3,1, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');


insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Casa Verde será anfitriona y protagonista del próximo Art City Tour virtual','El próximo Art City Tour virtual de San José se transmitirá desde la Casa Verde de Barrio Amón, un inmueble declarado patrimonio histórico-arquitectónico del país y que es propiedad del Tecnológico de Costa Rica.

Además de ser la anfitriona de la actividad, Casa Verde también participará con una cápsula que mostrará sus principales características arquitectónicas y contará parte de su historia.

De acuerdo con Henry Bastos Ulate, director de GAM Cultural + Art City Tour, Casa Verde es un referente arquitectónico de Barrio Amón. Su construcción en madera de principios del siglo XX y su buena conservación hasta la fecha, la convierten en una pieza fundamental del paisaje urbano.

“El momentum generado por el debate público como consecuencia de la demolición de la edificación de Cuesta Nuñez es una gran oportunidad para reforzar ante diferentes audiencias la importancia del patrimonio, proyectar sus beneficios y la apuesta por su conservación”, subrayó Bastos.

El Art City Tour adaptó sus recorridos culturales a la virtualidad vía streaming desde junio del 2020 bajo el nombre Por Chepe desde casa, con la finalidad de seguir difundiendo la amplia producción cultural del país en medio de la pandemia por COVID-19.

Cada transmisión se ha realizado desde espacios icónicos de la capital y de gran valor histórico para la población, como el Museo Nacional, el Museo de Jade, el Teatro Nacional, el Museo de Arte y Diseño Contemporáneo y el Castillo Azul de la Asamblea Legislativa.

Además de la Casa Verde del TEC, en este último Art City Tour virtual del año, participarán el Teatro Nacional de Costa Rica, el Museo Nacional, el Museo Penitenciario, el Museo Filatélico, la Galería Nacional, el Centro Cultural de España, el Centro Cultural Histórico José Figueres Ferrer, la Compañía Nacional de Danza, la Compañía Nacional de Teatro y DidiFood.',DATE '2021-10-7',1,1,8,1, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');


insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Estudiantes elaboraron 14 propuestas para mejorar el espacio urbano en la capital 
','Los barrios Amón y Otoya, al norte de la capital, fueron el foco de atención de toda la comunidad estudiantil y docente de la Escuela de Arquitectura y Urbanismo por toda una semana durante la XVIII edición del Taller Vertical, una experiencia académica que promueve la búsqueda de soluciones a problemáticas del espacio urbano mediante el trabajo colaborativo entre estudiantes de todos los niveles de la carrera.

El lema de la actividad fue “Hacer lugares”, un concepto que busca convertir espacios públicos olvidados e inseguros en puntos atractivos y de confianza para la comunidad. Para ello, se utilizó el principio de “urbanismo táctico”, el cual promueve la recuperación de las áreas públicas y su puesta en valor por medio de intervenciones ligeras, de bajo costo y de rápida implementación para explorar opciones de mejora periódicamente.

En esta ocasión, el Taller integró a representantes de ambos barrios para que aportaran sus ideas y sugerencias. Esto se hizo tanto en las reuniones preparatorias durante los meses de abril, mayo y agosto, como en la semana de realización del Taller, cuando abrieron las puertas de sus casas a los equipos estudiantiles y asistieron al acto de inauguración. Además, se contó con el aporte de la Municipalidad de San José y del Colegio de Arquitectos de Costa Rica.

Para lograr los objetivos, estudiantes y docentes se dividieron en catorce equipos de trabajo, los cuales elaboraron propuestas de mejora para siete zonas claves de este sector de San José. A cada uno de estos puntos se le especificó un enfoque en relación con el uso actual de la tierra (cultural, institucional o comercial) y, además, se le definieron posibles estrategias de intervención que cada equipo de trabajo debía considerar para su propuesta.

Todos los equipos tuvieron como eje central la puesta en valor del paisaje urbano histórico de los barrios Amón y Otoya y debieron considerar dentro de las propuestas elementos de temporalidad en el uso del espacio, iluminación y mobiliario urbano, diseño con enfoque en derechos humanos, paisajismo urbano y perdurabilidad de los materiales propuestos.

Durante la inauguración de la actividad, Alejandro Víctor Benavides, presidente de la Asociación de Estudiantes de Arquitectura y Urbanismo, invitó a los equipos de trabajo a convertir el Taller Vertical en un “laboratorio de sueños”, a reimaginar la ciudad y a visionar los barrios Amón y Otoya del mañana como espacios más activos, participativos y seguros.

“Hemos detectado junto a la comunidad una serie de problemáticas que afecta a nuestro barrio, problemáticas sociales, políticas, económicas y de infraestructura que han debilitado la ciudad y la forma en la que participamos en ella. Por ejemplo, la percepción de inseguridad, el comercio sexual ilícito, basura, falta de iluminación, demarcación incorrecta de calles, prioridad vehicular, aceras en mal estado e inaccesibles son algunas de las problemáticas que aquejan nuestro entorno urbano”, especificó Víctor.

Por su parte, Pablo Bulgarelli Bolaños, coordinador general del XVIII Taller Vertical, resaltó la importancia de esta actividad porque es cuando “se hace escuela” y toda la población estudiantil une sus esfuerzos para construir propuestas que van mucho más allá de ganar puntos para los cursos. De acuerdo con Bulgarelli, además de ser una experiencia académica, el Taller Vertical facilita que los estudiantes de todos los niveles de la carrera se conozcan entre sí, ejerciten sus habilidades blandas y comprendan la importancia de que el conocimiento traspase las paredes de las aulas.',DATE '2022-09-7',1,1,8,1, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Teatro Agosto estrenó "Uvieta" en la virtualidad','En el marco del centenario de la publicación de los Cuentos de mi tía Panchita de Carmen Lyra, Teatro Agosto, del Campus Tecnológico Local San José, estrenó su adaptación para teatro virtual del cuento Uvieta, el pasado 28 de noviembre por su canal de YouTube.

La obra también se proyectó en vivo, ese mismo día, durante el Festival Internacional de Teatro Puntarenense de la Universidad de Costa Rica y estuvo disponible hasta el 30 de noviembre. Posteriormente, quienes visitaron la Feria Internacional del Libro, en su versión virtual, pudieron observarla en el stand de la Editorial Tecnológica de Costa Rica, del 4 al 6 de diciembre.

Luego de 6 días de exposición al público, la obra dirigida por Alexandra De Simone logró acumular más de 1050 visualizaciones y centenares de comentarios.

De acuerdo con Daniel Morales Sibaja, estudiante de Ingeniería en Diseño Industrial e integrante del Teatro Agosto, a lo largo del segundo semestre el grupo se dedicó de lleno a la adaptación del cuento, a la exploración de herramientas virtuales y a la creación colectiva para el desarrollo del montaje.
Como punto de partida se definió una estética de “un mundo dentro de otro”. De esta manera, los integrantes de este grupo artístico jugaron a distorsionar tamaños, pesos y dimensiones y a imaginar formas en las que viajan las historias.

“A partir de la concepción de que el mundo de Uvieta iba a suceder dentro del armario de tía Panchita, fue fundamental la selección de los objetos que van a estar ahí. Realizamos una gran colección de unos 200 objetos que cada miembro del grupo encontró en su casa”, detalló Morales.

El grupo utilizó para el montaje una técnica audiovisual denominada “croma” o “clave de color” que consiste en extraer un color de una imagen o vídeo y reemplazar el área que ocupaba ese color por otra imagen o vídeo, con la ayuda de un equipo especializado o una computadora. Esta técnica es ampliamente usada en cine, televisión y fotografía para recrear escenas en ambientes imaginarios o de ciencia ficción, similares a los fondos virtuales que ofrece la plataforma Zoom.

Gracias al uso del croma, Teatro Agosto pudo crear escenas grupales y generar una mejor interacción entre los personajes. Para ello, cada actor tuvo que acondicionar su espacio de grabación de acuerdo con sus posibilidades y limitaciones y convertirse en su propio camarógrafo.

“Utilizamos una gran variedad de recursos tecnológicos para darle vida al montaje, desde filtros de aplicaciones móviles para cambiar el aspecto facial de algunos personajes hasta programas de diseño y modelado en 3D para realizar la casa de tía Panchita y el armario. También usamos programas de edición fotográfica para crear los escenarios junto a la colección de objetos, además de programas de edición de vídeo y animación para crear el producto final”, especificó Morales.

Otro rasgo particular del montaje es su música original. Para ello se echó mano de software y recursos gratuitos para la composición musical y se obtuvieron 4 canciones originales que se utilizan a lo largo de la obra.

“También, en enero estrenamos Uvieta: la miniserie en el canal de YouTube del grupo. Una miniserie de 3 episodios cortos que exploran historias producto de las consecuencias de dejar a La Muerte atrapada tanto tiempo en el palo de uvas de Uvieta”, adelantó Morales.

El primer episodio de Uvieta: la miniserie se llama Inmortales y se transmitirá el viernes 15 de enero a las 7 p.m. El segundo episodio se titula Crisis infernal y se emitirá el viernes 22 de enero a las 7 p.m. Mientras que el último capítulo se denomina El regreso y se podrá ver el viernes 29 de enero a las 7 p.m.',DATE '2020-12-9',1,1,4,1, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');


insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('Centro Histórico de San José contará con señalética diseñada por egresado del TEC','A partir de hoy, los transeúntes de la capital contarán con un sistema de información cultural y turística que contribuirá a visibilizar edificios patrimoniales y atractivos del Centro Histórico de San José y sus ensanches.

Se trata de 4 mojones de delimitación, 13 señales grupales o tótems y 8 señales individuales ubicadas en los postes de alumbrado público, que se ubicarán en puntos estratégicos del centro de San José.

El proyecto fue inaugurado el miércoles 16 de diciembre en el parque España, en una actividad donde estuvieron presentes autoridades de la Municipalidad de San José y del Tecnológico de Costa Rica.

Esta iniciativa forma parte del proyecto “Señalética para el Centro Histórico de San José y sus Ensanches”, impulsado por la Comisión Centro Histórico, conformada por la Municipalidad de San José (MSJ), el Tecnológico de Costa Rica (TEC) y el Ministerio de Cultura y Juventud (MCJ), entre otras organizaciones públicas y privadas.

Jorge Mora Jara, arquitecto recién egresado del TEC, tuvo a su cargo el diseño del sistema informativo como asistente del proyecto Centro Histórico de San José y, posteriormente, de forma voluntaria y ad honorem. Para él, es de suma importancia desarrollar estrategias de información, difusión y visibilización de los atractivos e historia de la ciudad de San José para que la ciudadanía los valore y aprecie.
“Lo más satisfactorio para mí es poder generar, con este proyecto, un pequeño aporte que comenzará a visibilizar las acciones que se han generado durante algunos años, desde la academia y el municipio, para consolidar la imagen y la importancia de un proyecto tan interesante como lo es el Centro Histórico de la ciudad de San José. Jorge Mora Jara, arquitecto egresado del TEC y quien tuvo a su cargo el diseño de la señalética.
“Aparte de visibilizar nuestro patrimonio, la señalética permitirá tener mapeados diferentes hitos de la ciudad, fortaleciendo el sentido de pertenencia y ubicación en la misma, ya sea identificando un edificio o un espacio público. Además, ayudará a que más población pueda tener más información sobre sitios que pasan desapercibidos en la actualidad y, por ende, un mayor acceso a los mismos”, destacó.

Además, explicó que el proyecto es un complemento a las rutas turísticas que ya han desarrollado el Departamento de Servicios Culturales y la Oficina de Turismo, de la Municipalidad de San José, con el acompañamiento del TEC. En este sentido, se espera que la nueva señalética ayude a proyectar el Centro Histórico de San José y sus atractivos turísticos, patrimoniales y culturales, al turismo local e internacional, de la misma forma como sucede en otras ciudades latinoamericanas.
La señalización utiliza componentes de alta resistencia a golpes y a las inclemencias del tiempo, como policarbonatos, acrílicos, impresiones de alto gramaje, tintas resistentes a la luz solar y emplasticados mate. A la vez, todos estos materiales son de escaso o nulo valor en las plantas recicladoras, por lo que se espera que no sean objeto de robo.

Jeannette Alvarado, directora de la Escuela de Arquitectura y Urbanismo del TEC, explica que la señalética es una técnica de comunicación visual que utiliza señales icónicas y símbolos, cromáticos y lingüísticos, para brindar información y orientar a las personas un espacio determinado.

De acuerdo con Alvarado, una señalética debe ser de fácil lectura y comprensión. Además, es imprescindible que la información sea concreta, clara y precisa. Para ello, se presentan datos esenciales, de forma esquemática y en un sistema arquitectónico que quede en el imaginario de la población.

“El TEC, en coordinación con la Municipalidad de San José, ha promovido que la ciudadanía valore su ciudad mediante intervenciones urbanas y proyectos. Desde la academia se ha realizado diseño en ciudad y de marca desde el año 2013.
',DATE '2020-12-17',1,1,4,1, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');


insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('El poder transformador del arte','La vida y obra de Juan Luis Rodríguez Sibaja, Premio Magón 2020, fue el tema de la lección inaugural del Campus Tecnológico Local San José, realizada de forma virtual y con la participación del historiador del arte y exprofesor del Tecnológico de Costa Rica, Luis Fernando Quirós.

Tradicionalmente, esta lección es dictada por la persona galardonada con el máximo reconocimiento que otorga el Ministerio de Cultura y Juventud. En esta ocasión, Rodríguez no pudo estar presente por razones de salud, pero su esposa, Diana Patricia Mosheim Castro, compartió una serie de ideas y principios que el artista ha pregonado a lo largo de su vida.

Posteriormente, Quirós hizo una reseña de la vida de Rodríguez y destacó algunos momentos de su carrera artística y su capacidad creativa para transformar materiales de desecho en verdaderas obras de arte, muchas de ellas efímeras y creadas a partir de elementos naturales.

En la voz de su esposa, Diana Patricia Mosheim Castro:
“Hay algunas palabras y algunas ideas que Juan Luis repite, no solamente de manera hablada, sino también en sus trabajos, y voy a tratar de transmitirlas. Claro, no es igual. Pero, él siempre dice que hay un vacío del que se debe estar consciente, algo que uno desea llenar con lo que hace, pero tiene que ser a partir de quién es uno y definir el terreno donde uno está, porque uno siempre tiene un sustento. Entonces, conocer el terreno es importante. El terreno externo como el terreno interno.

“En el trabajo creativo, mientras uno hace las cosas, porque una cosa es imaginarlas y otra cosa es hacerlas, uno tiene que estar un poco suelto, tiene que seguir las intuiciones, dejar que se manifieste esa parte de uno que no necesariamente es tan consciente. Cada idea que uno tiene, la manifestación no necesariamente es a través del mismo material. Entonces, por ejemplo, a veces hay una gran inquietud, algo que uno quiere transmitir y no va a ser por medio del dibujo o de un grabado como él lo hace, sino puede ser a través de la poesía, puede ser a través de la escultura o puede ser a través de una receta de cocina o puede ser, simplemente, de una forma de vivir, un giro en la forma de vivir. Entonces, la creatividad, en este aspecto del artista, tiene que cubrir muchas partes de su vida y, en general, él dice de cualquier persona, así debe ser.

“La copia, inicialmente, tal vez es un ejercicio que los artistas o los intelectuales o cualquier persona hace, pero, poco a poco, la copia o ese ejemplo que uno sigue tiene que ir cogiendo características personales. Eso hay que irlo reconociendo. La línea nunca es igual, el peso de una línea sobre un papel o el trabajo que uno hace nunca es igual al de otra persona, porque uno tiene vivencias diferentes. Entonces, siempre hay que recuperar eso, esa parte que se va manifestado, que es lo que uno llama su sombra, su terreno interno. Ese es un gran respeto que él siempre promueve.

“Juan Luis dice que lo que uno hace tiene que ser algo que no podría dejar de hacer. Es decir, que lo llena tanto de pasión y de alegría o hasta de sufrimiento o tensión, que no puede dejar de hacerlo. Entonces, no es una cosa que se elige por comercio, digámosle así. Si, finalmente, dan buenos resultados en cuestión de dinero pues es muy bueno, pero la creatividad no puede estar solamente manejada por un aspecto de bienestar material. Dentro de estas manifestaciones, a veces, surgen lo que la gente califica como errores. Dice Juan Luis que estos errores son la punta del iceberg de lo que uno es de su originalidad, de su particularidad. Estos errores hay que estudiarlos, limarlos, ver cómo fue que salieron de esa parte no racional que uno tiene y pueden ser la fuente de un trabajo o un hallazgo que sea parte de lo que uno va a dejar de original.',DATE '2021-02-16',2,1,4,1, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');


insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (' El 54,8% de los estudiantes del TEC tienen trabajo antes de graduarse','Cuando se trata de insertarse en el mercado laboral, los estudiantes del Tecnológico de Costa Rica (TEC) tienen un panorama prometedor. 

Así lo confirma el primer censo realizado por la Oficina de Planificación Institucional del TEC, el cual reveló que el 54,84% de los estudiantes de grado (bachillerato y licenciatura) tienen trabajo antes de graduarse. Se trata específicamente de jóvenes que se encuentran en el último ciclo y, por ende, están realizando sus tesis o pasantías.

El informe señala, además, que  de los estudiantes que se encuentran trabajando durante sus estudios (independientemente del ciclo lectivo) el 88,39% laboran para el sector privado, mientras que el 10,05% lo hace para el sector público.

Caso de éxito

Uno de ellos es José Pablo Delgado, quien recibió su título hace 15 días como ingeniero en Biotecnología. 

Sin embargo, desde antes de comenzar su proyecto de graduación ya había sido seleccionado para trabajar en la empresa Ginkgo Bioworks en Boston, Estados Unidos. 

Ginkgo Bioworks es una empresa dedicada a facilitar la modificación de organismos por medio de la biología sintética y la automatización. 

“Definitivamente, la preparación académica del TEC nos permite integrarnos en el ámbito laboral más rápido. Creo que el secreto es que desde el primer año nos enseñan a no conformarnos y buscar siempre nuevas soluciones a problemas tanto en la investigación como para la vida”, afirmó el joven de 23 años. 

El censo fue realizado entre abril y octubre del 2019 y contó con la participación de 9 574 estudiantes; es decir, un 90,1% de porcentaje de respuesta de la población estudiantil de grado. 

En el caso de los graduados con al menos 3 años en el mercado, según datos del Estudio de Seguimiento de Graduados 2016, del Consejo Nacional de Rectores (Conare), el porcentaje de graduados del TEC con empleo es del 98%, siendo la universidad con el mayor porcentaje de empleabilidad.',DATE '2020-10-20',1,1,1,1, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('Gemelas reciben su título junto a 409 nuevos profesionales','El Tecnológico de Costa Rica (TEC) llevó a cabo la graduación No.307 correspondiente al segundo Acto Ordinario del 2022 en su campus Central localizado en Cartago.

En total, el TEC entregó al país 409 nuevos profesionales, correspondiente a 128 bachilleratos universitarios, 195 licenciados, en maestría 86 y un doctorado. Representando a un total de 157 mujeres y 253 son hombres. 

“Con esto seguimos cumpliendo con el objetivo para el cual  fue creada esta Institución hace 51 años: ´aportar al país  profesionales capaces de liderar el cambio en nuestro modelo  de desarrollo. Para nosotros es un orgullo seguir aportando con profesionales, cuya calidad es reconocida a nivel nacional e internacional en disciplinas de alto impacto”, indicó el rector, Luis Paulino Méndez.
Entre los graduados, las jóvenes gemelas, oriundas de Coronado también recibieron su título. 

Se trató de María Graciela y Ana Gabriela Rosales Largaespada. Ambas recibieron su título como licenciadas en el mismo acto de graduación. La primera en Ingeniería en Biotecnología y la segunda en Ingeniería en Mecatrónica. 

“Cualquiera podría pensar que nos pusimos de acuerdo. Pero no fue así. Yo por ejemplo, me atrasé en mi carrera, porque mi sueño era entrar a Biotecnología, y la primera vez que hice el examen de admisión no alcancé el puntaje. Pero lo intenté hasta que logré ingresar”, recuerda muy orgullosa, Ana Gabriela Rosales, quien recibió su título con mención de honor tras obtener un promedio ponderado de 97,83. 

Por su parte María Gabriela, relató que se atrasó en su carrera tras vivir dos etapas de depresión. “Pero hoy, gracias a la ayuda de profesionales, familia y amigos logré sacar la carrera”, indicó.

“Deseo aprovechar este espacio para recordarle a los profesores, administrativos y estudiantes que debemos cuidar nuestra salud. Que el TEC brinda herramientas para poder cuidarla, no están solos. Yo acudí a ellas y les agradezco mucho”, puntualizó la Joven. 

Las jóvenes de 25 años recibieron su certifcado acompañadas de sus padres, hermana y amigos. 

El evento se desarrolló en tres actos. Uno en la mañana, la tarde y la noche. Todos en el auditorio del Centro de las Artes. 

Tras 51 años de existencia, el TEC ha graduado más  de  28 mil profesionales, con el esfuerzo por impulsar el desarrollo económico y social.',DATE '2022-09-6',3,1,8,1, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('El 75,9% de los estudiantes matriculados en el TEC provienen de colegios públicos o semi-públicos','La Oficina de Planificación Institucional (OPI) del Tecnológico de Costa Rica (TEC) presentó los resultados del Censo Estudiantil del primer semestre 2019, donde se dan a conocer los datos sociodemográficos, vida universitaria y laboral. 

La presentación oficial se llevó a cabo durante una de las sesiones del Consejo de Rectoría.

Dentro de los resultados se dio a conocer que del total de estudiantes matriculados en la Institución, el 57,89% provienen de colegios públicos y el 18,07% de colegios semipúblicos; es decir, el 75,9% de los estudiantes proceden de estas modalidades. 

“En la categoría de colegios semipúblicos se incluyen aquellos que cuentan con un aporte del presupuesto nacional, entre ellos colegios científicos, bilingües y otras modalidades que ofrecen opciones de formación adicional a la oferta tradicional de los colegios públicos para poblaciones que no tienen acceso a la educación privada”, afirmó Evelyn Hernández, funcionaria de la OPI. 

De igual manera, se indica que el 23,29% de los estudiantes matriculados provienen de colegios privados. 

“Con este tipo de estudios, lo que se busca es tener un mayor acercamiento a la población estudiantil desde varias aristas, que sirva como insumo para la toma de decisiones”, puntualizó Hernández. 

El censo fue realizado entre abril y octubre de 2019, y en él participaron 9 574 estudiantes de grado; es decir, el 90,1% de la población en estudio.
',DATE '2020-10-21',1,1,1,1, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('¿Por qué cantamos el Himno Nacional cada 14 de septiembre a las 6:00 p.m?','Cada 14 de septiembre, a las 6:00 p. m., el país revive la tradición de entonar el Himno Nacional en Costa Rica. Este año no será la excepción, en vísperas de cumplir 201 años de vida independiente, luego de llegar al Bicentenario en el 2021.

La tradición de cantar el Himno Nacional cada 14 de septiembre a las 6:00 p. m., se estableció a partir del gobierno de Luis Alberto Monge, en 1982; en el marco de la Guerra Civil en Centroamérica.

Esta guerrilla estableció tensión en el istmo centroamericano y con la llegada al poder de Ronald Reagan en Estados Unidos, se pretendía el establecimiento de un “Frente Sur” en Costa Rica, como medida de presión a la dictadura Sandinista en Nicaragua.

Para el Dr. David Díaz Arias, director del Centro de Investigaciones Históricas de América Central (CIHAC) de la Universidad de Costa Rica, esta celebración constituyó un marco nuevo de la fiesta a la independencia en un momento de crisis muy fuerte en Centroamérica, así como a lo interno del país.

Fue en este contexto, posterior a una crisis económica y siendo frontera sur de la Revolución Sandinista, que el ex presidente Monge implementó la denominada “Declaración Perpetua de Neutralidad Costarricense” como medida de oposición a la intención del presidente Reagan, de establecer un ejército en el país.

La Declaración Perpetua de Neutralidad Costarricense fue proclamada en 1983, en la cual el exmandatario Luis Alberto Monge, estableció la neutralidad perpetua, activa y no armada de Costa Rica ante cualquier conflicto bélico. Esta acción representó la culminación del proceso de desarme unilateral y voluntario, que se originó en 1949.
Monge reordenó las fiestas patrias, incluyendo al 14 de septiembre como parte de las celebraciones; contrario a las disposiciones del mandatario anterior, Rodrigo Carazo Odio, quien estableció que las festividades se realizarían únicamente el 15 de septiembre y con concentración en el Estadio Nacional de Costa Rica.

El ex mandatario Monge, estableció como parte de las festividades que niños, niñas y jóvenes de escuelas y colegios marcharan en las calles y que se estableciera una cadena nacional, en radio y televisión, con el propósito de cantar el Himno Nacional el 14 de septiembre a las 6:00 p.m., en un acto que unificara a la ciudadanía.

La tradición del “Desfile de los Faroles” y la llegada de la Antorcha de la Independencia se establecieron varios años antes, en 1949, como medidas para enriquecer las celebraciones del 14 de septiembre en el país.

La tradición del desfile de los faroles inició en 1949, ante el rescate de los valores patrios. Por este motivo, el profesor Víctor Manuel Ureña Arguedas, director provincial de las Escuelas de San José, organizó oficialmente el desfile de los faroles y encomendó a los docentes de escuelas y colegios, realizar esta actividad cada año el 14 de septiembre, a las 6:00 p.m., con el objetivo de inculcar el espíritu cívico en la ciudadanía.

“El canto del himno nacional y el desfile de los faroles, constituyen una recuperación de la fiesta patria que había perdido mucho brillo, en la década de 1970. Principalmente por la pérdida del eje que se centraba en los niños y niñas y sólo contemplaba a los jóvenes en las celebraciones en el Estadio Nacional”, expresó el historiador David Díaz.

“Ambas tradiciones constituyeron un esfuerzo importante de la recuperación y popularización de esa fiesta en sitios públicos y las calles. Así como para impulsar el nacionalismo costarricense en el marco de la crisis centroamericana que atravesó el país”, concluyó el académico.',DATE '2022-09-14',1,2,4,2, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('La UCR creó una guía sobre pruebas estandarizadas de alto impacto','El Instituto de Investigaciones Psicológicas (IIP) de la Universidad de Costa Rica (UCR) publicó una guía sobre los estándares de calidad para las Pruebas Estandarizadas de Alto Impacto en diversos contextos académicos y profesionales del país.

Las Pruebas Estandarizadas son dispositivos o procedimientos evaluativos que brindan muestras de la conducta, características, aptitudes y destrezas de las personas evaluadas, las cuales se aplican en poblaciones muy grandes; tal como se realiza en los procesos de admisión a universidades o la incorporación a colegios profesionales.

“Las pruebas estandarizadas de alto impacto y sus resultados afectan directamente las vidas de las personas; desde entrar a la universidad, obtener el bachillerato o ejercer una profesión”, expresó la Dra. Vanessa Smith Castro, psicóloga y creadora del proyecto.

Este esfuerzo es producto de la Comisión Interinstitucional Estándares de Calidad del IIP, conformada desde el 2016, ante la necesidad de una instancia que estableciera estándares de calidad para las Pruebas de Alto Impacto que se aplican en el país desde diversos contextos. 

A lo interno de la Comisión Interinstitucional, coordinada por el IIP, participan diversas unidades de la Universidad de Costa Rica, tales como la Maestría en Evaluación Educativa, el Posgrado en Especialidades Médicas, y la Oficina de Recursos Humanos, entre otras; así como entidades externas a la UCR, incluidas el Instituto Tecnológico, el Colegio de Abogados y Abogadas, el Colegio de Profesionales en Psicología, la Dirección General del Servicio Civil y, el Ministerio de Educación Pública.

El IIP busca con esta nueva publicación ofrecer insumos para la conformación de pruebas estandarizadas que sean justas, válidas, éticas y científicas. La guía será compartida con entidades tales como universidades públicas, colegios profesionales, centros de investigación, ministerios y otras entidades que elaboren y apliquen Pruebas Estandarizadas,  o bien, aquellas que se encarguen del estudio de las mismas.

Según la Dra. Eiliana Montero Rojas, evaluadora educativa y estadística, el uso de Pruebas Estandarizadas de Alto Impacto implica un proceso de construcción y validación guiado científicamente, utilizando los más altos estándares de calidad para garantizar la confiabilidad y validez de las inferencias que se realizan en dichas evaluaciones.

La académica afirmó que con la publicación de esta guía se busca erradicar los mitos alrededor de estas pruebas y sus usos, con el objetivo de promover la práctica de una cultura rigurosa, transparente, ética y justa alrededor de este tipo de procedimientos evaluativos.

Para Montero, la guía para las Pruebas Estandarizadas constituye un primer esfuerzo, en la generación de productos y estándares de calidad, los cuales sin embargo, requieren de una continua actualización de los tópicos y lineamientos.

“El avance en metodologías y construcción de pruebas estandarizadas hace necesarias la continua actualización de los temas y la inclusión de temas emergentes. Por lo que es un trabajo en proceso”, aclaró la investigadora que lidera la iniciativa. 

Debido a que se trata de exámenes de grandes consecuencias para la vida y el desarrollo de las personas, las pruebas deben ser construidas, validadas y aplicadas respetando la tradición científica en psicometría y medición educativa.

El documento generado tiene como propósito orientar la labor y los planes de mejoramiento de las instituciones involucradas con la validez, equidad y ética en la aplicación de las Pruebas Estandarizadas en contextos académicos y profesionales.

Las investigadoras involucradas en este proceso enfatizan en que las recomendaciones constituyen un primer paso y aspiran a una futura acreditación, con el fin de que estas guías y el trabajo de la Comisión Interinstitucional se conviertan en referentes en materia de elaboración de pruebas estandarizadas en el país.',DATE '2022-09-09',3,2,1,2, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
values('Voz experta: Negociar el FEES','Hace pocos días inició un proceso de negociación del Fondo Especial para la Educación Superior (FEES), que se da en el seno de la Comisión de Enlace, constituida por representantes de las universidades públicas y del gobierno. Este proceso, según una lectura estricta del artículo 85 de la Constitución Política de nuestro país debería darse cada 5 años, pero en los últimos años ha ocurrido anualmente.

Negociar, según la segunda acepción del Diccionario de la Real Academia Española, significa “Tratar asuntos públicos o privados procurando su mejor logro.” Debería ser un proceso de diálogo honesto, claro, basado en datos y hechos que lleve a un acuerdo entre las partes. Puede ser corto, en el que las partes llegan a un acuerdo rápido o lento con muchas discusiones, propuestas y contrapropuestas. No es, ni debería ser uno en el que una de las partes imponga sus condiciones. Debe prevalecer un interés común, en el caso de la negociación del FEES, más aún, un interés superior.

Este año, la negociación del FFES inició tardíamente, y luego de dos sesiones de negociación, el conflicto estalló. Las universidades iniciaron la negociación con su propuesta en la primera sesión y el Gobierno hizo la suya en la segunda. Hasta allí todo parecía ir bien. Sin embargo, el Gobierno acompañó su propuesta con una declaración pública de exigencias a las universidades, en tono confrontativo e insultante.

En la primera parte de esta declaración, el Gobierno enfrenta la educación básica y media a la universitaria. Dice que “Estamos ante un gran dilema, porque todos los niveles de educación son importantes.” Hasta aquí estamos de acuerdo, pero luego, hace un salto ilógico al decir: “¿A quién damos más quitándole al otro?” No, señora Ministra de Educación, a todos debemos darles más y satisfacer sus necesidades. Nuestra Constitución Política, en su Artículo 78 dice que “En la educación estatal, incluida la superior, el gasto público no será inferior al ocho por ciento (8%) anual del producto interno bruto, de acuerdo con la ley, sin perjuicio de lo establecido en los artículos 84 y 85 de esta Constitución.” Actualmente ese gasto apenas llega al 6 %. Si “El estado de las escuelas y colegios es deplorable, la infraestructura está en un nivel de deterioro sin precedentes, maestros trabajan con las uñas…”, si esto es así no es porque “El presupuesto de las Universidades viene creciendo de manera sostenida desde el año 2010, mientras que el presupuesto del MEP decrece, con los resultados no satisfactorios en calidad educativa que estamos teniendo.” No, señora Ministra, este estado de cosas no se debe al “crecimiento del FEES” sino a la baja inversión del Estado en educación. Por otra parte, la proporción del FEES en el presupuesto de la educación se ha mantenido casi constante alrededor del 19 al 20%.

La declaración del Gobierno, luego de enfrentar los estudiantes universitarios a los estudiantes del MEP en la primera página, con un nuevo salto argumentativo dice, cínicamente en la segunda página, “No estamos propiciando una lucha entre estudiantes del MEP y estudiantes de las universidades porque ambos son igualmente importantes. Debemos velar por los derechos de ambas poblaciones.”

Luego viene la lista de 10 “vehementes solicitudes”. No me referiré a ellas una a una, ya que todas estas solicitudes ya se están cumpliendo de muchas formas. Me detengo en la número 9, que es la que califico de insultante: “Que (las Universidades) sean transparentes, no engañen a la opinión ni a la comunidad estudiantil, que muestren datos incluyendo el costo por estudiante y la asignación real en becas.”

No señora Ministra, las Universidades públicas no engañan “ni a la opinión (¿pública?) ni a la comunidad estudiantil…” La Universidad de Costa Rica está entre las primeras instituciones en el “Índice de Transparencia del Sector Público, ITSP” que publica la Defensoría de los Habitantes.',DATE '2022-08-23',2,2,3,2, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');


insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
values('Aumento en intereses no da tregua al bolsillo nacional','Tasa de política monetaria subió a 8,5% y condiciona intereses de préstamos
En agosto pasado, la variación del IPC alcanzó el 12,13%, siendo la inflación más alta en el país en los últimos 13 años.
Con la más alta Inflación Interanual y Tasa de Política Monetaria de la última década, así cerró la noche del 14 de setiembre, cuando la Junta Directiva del Banco Central de Costa Rica (BCCR) anunció mediante comunicado de prensa el sétimo aumento consecutivo de la Tasa de Política Monetaria (TPM). El incremento de 7,50% a 8,50%, representa un aumento de 7,75 puntos porcentuales desde diciembre del 2021. 

Bajo esta premisa, los aumentos de la tasa tienen implicaciones muy serias en todo el sistema financiero y la economía nacional. La TPM parte como referencia de las entidades financieras, intermediarios y otros, para calcular el costo económico en caso de requerir recursos del Banco Central; además parte como base de cobro para el cálculo de las tasas de créditos al público, es decir, los aumentos de la TPM terminan traspasándose a las tasas activas, que son las que paga el público y las empresas por sus créditos.

“Los efectos para las familias y el sector productivo que requieren dinero o que tienen préstamos es de estrujamiento en sus finanzas y de desaceleración de la actividad económica.  Si las personas tienen deudas con tasas variables, las mismas van a aumentar reduciendo el ingreso disponible y necesariamente el consumo de otros bienes y servicios”, indicó Olman Segura Bonilla, Director del Centro Internacional de Política Económica para el Desarrollo Sostenible (CINPE), de la Universidad Nacional. 

Así mismo, las empresas igualmente deberán acomodar sus finanzas y de hecho tenderán a reducir sus gastos para ajustar su presupuesto a la nueva realidad. También, ante el aumento de las tasas de interés se reduce la propensión al riesgo y a las inversiones en nuevos emprendimientos.

Costa Rica, de acuerdo a el Índice Mensual de Actividad Económica (IMAE) ha registrado 12 meses seguidos de desaceleración, pasando de 10,3% en enero del 2022, a 3,5% en agosto de este año. Por otra parte, el país registró el mayor aumento del índice de precios al consumidor (IPC), siendo un 12,13% de inflación interanual de setiembre del 2021 a agosto 2022.

Los aumentos de la TPM, a pesar de la ralentización de la economía, se realizan con la intención de controlar la inflación. Ésta, a diferencia del 2021 en que terminó dentro del rango meta que había establecido el BCCR de entre 2% y 4%, siendo 3,30%; en el 2022 definitivamente terminará fuera de ese rango, pues de enero a agosto de este año ya alcanzó 9,45%.

Según el Instituto Nacional de Estadística y Censos (INEC), el transporte, los alimentos y bebidas no alcohólicas, y comidas fuera del hogar son los que más contribuyen al aumento de la inflación. Este tipo de gastos representan una mayor porción de los ingresos de las personas de ingresos más bajos, lo que convierte lamentablemente a la inflación como el “impuesto enemigo” que puede enfrentar la población. 

“El Banco Central y el gobierno deben considerar esta situación de un doble estrujamiento a los bolsillos de las familias más pobres y endeudadas, que en el corto plazo tendrán que enfrentar aumentos en el pago de intereses y aumento de precios en su canasta básica, y quizás hasta un tercer efecto que puede ser la pérdida de empleo ante la desaceleración de la economía”, manifestó el Director Segura.

A su vez Segura calificó como preciso y urgente un plan de reactivación económica y el anuncio de una política económica clara que reduzca la incertidumbre, y genere estabilidad y confianza en el sector productivo nacional.',DATE '2022-09-06',1,3,5,2, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');


insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('A 12 años del terremoto de Cinchona','“Costa Rica, 8 de enero del 2009, 13:21 pm, hora local, un terremoto con magnitud de momento sísmico, MW= 6,2, ubicado 4 km hacia el Suroeste de Cinchona de Sarapiquí de Alajuela, a una profundidad de 7 km, generó una basta cantidad de deslizamientos que provocaron la muerte a 22 personas, 100 desaparecidos y gran cantidad de heridos, también daños estructurales en casas y edificios cercanos”, así consta en el reporte oficial emitido por el Observatorio Vulcanológico y Sismológico de Costa Rica de la Universidad Nacional (Ovsicori-UNA).

Datos del instituto señalan que el evento principal estuvo asociado al sistema de fallas Vara Blanca-Ángel; un sistema de fallas ubicado en el flanco este del volcán Poás con movimiento lateral derecho y orientación Noroeste-Suroeste.

Marino Protti, sismólogo y actual director del Ovsicori, indicó que el evento fue precedido por un sismo (evento premonitor) de magnitud 4,5, ubicado 4 km al Noroeste de Fraijanes de Sabanilla de Alajuela, (a menos de 3 km del Terremoto de Cinchona), ocurrido el 7 de enero a las 10:00 hora local, el cual generó alrededor de 25 réplicas con magnitudes locales menores a 3,0.

En esa oportunidad, la red sísmica del OVSICORI-UNA localizó un total de 1032 réplicas todo el mes de enero de 2009. Asimismo, el deslizamiento ocurrido en esa falla durante el terremoto de Cinchona tuvo una duración de ~5 s, generando una caída de esfuerzos de 6.71 MPa y aceleraciones máximas en superficie de 223 gal (2.156 m/s2) en el valle central.

Durante 12 años, la misma naturaleza se ha encargado de ocultar los deslizamientos en los cerros cercanos al lugar del epicentro, la carretera se habilitó, la actividad agrícola de la zona se activó tiempo después y el poblado de Cinchona fue reubicado en Cariblanco de Sarapiquí de Alajuela, donde habitan las casi 80 familias que perdieron sus casas en el terremoto de Cinchona, la tarde del 8 de enero del 2009.',DATE '2021-01-08',1,3,4,3, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

insert into article
(title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('Situación del empleo en Costa Rica sigue delicada','El Observatorio Económico y Social (OES) de la Escuela de Economía de la Universidad Nacional (UNA), presentó un análisis sobre la situación del empleo en Costa Rica, con base en los datos obtenidos de la Encuesta Continua de Empleo del primer trimestre del 2021, a cargo de los economistas Fernando Rodríguez y Greivin Salazar, quienes consideran que volver a la situación pre covid-19 en materia de empleo implicará un esfuerzo muy grande en cuanto a crecimiento de ciertos sectores. A la vez, que jóvenes, mujeres y habitantes de zonas rurales son quienes sufren mayor afectación por problemas de desempleo e informalidad.

Una de las principales observaciones del estudio es que el dato de desempleo podría ser mayor, pues muchas personas se quedaron sin trabajo y decidieron no buscar empleo, por lo que formalmente no se les considera desempleados. Este grupo de personas que están fuera del mercado laboral incluye un porcentaje creciente de jóvenes, quienes no sólo no están trabajando, sino que tampoco están estudiando en el sistema formal.

Aquellas actividades que perdieron empleos producto de la pandemia covid-19 requerirán crecer a tasas importantes en los próximos años para que se puedan recuperar esos puestos de trabajo perdidos. En actividades vinculadas con el turismo, la actividad económica deberá crecer un 31% en dos años, para reponer los trabajos perdidos durante el 2020, mientras que en el caso de construcción se deberá crecer un 3,9% y en el sector comercial a un 5,1%, a fin de lograr el mismo objetivo.

La informalidad se alivió parcialmente durante la etapa más fuerte del confinamiento no por una mejora en las condiciones de trabajo del país, sino porque muchas personas en actividades informales perdieron su empleo y no salieron a buscar trabajo. La informalidad se sigue centrando en el pacífico costarricense, donde alcanza casi un 47% de la población ocupada a nivel nacional.
En cuanto al ingreso de las personas ocupadas, este no sufrió mayor variación en el último año, cuando se ve al total de la población, pero sí aumentó ligeramente para los hombres y disminuyó en una proporción similar para las mujeres. Cuando se desglosa el ingreso según posición en el trabajo, los asalariados y los trabajadores por cuenta propia no sufrieron mayor variación, mientras que los empleadores mejoraron su ingreso al punto de ubicarse por encima de los niveles de la pre pandemia.

Sobre los datos de desempleo, la mayoría de las personas desempleadas no tienen formación profesional: el 81% tiene secundaria completa o una formación menor y es, mayoritariamente, un grupo joven; el 62% de los desempleados tiene 34 años o menos. La región con más problemas de desempleo es la región Central, seguida de la Brunca y de la Chorotega. El desempleo continúa siendo un problema que afecta más a las mujeres, pues casi se duplica el porcentaje con respecto a los hombres. El dato es todavía más dramático en el caso de las mujeres jóvenes, pues aquí el desempleo entre mujeres de 15 a 24 años es de 58,8%, mientras que en el grupo de 25 a 34 años es de 26,4%.

A fin de retomar la recuperación del empleo, los investigadores del Observatorio Económico y Social de la Escuela de Economía llaman a aplicar medidas de estímulo productivo, que cambien la senda actual de crecimiento y rompan con las medidas contractivas aplicadas desde la política fiscal (centrada en recortes de gasto). Es fundamental—agregan—una política de recuperación de empleo con visión de género, que promueva un mayor acceso al mercado de trabajo y no se convierta en un obstáculo para ese fin. Por lo tanto, los investigadores reiteran su rechazo al Proyecto de Ley de Jornadas Extraordinarias y más bien hacen un llamado a fortalecer las iniciativas que promuevan una mayor incorporación de las mujeres al mercado laboral.',DATE '2021-07-09',3,3,6,3, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');
