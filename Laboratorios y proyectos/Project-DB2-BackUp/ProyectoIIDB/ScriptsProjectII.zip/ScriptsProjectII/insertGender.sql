USE bdproject;
INSERT INTO GENDER
(type_gender, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Femenino',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO GENDER
(type_gender, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Masculino',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO GENDER
(type_gender, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('No definido',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

