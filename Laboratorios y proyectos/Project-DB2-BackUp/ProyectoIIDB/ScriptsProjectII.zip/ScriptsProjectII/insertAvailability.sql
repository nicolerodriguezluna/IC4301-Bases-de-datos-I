use bdproject;
INSERT INTO availabilitypr
(description_availability,creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Disponible',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO availabilitypr
(description_availability,creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Agotado',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


