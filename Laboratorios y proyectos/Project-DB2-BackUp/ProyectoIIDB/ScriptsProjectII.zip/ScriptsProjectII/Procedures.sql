use bdproject;

DELIMITER //
CREATE PROCEDURE get_administratives()
BEGIN
	select administrative.id_person,id_dedication
	from administrative;
END; //
DELIMITER ;
DELIMITER //
-- Already in Java
CREATE PROCEDURE get_administrative(IN pId INT)
BEGIN
	select administrative.id_person,id_dedication
	from administrative
	where administrative.id_person = pId;
END; //
DELIMITER ;

-- Already in java
DELIMITER //
CREATE PROCEDURE get_administrators()
BEGIN
	SELECT administrator.id_person,password_admin
	from administrator;
END; //
DELIMITER ;

DELIMITER //
-- Already in java
CREATE PROCEDURE get_Administrator(in pId INT)
BEGIN
	select administrator.id_person,password_admin
	from administrator
	where administrator.id_person = pId;
END; //
DELIMITER ;

-- Get article by author is the same as get authorxarticle

DELIMITER //
-- Already in Java
CREATE PROCEDURE get_article_bydate(in pDate Date)
BEGIN
	select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
	from article
	where article.publication_date = TO_DATE(pDate,'YYYY-MM-DD') and id_status_article=0;
END; //
DELIMITER ;

-- Already in Java

DELIMITER //
CREATE PROCEDURE get_article_bycategory(IN pIdCategory INT)
BEGIN
	select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
	from article
	where article.id_art_cat = pIdCategory and id_status_article=0;
END; //
DELIMITER ;


-- Already in java
DELIMITER //
CREATE PROCEDURE get_article_bycategory_admin(in pIdCategory INT)
BEGIN
	select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
	from article
	where article.id_art_cat = pIdCategory;
END; //
DELIMITER ;

-- Already in java

DELIMITER //
CREATE PROCEDURE get_article_fullsearch(IN pidAuthor INT, in pArticleCategory INT,in pDate DATE)
BEGIN
	select id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
	from article
	inner join articlecategory
	on article.id_art_cat = articlecategory.id_article_category
	inner join authorxarticle
	ON authorxarticle.id_article_autart = article.id_article
	where articlecategory.id_article_category = pArticleCategory AND article.publication_date = TO_DATE(pDate,'YYYY-MM-DD') AND authorxarticle.id_author_autart = pidAuthor
	order by(title_article);
END; //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_articlecategories()
BEGIN
	select id_article_category,name_category,description_category
	from articlecategory;
END; //
DELIMITER ;

-- CREATE OR REPLACE PROCEDURE get_articlecategory_descr(pIdCategory in NUMBER,pCursorDescription out sys_refcursor)
-- AS
-- BEGIN
  --  OPEN pCursorDescription for
    -- SELECT description_category
    -- from articlecategory
    -- where id_article_category = pIdCategory;
-- END;

-- Already in Java
DELIMITER //
CREATE PROCEDURE get_authors()
BEGIN
	SELECT author.id_person,id_author_cathegory
	from author;
END;//
DELIMITER ;

-- Already in Java
DELIMITER //
CREATE PROCEDURE get_author_categories()
BEGIN
	SELECT id_author_category,type_category
	from authorcategory;
END; //
DELIMITER ;

-- Already in java
DELIMITER //
CREATE PROCEDURE get_author_bycategory(IN pIdCategory INT)
BEGIN
	SELECT author.id_person,id_author_cathegory
	from author
	inner join person
	on person.id_person = author.id_person
	where id_author_cathegory = pIdCategory;
END;
DELIMITER;

-- Already in java as getArticleByAuthor
DELIMITER //
CREATE PROCEDURE get_articles_byauthor(IN pIdAuthor INT)
BEGIN
    SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    from article
    inner join authorxarticle
    on article.id_article = authorxarticle.id_article_autart
    where authorxarticle.id_author_autart = pIdAuthor  and id_status_article=0;
END; //
DELIMITER ;

-- Returns all contents from authorxarticles
DELIMITER //
CREATE PROCEDURE get_authorxarticle()
BEGIN
    SELECT id_author_autart, id_article_autart
    from authorxarticle;
END; //
DELIMITER ;

-- Already in java
DELIMITER //
CREATE PROCEDURE get_availability()
BEGIN
    SELECT id_availability,description_availability
    from availabilitypr;
END; //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_campus()
BEGIN
    select id_campus,name_campus,id_university,id_district
    from campus;
END; //
DELIMITER ;

-- Already in java
DELIMITER //
CREATE PROCEDURE get_campusbycollege(IN pIdCollege INT)
BEGIN
    select  id_campus,name_campus,id_university,id_district
    from campus
    where id_university = pIdcollege;
END; //
DELIMITER ;

-- Already in java
DELIMITER //
CREATE PROCEDURE get_canton_byarea(IN pIdArea INT)
BEGIN
    select id_canton,name_canton,id_area
    from canton
    where id_area = pIdArea;
END; //
DELIMITER ;

DELIMITER //
create PROCEDURE get_canton(IN pnIdCanton INT)
BEGIN
    SELECT id_canton,name_canton,id_area
    FROM canton
    WHERE id_canton = pnidcanton;
END; //
DELIMITER ;

DELIMITER //
create PROCEDURE get_cantons()
BEGIN
    select id_canton,name_canton,id_area
    from canton;
END; //
DELIMITER ;

-- Already in java
DELIMITER //
CREATE PROCEDURE get_catalogs()
begin
    select id_catalog,id_newspaper,description_catalog
    from catalog;
END; //
DELIMITER ;

-- Already in Java
DELIMITER //
CREATE PROCEDURE get_catalogs_byPaper(IN pidNPaper INT)
begin
    select id_catalog,id_newspaper,description_catalog
    from catalog
    where id_newspaper = pidNPaper;
END; //
DELIMITER ;

-- Already in java
DELIMITER //
CREATE PROCEDURE get_catalog(IN pidCatalog INT)
BEGIN
    select id_catalog,id_newspaper,description_catalog
    from catalog
    where id_catalog = pidCatalog;
END; //
DELIMITER ;

-- Already in java
DELIMITER //
CREATE PROCEDURE get_colleges()
BEGIN
    select id_college,name_college
    from college;
END; //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_user_person(IN pidUser INT)
begin
select b.id_person,b.first_name,b.second_name,b.first_surname,b.second_surname,b.identification_card,b.datebirth,b.id_quad,b.id_gender,b.exact_location,b.id_district
from(select person.id_person,first_name,second_name,first_surname,second_surname,identification_card,datebirth,id_quad,id_gender,exact_location,id_district
    from person
    inner join userdb
    on person.id_person = userdb.id_person
    where userdb.id_user = pidUser) AS b
LIMIT 1;
END; DELIMITER ;

DELIMITER //
create PROCEDURE update_committee_description(IN pidCommittee INT,IN pNewDescriptionCommittee VARCHAR(100))
BEGIN
    UPDATE committe
    SET committe.description_committe = pNewDescriptionCommittee
    WHERE committe.id_committe= pidCommittee;
    COMMIT;
END;//
DELIMITER ;

DELIMITER //
create  PROCEDURE get_articlecategory_descr(IN pIdCategory int)
BEGIN
    SELECT description_category
    from articlecategory
    where id_article_category = pIdCategory;
END;//
DELIMITER ;

DELIMITER //
create PROCEDURE get_committe_byCollege(IN pCampus inT)
BEGIN 
Select committe.id_committe,committe.description_committe,id_campus
from committe
where committe.id_campus = pCampus;
END; //
DELIMITER ;

DELIMITER //
CREATE  PROCEDURE delete_favourite_unique(IN pidArtRev  INT, IN pidUserRev INT)
BEGIN
    DELETE FROM favourite
    WHERE favourite.id_user_fav = pidUserRev AND favourite.id_article_fav = pidArtRev;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
create PROCEDURE update_photo_product( in pidProduct int,in pNewRoute VARCHAR(200))
BEGIN
    UPDATE photo
    SET route = pnewRoute
    WHERE id_product = pidProduct;
    COMMIT;
END; //
DELIMITER ;

DELIMITER //
create PROCEDURE update_photo_article(IN pidArticle INT,IN pNewRoute VARCHAR(200))
BEGIN
    UPDATE photo
    SET route = pnewRoute
    WHERE id_article = pidArticle;
    COMMIT;
END; //
DELIMITER ;

select * from author;
SELECT * FROM personxcommitte;
select * from person;
select * from photo;
select * from article;


