USE BDPROJECT;
INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (22509878,1, 1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (64854789,2, 2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (22707713,3, 3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (71602741,4, 1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (88906576,5, 2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (22145391,6, 3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (22144536,7, 1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (88375692,8,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (22142111,9,3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (89098162,10,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (28716278,11,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (84854780,12,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (22707711,13,3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (88192817,14,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (22817627,15,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (22145123,16,3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (22144231,17,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (88375618,18,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (22142019,19,3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT into phone
(number_phone,id_person,id_phone_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(89098117,20,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');
