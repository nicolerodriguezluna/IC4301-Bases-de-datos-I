use bdproject;
INSERT INTO Catalog
(description_catalog,id_newspaper,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES ('InvierTEC',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO Catalog
(description_catalog,id_newspaper,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES ('UCR te vende',2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO Catalog
(description_catalog,id_newspaper,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES ('UNA te vende',3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

