use bdproject;

Insert into campus
(name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Campus Tecnológico Local San José',1,1, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');


Insert into campus
(name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Campus Central Tecnológico Cartago',1,131, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

Insert into campus
(name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Campus Tecnológico Local San Carlos',1,71, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

Insert into campus
(name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Centro Académico de Alajuela',1,245, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

Insert into campus
(name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Centro Académico de Limón',1,471, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

Insert into campus
(name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Ciudad Universitaria Rodrigo Facio',2,67, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

Insert into campus
(name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Sede de Occidente',2,258, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

Insert into campus
(name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Recinto de Paraíso',2,134, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

Insert into campus
(name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Campus Benjamín Núñez Presbítero',3,360, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

Insert into campus
(name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Campus Omar Dengo',3,362, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

Insert into campus
(name_campus,id_university,id_district, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Campus Sarapiquí',3,396, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');






