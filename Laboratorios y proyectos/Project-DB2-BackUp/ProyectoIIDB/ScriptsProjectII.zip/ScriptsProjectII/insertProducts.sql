use bdproject;

INSERT INTO product
(cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (50,'Artículo del Espacio',1,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO product
(cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (50,'Una breve Historia de Todo',1,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO product
(cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (75,'Genios de la Historia',1,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO product
(cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (100,'Kit Molecular',2,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO product
(cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (80,'Probetas',2,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO product
(cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (30,'Artículo de Robótica',2,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO product
(cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (200,'Telescopio',3,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO product
(cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (150,'Tabla Periódica',3,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO product
(cost_product,description_product,id_catalog_pr,id_availability, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (150,'Artículo Inteligencia Artificial',3,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

