
use bdproject;
INSERT INTO articlecategory
(name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Investigación Cinetífica','Esta categoría incluye artículos relacionados a distintas áreas de la ciencia ',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO articlecategory
(name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Trabajo Social','Esta categoría incluye artículos relacionados a distintas áreas del trabajo social',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO articlecategory
(name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Política','Esta categoría incluye artículos relacionados a distintas áreas de la política',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO articlecategory
(name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Cultura','Esta categoría incluye artículos relacionados a distintas áreas de cultura',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO articlecategory
(name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Deportes','Esta categoría incluye artículos relacionados a distintas áreas de deportes',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO articlecategory
(name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Sucesos','Esta categoría incluye artículos relacionados a distintas áreas de sucesos',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO articlecategory
(name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Opinión','Esta categoría incluye artículos de opinión sobre diversas materias',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO articlecategory
(name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Ofertas de Trabajo','Esta categoría incluye artículos sobre ofertas de trabajo',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO articlecategory
(name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Eventos Sociales','Esta categoría incluye artículos de eventos sociales',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO articlecategory
(name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Eventos Ambientales','Esta categoría incluye artículos sobre eventos ambientales',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO articlecategory
(name_category,description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Eventos Deportivos','Esta categoría incluye artículos sobre eventos deportivos',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');