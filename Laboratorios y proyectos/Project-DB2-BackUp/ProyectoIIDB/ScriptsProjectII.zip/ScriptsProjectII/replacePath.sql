Update photo
set route = replace(route,'C:\app\JeffreyLeiva\oradata\photosdb','C:\\app\\JeffreyLeiva\\oradata\\photosdb')
where id_photo is not null;

select * from article;

update administrator
set password_Admin = 'c194edac3bc7561e37a883dfb5749fcb'
where id_person = 19;

select * from article;

show triggers