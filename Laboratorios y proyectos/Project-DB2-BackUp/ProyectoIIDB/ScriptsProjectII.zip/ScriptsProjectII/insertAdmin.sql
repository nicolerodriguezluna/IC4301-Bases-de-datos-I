use bdproject;
INSERT INTO administrator
(id_person, password_admin, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(18, 'n0tt2003Nikol30528', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO administrator
(id_person, password_admin, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(19, '01Imagine1998D1sc4r3d0047', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

