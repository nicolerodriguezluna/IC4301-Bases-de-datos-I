use bdproject;
INSERT INTO dedication
(description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES ('Docente',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO dedication
(description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES ('Director',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO dedication
(description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES ('Coordinador',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO dedication
(description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES ('Secretariado',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO dedication
(description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES ('Receptionista',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO dedication
(description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES ('Tesorería',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO dedication
(description_dedication,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES ('Investigador',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');



