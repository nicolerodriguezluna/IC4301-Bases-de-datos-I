use bdproject;
INSERT INTO student
(id_person,student_card, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (1,2021016720,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO student
(id_person,student_card, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (2,2021077818,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO student
(id_person,student_card, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (3,2021042885,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO student
(id_person,student_card, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (4,2021946102,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO student
(id_person,student_card, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (5,2021892532,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO student
(id_person,student_card, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (6,2021345671,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO student
(id_person,student_card, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (7,2019345671,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO student
(id_person,student_card, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (8,2019890912,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');