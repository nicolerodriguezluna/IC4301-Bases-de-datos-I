delimiter //
create PROCEDURE get_college_byauthor(in pidAuthor int)
BEGIN
    SELECT id_college,name_college
    from college
    inner join campus
    on college.id_college = campus.id_university
    inner join person
    on person.id_quad = campus.id_campus
    inner join author
    on person.id_person = author.id_person
    where author.id_person = pidAuthor;
END;//
delimiter ;



