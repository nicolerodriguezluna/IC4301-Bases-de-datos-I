use bdproject;

insert into personxcommitte
(id_person,id_committe, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (12,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into personxcommitte
(id_person,id_committe, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (13,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into personxcommitte
(id_person,id_committe, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (14,3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into personxcommitte
(id_person,id_committe, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (15,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into personxcommitte
(id_person,id_committe, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (16,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into personxcommitte
(id_person,id_committe, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (17,3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');
