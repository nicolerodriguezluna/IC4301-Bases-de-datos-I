USE bdproject;
INSERT INTO digitalnewspaper
(name_digital_newspaper,id_quad, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Hoy en el Tec',2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO digitalnewspaper
(name_digital_newspaper,id_quad, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Noticias UCR',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO digitalnewspaper
(name_digital_newspaper,id_quad, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('UNA Comunica',10,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

