DELIMITER //
CREATE TRIGGER before_insert_username
before insert on userdb
for each row
begin
    insert into logdb
    (systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW USERNAME', NULL,new.user_name);
end; //
delimiter ;


DELIMITER //
Create TRIGGER before_insert_name_dignews
before insert on digitalnewspaper
for each row
begin
    insert into logdb
    (systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW DIG_NEWS NAME',NULL,new.name_digital_newspaper);
end; //
DELIMITER ;


delimiter //
create  TRIGGER before_insert_dedi_descrp
before insert on dedication
for each row
begin
    insert into logdb
    (systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW DESCRIPTION DEDICATION',NULL,new.description_dedication);
end; //
delimiter ;



DELIMITER //
create  TRIGGER before_insert_country_name
before insert on country
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW NAME COUNTRY',NULL,new.name_country);
end; //
DELIMITER ;


DELIMITER //
create TRIGGER before_insert_committe_descrp
before insert on committe
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW DESCRIPTION COMMITTE',NULL,new.description_committe);
end; //
DELIMITER ;


DELIMITER //
create TRIGGER before_insert_college_name
before insert on college
for each row
begin
		insert into logdb (systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW NAME COLLEGE',NULL,
		new.name_college);
END; //
DELIMITER ;

select * from authorxarticle;
DELIMITER //
create TRIGGER before_insert_catalog_descrp
before insert on catalog
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW DESCRIPTION CATALOG',NULL,new.description_catalog);
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_insert_catalog_news
before insert on catalog
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW NEWSPAPER CATALOG',NULL,(SELECT name_digital_newspaper from digitalnewspaper
		where new.id_newspaper = digitalnewspaper.id_digital_newspaper));
end; //
DELIMITER ;

DELIMITER //
create  TRIGGER before_insert_canton_area
before insert on canton
for each row
begin
	 insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW CANTON AREA',null,(SELECT name_province from province
		where new.id_area = province.id_province));
end; //
DELIMITER ;


DELIMITER //
create TRIGGER before_insert_canton_name
before insert on canton
for each row
begin
		insert into logdb (systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW CANTON NAME',null,
		new.name_canton);
end;// 
DELIMITER ;

DELIMITER //
create TRIGGER before_insert_campus_district
before insert on campus
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW DISTRICT CAMPUS',NULL,(SELECT name_district from district
		where new.id_district = district.id_district));
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_insert_campus_name
before insert on campus
for each row
begin
		 insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW CAMPUS NAME',NULL,
		new.name_campus);
end; //
DELIMITER ;

delimiter //
create TRIGGER before_insert_campus_uni
before insert on campus
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW CAMPUS COLLEGE',NULL,(SELECT name_college from college
		where new.id_university = college.id_college));
END; //
DELIMITER ;


DELIMITER //
create TRIGGER before_insert_available_descrp
before insert on availabilitypr
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW AVAILABILITY DESCR',NULL,
		new.description_availability);
end; //
DELIMITER ;

delimiter //
create  TRIGGER before_insert_author_category
before insert on author
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW AUTHOR CATEGORY',NULL,(SELECT type_category from authorcategory
		where new.id_author_cathegory = authorcategory.id_author_category));
END; //
delimiter ;

DELIMITER //
create TRIGGER before_insert_authorcat_type
before insert on authorcategory
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW AUTHOR CATEGORY',NULL,new.type_category);
END; //
delimiter ;

DELIMITER //
create TRIGGER before_insert_article_cat_name
before insert on articlecategory
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW NAME CATEGORY',NULL,new.name_category);
end; //
DELIMITER ;


DELIMITER //
create TRIGGER before_insertNEW_article_category
before insert on articlecategory
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW ARTICLE CATEGORY',NULL,(SELECT name_category from articlecategory
		where new.id_art_cat = articlecategory.id_article_category));
end; //
DELIMITER ;



DELIMITER //
create TRIGGER before_insert_article_committe
before insert on article
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP,'NEW ARTICLE COMMITTE',null,(SELECT description_committe from committe
		where new.id_committe_art = committe.id_committe));
END; // 
DELIMITER ;

delimiter //
create TRIGGER before_insert_article_note
before insert on article
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW ARTICLE NOTE',NULL,new.text_note);
end; //
delimiter ;


DELIMITER //
create TRIGGER before_insert_article_paper
before insert on article
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW ARTICLE NEWSPAPER',NULL,(SELECT  name_digital_newspaper from digitalnewspaper
		where new.id_dig_news = digitalnewspaper.id_digital_newspaper));
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_insert_article_status
before insert on article
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW ARTICLE STATUS',null,(SELECT  name_status from status
		where new.id_status_article = status.id_status));
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_insert_article_title
before insert on article
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW TITLE ARTICLE',NULL,new.title_article);
END; //
DELIMITER ;

DELIMITER //
create TRIGGER before_insert_artcat_descrp
before insert on articlecategory
for each row
begin
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW ARTICLE CAT DESCR',NULL,new.description_category);
END; //
DELIMITER ;


DELIMITER //
create TRIGGER before_insert_article_date
before insert on article
for each row
BEGIN
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW PUBLI DATE ARTICLE',NULL,
		cast(new.publication_date as char));
end; //
DELIMITER ;


DELIMITER //
create TRIGGER before_ins_catalog_descr
before insert on catalog 
for each row
begin 
    insert into logdb (systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW CATALOG DESCR',NULL, new.description_catalog);
END ; //
DELIMITER ;


DELIMITER //
create TRIGGER before_insert_newadministrative
before insert on administrative
for each row
BEGIN
    INSERT INTO logdb(systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW ADMIN DEDICATION',NULL,(SELECT description_dedication from dedication
    where new.id_dedication = dedication.id_dedication));
END ; //
DELIMITER ;


DELIMITER //
create TRIGGER before_insert_newadministrator
BEFORE insert ON administrator
for each row
begin 
    INSERT INTO logdb
    (systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW PASSWORD ADMIN',NULL,new.password_admin);
END ; //
DELIMITER ;

DELIMITER //
create TRIGGER before_insert_campus_district
before insert on campus
for each row 
begin
		insert into logdb(systemdate,time_log,change_descrp,previous_text,current_text)
        VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW DISTRICT CAMPUS',NULL,(SELECT name_district from district
        where new.id_district = district.id_district));
END; //
DELIMITER ;
