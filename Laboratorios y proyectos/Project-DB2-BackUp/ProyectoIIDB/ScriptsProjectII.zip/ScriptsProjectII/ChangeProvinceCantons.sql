UPDATE CANTON
SET id_area = 4
where id_canton between 37 and 46;

update canton
set id_area = 3
where id_canton between 47 and 54;