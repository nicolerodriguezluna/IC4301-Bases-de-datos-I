use bdproject;

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('zmelissa@estudiantec.cr',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('scatalina@estudiantec.cr',2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('falejandro@estudiantec.cr',3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('ppaula@estudiantec.cr',4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('gariana@estudiantec.cr',5,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('pisabel@ucr.ac.cr',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('rkenneth@ucr.ac.cr',7,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('mjezabel@ucr.ac.cr',8,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('rluis@est.una.ac.cr',9,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('ljeffrey@est.una.ac.cr',10,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('pesteban@est.una.ac.cr',11,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('vandres@estudiantec.cr',12,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('sfrancisco@estudiantec.cr',13,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('rhilda@estudiantec.cr',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into email
(address_email,id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('fcarlos@estudiantec.cr',15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO email( address_email, id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES( 'vjames@estudiantec.cr', 16,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO email( address_email, id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES( 'mpedro@ucr.ac.cr', 17,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO email( address_email, id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES( 'brachel@ucr.ac.cr', 18,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO email( address_email, id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES( 'omariana@ucr.ac.cr', 19,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO email( address_email, id_person_mail, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES( 'ajeffry@est.una.ac.cr', 20,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');
