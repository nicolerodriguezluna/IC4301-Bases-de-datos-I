USE bdproject;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Administrative(
    id_person INT NOT NULL auto_increment,
    id_dedication INT NOT NULL,
    creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_person)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE administrator(
    id_person INT NOT NULL auto_increment,
    password_Admin VARCHAR(200) NOT NULL,
    creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_person)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Article(
    id_article INT NOT NULL AUTO_INCREMENT,
    title_article VARCHAR(100) NOT NULL,
    text_note VARCHAR(4000) NOT NULL,
    publication_date DATETIME NOT NULL,
    id_status_article INT NOT NULL,
    id_dig_news INT NOT NULL,
    id_art_cat INT NOT NULL,
    id_committe_art INT NOT NULL,
    creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_article)
)auto_increment = 1;


-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE ArticleCategory(
    id_article_category INT NOT NULL auto_increment,
    name_category VARCHAR(30) NOT NULL,
    description_category VARCHAR(1000) NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_article_category)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Author(
    id_person INT NOT NULL,
    id_author_cathegory INT NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_person)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE authorcategory(
    id_author_category INT NOT NULL auto_increment,
    type_category VARCHAR(30) NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY(id_author_category)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Authorxarticle(
    id_author_autart INT NOT NULL,
    id_article_autart INT NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_author_autart,id_article_autart)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Availabilitypr(
    id_availability INT NOT NULL auto_increment,
    description_availability VARCHAR(100) NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY(id_availability)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Campus(
    id_campus INT NOT NULL auto_increment,
    name_campus VARCHAR(100) NOT NULL,
    id_university INT NOT NULL,
    id_district INT NOT NULL,
	creationDate DATETIME,
	userId VARCHAR(1000),
	lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_campus)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Canton(
	id_canton INT NOT NULL auto_increment,
	name_canton VARCHAR(100)  NOT NULL,    
	id_area INT NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY(id_canton)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Catalog(
    id_catalog INT NOT NULL auto_increment,
    id_newspaper INT NOT NULL,
    description_catalog VARCHAR(1000)  NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_catalog)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE College(
    id_college INT NOT NULL auto_increment,
    name_college VARCHAR(100)  NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    Primary key(id_college)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Committe(
    id_committe INT NOT NULL auto_increment,
    description_committe VARCHAR(100) NOT NULL,
    creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    id_campus INT NOT NULL,
    primary key (id_committe)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Country(
    id_country INT NOT NULL auto_increment,
    name_country VARCHAR(60) NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_country)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Dedication(
    id_dedication INT NOT NULL auto_increment,
    description_dedication VARCHAR(30) NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_dedication)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE digitalnewspaper(
    id_digital_newspaper INT NOT NULL auto_increment,
    name_digital_newspaper VARCHAR(30) NOT NULL,
    id_quad INT NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_digital_newspaper)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE District(
	id_district INT NOT NULL auto_increment,
    name_district VARCHAR(100)  NOT NULL,
	id_sector INT NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_district)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Email(
	id_email INT NOT NULL auto_increment,
	address_email VARCHAR(100) NOT NULL,
    id_person_mail INT NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_email)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Favourite (
	id_article_fav INT NOT NULL,
    id_user_fav INT NOT NULL,
    date_favourite DATETIME NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_article_fav,id_user_fav)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Gender(
    id_gender INT NOT NULL auto_increment,
    type_gender VARCHAR(38)  NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_gender)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE LogDB(
    id_log INT NOT NULL auto_increment,
	systemdate DATETIME NOT NULL,
    time_log TIMESTAMP(6) NOT NULL,
	change_descrp VARCHAR(100) NOT NULL,
    previous_text VARCHAR(4000),
    current_text VARCHAR(4000) NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    primary KEY (id_log)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Neighbour(
    id_person INT NOT NULL auto_increment,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_person)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE table ParameterDb(
    id_parameter INT NOT NULL auto_increment,
    name_parameter VARCHAR(30) NOT NULL,
    description_parameter VARCHAR(100) NOT NULL,
	value_parameter INT NOT NULL,
    route VARCHAR(200) NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_parameter)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Person(
    id_person INT NOT NULL auto_increment,
    identification_card INT NOT NULL,
    first_name VARCHAR(30) NOT NULL,
    second_name VARCHAR(30),
    first_surname VARCHAR(30) NOT NULL,
    second_surname VARCHAR(30) NOT NULL,
    datebirth DATETIME NOT NULL,
	id_quad INT NOT NULL,
    id_gender INT NOT NULL,
	exact_location VARCHAR(2000) NOT NULL,
	id_district INT NOT NULL,
    creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_person)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE PersonXCommitte
(
    id_person INT NOT NULL ,
    id_committe INT NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_person,id_committe)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Phone(
    id_phone INT NOT NULL auto_increment,
    number_phone INT NOT NULL,
    id_person INT NOT NULL,
    id_phone_category INT  NOT NULL,
    creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_phone)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE PhoneCategory(
    id_category INT NOT NULL auto_increment,
    description_category VARCHAR(100) NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_category)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Photo(
    id_photo INT  NOT NULL auto_increment,
    id_article INT,
    route VARCHAR(200) NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
	id_user INT,
    id_product INT,
    PRIMARY KEY (id_photo)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Product(
    id_product INT NOT NULL auto_increment,
	cost_product INT NOT NULL,
    description_product VARCHAR(100) NOT NULL,
    id_catalog_pr INT NOT NULL,
    id_availability INT NOT NULL,
    creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_product)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE ProductXAuthor(
    id_product_pa INT NOT NULL,
    id_author_pa INT NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Professor(
    id_person INT NOT NULL auto_increment,
    id_dedication INT NOT NULL,
    creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_person)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Province(
    id_province INT NOT NULL auto_increment,
    name_province VARCHAR(100) NOT NULL,
    id_nation INT NOT NULL,
    creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_province)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Review(
    description_review VARCHAR(200) NOT NULL,
    stars INT NOT NULL,
    id_article_rev INT NOT NULL,
    id_user_rev INT NOT NULL,
    creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_article_rev,id_user_rev)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Status(
    id_status INT NOT NULL auto_increment,
    name_status VARCHAR(15) NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_status)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Student(
    id_person INT NOT NULL,
    student_card DECIMAL(10) NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    PRIMARY KEY (id_person)
)auto_increment = 1;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE userDB(
    id_user INT NOT NULL auto_increment,
    password_user VARCHAR(100)  NOT NULL,
    id_person INT NOT NULL,
	creationDate DATETIME,
    userId VARCHAR(1000),
    lastModifyDate DATETIME,
    lastModifyBy VARCHAR(1000),
    user_name VARCHAR(1000) NOT NULL,
    PRIMARY KEY (id_user)
)auto_increment = 1;