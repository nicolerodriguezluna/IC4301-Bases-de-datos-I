use bdproject;

DELIMITER //
CREATE PROCEDURE get_usersByPerson(IN pnIdPerson INT)
BEGIN
    SELECT id_person, id_user, user_name, password_user
    FROM userdb
    WHERE id_person = pnIdPerson;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_products_byCampus(IN pidCampus INT)
BEGIN
    SELECT id_product, cost_product, description_product,
    id_catalog_pr, id_availability
    FROM product
    INNER JOIN catalog
    ON catalog.id_catalog = product.id_catalog_pr
    INNER JOIN digitalnewspaper
    ON digitalnewspaper.id_digital_newspaper = catalog.id_newspaper
    INNER JOIN campus
    ON digitalnewspaper.id_quad = campus.id_campus
    WHERE campus.id_campus = pidCampus;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_province_bycountry(IN pIdCountry INT)
BEGIN
    SELECT id_province, name_province, id_nation
    FROM province
    WHERE id_nation = pidcountry;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_user_favourites(IN pIdUser INT)
BEGIN
    SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
    FROM article
    INNER JOIN favourite
    ON article.id_article = favourite.id_article_fav
    INNER JOIN userdb
    ON userdb.id_person =  favourite.id_user_fav
    WHERE userdb.id_user = pIdUser;
END //
DELIMITER ;
 
DELIMITER //
CREATE PROCEDURE get_articles_byCommittee(IN pidCommittee INT)
BEGIN 
    SELECT id_article,title_article,text_note,publication_date,id_status_article,id_dig_news,id_art_cat,id_committe_art
	FROM article
	WHERE article.id_committe_art = pidCommittee
    ORDER BY publication_date DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_user_person(IN pidUser INT)
BEGIN
SELECT id_person,first_name,second_name,first_surname,second_surname,identification_card,datebirth,id_quad,id_gender,exact_location,id_district
FROM person WHERE person.id_person = (SELECT u.id_user, u.id_person, u.password_user, u.user_name 
    FROM person
    INNER JOIN userdb AS u
    ON person.id_person = userdb.id_person
    WHERE userdb.id_user = pidUser)
HAVING rownum<=1;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_reviews_article(IN pidArticle INT)
BEGIN
    SELECT review.id_article_rev, review.id_user_rev ,review.description_review, review.stars  
    FROM review 
    WHERE review.id_article_rev = pidArticle;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_user(IN pidUser INT)
BEGIN
    SELECT userdb.id_person, userdb.password_user,userdb.user_name,userdb.id_user
    FROM userdb 
    WHERE userdb.id_person = pidUser;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_users()
BEGIN
    SELECT userdb.id_user, userdb.password_user, userdb.id_person, userdb.user_name
    FROM userdb;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_students()
BEGIN
    SELECT id_person, student_card
    FROM student;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_student(IN pId INT)
BEGIN
    SELECT id_person, student_card
    FROM student 
    WHERE id_person = pId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_statuses()
BEGIN
    SELECT id_status, name_status
    FROM status;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_status(IN idStatus INT)
BEGIN
    SELECT id_status, name_status
    FROM status
    WHERE id_status = idStatus;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_reviews_byarticle(IN pId INT)
BEGIN
    SELECT review.id_article_rev, review.id_user_rev , review.description_review, review.stars  
    FROM review
    WHERE review.id_article_rev = pId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_reviews()
BEGIN
    SELECT review.id_article_rev, review.id_user_rev, review.description_review, review.stars  
    FROM review;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_provinces(IN pId INT)
BEGIN
    SELECT province.id_province, province.name_province 
    FROM province
    WHERE province.id_province = pId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_province(IN pId INT)
BEGIN
    SELECT province.id_province, province.name_province, province.id_nation
    FROM province
    WHERE province.id_province = pId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_professors()
BEGIN
    SELECT id_person, id_dedication
    FROM professor;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_professor(IN pId INT)
BEGIN
    SELECT id_person, id_dedication
    FROM professor 
    WHERE id_person = pId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_productxauthor_byauthor(IN pIdAuthor INT) -- PROBAR
BEGIN
    SELECT id_product,cost_product,description_product,id_catalog_pr,id_availability
    FROM product
    INNER JOIN productxauthor AS pxa
    ON product.id_product = pxa.id_product_pa
    WHERE pxa.id_author_pa = pIdAuthor;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_productxauthor_byproduct(IN pIdProduct INT)
BEGIN
    SELECT id_person,id_author_cathegory
    FROM author
    INNER JOIN productxauthor AS pxa
    ON author.id_person = pxa.id_author_pa
    WHERE pxa.id_product_pa = pIdProduct;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_productxauthor(IN pIdProduct INT, IN pIdAuthor INT)
BEGIN
    SELECT pxa.id_product_pa, pxa.id_author_pa
    FROM productxauthor AS pxa
    WHERE pxa.id_product_pa = pIdProduct AND pxa.id_author_pa = pIdAuthor;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_products_byCollege(IN pidCollege INT)
BEGIN
    SELECT id_product, cost_product, description_product,
	id_catalog_pr, id_availability
    FROM product
    INNER JOIN catalog
    ON catalog.id_catalog = product.id_catalog_pr
    INNER JOIN digitalnewspaper
    ON digitalnewspaper.id_digital_newspaper = catalog.id_newspaper
    INNER JOIN campus
    ON digitalnewspaper.id_quad = campus.id_campus
    INNER JOIN college
    ON college.id_college = campus.id_university
    WHERE college.id_college = pidCollege;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_products()
BEGIN
    SELECT id_product, cost_product, description_product,
    id_catalog_pr, id_availability
    FROM product
    ORDER BY (cost_product) DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_product(IN pId INT)
BEGIN
    SELECT id_product, cost_product, description_product, id_catalog_pr, id_availability
    FROM product 
    WHERE id_product = pId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_photo_user(IN pId INT)
BEGIN
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo AS p
    WHERE p.id_user = pId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_photo_product(IN pId INT)
BEGIN
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo AS p
    WHERE p.id_product = pId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_photos()
BEGIN
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo p;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_photo_article(IN pId INT)
BEGIN
    SELECT p.id_photo, p.id_article, p.route,p.id_user,p.id_product
    FROM photo p
    WHERE p.id_article = pId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_phonecategories()
BEGIN
    SELECT p.id_category, p.description_category
    FROM phonecategory p;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_phonecategory(IN pId INT)
BEGIN
    SELECT p.id_category, p.description_category
    FROM phonecategory p
    WHERE p.id_category = pId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_phone(IN pId INT)
BEGIN
    SELECT p.id_phone, id_person ,p.number_phone, ph.description_category
    FROM phone AS p
    INNER JOIN phonecategory AS ph
    ON p.id_phone_category = ph.id_category
    WHERE p.id_phone = pId;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_person_phones(IN pidPerson INT)
BEGIN
    SELECT id_phone,number_phone,id_person,id_phone_category
    FROM phone
    WHERE id_person =pidPerson;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_all_phones()
BEGIN
    SELECT id_phone,number_phone,id_person,id_phone_category
    FROM phone;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_personxcommitte()
BEGIN
    SELECT id_person,id_committe
    from personxcommitte;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_people_bycommittee(IN pIdCommittee INT)
BEGIN
    SELECT  person.id_person,first_name,second_name,first_surname,
    second_surname,identification_card,datebirth, id_quad, id_gender, exact_location, id_district
    FROM person
    INNER JOIN personxcommitte AS pxc
    On person.id_person = pxc.id_person
    WHERE pxc.id_committe = pIdCommittee
    ORDER BY(first_name);
END //
DELIMITER ;