USE BDPROJECT;

INSERT INTO phonecategory
(description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('Celular',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO phonecategory
(description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('Casa',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO phonecategory
(description_category, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('Oficina',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT')
