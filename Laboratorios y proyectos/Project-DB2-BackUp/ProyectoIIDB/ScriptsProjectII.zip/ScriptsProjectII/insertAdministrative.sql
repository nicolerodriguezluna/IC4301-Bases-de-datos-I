use bdproject;
insert into administrative
(id_person,id_dedication, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(16,2, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');
insert into administrative
(id_person,id_dedication, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(17,3, SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

