INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('503214696f1eb0e97212bb1a51bb3f04',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','Carrillo29');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('2186641da277f833524b67dcd98362e1',2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','camaronSupremo');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('74bb78eaf2e58a9cb0571b1c5b827abb',3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','sebaselmasguapo74');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('ae9fc3413e2c520736617e28384fd1a1',4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','cosmosInfinito');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('5f4dcc3b5aa765d61d8327deb882cf99',5,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','guijarro81');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('91fcd47573a9b67b4850f1e3672c5ed2',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','inteligente123');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('d1a6c8860e31cb493ba2edb8e8618614',7,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','perrofachero90');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('2ccc2d940f8898ab821d9ecc30a7bdbe',8,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','bubblegum89');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('ae195426c47d67af60991d951f2b80ce',9,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','marioysonic01');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('2a9ccb2fa7cb6da31f992e015b2e2e77',10,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','meGustaMario');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('96cbfea31ccf811060c169b7fcc1df25',11,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','arcaneIsgood76');

INSERT INTO userdb
(password_user,id_person,creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('07a10f091a7b485fb7e0f775e4f9ab87',12,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','minecraftForLife');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('c578644c150872c38c910288d7bd771a',13,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','willyrexfanboy');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('f083fc80c99a451ca4895816d7c14af4',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','videogameGeek');

INSERT INTO userdb
(password_user,id_person ,creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('b96cb55c69c8df30b2328c48630b726c',15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','ibaiHasStream');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('e1f66bd3d29c81deee38c485f7ceae95',16,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','colombiaCampeon2022');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('2fda1e437cf3cd5f8d9bb718c20102ef',17,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','picapiedra28');

use bdproject;

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('fa95ec5fdbe9b586c45c57efd06ebff1',18,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','ratchetElGenio');

INSERT INTO userdb
(password_user,id_person,creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('af00c87a55e2e8a882710c1775f8ebdf',19,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','steffPop65');

INSERT INTO userdb
(password_user,id_person, creationDate, userId, lastModifyDate, lastModifyBy,user_name)
VALUES ('e5f5628324aaa3f04066ca862fce630a',20,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT','chillingIntheHouse');