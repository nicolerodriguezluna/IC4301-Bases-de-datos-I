USE BDPROJECT;
INSERT INTO status
(name_status, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('Aprobado',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO status
(name_status, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('Pendiente',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO status
(name_status, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES('Rechazado',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');