USE bdPROJECT;

insert into committe
(description_committe, creationDate, userId, lastModifyDate, lastModifyBy,id_campus)
values ('ComiTEC', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT',2);

insert into committe
(description_committe, creationDate, userId, lastModifyDate, lastModifyBy,id_campus)
values ('UCRevisa', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT',6);

insert into committe
(description_committe, creationDate, userId, lastModifyDate, lastModifyBy,id_campus)
values ('UNAprobado', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT',10);





