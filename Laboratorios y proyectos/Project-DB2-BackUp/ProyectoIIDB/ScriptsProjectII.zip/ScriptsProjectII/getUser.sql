
DELIMITER //
CREATE PROCEDURE get_user (IN pidUser INT, OUT id INT, OUT pass VARCHAR(100), OUT userName VARCHAR(1000))
BEGIN
    SELECT u.id_person, u.password_user,u.user_name
    INTO id, pass, userName
    from userdb u
    where u.id_person = pidUser;
END;
DELIMITER;
