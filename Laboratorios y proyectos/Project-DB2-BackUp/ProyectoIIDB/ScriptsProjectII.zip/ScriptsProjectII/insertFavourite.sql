use bdproject;
INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,1,DATE '2022-08-18',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(2,2,DATE '2021-10-08',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(3,3,DATE '2022-09-08',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(4,4,DATE '2020-12-10',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(5,5,DATE '2020-12-18',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(6,6,DATE '2021-03-18',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(7,7,DATE '2021-09-08',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(8,8,DATE '2022-09-07',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(9,9,DATE '2022-01-19',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(10,10,DATE '2022-09-15',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(11,11,DATE '2022-09-10',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(12,12,DATE '2022-09-23',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(13,13,DATE '2022-09-07',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(14,14,DATE '2021-02-08',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO favourite
(id_article_fav,id_user_fav,date_favourite, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(15,15,DATE '2021-08-9',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');
