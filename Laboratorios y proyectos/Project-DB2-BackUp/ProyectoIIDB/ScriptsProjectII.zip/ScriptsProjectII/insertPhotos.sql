-- ---------------------------------------------------- Photos Users ---------------------------------------------------------------
use bdproject;
insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\camaron.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',1,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\amsiedad.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',2,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\asaltoLaNota.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',3,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\clemenciaporfa.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',4,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\companerosenverano.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',5,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\dobby.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',6,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\doraUno.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',7,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\entregadeactas.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',8,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\examendeanalisis.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',9,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\facha.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',10,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\fumigandobugs.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',11,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\impaktado.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',12,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\leyendoexamen.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',13,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\meperdonas.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',14,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\porfapaseme.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',15,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\revisiondeproyecto.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',16,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\semana16.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',17,NULL);


insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\semanaUno.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',18,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\viendoMiCodigo.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',19,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\chill.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',20,NULL);

-- ---------------------------------------------------- Photos Articles ---------------------------------------------------------------
insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(6,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\arte.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(13,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\aumentoIntereses.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',null,null);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(2,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\casaVerde.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(5,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\centrohistorico.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(9,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\estudiantesTec.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(10,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\farolesUcr.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(12,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\feesUcr.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(8,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\gemelas.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(11,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\guiasEstandarizadas.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(1,'C:\\app\\JeffreyLeiva\\oradata\\photosdb\\\\marchafees.jpeg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(15,'C:\\app\\JeffreyLeiva\\oradata\photosdb\\situacionEmpleo.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(3,'C:\app\JeffreyLeiva\oradata\photosdb\\tallerVertical.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(4,'C:\app\JeffreyLeiva\oradata\photosdb\\teatroagosto.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(14,'C:\app\JeffreyLeiva\oradata\photosdb\\terremotoCinchona.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(7,'C:\app\JeffreyLeiva\oradata\photosdb\\trabajo.png',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,NULL);

-- ---------------------------------------------------- Photos Products ---------------------------------------------------------------
insert into photo(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\app\JeffreyLeiva\oradata\photosdb\\astronautArticle.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,1);

insert into photo(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\app\JeffreyLeiva\oradata\photosdb\\briefhistoryofeverything.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,2);

insert into photo(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\app\JeffreyLeiva\oradata\photosdb\\einsteinArticle.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,3);

insert into photo(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\app\JeffreyLeiva\oradata\photosdb\\kitMolecular.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,4);

insert into photo(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\app\JeffreyLeiva\oradata\photosdb\\probetas.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,5);

insert into photo(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\app\JeffreyLeiva\oradata\photosdb\\robotArticle.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,6);

insert into photo(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\app\JeffreyLeiva\oradata\photosdb\\telescopio.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,7);

insert into photo(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\app\JeffreyLeiva\oradata\photosdb\\tablaPeriodica.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,8);

insert into photo
(id_article,route, creationDate, userId, lastModifyDate, lastModifyBy,id_user,id_product)
VALUES(NULL,'C:\app\JeffreyLeiva\oradata\photosdb\\articleIA.jpg',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT',NULL,9);

select * from administrator;
update administrator
set password_admin = 'c194edac3bc7561e37a883dfb5749fcb'
where id_person = 18;

update administrator
set password_admin = 'aa8c97240fbf5760f209ac65b7c374d9'
where id_person = 19;