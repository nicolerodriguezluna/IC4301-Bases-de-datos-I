DELIMITER //
create PROCEDURE authors_per_college()
  BEGIN
        SELECT COUNT(1) as countAuthors,name_college
        from author
        inner join person
        On author.id_person = person.id_person
        inner join campus
        ON person.id_quad = campus.id_campus
        inner join college
        On college.id_college = campus.id_university
        group by name_college;
  END;//
  DELIMITER ;