use bdproject;

ALTER TABLE parameterdb MODIFY value_parameter INT;

INSERT INTO parameterdb
(name_parameter,description_parameter,value_parameter,route)
VALUES('Photos','User and article photos',NULL,'C:\\app\\JeffreyLeiva\\oradata\\photosdb');