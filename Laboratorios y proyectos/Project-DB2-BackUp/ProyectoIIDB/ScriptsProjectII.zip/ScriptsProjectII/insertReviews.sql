use bdproject;
INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Estoy en total acuerdo con que se manifiesten los estudiantes, la U pública es por y para el pueblo.',6,1,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Espero poder ir, sin embargo creo que esa casa está un poco peligrosa por sus años en nuestro querido barrio Amón.',5,2,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('La verdad no me gustaron las maquetas, tantos días de trabajo para tres palos y cartones puestos',3,3,3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Qué bonito ver como las obras de antaño se modernizan y en plena crisis sanitaria hacen que sonríamos a la distancia.',6,4,4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Lo hizo alguien del TEC, ni la ha puesto y ya sé que no sirve.#SiempreUCR #AlmaMater',3,5,5,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('La creatividad es una maravillosa herramienta que nos abre muchas puertas, un aplauso para este artista.',6,6,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Muy bien por estos jóvenes que aprovechan el tiempo, no andan perdiendo el tiempo y atribuyen a la sociedad.',6,7,13,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Fueron mis compañeras en varios cursos, son muy inteligentes  pero algo juega de vivas.',4,8,19,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Qué va! No rinden los de privada',4,9,14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Noble patria, tu hermosa bandera, expresión de tu vida nos da; bajo el límpido azul de tu cielo blanca y pura descansa la paz.',6,10,2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');
INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev,creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Me parece muy bien que saquen pruebas que ayuden a mejorar la educación superior del país',6,11,6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('No sé que tanto discuten, no entiendo como es que le quitan dinero a la educación...',5,12,11,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Nombres... y uno sin plata, viviendo a como humildemente se puede, y el presidente sigue y sigue aumentando los impuestos e intereses. Piensan que uno es un banco',2,13,9,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Ishhh que loco, yo me acuerdo esa tarde cuando estaba chamaco. Que ras susto legal. Mi casa todavía tiene un hueco de ese temblor.',5,14,7,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO review
(description_review,stars,id_article_rev,id_user_rev, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Que triste, por eso todo el mundo se quiere ir del país. Apenas me gradué voy jalando de aquí. Para algún país con oportunidades como Estados Unidos o Canadá.',2,15,16,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');
