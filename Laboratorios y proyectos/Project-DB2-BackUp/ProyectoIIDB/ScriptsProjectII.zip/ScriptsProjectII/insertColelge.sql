INSERT INTO college
(name_college, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Instituto Tecnológico de Costa Rica', SYSDATE(), 'BDPROJECT',SYSDATE(), 'BDPROJECT');

INSERT INTO college
(name_college, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Universidad de Costa Rica', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');

INSERT INTO college
(name_college, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Universidad Nacional', SYSDATE(), 'BDPROJECT', SYSDATE(), 'BDPROJECT');