use bdproject;
insert into author
(id_person,id_author_cathegory, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (20,3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into author
(id_person,id_author_cathegory, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (1,4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');