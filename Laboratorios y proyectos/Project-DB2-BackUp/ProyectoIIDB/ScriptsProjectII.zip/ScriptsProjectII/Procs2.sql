DELIMITER //
CREATE PROCEDURE get_person(IN pidPerson INT)
BEGIN
    SELECT person.id_person,first_name,second_name,first_surname,second_surname,identification_card,datebirth
    FROM person
    WHERE person.id_person = pidPerson;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_people()
BEGIN
    SELECT id_person,first_name,second_name,first_surname,
    second_surname,identification_card,datebirth, id_quad, id_gender, exact_location, id_district
    FROM person
    ORDER BY(first_name)DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_parameter(IN pindParameter INT)
BEGIN
    SELECT id_parameter,name_parameter, description_parameter, value_parameter, route
    FROM parameterdb
    WHERE id_parameter = pindParameter;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_parameters()
BEGIN
    SELECT id_parameter,name_parameter, description_parameter, value_parameter, route
    FROM parameterdb
    ORDER BY(name_parameter)DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_logdb(IN pidLogdb INT)
BEGIN 
    SELECT id_log,systemdate, time_log, change_descrp, previous_text, current_text
    FROM logdb
    WHERE id_log = pidLogdb;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_logdbs()
BEGIN
    SELECT id_log,systemdate, time_log, change_descrp, previous_text, current_text
    FROM logdb
    ORDER BY(systemdate)DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_gender(IN pidGender INT)
BEGIN
    SELECT id_gender,type_gender
    FROM gender
    WHERE id_gender = pidGender
    ORDER BY(type_gender);
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_genders()
BEGIN
    SELECT id_gender,type_gender
    FROM gender
    ORDER BY(type_gender)DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_emails_person(IN pidPerson INT)
BEGIN
    SELECT id_email,address_email,id_person_mail
    FROM email
    WHERE id_person_mail = pidPerson
    ORDER BY(address_email);
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_emails()
BEGIN
    SELECT id_email,address_email,id_person_mail
    FROM email
    ORDER BY(address_email)DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_district(IN pidDistrict INT)
BEGIN
    SELECT id_district,name_district,id_sector
    FROM district
    WHERE id_district = pidDistrict;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_districts()
BEGIN
    SELECT id_district,name_district,id_sector
    from district
    ORDER BY(name_district)DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_digital_newspaper(IN pinDNewspaper INT)
BEGIN
    SELECT id_digital_newspaper,name_digital_newspaper,id_quad
    FROM digitalnewspaper
    WHERE id_digital_newspaper = pinDNewspaper;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_digital_newspapers()
BEGIN
    SELECT id_digital_newspaper,name_digital_newspaper,id_quad
    FROM digitalnewspaper
    ORDER BY(name_digital_newspaper)DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_dedication(IN pindDedication INT)
BEGIN
    SELECT id_dedication,description_dedication
    FROM dedication
    WHERE id_dedication = pindDedication;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_dedications()
BEGIN
    SELECT id_dedication,description_dedication
    FROM dedication
    ORDER BY(description_dedication)DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_country(IN pindCountry INT)
BEGIN
    select id_country,name_country
    from country
    where id_country = pindCountry;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_countries()
BEGIN
    SELECT id_country,name_country
    FROM country
    ORDER BY(name_country)DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_committee(IN pidCommittee INT)
BEGIN
    SELECT id_committe,description_committe,id_campus
    FROM committe
    WHERE id_committe = pidCommittee;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_committees()
BEGIN
    SELECT id_committe,description_committe,id_campus
    FROM committe
    ORDER BY(description_committe)DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_committe_byCampus(IN pCampus INT)
BEGIN 
	SELECT committe.id_committe,committe.description_committe,id_campus
	FROM committe
	WHERE committe.id_campus = pCampus;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_committe_byAuthor(IN pidAuthor INT)
BEGIN 
	SELECT committe.id_committe,committe.description_committe,id_campus
	FROM author
	INNER JOIN person
	ON author.id_person = person.id_person
	INNER JOIN committe
	ON committe.id_campus = person.id_quad
	WHERE author.id_person = pidAuthor;
END //
DELIMITER ;