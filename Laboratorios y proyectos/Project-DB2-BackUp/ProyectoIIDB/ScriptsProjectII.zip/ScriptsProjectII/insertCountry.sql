INSERT INTO COUNTRY (name_country,creationdate,userid,lastmodifydate,lastmodifyby)
VALUES ('Costa Rica',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

