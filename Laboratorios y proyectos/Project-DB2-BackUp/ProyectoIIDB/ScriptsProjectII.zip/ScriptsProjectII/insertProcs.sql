-- ------------------------------ UPDATES --------------------------------------
DELIMITER //
CREATE PROCEDURE update_personXCommittee(IN pidPerson INT, IN pidCommittee INT) 
BEGIN
    UPDATE personxcommitte
    SET id_committe = pidCommittee
    WHERE id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_photo_user(IN pidUser INT, IN pNewRoute VARCHAR(100)) -- AREGLAR
BEGIN
    UPDATE photo
    SET route = pnewRoute
    WHERE pidUser = id_user;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_phone(IN pidPhone INT, IN pNewNumber INT) 
BEGIN
    UPDATE phone
    SET number_phone = pNewNumber
    WHERE pidPhone = id_phone;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_phoneCategory(IN pidCategory INT, IN pNewDescription VARCHAR(100)) 
BEGIN
    UPDATE phonecategory
    SET description_category = pNewDescription
    WHERE pidCategory = id_category;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_photo(IN pidPhoto INT, IN pNewDescription VARCHAR(100)) 
BEGIN
    UPDATE photo
    SET route = pnewRoute
    WHERE pidPhoto = id_photo;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_product_availability(IN pidProduct INT, IN pnIdNewAv INT) 
BEGIN
    UPDATE product
    SET id_availability = pnidnewav
    WHERE pidProduct = id_product;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_product_catalog(IN pidProduct INT, IN idCatalog INT) 
BEGIN
    UPDATE product
    SET  id_catalog_pr = idCatalog
    WHERE pidProduct = id_product;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_product_cost(IN pidProduct INT, IN costProduct INT) 
BEGIN
    UPDATE product
    SET  cost_product = costProduct
    WHERE pidProduct = id_product;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_product_description(IN pidProduct INT, IN pNewDescription VARCHAR(100)) 
BEGIN
    UPDATE product
    SET  description_product = pNewDescription
    WHERE pidProduct = id_product;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_product(IN pidProduct INT, IN pNewCost INT, IN pNewDescription VARCHAR(100)) 
BEGIN
    UPDATE product
    SET cost_product = pNewCost, 
        description_product = pNewDescription
    WHERE pidProduct = id_product;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_professor(IN pidPerson INT, IN pNewDedication INT) 
BEGIN
    UPDATE professor
    SET id_dedication = pNewDedication
    WHERE pidPerson = id_person;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE  update_province(IN pidProvince INT, IN pNewName VARCHAR(100)) 
BEGIN
    UPDATE province
    SET name_province = pNewName
    WHERE pidProvince = id_province;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_review(IN pidArtRev INT, IN pidUserRev INT, IN pNewDescription VARCHAR(100)) 
BEGIN
    UPDATE review
    SET description_review = pNewDescription
    WHERE pidUserRev = id_user_rev AND pidArtRev = id_article_rev;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_status(IN pidStatus INT, IN pNewStatus VARCHAR(100)) 
BEGIN
    UPDATE status
    SET name_status = pNewStatus
    WHERE pidStatus = id_status;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_student(IN pidPerson INT, IN pNewStudCard INT)
BEGIN
    UPDATE student
    SET student_card = pNewStudCard
    WHERE pidPerson = id_person;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_user_username(IN pidUser INT, IN pNewName VARCHAR(100))
BEGIN
    UPDATE userdb
    SET user_name = pNewName
    WHERE pidUser = id_user;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_user_password(IN pidUser INT, IN pNewPass VARCHAR(100)) 
BEGIN
    UPDATE userdb
    SET password_user = pNewPass
    WHERE pidUser = id_user;
    COMMIT;
END //
DELIMITER ;

-- ------------------------------ DELETES --------------------------------------
DELIMITER //
CREATE PROCEDURE delete_user_person(IN pidPerson INT)
BEGIN
    DELETE FROM userdb
    WHERE id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_phone_person(IN pidPerson INT) 
BEGIN
    DELETE FROM phone
    WHERE id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_email_person(IN pidPerson INT) 
BEGIN
    DELETE FROM email
    WHERE email.id_person_mail = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_review_user(IN pidUserRev INT) 
BEGIN
    DELETE FROM review
    WHERE id_user_rev = pidUserRev;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_favourite_user(IN pidUserRev INT)
BEGIN
    DELETE FROM favourite
    WHERE favourite.id_user_fav = pidUserRev;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_photo_user(IN pidUser INT) 
BEGIN
    DELETE FROM photo
    WHERE id_user = pidUser;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_personxcommitte_comm(IN pidCommittee INT) 
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_committe = pidCommittee;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_personxcommitte_person(IN pidPerson INT) 
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_personxcommitte(IN pidPerson INT, IN pidCommitte INT) 
BEGIN 
    DELETE FROM personxcommitte
    WHERE id_person = pidPerson AND id_committe = pidCommitte;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_phone(IN pidPhone INT) 
BEGIN
    DELETE FROM phone
    WHERE id_phone = pidPhone;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_phoneCategory(IN pidCategory INT) 
BEGIN
    DELETE FROM phonecategory
    WHERE id_category = pidCategory;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_photo_product(IN pidProduct INT) 
BEGIN
    DELETE FROM photo
    WHERE id_product = pidProduct;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_photo_article(IN pidArticle INT) 
BEGIN
    DELETE FROM photo
    WHERE id_article = pidArticle;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_photo(IN pidPhoto INT) 
BEGIN
    DELETE FROM photo
    WHERE id_photo = pidPhoto;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_product(IN pidProduct INT) 
BEGIN
    DELETE FROM product
    WHERE id_product = pidProduct;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_professor(IN pidPerson INT) 
BEGIN
    DELETE FROM professor
    WHERE id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_province(IN pidProvince INT) 
BEGIN
    DELETE FROM province
    WHERE id_province = pidProvince;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_review(IN pidArtRev INT, IN pidUserRev INT)
BEGIN
    DELETE FROM review
    WHERE id_user_rev = pidUserRev AND id_article_rev = pidArtRev;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_status(IN pidStatus INT)
BEGIN
    DELETE FROM status
    WHERE id_status = pidStatus;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_user(IN pidUser INT) 
BEGIN
    DELETE FROM userdb
    WHERE id_user = pidUser;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_student(IN pidPerson INT) 
BEGIN
    DELETE FROM student
    WHERE id_person = pidPerson;
    COMMIT;
END //
DELIMITER ;
-- ------------------------------ INSERTS --------------------------------------
DELIMITER //
CREATE PROCEDURE insert_personxcommitte(IN pidPerson INT, IN pidCommitte INT) 
BEGIN
    INSERT INTO personxcommitte(id_committe, id_person, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidCommitte, pidPerson, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_phone(IN pnumber INT, IN pidPerson INT, IN pidPhoneCategory INT)
BEGIN
    INSERT INTO phone(number_phone, id_person, id_phone_category, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pnumber, pidPerson, pidPhoneCategory, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_phoneCategory(IN pdescription VARCHAR(100))
BEGIN
    INSERT INTO phoneCategory(description_category,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pdescription, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_photo_product(IN proute VARCHAR(100), IN pidProduct INT) 
BEGIN
    INSERT INTO photo(route, id_article, id_user, id_product,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(proute, NULL, NULL, pidProduct, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_photo_user(IN proute VARCHAR(100), IN pidUser INT)
BEGIN
    INSERT INTO photo(route, id_article, id_user, id_product,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(proute, NULL, pidUser, NULL, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_photo_article(IN proute VARCHAR(100) , IN pidArticle INT) 
BEGIN
    INSERT INTO photo(route, id_article, id_user, id_product,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(proute, pidArticle, NULL, NULL, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_product(IN pCost INT, IN pdescription VARCHAR(100), IN pidCatalog INT, IN pidAvailability INT) 
BEGIN
    INSERT INTO product(cost_product, description_product, id_catalog_pr, id_availability,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pcost, pdescription, pidcatalog, pidavailability, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_productxauthor(IN pidProPa INT, IN pidAutPa INT)
BEGIN
    INSERT INTO productxauthor(id_product_pa, id_author_pa, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidProPa, pidAutPa, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_professor(IN pidDedication INT, IN pidPerson INT) 
BEGIN
    INSERT INTO professor(id_dedication, id_person, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidDedication, pidPerson,NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_province(IN pname VARCHAR(100), IN pidNation INT) 
BEGIN
    INSERT INTO province(name_province, id_nation, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pname, pidNation ,NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_review(IN pdescription VARCHAR(100), IN pid_article_rev INT, IN pid_user_rev INT)
BEGIN
    INSERT INTO review(description_review, id_article_rev, id_user_rev,creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pdescription, pid_article_rev, pid_user_rev, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_status(IN pnameStatus VARCHAR(100)) 
BEGIN
    INSERT INTO status(name_status, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pnameStatus, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE insert_student(IN pidPerson INT, IN pstudentCard INT)
BEGIN
    INSERT INTO student(id_person, student_card, creationDate, userid, lastModifyDate, lastModifyBy)
    VALUES(pidPerson, pstudentCard, NULL, NULL, NULL, NULL);
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE  insert_user(IN pUserName VARCHAR(100) , IN pPassUser VARCHAR(100), IN pidPerson INT)
BEGIN
    INSERT INTO userdb(password_user, id_person, creationDate, userid, lastModifyDate, lastModifyBy,user_name)
    VALUES(pPassUser, pidPerson, NULL, NULL, NULL, NULL,pUserName);
    COMMIT;
END //
DELIMITER ;