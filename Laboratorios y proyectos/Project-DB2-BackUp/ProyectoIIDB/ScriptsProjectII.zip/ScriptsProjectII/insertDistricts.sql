
USE bdproject;

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Carmen',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Catedral',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Hatillo',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Hospital',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('La Uruca',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Mata Redonda',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Merced',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Pavas',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Francisco de dos Ríos',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Sebastián',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Zapote',1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');



-- Canton 2
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Cangrejal',2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Guaitil',2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Palmichal',2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Sabanillas',2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Ignacio',2,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 3
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Alajuelita',3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Concepción',3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Antonio',3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Felipe',3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Josecito',3,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 4
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Aserrí',4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Legua',4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Monterrey',4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Salitrillos',4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Gabriel',4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Tarbaca',4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Vuelta de Jorco',4,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 5
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Curridabat',5,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Granadilla',5,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Sánchez',5,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Tirrases',5,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 6
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Damas',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Desamparados',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Frailes',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Gravilias',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Los Guido',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Patarrá',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Rosario',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Antonio',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Cristóbal',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Juan de Dios',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Miguel',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Rafael Abajo',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Rafael Arriba',6,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 7
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Copey',7,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Jardín',7,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Santa María',7,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 8
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Escazú',8,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Antonio',8,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Rafael',8,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');



-- Canton 9
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Calle Blancos',9,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Guadalupe',9,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Ipís',9,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Mata de Plátano',9,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Purral',9,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Rancho Redondo',9,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Francisco',9,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 10
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Pablo',10,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Andrés',10,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Llano Bonito',10,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Isidro',10,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Santa Cruz',10,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Antonio',10,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 11
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Mercedes',11,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Sabanilla',11,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Pedro',11,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Rafael',11,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 12
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Cuidad Colón',12,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Guayabo',12,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Jaris',12,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Picagres',12,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Piedras Negras',12,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Tabarcia',12,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 13
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Jerónimo',13,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Vicente',13,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Trinidad',13,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 14
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Isidro de El General',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Barú',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Cajón',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Daniel Flores',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('El General',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('La Amistad',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Páramo',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Pejibaye',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Platanares',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Río Nuevo',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Rivas',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Pedro',14,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 15
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Barbacoas',15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Candelarita',15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Chires',15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Desamparaditos',15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Grifo Alto',15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Mercedes Sur',15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Antonio',15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Rafael',15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Santiago',15,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 16
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Brasil',16,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Piedades',16,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Pozos',16,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Salitral',16,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Santa Ana',16,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Uruca',16,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 17
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Carlos',17,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Lorenzo',17,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Marcos',17,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 18
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Anselmo Llorente',18,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Cinco Esquinas',18,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Colima',18,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('León XIII',18,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Juan',18,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 19
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Carara',19,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Juan de Mata',19,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Luis',19,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Pablo',19,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Pedro',19,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 20
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Cascajal',20,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Dulce Nombre de Jesús',20,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Patalillo',20,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Isidro',20,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Rafael',20,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 21
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Oriental' ,21,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Occidental' ,21,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Carmen' ,21,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Nicolás',21,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Aguacaliente' ,21,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Guadalupe' ,21,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Corralillo' ,21,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tierra Blanca' ,21,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Dulce Nombre' ,21,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Llano Grande' ,21,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Quebradilla' ,21,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 22
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Paraíso' ,22,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santiago' ,22,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Orosi' ,22,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cachí',22,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Llanos de Santa Lucía' ,22,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Birrisito' ,22,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 23

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tres Ríos' ,23,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Diego' ,23,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Juan' ,23,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Rafael' ,23,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Concepción' ,23,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Dulce Nombre' ,23,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Ramón' ,23,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Río Azul' ,23,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 24
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Juan Viñas',24,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tucurrique' ,24,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Pejibaye' ,24,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Victoria' ,24,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 25

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Turrialba' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Suiza' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Peralta' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Cruz' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Teresita' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Pavones' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tuis' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tayutic' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Rosa' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tres Equis' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Isabel' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Chirripó' ,25,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 26
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Pacayas' ,26,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cervantes' ,26,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Capellades' ,26,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 27
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Rafael' ,27,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cot' ,27,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Potrero Cerrado' ,27,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cipreses' ,27,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Rosa' ,27,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 28
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'El Tejar' ,28,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Isidro' ,28,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tobosi' ,28,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Patio de Agua' ,28,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 29
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Puntarenas' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Pitahaya' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Chomes' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Lepanto' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');



INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Paquera' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Manzanillo' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Guacimal' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Barranca' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Isla del Coco' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cóbano' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Chacarita' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Chira' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Acapulco' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'El Roble' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Arancibia' ,29,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');



-- Canton 30
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Espíritu Santo' ,30,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Juan Grande' ,30,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Maracona' ,30,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Rafael' ,30,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Jerónimo' ,30,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Caldera' ,30,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 31
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Buenos Aires' ,31,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Volcán' ,31,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Potrero Grande' ,31,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');



INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Boruca' ,31,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Pilas' ,31,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Colinas' ,31,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Chánguena' ,31,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Biolley' ,31,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Brunca' ,31,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 32

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Miramar' ,32,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Unión' ,32,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Isidro' ,32,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 33
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Puerto Cortés' ,33,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Palmar' ,33,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Sierpe' ,33,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Piedras Blancas' ,33,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Bahía Ballena' ,33,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Bahía Drake' ,33,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 34


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Quepos' ,34,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Savegre' ,34,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Naranjito' ,34,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 35
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Golfito' ,35,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Guaycará' ,35,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Pavón' ,35,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 36
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Vito' ,36,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Sabalito' ,36,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Agua Buena' ,36,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Limonsito' ,36,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Pittier' ,36,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Gutierréz Braun' ,36,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 37
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Parrita' ,37,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 38
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Corredor' ,38,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Cuesta' ,38,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Canoas' ,38,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Laurel' ,38,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- Canton 39
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Jacó' ,39,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tárcoles' ,39,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 40
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Monteverde' ,40,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 41
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Puerto Jiménez' ,41,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 42
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Alajuela' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San José' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Carrizal' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Antonio' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Guácima' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Isidro' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Sabanilla' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Rafael' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Río Segundo' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Desamparados' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Turrúcares' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tambor' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Garita' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Sarapiquí' ,42,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 43
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Ramón' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santiago' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Juan' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Piedades Norte' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Piedades Sur' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Rafael' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Isidro' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Ángeles' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Alfaro' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Volio' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Concepción' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Zapotal' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Peñas Blancas' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Lorenzo' ,43,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 44
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Grecia' ,44,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Isidro' ,44,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San José' ,44,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Roque' ,44,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tacares' ,44,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Puente de Piedra' ,44,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Bolívar' ,44,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 45
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Mateo' ,45,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Desmonte' ,45,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Jesús María' ,45,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Labrador' ,45,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 46
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Atenas' ,46,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Jesús' ,46,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Mercedes' ,46,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Isidro' ,46,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Concepción' ,46,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San José' ,46,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Eulalia' ,46,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Escobal' ,46,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 47
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Naranjo' ,47,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Miguel' ,47,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San José' ,47,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cirrí Sur' ,47,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Jerónimo' ,47,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Juan' ,47,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'El Rosario' ,47,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Palmitos' ,47,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 48
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Palmares' ,48,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Zaragoza' ,48,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Buenos Aires' ,48,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santiago' ,48,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Candelaria' ,48,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Esquipulas' ,48,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Granja' ,48,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 49
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Pedro' ,49,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Juan' ,49,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Rafael' ,49,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Carrillos' ,49,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Sabanda Redonda' ,49,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 50
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Orotina' ,50,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'El Mastate' ,50,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Hacienda Vieja' ,50,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Coyolar' ,50,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Ceiba' ,50,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 51
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Quesada' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Florencia' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Buenavista' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Aguas Zarcas' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Venecia' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Pital' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Fortuna' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Tigra' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Palmera' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Venado' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cutris' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Monterrey' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Pocosol' ,51,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 52
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Zarcero' ,52,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Laguna' ,52,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tapesco' ,52,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Guadalupe' ,52,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Palmira' ,52,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Zapote' ,52,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Brisas' ,52,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 53
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Sarchí Norte'  ,53,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Sarchí Sur' ,53,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Toro Amarillo' ,53,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Pedro' ,53,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Rodríguez' ,53,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 54
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Upala' ,54,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Aguas Claras' ,54,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San José' ,54,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Bijagua' ,54,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Delicias' ,54,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Dos Ríos' ,54,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Yolillal' ,54,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Canalete' ,54,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 55
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Los Chiles' ,55,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Caño Negro' ,55,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'El Amparo' ,54,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Jorge' ,55,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 56
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Rafael' ,56,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Buenavista' ,56,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cote' ,56,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Katira' ,56,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 57
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Río Cuarto' ,57,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Rita' ,57,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Isabel' ,57,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 58

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Heredia',58,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Mercedes',58,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Francisco',58,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Ulloa',58,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Varablanca',58,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 59
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Barva',59,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San José de la Montaña',59,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Pablo',59,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Pedro',59,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Roque',59,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Santa Lucía',59,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 60
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('La asunción',60,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('La Ribera',60,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Antonio',60,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 61
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Barrantes',61,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Llorente',61,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Joaquín',61,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 62
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Concepción',62,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Francisco',62,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Isidro',62,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San José',62,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 63
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Rincón de Sabanilla',63,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Pablo',63,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 64
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Ángeles',64,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Concepción',64,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Josecito',64,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Rafael',64,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Santiago',64,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 65
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Jesús',65,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Purabá',65,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Juan',65,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Pedro',65,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Santa Bárbara',65,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Santo Domingo',65,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 66
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Pará',66,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Paracito',66,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Miguel',66,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('San Vicente',66,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Santa Rosa',66,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Santo Domingo',66,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Santo Tomás',66,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Tures',66,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 67
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Cureña',67,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('La Virgen',67,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Las Horquetas',67,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Llanuras del Gaspar',67,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ('Puerto Viejo',67,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 68
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Liberia' ,68,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cañas Dulces' ,68,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Mayorga' ,68,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Nacascolo' ,68,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Curubandé' ,68,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 69
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Nicoya' ,69,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Mansión' ,69,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Antonio' ,69,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Quebrada Honda' ,69,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Sámara' ,69,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Nosara' ,69,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Belén de Nosarita' ,69,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 70

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Cruz' ,70,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Bolsón' ,70,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Veintisiete de Abril' ,70,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tempate' ,70,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cartagena' ,70,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cuajiniquil' ,70,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Diriá' ,70,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cabos Velas' ,70,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tamarindo' ,70,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 71

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Bagaces' ,71,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Fortuna' ,71,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Mogote' ,71,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Río Naranjo' ,71,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 72
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Filadelfia' ,72,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Palmira' ,72,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Sardinal' ,72,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Belén' ,72,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- Canton 73

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cañas' ,73,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Palmira' ,73,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Miguel' ,73,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Bebedero' ,73,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Porozal' ,73,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 74
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Las Juntas' ,74,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Sierra' ,74,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Juan' ,74,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Colorado' ,74,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 75
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tilarán' ,75,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Quebrada Grande' ,75,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tronadora' ,75,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Rosa' ,75,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Líbano' ,75,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Tierras Morenas' ,75,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Arenal' ,75,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cabeceras' ,75,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 76
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Carmona' ,76,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Rita' ,76,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Zapotal' ,76,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'San Pablo' ,76,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Porvenir' ,76,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Bejuco' ,76,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 77

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Cruz' ,77,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Cecilia' ,77,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Garita' ,77,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Santa Elena' ,77,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 78
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Hojancha' ,78,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Monte Romo' ,78,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Puerto Carrillo' ,78,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Huacas' ,78,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Matambú' ,78,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 79
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Limón' ,79,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Valle La Estrella' ,79,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Río Blanco' ,79,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Matama' ,79,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 80
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Guápiles' ,80,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Jiménez' ,80,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Rita' ,80,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Roxana' ,80,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cariari' ,80,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Colorado' ,80,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');



INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'La Corona' ,80,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 81
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Siquirres' ,81,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Pacuarito' ,81,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Florida' ,81,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Germania' ,81,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cairo' ,81,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Alegría' ,81,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Reventazón' ,81,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- canton 82

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Bratsi' ,82,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Sixaola' ,82,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Cahuita' ,82,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Telire' ,82,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');


-- CANTON 83
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Matina' ,83,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Batán' ,83,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Carrandi' ,83,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

-- CANTON 84
INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Guácimo' ,84,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Mercedes' ,84,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Pocora' ,84,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Río Jiménez' ,84,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO DISTRICT
(name_district,id_sector, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES ( 'Duacarí' ,84,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');
