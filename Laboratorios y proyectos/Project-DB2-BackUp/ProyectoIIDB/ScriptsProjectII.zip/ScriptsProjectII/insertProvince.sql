INSERT INTO province(id_nation, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'San José',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO province(id_nation, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Alajuela',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO province(id_nation, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Cartago',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO province(id_nation, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Heredia',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO province(id_nation, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Guanacaste',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO province(id_nation, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Puntarenas',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

INSERT INTO province(id_nation, name_province, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES(1,'Limón',SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');
