use bdproject;
insert into professor
(id_person,id_dedication, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (14,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

insert into professor
(id_person,id_dedication, creationDate, userId, lastModifyDate, lastModifyBy)
VALUES (15,1,SYSDATE(),'BDPROJECT',SYSDATE(),'BDPROJECT');

