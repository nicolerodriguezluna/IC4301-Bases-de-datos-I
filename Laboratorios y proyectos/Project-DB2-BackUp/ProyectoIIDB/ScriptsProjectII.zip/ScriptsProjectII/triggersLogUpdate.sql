DELIMITER //
CREATE TRIGGER bdproject.before_update_username
before update on userdb
for each row
begin
	if not(new.user_name<=>old.user_name) Then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'USERNAME CHANGED',old.user_name,new.user_name);
	END if;
end; //
delimiter ;

DELIMITER //
Create TRIGGER before_update_name_dignews
before update on digitalnewspaper
for each row
begin
	if not(old.name_digital_newspaper<=>new.name_digital_newspaper) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NAME CHANGED',old.name_digital_newspaper,new.name_digital_newspaper);
    END if;
end; //
DELIMITER ;

delimiter //
create  TRIGGER before_update_dedi_descrp
before update on dedication
for each row
begin
	if not(old.description_dedication <=> new.description_dedication) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'DESCRIPTION CHANGED',old.description_dedication,new.description_dedication);
	end if;
end; //
delimiter ;

DELIMITER //
create  TRIGGER before_update_country_name
before update on country
for each row
begin
	if not(old.name_country <=> new.name_country) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NAME CHANGED',old.name_country,new.name_country);
	END IF;
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_committe_descrp
before update on committe
for each row
begin
	if not(old.description_committe<=>new.description_committe) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'DESCRIPTION CHANGED',old.description_committe,new.description_committe);
	END IF;
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_college_name
before update on college
for each row
begin
	if not(old.name_college <=> new.name_college) then
		insert into logdb (systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NAME CHANGED',old.name_college,
		new.name_college);
	END IF;
END; //
DELIMITER ;

DELIMITER //
create  TRIGGER before_update_catalog_descrp
before update on catalog
for each row
begin
	if not(old.description_catalog <=> new.description_catalog) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'DESCRIPTION CHANGED',old.description_catalog,new.description_catalog);
	END IF;
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_catalog_news
before update on catalog
for each row
begin
	if not(old.id_newspaper <=> new.id_newspaper) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEWSPAPER CHANGED',(SELECT name_digital_newspaper from digitalnewspaper
		where old.id_newspaper = digitalnewspaper.id_digital_newspaper),(SELECT name_digital_newspaper from digitalnewspaper
		where new.id_newspaper = digitalnewspaper.id_digital_newspaper));
    END IF;
end; //
DELIMITER ;

DELIMITER //
create  TRIGGER before_update_canton_area
before update on canton
for each row
begin
  if not(old.id_area <=> new.id_area) then
	 insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'AREA CHANGED',(SELECT name_province from province
		where old.id_area = province.id_province),(SELECT name_province from province
		where new.id_area = province.id_province));
 END IF;
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_canton_name
before update on canton
for each row
begin
	if not(old.name_canton <=> new.name_canton) then
		insert into logdb (systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NAME CHANGED',old.name_canton,
		new.name_canton);
	END IF;
end;// 
DELIMITER ;

DELIMITER //
create TRIGGER before_update_campus_district
before update on campus
for each row
begin
	if not(old.id_district <=> new.id_district) then
		 insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'DISTRICT CHANGED',(SELECT name_district from district
		where old.id_district = district.id_district),(SELECT name_district from district
		where new.id_district = district.id_district));
	END IF;
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_campus_name
before update on campus
for each row
begin
	if not(old.name_campus <=> new.name_campus) then
		 insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NAME CHANGED',old.name_campus,
		new.name_campus);
	END IF;
end; //
DELIMITER ;

delimiter //
create TRIGGER before_update_campus_uni
before update on campus
for each row
begin
	if not(old.id_university <=> new.id_university) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'COLLEGE CHANGED',(SELECT name_college from college
		where old.id_university = college.id_college),(SELECT name_college from college
		where new.id_university = college.id_college));
	END IF;
END; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_available_descrp
before update on availabilitypr
for each row
begin
	if not(old.description_availability <=> new.description_availability) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'AVAILABILITY DESCR CAHNGED',old.description_availability,
		new.description_availability);
	END IF;
end; //
DELIMITER ;

delimiter //
create  TRIGGER before_update_author_category
before update on author
for each row
begin
	if not(old.id_author_cathegory <=> new.id_author_cathegory) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'CATEGORY CHANGED',(SELECT type_category from authorcategory
		where old.id_author_cathegory = authorcategory.id_author_category),(SELECT type_category from authorcategory
		where new.id_author_cathegory = authorcategory.id_author_category));
	END IF;
END; //
delimiter ;

DELIMITER //
create TRIGGER before_update_authorcat_type
before update on authorcategory
for each row
begin
	if not(old.type_category <=> new.type_category) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'TYPE CHANGED',old.type_category,new.type_category);
	END IF;
END; //
delimiter ;

DELIMITER //
create TRIGGER before_update_article_cat_name
before update on articlecategory
for each row
begin
	if not(old.name_category <=> new.name_category) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NAME CHANGED',old.name_category,new.name_category);
	END IF;
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_article_category
before update on article
for each row
begin
	if not(old.id_art_cat <=> new.id_art_cat) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'CATEGORY CHANGED',(SELECT name_category from articlecategory
		where old.id_art_cat = articlecategory.id_article_category),(SELECT name_category from articlecategory
		where new.id_art_cat = articlecategory.id_article_category));
	END IF;
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_article_committe
before UPDATE on article
for each row
begin
	if not(old.id_committe_art <=> new.id_committe_art) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP,'COMMITTE CHANGED',(SELECT description_committe from committe
		where old.id_committe_art = committe.id_committe),(SELECT description_committe from committe
		where new.id_committe_art = committe.id_committe));
	END IF;
END; // 
DELIMITER ;

DELIMITER //
create TRIGGER before_update_article_date
before update
on article
for each row
BEGIN
	if not(new.publication_date <=> old.publication_date) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'PUBLICATION DATE CHANGE',CAST(old.publication_date as char),
		cast(new.publication_date as char));
	END IF;
end; //
DELIMITER ;

delimiter //
create TRIGGER before_update_article_note
before update
on article
for each row
begin
	if not(old.text_note <=> new.text_note) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NOTE CHANGE',old.text_note,new.text_note);
	END IF;
end; //
delimiter ;

DELIMITER //
create TRIGGER before_update_article_paper
before update
on article
for each row
begin
	if not(old.id_dig_news <=> new.id_dig_news) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEWSPAPER CHANGED',(SELECT name_digital_newspaper from digitalnewspaper
		where old.id_dig_news = digitalnewspaper.id_digital_newspaper),(SELECT  name_digital_newspaper from digitalnewspaper
		where new.id_dig_news = digitalnewspaper.id_digital_newspaper));
	END IF;
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_article_status
before update 
on article
for each row
begin
	if not(old.id_status_article <=> new.id_status_article) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NEW ARTICLE STATUS',(SELECT name_status from status
		where old.id_status_article = status.id_status),(SELECT  name_status from status
		where new.id_status_article = status.id_status));
	END IF;
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_article_title
before update
on article
for each row
begin
	if not(old.title_article <=> new.title_article) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'TITLE CHANGE',old.title_article,new.title_article);
	END IF;
END; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_artcat_descrp
before update
on articlecategory
for each row
begin
	if not(old.description_category <=> new.description_category) then
		insert into logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'DESCRIPTION CHANGED',old.description_category,new.description_category);
	END IF;
END; //
DELIMITER ;

delimiter //
create TRIGGER before_update_art_pub_date
before update
on article
for each row
BEGIN
	if not(old.publication_date <=> new.publication_date) then
		insert into logdb
		(id_log,systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES (s_log.nextval,SYSDATE,CURRENT_TIMESTAMP,'PUBLICATION DATE CHANGE',CAST(old.publication_date AS CHAR),
		CAST(new.publication_date AS char));
	END if;
end; //
DELIMITER ;

DELIMITER //
create TRIGGER before_up_catalog_descr
before update on catalog 
for each row
begin 
    if not(new.description_catalog <=> old.description_catalog)
    then insert into logdb (systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'NAME CHANGED',old.description_catalog, new.description_catalog);
    END if;
END ; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_administrative
before update on administrative
for each row
BEGIN
    if not(new.id_dedication <=> old.id_dedication)
    then INSERT INTO logdb(systemdate,time_log,change_descrp,previous_text,current_text)
    VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'Change of Dedication',(SELECT description_dedication from dedication
    where old.id_dedication = dedication.id_dedication),(SELECT description_dedication from dedication
    where new.id_dedication = dedication.id_dedication));
    END if;
END ; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_administrator
BEFORE UPDATE ON administrator
for each row
begin 
	if not(new.password_admin<=> old.password_admin) then
		INSERT INTO logdb
		(systemdate,time_log,change_descrp,previous_text,current_text)
		VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'PASSWORD CHANGE',old.password_admin,new.password_admin);
	END IF;
END ; //
DELIMITER ;

DELIMITER //
create TRIGGER before_update_campus_district
before update on campus
for each row 
begin
    if not(new.id_district<=> old.id_district)
        then insert into logdb(systemdate,time_log,change_descrp,previous_text,current_text)
        VALUES(SYSDATE(),CURRENT_TIMESTAMP(),'DISTRICT CHANGED', (SELECT name_district from district
        where old.id_district = district.id_district),(SELECT name_district from district
        where new.id_district = district.id_district));
    END if;
END; //
DELIMITER ;

DELIMITER //
create trigger beforeUpdateDistrictName
before insert 
on district
for each row
BEGIN
	if not(new.name_district<=> old.name_district) then
		INSERT INTO logdb
		(systemdate, time_log, change_descrp, previous_text, current_text)
		VALUES (SYSDATE(), CURRENT_TIMESTAMP(), 'New name of district',NULL, new.name_district);
    END IF;
END;//
DELIMITER ;