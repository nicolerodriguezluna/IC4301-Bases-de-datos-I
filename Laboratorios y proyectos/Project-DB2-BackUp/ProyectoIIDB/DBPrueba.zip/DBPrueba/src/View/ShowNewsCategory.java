/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Control.ConnectDB;
import Control.Cursors;
import Model.Article;
import Model.Author;
import Model.Favourite;
import Model.Person;
import Model.Photo;
import Model.Review;
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author Jeffrey Leiva
 */
public class ShowNewsCategory extends javax.swing.JFrame {

    /**
     * Creates new form ShowNewsCategory
     */
    int xMouse,yMouse;
    Article article;
    boolean commentsClicked;
    Photo photo;
    int clicked;
    ArrayList<Review> revArticle;
    ArrayList<Photo> commentPhotos;
    Author author;
    Person personAuthor;
    String nameAuthor;
    String dateString;
    JScrollPane scrollPane;
    JPanel bgLast;
    int idUser;
    public ShowNewsCategory(Article art,Photo ph,int idUser) throws SQLException {
        initComponents();
        this.idUser = idUser;
        this.commentsClicked = false;
        this.bgLast = new javax.swing.JPanel();
        this.article = art;
        this.photo = ph;
        this.clicked = 0;
        this.author = Cursors.getAuthorByArticle(art.getIdArticle());
        this.revArticle =  Cursors.getReviewsByArticle(article.getIdArticle());
        this.personAuthor = Cursors.getPerson(this.author.getIdPerson());
        this.nameAuthor = personAuthor.getFirstName()+" "+personAuthor.getSecondName()+" "+personAuthor.getFirstSurname()+" "+personAuthor.getSecondSurname();
        ArrayList<Article> favsUser = Cursors.getUserFavourites(idUser);
        for(Article t: favsUser){
             System.out.println(t.getIdArticle()+ "id de articulo con like");
             if(t.getIdArticle()==article.getIdArticle()){
                    System.out.println(t.getIdArticle()+ "id del articulo");
                    clicked = 1;
                    youLikeThisText.setText("Te gusta esto");
             }
        }
        Date date = art.getPublicationDate();
        this.dateString = date.toString();
        ArrayList<Integer> completeTextLenghts = new ArrayList<>();
        String [] Text = art.getTextNote().split("\n");
        Font f = new java.awt.Font("Roboto Black", 1, 12);
        for(String txt:Text){
            completeTextLenghts.add(txt.length());
        }    
        Canvas c = new Canvas();
        FontMetrics fontMetrics = c.getFontMetrics(f);
        int max = Collections.max(completeTextLenghts);
        int textWidth = 0;
        for(String str: Text){
            if(str.length()==max){
                textWidth = fontMetrics.stringWidth(str);
            }
        }
        textWidth+=500;
        bgLast.setBackground(new java.awt.Color(255, 255, 255));
        bgLast.setLayout(null);
        File selectedFile = new File(ph.getRoute());
            BufferedImage img = null;
            try {  
                img = ImageIO.read(selectedFile);
            } catch (IOException ex) {
                Logger.getLogger(createArticle.class.getName()).log(Level.SEVERE, null, ex);
            }
        ImageIcon image1 = new ImageIcon(img);
        JLabel label = new JLabel(image1);
        int heightIcon = image1.getIconHeight();
        label.setBounds(212, 0,424 ,heightIcon);
        bgLast.add(label);
        int y = heightIcon+20;
        JLabel textAuthor = new JLabel();
        textAuthor.setFont(f);
        textAuthor.setBounds(0, y, textWidth, 20);
        textAuthor.setText(nameAuthor); 
        bgLast.add(textAuthor);
        y+=25;
        JLabel textDate = new JLabel();
        textDate.setFont(f);
        textDate.setBounds(0, y, textWidth, 20);
        textDate.setText(dateString); 
        bgLast.add(textDate);
        y+=50;
        for(String cm: Text){
            JLabel labelText = new JLabel();
            label.setFont(f);
            labelText.setBounds(0, y, textWidth,20);
            labelText.setText(cm);
            bgLast.add(labelText);
            y+=20;    
        }
        bgLast.setPreferredSize(new Dimension(textWidth, 50 + y));
        scrollPane = new JScrollPane(bgLast);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(0,0,850,410);
                
        content.removeAll();
        content.add(scrollPane, BorderLayout.CENTER); 
        content.revalidate();
        content.repaint();
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        headerPanel = new javax.swing.JPanel();
        backPanel = new javax.swing.JPanel();
        backTxt = new javax.swing.JLabel();
        exitPanel = new javax.swing.JPanel();
        exitTxt = new javax.swing.JLabel();
        likeAndStarsPanel = new javax.swing.JPanel();
        likePanel = new javax.swing.JPanel();
        likeLabel = new javax.swing.JLabel();
        youLikeThisText = new javax.swing.JLabel();
        commentButton = new javax.swing.JPanel();
        commentTxt = new javax.swing.JLabel();
        content = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        headerPanel.setBackground(new java.awt.Color(255, 255, 255));
        headerPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerPanelMouseDragged(evt);
            }
        });
        headerPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerPanelMousePressed(evt);
            }
        });

        backPanel.setBackground(new java.awt.Color(255, 255, 255));

        backTxt.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        backTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        backTxt.setText("←");
        backTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        backTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                backTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                backTxtMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                backTxtMousePressed(evt);
            }
        });

        javax.swing.GroupLayout backPanelLayout = new javax.swing.GroupLayout(backPanel);
        backPanel.setLayout(backPanelLayout);
        backPanelLayout.setHorizontalGroup(
            backPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(backTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
        );
        backPanelLayout.setVerticalGroup(
            backPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(backTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        exitPanel.setBackground(new java.awt.Color(255, 255, 255));

        exitTxt.setFont(new java.awt.Font("Roboto Thin", 0, 24)); // NOI18N
        exitTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitTxt.setText("X");
        exitTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exitTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitTxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout exitPanelLayout = new javax.swing.GroupLayout(exitPanel);
        exitPanel.setLayout(exitPanelLayout);
        exitPanelLayout.setHorizontalGroup(
            exitPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(exitTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
        );
        exitPanelLayout.setVerticalGroup(
            exitPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(exitTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout headerPanelLayout = new javax.swing.GroupLayout(headerPanel);
        headerPanel.setLayout(headerPanelLayout);
        headerPanelLayout.setHorizontalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addComponent(backPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 690, Short.MAX_VALUE)
                .addComponent(exitPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        headerPanelLayout.setVerticalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGroup(headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(backPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(exitPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(40, 40, 40))
        );

        bg.add(headerPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 60));

        likeAndStarsPanel.setBackground(new java.awt.Color(87, 170, 170));

        likePanel.setBackground(new java.awt.Color(85, 170, 170));

        likeLabel.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        likeLabel.setForeground(new java.awt.Color(255, 255, 255));
        likeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        likeLabel.setText("Me gusta");
        likeLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        likeLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                likeLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                likeLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                likeLabelMouseExited(evt);
            }
        });

        javax.swing.GroupLayout likePanelLayout = new javax.swing.GroupLayout(likePanel);
        likePanel.setLayout(likePanelLayout);
        likePanelLayout.setHorizontalGroup(
            likePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(likePanelLayout.createSequentialGroup()
                .addComponent(likeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                .addContainerGap())
        );
        likePanelLayout.setVerticalGroup(
            likePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(likeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
        );

        youLikeThisText.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        youLikeThisText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        commentButton.setBackground(new java.awt.Color(85, 170, 170));

        commentTxt.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        commentTxt.setForeground(new java.awt.Color(255, 255, 255));
        commentTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        commentTxt.setText("Comentarios");
        commentTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        commentTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                commentTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                commentTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                commentTxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout commentButtonLayout = new javax.swing.GroupLayout(commentButton);
        commentButton.setLayout(commentButtonLayout);
        commentButtonLayout.setHorizontalGroup(
            commentButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(commentTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
        );
        commentButtonLayout.setVerticalGroup(
            commentButtonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(commentTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout likeAndStarsPanelLayout = new javax.swing.GroupLayout(likeAndStarsPanel);
        likeAndStarsPanel.setLayout(likeAndStarsPanelLayout);
        likeAndStarsPanelLayout.setHorizontalGroup(
            likeAndStarsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(likeAndStarsPanelLayout.createSequentialGroup()
                .addComponent(likePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(youLikeThisText, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 322, Short.MAX_VALUE)
                .addComponent(commentButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        likeAndStarsPanelLayout.setVerticalGroup(
            likeAndStarsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(likeAndStarsPanelLayout.createSequentialGroup()
                .addGroup(likeAndStarsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(likePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(youLikeThisText, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, likeAndStarsPanelLayout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(commentButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        bg.add(likeAndStarsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 850, 30));

        content.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout contentLayout = new javax.swing.GroupLayout(content);
        content.setLayout(contentLayout);
        contentLayout.setHorizontalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 850, Short.MAX_VALUE)
        );
        contentLayout.setVerticalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 410, Short.MAX_VALUE)
        );

        bg.add(content, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 850, 410));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backTxtMouseClicked
        try {
            otherCategoriesSelection newSelect = new otherCategoriesSelection(idUser);
            newSelect.setVisible(true);
            this.dispose();
        } catch (SQLException ex) {
            Logger.getLogger(ShowNewsCategory.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_backTxtMouseClicked

    private void exitTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitTxtMouseClicked

    private void commentTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_commentTxtMouseClicked
        Comments comment = null;
        if(idUser!=-1){
            try {
                comment = new Comments(article,this.idUser,photo);
                comment.setVisible(true);
            } catch (SQLException ex) {
                Logger.getLogger(showNews.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.dispose();
            commentsClicked = true;
        }else{
            JOptionPane.showMessageDialog(this,"Para comentar debe tener una cuenta de usuario registrada");
        }
    }//GEN-LAST:event_commentTxtMouseClicked

    private void likeLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_likeLabelMouseClicked
        if(idUser!=-1){
            if(clicked==0){
                clicked = 1;
                youLikeThisText.setText("Te gusta esto");
                long millis=System.currentTimeMillis();  
                java.sql.Date date = new java.sql.Date(millis);      
                try {
                    ConnectDB.insertFavourite(article.getIdArticle(),this.idUser,date);
                } catch (SQLException ex) {
                    Logger.getLogger(showNews.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else{
                clicked = 0;
                youLikeThisText.setText("");
                try {
                    ConnectDB.deleteFavouriteUnique(this.idUser, article.getIdArticle());
                } catch (SQLException ex) {
                    Logger.getLogger(showNews.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }else{
            JOptionPane.showMessageDialog(this,"Para dar favorito debe tener una cuenta de usuario registrada");
        }
    }//GEN-LAST:event_likeLabelMouseClicked

    private void commentTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_commentTxtMouseEntered
       commentTxt.setForeground(new Color(0,128,128));
    }//GEN-LAST:event_commentTxtMouseEntered

    private void commentTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_commentTxtMouseExited
       commentTxt.setForeground(Color.white);
    }//GEN-LAST:event_commentTxtMouseExited

    private void likeLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_likeLabelMouseEntered
       likeLabel.setForeground(new Color(0,128,128));
    }//GEN-LAST:event_likeLabelMouseEntered

    private void likeLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_likeLabelMouseExited
       likeLabel.setForeground(Color.white);
    }//GEN-LAST:event_likeLabelMouseExited

    private void backTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backTxtMouseEntered
         backTxt.setForeground(Color.white);
         backPanel.setBackground(new Color(87,170,170));
    }//GEN-LAST:event_backTxtMouseEntered

    private void backTxtMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backTxtMousePressed
        backPanel.setBackground(Color.white);
        backTxt.setForeground(Color.black);
    }//GEN-LAST:event_backTxtMousePressed

    private void exitTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseEntered
       exitTxt.setForeground(Color.white);
       exitPanel.setBackground(Color.red);
    }//GEN-LAST:event_exitTxtMouseEntered

    private void exitTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseExited
        exitTxt.setForeground(Color.black);
        exitPanel.setBackground(Color.white);
    }//GEN-LAST:event_exitTxtMouseExited

    private void backTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backTxtMouseExited
        backTxt.setForeground(Color.black);
        backPanel.setBackground(Color.white);
    }//GEN-LAST:event_backTxtMouseExited

    private void headerPanelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_headerPanelMousePressed

    private void headerPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-xMouse,y-yMouse);
    }//GEN-LAST:event_headerPanelMouseDragged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel backPanel;
    private javax.swing.JLabel backTxt;
    private javax.swing.JPanel bg;
    private javax.swing.JPanel commentButton;
    private javax.swing.JLabel commentTxt;
    private javax.swing.JPanel content;
    private javax.swing.JPanel exitPanel;
    private javax.swing.JLabel exitTxt;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JPanel likeAndStarsPanel;
    private javax.swing.JLabel likeLabel;
    private javax.swing.JPanel likePanel;
    private javax.swing.JLabel youLikeThisText;
    // End of variables declaration//GEN-END:variables
}
