/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Control.Statistics;
import Model.ArticlesPerCollege;
import Model.AuthorAverageReview;
import Model.AuthorPerCollege;
import Model.AuthorRangeAge;
import Model.Top10Products;
import Model.TopNAuthors;
import Model.TotalArticlesxAuthor;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author Jeffrey Leiva
 */
public class manageStatistics extends javax.swing.JFrame {

    /**
     * Creates new form manageSttistics
     */
    int xMouse;
    int yMouse;
    ArrayList<ArticlesPerCollege> articles;
    ArrayList<AuthorAverageReview> average;
    ArrayList<AuthorRangeAge> range;
    ArrayList<AuthorPerCollege> authorCollege;
    ArrayList<TopNAuthors> topAuthors;
    ArrayList<Top10Products> products;
    ArrayList<TotalArticlesxAuthor> articlexauthor;
    int par;
    int identify;
    int idUser;
    DefaultTableModel dtm = new DefaultTableModel();
    public manageStatistics(int identify,int idCategory,int idCollege,int idGender,int parameter,int idUser) throws SQLException {
        initComponents(); 
        this.idUser = idUser;
        this.identify = identify;
        par = parameter;
        String[] header = new String[]{"Nombre","Cantidad"};
        dtm.setColumnIdentifiers(header);
        table.setModel(dtm);
        if(identify==1){
            articles = Statistics.getArticlesPerCollege();
            for(ArticlesPerCollege artColl: articles){
                dtm.addRow(new Object[]{
                artColl.getNameCollege(), artColl.getTotal()});
            }
            setPieArticlePerCollege();
        }
        if(identify==2){
            average = Statistics.averageAuthorReview();
            for(AuthorAverageReview rev: average){
                dtm.addRow(new Object[]{
                rev.getNameAuthor(), rev.getAverage()});
            }   
            setPieAverageAuthorReview();
        }
        if(identify==3){
            authorCollege = Statistics.getAuthorsPerCollege();
            for(AuthorPerCollege aut: authorCollege){
                 dtm.addRow(new Object[]{
                 aut.getNameCollege(), aut.getCount()});
            }
            setPieAuthorPerCollege();
        }
        if(identify==4){
            String[] headerProd = new String[]{"Rango","Cantidad"};
            dtm.setColumnIdentifiers(headerProd);
            if(idCollege!=-1)
                this.range = Statistics.getAuthorsByAgeCollege(idCollege);        
            if(idCategory!=-1)
                this.range = Statistics.getAuthorsByAgeType(idCategory); 
            if(idGender!=-1)
                this.range = Statistics.getAuthorsByAgeGender(idGender); 
            for(AuthorRangeAge ran: range){
                 dtm.addRow(new Object[]{
                 ran.getRange(), ran.getCount()});
            }
            setPieAuthorRange();
        }
        if(identify==5){
            String[] headerArt = new String[]{"Nombre","Cantidad de artículos"};
            dtm.setColumnIdentifiers(headerArt);
            if(idCategory!=-1)
                this.topAuthors = Statistics.getTopAuthorsByCategory(parameter, idCategory);
            if(idGender!=-1)
                System.out.print(idGender + "id gender\n");
                this.topAuthors = Statistics.getTopAuthorsByGender(parameter, idGender);
            if(idCollege!=-1)
                this.topAuthors = Statistics.getTopAuthorsByCollege(parameter, idCollege);
            for(TopNAuthors n: topAuthors){
                 dtm.addRow(new Object[]{
                 n.getName(), n.getCount()});
            }
            setPieTopAuthor();
            
        }
        if(identify==6){
            String[] headerProd = new String[]{"Nombre","Costo","Total vendidos"};
            dtm.setColumnIdentifiers(headerProd);
            this.products = Statistics.getTopPurchasedProducts();
            for(Top10Products prod: products){
                dtm.addRow(new Object[]{
                 prod.getDescription(), prod.getCost(),prod.getTotalCount()});
            }
            setPieProducts();
        }
        if(identify==7){
            this.articlexauthor = Statistics.getTotalArticlesxAuthor();
            for(TotalArticlesxAuthor autart: articlexauthor){
                dtm.addRow(new Object[]{
                 autart.getName(), autart.getCount()});
            }
            setPieArticlexAuthor();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        headerPanel = new javax.swing.JPanel();
        exitPanel = new javax.swing.JPanel();
        exitTxt = new javax.swing.JLabel();
        backPanel = new javax.swing.JPanel();
        backTxt = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        content = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        headerPanel.setBackground(new java.awt.Color(255, 255, 255));
        headerPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerPanelMouseDragged(evt);
            }
        });
        headerPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerPanelMousePressed(evt);
            }
        });

        exitPanel.setBackground(new java.awt.Color(255, 255, 255));
        exitPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        exitTxt.setFont(new java.awt.Font("Roboto Thin", 0, 24)); // NOI18N
        exitTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitTxt.setText("X");
        exitTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exitTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitTxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout exitPanelLayout = new javax.swing.GroupLayout(exitPanel);
        exitPanel.setLayout(exitPanelLayout);
        exitPanelLayout.setHorizontalGroup(
            exitPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(exitTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
        );
        exitPanelLayout.setVerticalGroup(
            exitPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(exitTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        backPanel.setBackground(new java.awt.Color(255, 255, 255));

        backTxt.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        backTxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        backTxt.setText("←");
        backTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        backTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                backTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                backTxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout backPanelLayout = new javax.swing.GroupLayout(backPanel);
        backPanel.setLayout(backPanelLayout);
        backPanelLayout.setHorizontalGroup(
            backPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(backTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
        );
        backPanelLayout.setVerticalGroup(
            backPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(backTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout headerPanelLayout = new javax.swing.GroupLayout(headerPanel);
        headerPanel.setLayout(headerPanelLayout);
        headerPanelLayout.setHorizontalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, headerPanelLayout.createSequentialGroup()
                .addComponent(backPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 710, Short.MAX_VALUE)
                .addComponent(exitPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        headerPanelLayout.setVerticalGroup(
            headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerPanelLayout.createSequentialGroup()
                .addGroup(headerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(exitPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(backPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        bg.add(headerPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 50));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(table);

        bg.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 60, 850, 90));

        content.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout contentLayout = new javax.swing.GroupLayout(content);
        content.setLayout(contentLayout);
        contentLayout.setHorizontalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 850, Short.MAX_VALUE)
        );
        contentLayout.setVerticalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        bg.add(content, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 850, 300));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitTxtMouseClicked

    private void exitTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseEntered
        exitTxt.setForeground(Color.white);
        exitPanel.setBackground(Color.red);
    }//GEN-LAST:event_exitTxtMouseEntered

    private void exitTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitTxtMouseExited
        exitTxt.setForeground(Color.black);
        exitPanel.setBackground(Color.white);
    }//GEN-LAST:event_exitTxtMouseExited

    private void backTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backTxtMouseEntered
        backTxt.setForeground(Color.white);
        backPanel.setBackground(new Color(158,210,196));
    }//GEN-LAST:event_backTxtMouseEntered

    private void backTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backTxtMouseExited
        backTxt.setForeground(Color.black);
        backPanel.setBackground(Color.white);
    }//GEN-LAST:event_backTxtMouseExited

    private void headerPanelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_headerPanelMousePressed

    private void headerPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x-xMouse,y-yMouse);
    }//GEN-LAST:event_headerPanelMouseDragged

    private void backTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backTxtMouseClicked
        if(identify==4){
            try {
                authorRangeSelection sel = new authorRangeSelection(this.idUser);
                sel.setVisible(true);
                this.dispose();
            } catch (SQLException ex) {
                Logger.getLogger(manageStatistics.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(identify==5){
            try {
                topAuthorSelection sel = new topAuthorSelection(this.idUser);
                sel.setVisible(true);
                this.dispose();
            } catch (SQLException ex) {
                Logger.getLogger(manageStatistics.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else{
            statisticsMenu menu = new statisticsMenu(this.idUser);
            menu.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_backTxtMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel backPanel;
    private javax.swing.JLabel backTxt;
    private javax.swing.JPanel bg;
    private javax.swing.JPanel content;
    private javax.swing.JPanel exitPanel;
    private javax.swing.JLabel exitTxt;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables

    private void setPieArticlePerCollege() {
        DefaultPieDataset dat = new DefaultPieDataset();
        for(ArticlesPerCollege art: articles){
            dat.setValue(art.getNameCollege(), art.getTotal());
        }
        JFreeChart graphic = ChartFactory.createPieChart(
                "Artículos por universidad", dat, true,true,false);
        ChartPanel chart = new ChartPanel(graphic);
        chart.setMouseWheelEnabled(true);
        chart.setPreferredSize(new Dimension(850,200));
        JScrollPane scrollPane = new JScrollPane(chart);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(0,0,850,300);
                
        content.removeAll();
        content.add(scrollPane, BorderLayout.CENTER); 
        content.revalidate();
        content.repaint();
    }

    private void setPieAverageAuthorReview() {
        DefaultCategoryDataset dat = new DefaultCategoryDataset();
        for(AuthorAverageReview rev: average){
            dat.setValue(rev.getAverage(),rev.getNameAuthor(),"Media");
        }
        JFreeChart graphic = ChartFactory.createBarChart(
                "Media de reviews de los autores", "Autores","Media",dat,PlotOrientation.VERTICAL, true,true,false);
        ChartPanel chart = new ChartPanel(graphic);
        chart.setMouseWheelEnabled(true);
        chart.setPreferredSize(new Dimension(850,200));
        JScrollPane scrollPane = new JScrollPane(chart);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(0,0,850,300);
                
        content.removeAll();
        content.add(scrollPane, BorderLayout.CENTER); 
        content.revalidate();
        content.repaint();
    }

    private void setPieAuthorPerCollege() {
        DefaultPieDataset dat = new DefaultPieDataset();
        for(AuthorPerCollege avg: authorCollege){
            dat.setValue(avg.getNameCollege(), avg.getCount());
        }
        JFreeChart graphic = ChartFactory.createPieChart(
                "Autores por universidad", dat, true,true,false);
        ChartPanel chart = new ChartPanel(graphic);
        chart.setMouseWheelEnabled(true);
        chart.setPreferredSize(new Dimension(850,200));
        JScrollPane scrollPane = new JScrollPane(chart);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(0,0,850,300);
                
        content.removeAll();
        content.add(scrollPane, BorderLayout.CENTER); 
        content.revalidate();
        content.repaint();
    }

    private void setPieAuthorRange() {
       DefaultCategoryDataset dat = new DefaultCategoryDataset();
        for(AuthorRangeAge re: range){
            dat.setValue(re.getCount(),re.getRange(),"Rango");
        }
        JFreeChart graphic = ChartFactory.createBarChart(
                "Autores por edad", "Rango","Total",dat,PlotOrientation.VERTICAL, true,true,false);
        ChartPanel chart = new ChartPanel(graphic);
        chart.setMouseWheelEnabled(true);
        chart.setPreferredSize(new Dimension(850,200));
        JScrollPane scrollPane = new JScrollPane(chart);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(0,0,850,300);
                
        content.removeAll();
        content.add(scrollPane, BorderLayout.CENTER); 
        content.revalidate();
        content.repaint();
    }

    private void setPieTopAuthor() {
        DefaultPieDataset dat = new DefaultPieDataset();
        for(TopNAuthors aut: topAuthors){
            if(aut.getName()!=null)
                dat.setValue(aut.getName(), aut.getCount());
        }
        JFreeChart graphic = ChartFactory.createPieChart(
                "Top de autores", dat, true,true,false);
        ChartPanel chart = new ChartPanel(graphic);
        chart.setMouseWheelEnabled(true);
        chart.setPreferredSize(new Dimension(850,200));
        JScrollPane scrollPane = new JScrollPane(chart);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(0,0,850,300);
                
        content.removeAll();
        content.add(scrollPane, BorderLayout.CENTER); 
        content.revalidate();
        content.repaint();
    }

    private void setPieProducts() {
        DefaultPieDataset dat = new DefaultPieDataset();
        for(Top10Products aut: products){
            dat.setValue(aut.getDescription(), aut.getTotalCount());
        }
        JFreeChart graphic = ChartFactory.createPieChart(
                "Top 10 Productos más vendidos", dat, true,true,false);
        ChartPanel chart = new ChartPanel(graphic);
        chart.setMouseWheelEnabled(true);
        chart.setPreferredSize(new Dimension(850,200));
        JScrollPane scrollPane = new JScrollPane(chart);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(0,0,850,300);
                
        content.removeAll();
        content.add(scrollPane, BorderLayout.CENTER); 
        content.revalidate();
        content.repaint();
    }

    private void setPieArticlexAuthor() {
       DefaultPieDataset dat = new DefaultPieDataset();
        for(TotalArticlesxAuthor autart: articlexauthor){
            dat.setValue(autart.getName(), autart.getCount());
        }
        JFreeChart graphic = ChartFactory.createPieChart(
                "Artículos por autor", dat, true,true,false);
        ChartPanel chart = new ChartPanel(graphic);
        chart.setMouseWheelEnabled(true);
        chart.setPreferredSize(new Dimension(850,200));
        JScrollPane scrollPane = new JScrollPane(chart);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(0,0,850,300);
                
        content.removeAll();
        content.add(scrollPane, BorderLayout.CENTER); 
        content.revalidate();
        content.repaint();
    }

}
