/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package View;

import Control.ConnectDB;
import Control.Cursors;
import Model.Campus;
import Model.College;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Jeffrey Leiva
 */
public class Controller {
    
    menuPrincipal principal;
    lastNews lastNews;
    Controller () throws SQLException, IOException{
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, IOException, NoSuchAlgorithmException {
        ArrayList<Campus> camp = Cursors.getCampus();
        for(Campus c: camp){
            System.out.println(c.toString());
            System.out.println("\n");
        }
        int points = Cursors.getAuthorTotalPoints(20);
        System.out.println(points+" puntos del autor\n");
        College co = Cursors.getCollegeByAuthor(20);
        System.out.println("\n");
        System.out.println(co.toString());
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Enter password\n");

        String password = "n0tt2003Nikol30528";  // Read user input 01Imagine1998
        System.out.println();  // Output user input
       
        String encrypted = MD5(password);
        System.out.println(encrypted+"\n");
        String newPass = myObj.nextLine();
        String encryptedNewPass = MD5(newPass);
        System.out.println(encryptedNewPass);
        System.out.println(encryptedNewPass.equals(encrypted));
        
    }
    
    private static String MD5(String password) throws NoSuchAlgorithmException{
        try{
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            byte []array = md.digest(password.getBytes());
            StringBuffer sb = new StringBuffer();
            for(int i = 0;i<array.length;i++){
                sb.append(Integer.toHexString((array[i] & 0xFF)| 0X100).substring(1,3));
                
            }
            return sb.toString();
        } catch(java.security.NoSuchAlgorithmException e){
            
        }
        return null;
    }
    
}
