/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class Administrative {
    int idAdministrative;
    int idDedication;
    
    public Administrative(){
    }
    
    public Administrative(int idPerson,int dedication){
        this.idAdministrative = idPerson;
        this.idDedication = dedication;
    }

    public int getIdAdministrative() {
        return idAdministrative;
    }

    public void setIdAdministrative(int idAdministrative) {
        this.idAdministrative = idAdministrative;
    }

    public int getIdDedication() {
        return idDedication;
    }

    public void setIdDedication(int idDedication) {
        this.idDedication = idDedication;
    }
    
}
