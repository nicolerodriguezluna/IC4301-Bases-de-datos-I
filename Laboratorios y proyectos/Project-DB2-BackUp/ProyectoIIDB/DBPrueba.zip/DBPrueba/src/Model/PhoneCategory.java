/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class PhoneCategory {
    int idCategory;
    String description;

    public PhoneCategory() {
    }

    public PhoneCategory(int idCategory, String description) {
        this.idCategory = idCategory;
        this.description = description;
    }

    public void setIdCategory(int idCategory) {
        this.idCategory = idCategory;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getIdCategory() {
        return idCategory;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return "PhoneCategory{" + "idCategory=" + idCategory + ", description=" + description + '}';
    }
    
    
}
