/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class Committee {
    int idCommittee;
    String description;
    int idCampus;
    
    public Committee(){}
    
    public Committee(int id,String description,int idCampus){
        this.idCommittee = id;
        this.description = description;
        this.idCampus = idCampus;
    }

    public int getIdCommittee() {
        return idCommittee;
    }

    public void setIdCommittee(int idCommittee) {
        this.idCommittee = idCommittee;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getIdCampus() {
        return idCampus;
    }

    public void setIdCampus(int idCampus) {
        this.idCampus = idCampus;
    }
    
    
    
}
