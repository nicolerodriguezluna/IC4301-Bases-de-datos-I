/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Jeffrey Leiva
 */
public class AuthorAverageReview {
    float average;
    String nameAuthor;
    
    public AuthorAverageReview(){}
    
    public AuthorAverageReview(float average,String name){
        this.average = average;
        this.nameAuthor = name;
    }

    public float getAverage() {
        return average;
    }

    public void setAverage(float average) {
        this.average = average;
    }

    public String getNameAuthor() {
        return nameAuthor;
    }

    public void setNameAuthor(String nameAuthor) {
        this.nameAuthor = nameAuthor;
    }

    @Override
    public String toString() {
        return "AuthorAverageReview{" + "average=" + average + ", nameAuthor=" + nameAuthor + '}';
    }
    
    
}
