/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class ProductXAuthor {
    int idProduct;
    int idAuthor;

    public ProductXAuthor() {
    }

    public ProductXAuthor(int idProduct, int idAuthor) {
        this.idProduct = idProduct;
        this.idAuthor = idAuthor;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    public void setIdAuthor(int idAuthor) {
        this.idAuthor = idAuthor;
    }

    public int getIdProduct() {
        return idProduct;
    }

    public int getIdAuthor() {
        return idAuthor;
    }

    @Override
    public String toString() {
        return "ProductXAuthor{" + "idProduct=" + idProduct + ", idAuthor=" + idAuthor + '}';
    }
    
    
}
