/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class User {
    int idPerson;
    int idUser;
    String password;
    String userName;

    public User() {
    }

    public User(int idPerson, String password,String username,int idUser) {
        this.idPerson = idPerson;
        this.password = password;
        this.userName = username;
        this.idUser = idUser;
    }

    public void setIdPerson(int idPerson) {
        this.idPerson = idPerson;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getIdPerson() {
        return idPerson;
    }

    public String getPassword() {
        return password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    
    @Override
    public String toString() {
        return "User{" + "idPerson=" + idPerson + ", password=" + password + '}';
    }
    
    
}
