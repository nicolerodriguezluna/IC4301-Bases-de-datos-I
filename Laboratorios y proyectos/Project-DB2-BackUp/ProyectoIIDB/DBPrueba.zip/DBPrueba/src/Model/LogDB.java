/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.*;
import java.util.Date;

/**
 *
 * @author Jeffrey Leiva
 */
public class LogDB {
    int idLog;
    Date systemDate;
    Timestamp time;
    String description;
    String previous;
    String current;
    
    public LogDB(){}
    
    public LogDB(int id,Date date,Timestamp stamp,String description,String previous,String current){
        this.idLog = id;
        this.systemDate =date;
        this.time = stamp;
        this.description = description;
        this.previous = previous;
        this.current = current;
    }

    public int getIdLog() {
        return idLog;
    }

    public void setIdLog(int idLog) {
        this.idLog = idLog;
    }

    public Date getSystemDate() {
        return systemDate;
    }

    public void setSystemDate(Date systemDate) {
        this.systemDate = systemDate;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrevious() {
        return previous;
    }

    public void setPrevious(String previous) {
        this.previous = previous;
    }

    public String getCurrent() {
        return current;
    }

    public void setCurrent(String current) {
        this.current = current;
    }
    
    
}
