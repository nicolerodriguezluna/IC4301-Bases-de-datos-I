/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Alexander
 */
public class Status {
    int id;
    String name;

    public Status() {
    }

    public Status(int idStatus, String name) {
        this.id = idStatus;
        this.name = name;
    }

    public void setIdStatus(int idStatus) {
        this.id = idStatus;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIdStatus() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Status{" + "idStatus=" + id + ", name=" + name + '}';
    }
    
}
