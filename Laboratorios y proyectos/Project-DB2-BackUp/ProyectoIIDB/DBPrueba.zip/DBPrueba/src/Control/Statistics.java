/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Model.ArticlesPerCollege;
import Model.AuthorAverageReview;
import Model.AuthorPerCollege;
import Model.AuthorRangeAge;
import Model.Person;
import Model.Top10Products;
import Model.TopNAuthors;
import Model.TotalArticlesxAuthor;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import oracle.jdbc.internal.OracleTypes;

/**
 *
 * @author Jeffrey Leiva
 */
public class Statistics {
    
    public static ArrayList<AuthorAverageReview> averageAuthorReview() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_avg_review()}");
        
        ResultSet rs = sql.executeQuery();
        ArrayList<AuthorAverageReview> averages = new ArrayList<>();
        while(rs.next()){
            AuthorAverageReview authoraverage = new AuthorAverageReview();
            authoraverage.setAverage(rs.getFloat("average_stars"));
            authoraverage.setNameAuthor(rs.getString("complete_name"));
            averages.add(authoraverage);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return averages;
    }
    
    public static ArrayList<ArticlesPerCollege> getArticlesPerCollege() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call articles_per_university()}");

        ResultSet rs = sql.executeQuery();
        ArrayList<ArticlesPerCollege> statistics = new ArrayList<>();
        while(rs.next()){
            ArticlesPerCollege statistic = new ArticlesPerCollege();
            statistic.setTotal(rs.getInt("countArticles"));
            statistic.setNameCollege(rs.getString("name_college"));
            statistics.add(statistic);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return statistics;
    }
    
    public static ArrayList<AuthorPerCollege> getAuthorsPerCollege() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call authors_per_college()}");

        ResultSet rs = sql.executeQuery();
        ArrayList<AuthorPerCollege> statistics = new ArrayList<>();
        while(rs.next()){
            AuthorPerCollege statistic = new AuthorPerCollege();
            statistic.setNameCollege(rs.getString("name_college"));
            statistic.setCount(rs.getInt("countAuthors"));   
            statistics.add(statistic);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return statistics;
    }
    
    public static ArrayList<TopNAuthors> getTopAuthorsByCategory(int parameter,int idCategory) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_topn_authors_category(?,?)}");
        sql.setInt(1,parameter);
        sql.setInt(2, idCategory);
        
        ResultSet rs = sql.executeQuery();
        ArrayList<TopNAuthors> statistics = new ArrayList<>();
        while(rs.next()){
            TopNAuthors statistic = new TopNAuthors();
            statistic.setCount(rs.getInt("count_articles"));
            statistic.setName(rs.getString("full_name"));
            statistics.add(statistic);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return statistics;
    }
    
    public static ArrayList<TopNAuthors> getTopAuthorsByCollege(int parameter,int idCollege) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_topn_authors_college(?,?)}");
        sql.setInt(1,parameter);
        sql.setInt(2, idCollege);

        
        ResultSet rs = sql.executeQuery();
        ArrayList<TopNAuthors> statistics = new ArrayList<>();
        while(rs.next()){
            TopNAuthors statistic = new TopNAuthors();
            statistic.setCount(rs.getInt("count_articles"));
            statistic.setName(rs.getString("full_name"));
            statistics.add(statistic);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return statistics;
    }
    
       
    
    public static ArrayList<TopNAuthors> getTopAuthorsByGender(int parameter,int idGender) throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_topn_authors_gender(?,?)}");
        sql.setInt(1,parameter);
        sql.setInt(2, idGender);
   
        ResultSet rs = sql.executeQuery();
        ArrayList<TopNAuthors> statistics = new ArrayList<>();
        while(rs.next()){
            TopNAuthors statistic = new TopNAuthors();
            statistic.setCount(rs.getInt("count_articles"));
            statistic.setName(rs.getString("full_name"));
            statistics.add(statistic);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return statistics;
    }
    
    public static ArrayList<TotalArticlesxAuthor> getTotalArticlesxAuthor() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_author_articles()}");
        
        ResultSet rs = sql.executeQuery();
        ArrayList<TotalArticlesxAuthor> statistics = new ArrayList<>();
        while(rs.next()){
            TotalArticlesxAuthor statistic = new TotalArticlesxAuthor();
            statistic.setCount(rs.getInt("totalArticle"));
            statistic.setName(rs.getString("complete_name"));
            statistics.add(statistic);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return statistics;
    }
    
    public static ArrayList<AuthorRangeAge> getAuthorsByAgeGender(int idGender)throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_authors_byage_gender(?)}");
        sql.setInt(1, idGender);

        ResultSet rs = sql.executeQuery();
        ArrayList<AuthorRangeAge> statistics = new ArrayList<>();
        while(rs.next()){
            AuthorRangeAge statistic = new AuthorRangeAge();
            statistic.setRange(rs.getString("rangeAge"));
            statistic.setCount(rs.getInt("count"));
            statistics.add(statistic);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return statistics;
    }
    
    public static ArrayList<AuthorRangeAge> getAuthorsByAgeCollege(int idCollege)throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_authors_byage_college(?)}");
        sql.setInt(1, idCollege);
        
        ResultSet rs = sql.executeQuery();
        ArrayList<AuthorRangeAge> statistics = new ArrayList<>();
        while(rs.next()){
            AuthorRangeAge statistic = new AuthorRangeAge();
            statistic.setRange(rs.getString("rangeAge"));
            statistic.setCount(rs.getInt("count"));
            statistics.add(statistic);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return statistics;
    }
    
    public static ArrayList<AuthorRangeAge> getAuthorsByAgeType(int idType)throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call get_authors_byage_type(?)}");
        sql.setInt(1, idType);
        
        ResultSet rs = sql.executeQuery();
        ArrayList<AuthorRangeAge> statistics = new ArrayList<>();
        while(rs.next()){
            AuthorRangeAge statistic = new AuthorRangeAge();
            statistic.setRange(rs.getString("rangeAge"));
            statistic.setCount(rs.getInt("count"));
            statistics.add(statistic);
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return statistics;
    }
    
    public static ArrayList<Top10Products> getTopPurchasedProducts() throws SQLException{
        Connection conn = ConnectDB.getConnection();
        CallableStatement sql = conn.prepareCall("{call top_purchased_products()}");
        
        ResultSet rs = sql.executeQuery();
        ArrayList<Top10Products> top10 = new ArrayList<>();
        while(rs.next()){
            Top10Products product = new Top10Products();
            product.setDescription(rs.getString("description_product"));
            product.setCost(rs.getInt("cost_product"));
            product.setTotalCount(rs.getInt("total_count"));
            top10.add(product);
            
        }
        ConnectDB.closeConnectionCursors(sql, conn, rs);
        return top10;
    }
}
